/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Downloads;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;
import android.drm.mobile1.DrmRawContent;
import java.io.FileInputStream;

import java.util.HashMap;
import java.io.File;
import java.util.List;

import com.android.browser.midlet.MidletDownloadManager;

//remove before ship
import android.util.Log;

/**
 *  View showing the user's current browser downloads
 */
public class BrowserDownloadPage extends Activity 
        implements View.OnCreateContextMenuListener, OnItemClickListener {
    final static String TAG = "BrowserDownloadPage"; 
    private ListView                mListView;
    private Cursor                  mDownloadCursor;
    private BrowserDownloadAdapter  mDownloadAdapter;
    private int                     mStatusColumnId;
    private int                     mIdColumnId;
    private int                     mTitleColumnId;
    private int                     mContextMenuPosition;

    // Some files type we need to handle when download is completed.
    public static final String MIDLET_JAD_TYPE = "text/vnd.sun.j2me.app-descriptor";
    public static final String MIDLET_JAR_TYPE = "application/java-archive";
    public static final String OMA_DD_TYPE = "application/vnd.oma.dd+xml";
    public static final String ANDROID_APK_TYPE = "application/vnd.android.package-archive";
    public static final String OMS_UPK_TYPE = "application/vnd.oms.package-archive";
    public static final String SDP_TYPE = "application/sdp";
    public static final String CMDMH_TYPE = "application/x-cmdmh";

    @Override 
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        Intent intent = getIntent();

        // OMS: Request for orientation sensor
        //super.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);

        setContentView(R.layout.browser_downloads_page);
        
        setTitle(getText(R.string.download_title));

        mListView = (ListView) findViewById(R.id.list);
        LayoutInflater factory = LayoutInflater.from(this);
        View v = factory.inflate(R.layout.no_downloads, null);
        addContentView(v, new LayoutParams(LayoutParams.FILL_PARENT,
                LayoutParams.FILL_PARENT));
        mListView.setEmptyView(v);
        
        mDownloadCursor = managedQuery(Downloads.CONTENT_URI, 
                new String [] {"_id", Downloads.COLUMN_TITLE, Downloads.COLUMN_STATUS,
                Downloads.COLUMN_TOTAL_BYTES, Downloads.COLUMN_CURRENT_BYTES, 
                Downloads._DATA, Downloads.COLUMN_DESCRIPTION, 
                Downloads.COLUMN_MIME_TYPE, Downloads.COLUMN_LAST_MODIFICATION,
                Downloads.COLUMN_VISIBILITY, Downloads.COLUMN_NOTIFICATION_EXTRAS }, 
                null, null);
        
        // only attach everything to the listbox if we can access
        // the download database. Otherwise, just show it empty
        if (mDownloadCursor != null) {
            mStatusColumnId = 
                    mDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_STATUS);
            mIdColumnId =
                    mDownloadCursor.getColumnIndexOrThrow(Downloads._ID);
            mTitleColumnId = 
                    mDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_TITLE);
            
            // Create a list "controller" for the data
            mDownloadAdapter = new BrowserDownloadAdapter(this, 
                    R.layout.browser_download_item, mDownloadCursor);
            
            mListView.setAdapter(mDownloadAdapter);
            mListView.setScrollBarStyle(View.SCROLLBARS_INSIDE_INSET);
            mListView.setOnCreateContextMenuListener(this);
            mListView.setOnItemClickListener(this);
            
            if (intent != null && intent.getData() != null) {
                int position = -1;
                try{
                    position = checkStatus(ContentUris.parseId(intent.getData()));
                }catch(Exception e){
                    e.printStackTrace();
                }
                if (position >= 0) {
                    mListView.setSelection(position);
                }
            }
        }

        final String cid = intent.getStringExtra("drm_cid");
        if (cid != null && OmaDownloadManager.mDrmCidMap != null && OmaDownloadManager.mDrmCidMap.get(cid) != null) {
            final String file = OmaDownloadManager.mDrmCidMap.get(cid)[0]; 
            final String name = (new File(file)).getName();
            final String msg = getString(R.string.would_you_play, name);
            final String title = getString(R.string.rights_received);
            final Uri contentUri = Uri.fromFile(new File(file));

            // Ask the media scanner to scan this uri.
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, contentUri));

            new AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(msg)
                    .setPositiveButton(R.string.ok, 
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    String mime = OmaDownloadManager.mDrmCidMap.get(cid)[1];  

                                    Log.d("Browser", "file="+file+", mime="+mime+", contentUri="+contentUri);
                                    Intent i = new Intent(Intent.ACTION_VIEW);
                                    i.setDataAndType(contentUri, mime);
                                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    Log.d("Browser", "file="+file+", mime="+mime);
                                    try {
                                        startActivity(i); 
                                    } catch (ActivityNotFoundException e) {
                                                    /*new AlertDialog.Builder(this)
									.setTitle(R.string.download_failed_generic_dlg_title)
									.setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
									.setMessage(R.string.download_no_application)
									.setPositiveButton(R.string.ok, null)
									.show();*/
                                          Log.e("BrowserDownloadPage", "can not find app to play, e=" + e); 
                                    }

                                    finish();
                                }
                           })
                    .setNegativeButton(R.string.cancel, 
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    finish();
                                }
                           })
                    .show();
 
            //return;
        }



    }

    @Override
    public void onResume() {
        super.onResume();

        // OMS: This is for midlet download; we set the selection when downloading 
        // JAR files manually to show complete download item.

        if(mDownloadAdapter == null) return;

        int count = mDownloadAdapter.getCount();
        mListView.setSelection(count - 1);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (mDownloadCursor != null) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.downloadhistory, menu);
        }
        return true;
    }
    
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        // OMS: Show no options items if there's no download history.
        if(mListView.getCount() <= 0) {
            menu.findItem(R.id.download_menu_cancel_all).setVisible(false);
            menu.findItem(R.id.download_menu_clear_all).setVisible(false);
            return super.onPrepareOptionsMenu(menu);
        }

        boolean showCancel = getCancelableCount() > 0;
        menu.findItem(R.id.download_menu_cancel_all).setEnabled(showCancel);
        
        boolean showClear = getClearableCount() > 0;
        menu.findItem(R.id.download_menu_clear_all).setEnabled(showClear);
        return super.onPrepareOptionsMenu(menu);
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.download_menu_cancel_all:
                promptCancelAll();
                return true;
                
            case R.id.download_menu_clear_all:
                promptClearList();
                return true;
        }
        return false;
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        mDownloadCursor.moveToPosition(mContextMenuPosition);
        switch (item.getItemId()) {
            case R.id.download_menu_open:
                hideCompletedDownload();
                openCurrentDownload();
                return true;

            case R.id.download_menu_clear:
            case R.id.download_menu_cancel:
                // OMS: See if it's a unfinished midlet download...
                int status = mDownloadCursor.getInt(mStatusColumnId);
                String mimeType = mDownloadCursor.getString(mDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_MIME_TYPE));
                if (!Downloads.isStatusCompleted(status) && isMidlet(mimeType)) {
                    //Do not delete the DB record here as midlet will delete it by self
                    cancelMidletDownload();
                    return true;
                } 

                // OMS: the download task may have been finished at this moment.
                if (item.getItemId() == R.id.download_menu_cancel && 
                        Downloads.isStatusCompleted(status)) {
                    return true;
                }

                getContentResolver().delete(
                        ContentUris.withAppendedId(Downloads.CONTENT_URI,
                        mDownloadCursor.getLong(mIdColumnId)), null, null);
                return true;

             case R.id.download_menu_pause:
                 final int filenameColumnId = mDownloadCursor.getColumnIndexOrThrow(Downloads._DATA);
                 String filename = mDownloadCursor.getString(filenameColumnId);

                 pauseDownload(mDownloadCursor.getLong(mIdColumnId), filename);
                 return true;

            case R.id.download_menu_retry:
                retryDownload(mDownloadCursor.getLong(mIdColumnId));
                return true;

             case R.id.download_menu_resume:
                 if (false /* merge-todo ! Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)*/ ) {
                     Log.e(TAG, "can not find mounted media");
                     new AlertDialog.Builder(this)
                        .setTitle(R.string.download_failed_generic_dlg_title)
                        .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                        .setMessage(BrowserDownloadAdapter.getErrorText(Downloads.STATUS_FILE_ERROR))
                        .setPositiveButton(R.string.ok, null)
                        .show();
                     return false;
                 } else {
                     Log.d(TAG, "media SD available");
                     resumeDownload(mDownloadCursor.getLong(mIdColumnId));
                 }
                 return true;
        }
        return false;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
            ContextMenuInfo menuInfo) {
        if (mDownloadCursor != null) {
            AdapterView.AdapterContextMenuInfo info = 
                    (AdapterView.AdapterContextMenuInfo) menuInfo;
            mDownloadCursor.moveToPosition(info.position);
            mContextMenuPosition = info.position;
            // We don't need this for now.
            //menu.setHeaderTitle(mDownloadCursor.getString(mTitleColumnId));
            
            MenuInflater inflater = getMenuInflater();
            int status = mDownloadCursor.getInt(mStatusColumnId);
            if (Downloads.isStatusSuspended(status)) {
                inflater.inflate(R.menu.downloadhistorycontextpaused, menu);
            } else if (Downloads.isStatusSuccess(status)) {
                inflater.inflate(R.menu.downloadhistorycontextfinished, menu);
            } else if (Downloads.isStatusError(status)) {
                inflater.inflate(R.menu.downloadhistorycontextfailed, menu);
                Log.d("resume-after", "status code= "+status);
                if (status >= 400 && status < 490) {
                    Log.d("resume-after", "Can not resume download as server not support");
                    menu.findItem(R.id.download_menu_retry).setVisible(false);
                }
            } else {
                inflater.inflate(R.menu.downloadhistorycontextrunning, menu);

                // OMS: if current download item is midlet, we hide pause menu,
                // user only could cancel the downloading. 
                String mimeType = mDownloadCursor.getString(mDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_MIME_TYPE));
                if (!Downloads.isStatusCompleted(status) && isMidlet(mimeType)) {
                    menu.findItem(R.id.download_menu_pause).setVisible(false);
                }
            }
        }
    }

    /**
     * This function is called to check the status of the download and if it
     * has an error show an error dialog.
     * @param id Row id of the download to check
     * @return position of item
     */
    int checkStatus(final long id) {
        int position = -1;
        for (mDownloadCursor.moveToFirst(); !mDownloadCursor.isAfterLast(); 
                mDownloadCursor.moveToNext()) {
            if (id == mDownloadCursor.getLong(mIdColumnId)) {
                position = mDownloadCursor.getPosition();
                break;
            }
            
        }
        if (!mDownloadCursor.isAfterLast()) {
            int status = mDownloadCursor.getInt(mStatusColumnId);
            if (!Downloads.isStatusError(status)) {
                return position;
            }
            
            if (status == Downloads.STATUS_FILE_ERROR) {
                String title = mDownloadCursor.getString(mTitleColumnId);
                if (title == null || title.length() == 0) {
                    title = getString(R.string.download_unknown_filename);
                }
                String msg = getString(R.string.download_file_error_dlg_msg, 
                        title);
                new AlertDialog.Builder(this)
                        .setTitle(R.string.download_file_error_dlg_title)
                        .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                        .setMessage(msg)
                        .setPositiveButton(R.string.ok, null)
                        .setNegativeButton(R.string.retry, 
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, 
                                            int whichButton) {
                                        retryDownload(id);
                                    }
                                })
                        .show();
            } else {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.download_failed_generic_dlg_title)
                        .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                        .setMessage(BrowserDownloadAdapter.getErrorText(status))
                        .setPositiveButton(R.string.ok, null)
                        .show();
            }
        }
        return position;
    }
    
    /**
     * Resume a given download
     * @param id Row id of the download to resume
     */
    private void resumeDownload(final long id) {
        Uri record = ContentUris.withAppendedId(Downloads.CONTENT_URI, id);
        ContentValues values = new ContentValues();
        values.put(Downloads.COLUMN_CONTROL, Downloads.CONTROL_RUN);

        final int filenameColumnId = 
            mDownloadCursor.getColumnIndexOrThrow(Downloads._DATA);
        String filename = mDownloadCursor.getString(filenameColumnId);
        if (filename != null) {
            values.put(Downloads._DATA, filename);
        }
        getContentResolver().update(record, values, null, null);
    }

    private void retryDownload(final long id) {
        Uri record = ContentUris.withAppendedId(Downloads.CONTENT_URI, id);
        ContentValues values = new ContentValues();
        values.put(Downloads.COLUMN_CONTROL, Downloads.CONTROL_RUN);

        final int filenameColumnId = 
            mDownloadCursor.getColumnIndexOrThrow(Downloads._DATA);
        String filename = mDownloadCursor.getString(filenameColumnId);
        if (filename != null) {
            values.put(Downloads._DATA, filename);
        }
        values.put(Downloads.COLUMN_STATUS, Downloads.STATUS_RETRY);
        getContentResolver().update(record, values, null, null);
    }


    /**
     * Resume all the paused downloads
     */
    public void resumeAllDownloads() {
        if (!mDownloadCursor.requery()) {
            Log.w(TAG, "resumeAllDownloads requery failed.");
            return;
        }

        for (mDownloadCursor.moveToFirst(); !mDownloadCursor.isAfterLast(); mDownloadCursor.moveToNext()) {
            int status = mDownloadCursor.getInt(mStatusColumnId);
            if (Downloads.STATUS_PAUSED_BY_USER == status || Downloads.STATUS_RUNNING_PAUSED == status) {
                long id = mDownloadCursor.getLong(mIdColumnId);
                resumeDownload(id);
            }
        }
    }

    /**
     * Pause all the running downloads
     */
    public void pauseAllDownloads() {
        if (! mDownloadCursor.requery()) {
            Log.w(TAG, "pauseAllDownloads requery failed.");
            return;
        }

        for (mDownloadCursor.moveToFirst(); !mDownloadCursor.isAfterLast(); mDownloadCursor.moveToNext()) {
            int status = mDownloadCursor.getInt(mStatusColumnId);
            if (Downloads.STATUS_RUNNING == status) {
                long id = mDownloadCursor.getLong(mIdColumnId);
                final int filenameColumnId = mDownloadCursor.getColumnIndexOrThrow(Downloads._DATA);
                String filename = mDownloadCursor.getString(filenameColumnId);
                pauseDownload(id, filename);
            }
        }
    }
  
    /**
     * Borqs: Resume a given download with the filename as param
     * @param filename The file's name that in SD card of this download
     */
/*    private void resumeDownload(final long id, String filename) {
        Uri record = ContentUris.withAppendedId(Downloads.CONTENT_URI, id);
        ContentValues values = new ContentValues();
        values.put(Downloads.COLUMN_CONTROL, Downloads.CONTROL_RUN);
        
        if (filename != null)
             values.put(Downloads._DATA, filename);
        getContentResolver().update(record, values, null, null);
    }
*/

    /**
     * Pause a given download
     * @param id Row id of the download to pause
     */
    private void pauseDownload(final long id, String filename) {
        final String[] project = { Downloads.COLUMN_TOTAL_BYTES, 
                Downloads.COLUMN_CURRENT_BYTES, Downloads.COLUMN_STATUS };

        Uri record = ContentUris.withAppendedId(Downloads.CONTENT_URI, id);

        // OMS: Do nothing if the download has completed at the moment.
        Cursor c = null;
        try {
            c = getContentResolver().query(record, project, null, null, null);
            if(c == null) return;
            if(c.moveToFirst()) {
                if(c.getInt(2) == 200) {
                    c.close();
                    return;
                }
            }
        }catch(Exception ee) {
            Log.w(TAG, "pause download", ee);
        }

        ContentValues values = new ContentValues();
        values.put(Downloads.COLUMN_CONTROL, Downloads.CONTROL_PAUSE_BY_USER);
        values.put(Downloads._DATA, filename);
        getContentResolver().update(record, values, null, null);

        // OMS: query again to see if the download is done during 
        // the moment we click PAUSE. Reset it to COMPLETE in case.
        try {
            c.requery();
            if(c.moveToFirst()) {
                int downloaded = c.getInt(1);
                if(downloaded > 0 && downloaded == c.getInt(0)) {
                    Log.d(TAG, "Reset status from pause to complete.");
                    ContentValues v = new ContentValues();
                    v.put(Downloads.COLUMN_CONTROL, Downloads.CONTROL_STOP);
                    v.put(Downloads.COLUMN_STATUS, 200);
                    getContentResolver().update(record, v, null, null);
                }
                c.close();
            }
        }catch(Exception ee) {
            Log.w(TAG, "pause download", ee);
        }
    }
     
    /**
     * Prompt the user if they would like to clear the download history
     */
    private void promptClearList() {
        new AlertDialog.Builder(this)
               .setTitle(R.string.download_clear_dlg_title)
               .setIcon(com.android.internal.R.drawable.cmcc_dialog_question2)
               .setMessage(R.string.download_clear_dlg_msg)
               .setPositiveButton(R.string.ok, 
                       new DialogInterface.OnClickListener() {
                           public void onClick(DialogInterface dialog, 
                                   int whichButton) {
                               clearAllDownloads();
                           }
                       })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
    
    /**
     * Return the number of items in the list that can be canceled.
     * @return count
     */
    private int getCancelableCount() {
        // Count the number of items that will be canceled.
        int count = 0;
        if (mDownloadCursor != null) {
            for (mDownloadCursor.moveToFirst(); !mDownloadCursor.isAfterLast(); 
                    mDownloadCursor.moveToNext()) {
                int status = mDownloadCursor.getInt(mStatusColumnId);
                if (!Downloads.isStatusCompleted(status)) {
                    count++;
                }
            }
        }
        
        return count;
    }
    
    /**
     * Prompt the user if they would like to clear the download history
     */
    private void promptCancelAll() {
        int count = getCancelableCount();
        
        // If there is nothing to do, just return
        if (count == 0) {
            return;
        }
/*OMS 0089800:When count == 1 we also show a confirm dialog.
        // Don't show the dialog if there is only one download
        if (count == 1) {
            cancelAllDownloads();
            return;
        }
*/        
        String msg = 
            getString(R.string.download_cancel_dlg_msg);
        new AlertDialog.Builder(this)
                .setTitle(R.string.download_cancel_dlg_title)
                .setIcon(com.android.internal.R.drawable.cmcc_dialog_question2)
                .setMessage(msg)
                .setPositiveButton(R.string.ok, 
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, 
                                    int whichButton) {
                                cancelAllDownloads();
                            }
                        })
                 .setNegativeButton(R.string.cancel, null)
                 .show();
    }
    
    /**
     * Cancel all downloads. As canceled downloads are not
     * listed, we removed them from the db. Removing a download
     * record, cancels the download.
     */
    private void cancelAllDownloads() {
        if (mDownloadCursor.moveToFirst()) {
            StringBuilder where = new StringBuilder();
            boolean firstTime = true;
            while (!mDownloadCursor.isAfterLast()) {
                int status = mDownloadCursor.getInt(mStatusColumnId);
                String mimeType = mDownloadCursor.getString(mDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_MIME_TYPE));
                if (!Downloads.isStatusCompleted(status)) {
                    //OMS: Do not delete the DB record here as midlet will delete it by self
                    if (isMidlet(mimeType)) {
                        cancelMidletDownload();
                    } else {
                    if (firstTime) {
                        firstTime = false;
                    } else {
                        where.append(" OR ");
                    }
                    where.append("( ");
                    where.append(Downloads._ID);
                    where.append(" = '");
                    where.append(mDownloadCursor.getLong(mIdColumnId));
                    where.append("' )");
                    }
                }
                mDownloadCursor.moveToNext();
            }
            if (!firstTime) {
                getContentResolver().delete(Downloads.CONTENT_URI,
                        where.toString(), null);
            }
        }
    }
    
    private int getClearableCount() {
        int count = 0;
        if (mDownloadCursor.moveToFirst()) {
            while (!mDownloadCursor.isAfterLast()) {
                int status = mDownloadCursor.getInt(mStatusColumnId);
                if (Downloads.isStatusCompleted(status)) {
                    count++;
                }
                mDownloadCursor.moveToNext();
            }
        }
        return count;
    }
    
    /**
     * Clear all stopped downloads, ie canceled (though should not be
     * there), error and success download items.
     */
    private void clearAllDownloads() {
        if (mDownloadCursor.moveToFirst()) {
            StringBuilder where = new StringBuilder();
            boolean firstTime = true;
            while (!mDownloadCursor.isAfterLast()) {
                int status = mDownloadCursor.getInt(mStatusColumnId);
                if (Downloads.isStatusCompleted(status)) {
                    if (firstTime) {
                        firstTime = false;
                    } else {
                        where.append(" OR ");
                    }
                    where.append("( ");
                    where.append(Downloads._ID);
                    where.append(" = '");
                    where.append(mDownloadCursor.getLong(mIdColumnId));
                    where.append("' )");
                }
                mDownloadCursor.moveToNext();
            }
            if (!firstTime) {
                getContentResolver().delete(Downloads.CONTENT_URI,
                        where.toString(), null);
            }
        }
    }
    
    /**
     * Open the content where the download db cursor currently is
     */
    private void openCurrentDownload() {
        int filenameColumnId = 
                mDownloadCursor.getColumnIndexOrThrow(Downloads._DATA);
        String filename = mDownloadCursor.getString(filenameColumnId);
        int mimetypeColumnId =
                mDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_MIME_TYPE);
        String mimetype = mDownloadCursor.getString(mimetypeColumnId);
        Uri path = Uri.parse(filename);
        // If there is no scheme, then it must be a file
        if (path.getScheme() == null) {
            path = Uri.fromFile(new File(filename));
            // OMS: Check for file existance before going ahead
            if(!new File(filename).exists()) {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.download_open_failed)
                        .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                        .setMessage(R.string.download_local_file_not_exists)
                         .setPositiveButton(R.string.cancel, null)
                         .show();
                return;
            }
        }

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(path, mimetype);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        // OMS: Most apps do not want network information. Just for streaming player.
        if(NetworkManager.peekInstance() != null) {
            intent.putExtra("data_connection", 
                    NetworkManager.peekInstance().getNetworkProfile());
        }
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException ex) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.download_open_failed)
                    .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                    .setMessage(R.string.download_no_application)
                    .setPositiveButton(R.string.ok, null)
                    .show();
        }
    }

    /*
     * (non-Javadoc)
     * @see android.widget.AdapterView.OnItemClickListener#onItemClick(android.widget.AdapterView, android.view.View, int, long)
     */
    public void onItemClick(AdapterView parent, View view, int position, 
            long id) {
        // Open the selected item
        mDownloadCursor.moveToPosition(position);
        
        hideCompletedDownload();

        int status = mDownloadCursor.getInt(mStatusColumnId);
        if (Downloads.isStatusSuccess(status)) {
            // Open it if it downloaded successfully
            openCurrentDownload();
        } else {
            // Check to see if there is an error.
            checkStatus(id);
        }
    }
    
    /**
     * hides the notification for the download pointed by mDownloadCursor
     * if the download has completed.
     */
    private void hideCompletedDownload() {
        int status = mDownloadCursor.getInt(mStatusColumnId);

        int visibilityColumn = mDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_VISIBILITY);
        int visibility = mDownloadCursor.getInt(visibilityColumn);

        if (Downloads.isStatusCompleted(status) &&
                visibility == Downloads.VISIBILITY_VISIBLE_NOTIFY_COMPLETED) {
            ContentValues values = new ContentValues();
            values.put(Downloads.COLUMN_VISIBILITY, Downloads.VISIBILITY_VISIBLE);
            getContentResolver().update(
                    ContentUris.withAppendedId(Downloads.CONTENT_URI,
                    mDownloadCursor.getLong(mIdColumnId)), values, null, null);
        }
    }

    // OMS: Cancel midlet download will send status code 902 to server.
    private void cancelMidletDownload() {
        try {
            final int filenameColumnId = mDownloadCursor.getColumnIndexOrThrow(Downloads._DATA);
            String filename = mDownloadCursor.getString(filenameColumnId);
            if (filename != null) {
                File f = new File(filename);
                if (f.exists()) {
                    Log.d("midlet", "will delete file:"+filename);
                    f.delete();
                }
            }

            int id = mDownloadCursor.getInt(mIdColumnId);
            Uri uri = Uri.parse(Downloads.CONTENT_URI + "/" + id);
            Log.d("midlet", " ********* uri=" + uri);
            Intent newIntent = new Intent(this, MidletDownloadManager.class);
            newIntent.setData(uri);
            newIntent.putExtra("postIndicate", 902);
            startActivity(newIntent);
        }
        catch (Exception e) {
            Log.e("midlet", "cancelMidletDownload e="+e);
        }
    }

    static boolean isMidlet(String mimetype) {
        return mimetype != null 
            && ( mimetype.equalsIgnoreCase(MIDLET_JAD_TYPE) || mimetype.equalsIgnoreCase(MIDLET_JAR_TYPE) );
    }

    static boolean unfinishedMidlet(Context context) {
        final String[] projection = { Downloads.COLUMN_MIME_TYPE };
        final String where = "( " + Downloads.COLUMN_STATUS + " < '200' AND " + 
                                "(( " + Downloads.COLUMN_MIME_TYPE + " = '"
                                + MIDLET_JAD_TYPE + "' ) OR ( " 
                                + Downloads.COLUMN_MIME_TYPE + " = '" 
                                + MIDLET_JAR_TYPE + "' )))";

        Cursor c = context.getContentResolver().query(Downloads.CONTENT_URI, projection, where, null, null);
        boolean exist = (c != null) && (c.getCount() > 0);
        c.close();
        return exist;
    }

    static boolean unfinishedDownload(Context context) {
        // Those status < 200.
        final String[] projection = { Downloads.COLUMN_MIME_TYPE };
        final String where = "( " + Downloads.COLUMN_STATUS + " < '200' AND " + 
                Downloads.COLUMN_STATUS + " <> '" + Downloads.STATUS_PAUSED_BY_USER + "')";

        Cursor c = context.getContentResolver().query(Downloads.CONTENT_URI, projection, where, null, null);
        if(c == null) {
            return false;
        }
        boolean exist = c.getCount() > 0;
        c.close();
        return exist;
    }

/*
    static void viewDrmFileByCid(final Context context, final String cid) {
            new AlertDialog.Builder(context)
                    .setTitle("TODO: this is title")
                    .setMessage("TODO: this is msg")
                    .setPositiveButton(R.string.ok, 
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    String file = mDrmCidMap.get(cid)[0]; 
                                    String mime = mDrmCidMap.get(cid)[1];  
                                    Uri contentUri = Uri.parse(file);
                                    Intent i = new Intent();
                                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    i.setAction(Intent.ACTION_VIEW);
                                    i.setDataAndType(contentUri, mime);
                                    Log.d("Browser", "file="+file+", mime="+mime);
                                    context.startActivity(i); 
                                }
                           })
                    .setNegativeButton(R.string.cancel, null)
                    .show();

    }
*/
    /**
     * Broadcast receiver notified when the download service has finished 
     * the work. We can add handlers for specific downloads here , such as 
     * Midlet download, OMA download, etc. Or open the file immediately 
     * after download, with user interaction.
     */
    public  static class DownloadReceiver extends BroadcastReceiver {
        private Context mContext;
        private Uri mContentUri;
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.w(TAG, "DownloadReceiver onReceive, intent="+intent);
            //if the download have not finished, we will go to downloadpage
            if(intent.getAction().equals(Downloads.ACTION_NOTIFICATION_CLICKED)) {
                String className = intent.getComponent().getPackageName();
                if(!className.equalsIgnoreCase(context.getPackageName()))
                    return;
                Intent i = new Intent(context, BrowserDownloadPage.class);
                i.setData(intent.getData());
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
                return;
            }

            if (!intent.getAction().equals(Downloads.ACTION_DOWNLOAD_COMPLETED)) {
                return;
            }
            mContentUri = intent.getData();

            final String[] projection = { Downloads.COLUMN_STATUS, Downloads.COLUMN_URI, 
                    Downloads._DATA, Downloads.COLUMN_FILE_NAME_HINT, 
                    Downloads.COLUMN_MIME_TYPE, Downloads._ID, 
                    Downloads.COLUMN_TITLE, Downloads.COLUMN_NOTIFICATION_EXTRAS };
            Cursor c = context.getContentResolver().query(mContentUri, projection, null, null, null);
            if(c == null) {
                Log.w(TAG, "No download entry found!");
                return;
            }

            mContext = context;
            if (c.moveToFirst()) {
                int status = c.getInt(c.getColumnIndexOrThrow(Downloads.COLUMN_STATUS));
                Log.d("DownloadPage", "status = "+status);
                if (status == Downloads.STATUS_SUCCESS) {
                    handleDownload(c, true);
                }else {
                    handleDownloadError(c);
                    return;
                }
                c.close();
                return;
            } else {
                Log.w(TAG, "No download entry found in db!");
                return;
            }
        }

        private void handleDownload(Cursor cursor, boolean completed) {
            String mimeType = cursor.getString(cursor.getColumnIndexOrThrow(Downloads.COLUMN_MIME_TYPE));
            //String name = cursor.getString(cursor.getColumnIndexOrThrow(Downloads.COLUMN_FILE_NAME_HINT));
            String fileName = cursor.getString(cursor.getColumnIndexOrThrow(Downloads._DATA));
            String url = cursor.getString(cursor.getColumnIndexOrThrow(Downloads.COLUMN_URI));
            // Hack: We have put JadUri here.
            String params = cursor.getString(cursor.getColumnIndexOrThrow(Downloads.COLUMN_NOTIFICATION_EXTRAS));

            Log.d("BrowserDownloadPage", "handleDownload, mime="+mimeType+", fileName="+fileName+", params="+params);
            if(mimeType == null || mimeType.length() == 0) {
                return;
            }

            if (isMidlet(mimeType)) {
                Log.d("Browser", "is midlet");
                // Give a chance to 3-rd perty JVM to handle the midlet when 
                // the native one is not installed.
                try {
                    Intent intent = new Intent("android.intent.action.BORQS_MIDLETBOX_OTA", Uri.parse(url));
                    intent.setType(mimeType);
                    ResolveInfo ri = mContext.getPackageManager().resolveActivity(intent, 0);
                    if(ri == null) {
                        intent.setAction(Intent.ACTION_VIEW);
                        intent.putExtra("path", fileName);
                        // Remove the record.
                        Long id = cursor.getLong(cursor.getColumnIndexOrThrow(Downloads._ID));
                                mContext.getContentResolver().delete(
                                    ContentUris.withAppendedId(Downloads.CONTENT_URI,
                                    id), null, null);
                        // Set data connection in case...
                        if(NetworkManager.peekInstance() != null) {
                            intent.putExtra("data_connection", 
                                    NetworkManager.peekInstance().getNetworkProfile());
                        }
                        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                        Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.setDataAndType(Uri.parse(url), mimeType);
                        mContext.startActivity(intent);
                        return;
                    }
                } catch (Exception ex) {
                    return;
                }

                Intent newIntent = new Intent(mContext, MidletDownloadManager.class);
                newIntent.setData(mContentUri);
                newIntent.putExtra("filepath", fileName);
                newIntent.putExtra("mimetype", mimeType);
                newIntent.putExtra("currenturl", url);
                newIntent.putExtra("params", params);
                newIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                Intent.FLAG_ACTIVITY_NEW_TASK);

                mContext.startActivity(newIntent);            
            }

            // Launch the downloaded file for some predefined ones.
            if(mimeType.equalsIgnoreCase(OMA_DD_TYPE)) {
                Intent newIntent = new Intent(mContext, OmaDownloadManager.class);
                newIntent.setDataAndType(Uri.parse("file://" + fileName), mimeType);
                newIntent.setAction(Intent.ACTION_VIEW);
                newIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                Intent.FLAG_ACTIVITY_NEW_TASK);
                newIntent.putExtra("contenturi", mContentUri);
                launch(newIntent);
            }else if(mimeType.equalsIgnoreCase(ANDROID_APK_TYPE) || 
                    mimeType.equalsIgnoreCase(OMS_UPK_TYPE) || 
                    mimeType.equalsIgnoreCase(SDP_TYPE) || 
                    mimeType.equalsIgnoreCase(CMDMH_TYPE) ) {
                if(!completed) {
                    return;
                }
                Intent newIntent = new Intent(Intent.ACTION_VIEW);
                final Uri uri = Uri.fromFile(new File(fileName));
                newIntent.setDataAndType(uri, mimeType);
                // Most apps do not want network information. 
                // Just in case.
                if(NetworkManager.peekInstance() != null) {
                    newIntent.putExtra("data_connection", 
                            NetworkManager.peekInstance().getNetworkProfile());
                }
                newIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                Intent.FLAG_ACTIVITY_NEW_TASK);
                launch(newIntent);
            }
        }

        private void launch(Intent intent) {
            try {
                Log.w(TAG, "handleDownload:111");
                mContext.startActivity(intent);
            }catch(Exception ee) {
                Log.w(TAG, "handleDownload: no app to handle: " + intent.getType());
            }
        }

        private void handleDownloadError(Cursor cursor) {
            //Borqs: use the handleDownload now to handle the download error, 
            //such as "PUT is moved to a place without signal"
            Log.w(TAG, "handleDownloadError enter.");
            handleDownload(cursor, false);
        }
    }




}
