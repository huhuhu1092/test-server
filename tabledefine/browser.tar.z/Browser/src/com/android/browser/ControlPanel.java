/*
 * A floating control panel for quick access to some operations.
 * b052
 */

package com.android.browser;

import android.content.Context;
import android.os.SystemProperties;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ZoomButton;
import android.widget.Toast;
import android.webkit.WebView;
import android.graphics.Rect;
import android.app.Activity;

//import com.android.internal.R;

import android.util.Log;

/**
 * The {@code FloatPanel} class displays a simple set of controls for quick
 * access to menu items and provides callbacks to register for events.
 */

public  class ControlPanel extends LinearLayout {

    private static final int CONTROL_PANEL_TIMEOUT = 1700;
    private Handler mMsgHandler;
    private Runnable mTimeoutRunnable;

    // Default layout params.
    public final FrameLayout.LayoutParams DEFAULT_PARAMS =
        new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.RIGHT);

    // protected BrowserActivity mBrowserActivity;

    // static private ControlPanel mInstance;
    static private int MAX_BUTTONS = 7;
    // static com.android.internal.R mGlobalRes;

    private final ZoomButton[] mButtons;
        
    public ControlPanel(Context context, Handler h) {
        this(context, null, h);
        // mInstance = this;
    }
/*
    public static synchronized ControlPanel getInstance(Context context) {
        return ControlPanel.getInstance(context, null);
    }

    public static synchronized ControlPanel getInstance(Context context, Handler h) {
        if(mInstance == null) {
            mInstance = new ControlPanel(context, h);
        }
        return mInstance;
    }

    // See if control panel has been cerated.
    public static synchronized ControlPanel peekInstance() {
        return mInstance;
    }

    // Call this to remove the singleton if needed.
    public static synchronized void finish() {
        mInstance = null;
    }
*/
    // TODO: We can create our private handler instead of the one passed in.
    protected ControlPanel(Context context, AttributeSet attrs, Handler h) {
        super(context, attrs);
        Log.d("Browser", "Control panel created.");
        mMsgHandler = h;
        this.setLayoutParams(DEFAULT_PARAMS);
        //mBrowserActivity = (BrowserActivity)context;
        mButtons = new ZoomButton[MAX_BUTTONS];

        LayoutInflater inflater = (LayoutInflater) context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.control_panel, this, // we are the parent
                true);

        //setVisibility(View.INVISIBLE);
        initButtons();
        /*
        mTimeoutRunnable = new Runnable() {
            public void run() {
                if(!ControlPanel.this.hasFocus()) {
                    ControlPanel.this.hide();
                }else {
                    resetTimeout();
                    //mMsgHandler.removeCallbacks(mTimeoutRunnable);
                    //mMsgHandler.postDelayed(mTimeoutRunnable, CONTROL_PANEL_TIMEOUT);
                }
            }
        };*/
    }


    private int mMotionX = 0;
    private int mMotionY = 0;

    public void showIfNeeded(MotionEvent event) {
        //if(mInstance == null) return;

        // Return here if there's any sub view on top now.
        if(((BrowserActivity)getContext()).hasSubViews()) {
            return;
        }

        int x = 0, y = 0;
        switch(event.getAction()) {
        case MotionEvent.ACTION_DOWN:
            mMotionX = (int)event.getX();
            mMotionY = (int)event.getY();
            break;
        case MotionEvent.ACTION_MOVE:
            x = (int)event.getX();
            y = (int)event.getY();

            //Log.e("move", "move: " + Math.abs(x - mMotionX) + "/" + Math.abs(y - mMotionY));
            if(Math.abs(x - mMotionX) > 5 || Math.abs(y - mMotionY) > 5) {
                //mInstance.show();
                //mInstance.resetTimeout();
                show();
                resetTimeout();
            }
            mMotionX = x;
            mMotionY = y;
            break;
        default:
            break;
        } 
        setControlPanelHeight();
    }

    Toast mPageInMaxToast;
    Toast mPageInMinToast;

    // Multitouch disabled: back/forward/add bookmark/zoom scroll/zoom in/zoom out
    // Multitouch enabled: back/forward/windows/add bookmark/zoom scroll
    private void initButtons() {
        ZoomButton button = null;
        int index = 0;

        button = (ZoomButton) findViewById(R.id.button0);
        button.setBackgroundResource(R.drawable.ic_toolbar_back);
        setButton(index++, button, new View.OnClickListener() {
            public void onClick(View v) {
                resetTimeout();
                // In some rare case it can be null...
                WebView view = ((BrowserActivity)getContext()).getTopWindow();
                if(view == null) return;

                if(view.canGoBack()) {
                    ((BrowserActivity)getContext()).getTopWindow().goBack();
                    //updateIconState();
                    // Enable FORWARD button.
                    mButtons[1].setEnabled(true);
                    // Reset zoom button any way. 
                    // TODO: Why we are not able to get the correct zoom status in onPageFinished()?
                    // Strangely the status is correct after called again later...
                    resetZoomState();
                }else {
                    mButtons[0].setEnabled(false);
                }
            }
        });

        button = (ZoomButton) findViewById(R.id.button1);
        button.setBackgroundResource(R.drawable.ic_toolbar_forward);
        setButton(index++, button, new View.OnClickListener() {
            public void onClick(View v) {
                resetTimeout();
                // In some rare case it can be null...
                WebView view = ((BrowserActivity)getContext()).getTopWindow();
                if(view == null) return;

                if(view.canGoForward()) {
                    ((BrowserActivity)getContext()).getTopWindow().goForward();
                    //updateIconState();
                    // Enable BACK button.
                    mButtons[0].setEnabled(true);
                    // TODO: Why we are not able to get the correct zoom status in onPageFinished()?
                    // Strangely the status is correct after called again later...
                    resetZoomState();
                }else {
                    mButtons[1].setEnabled(false);
                }
            }
        });

        button = (ZoomButton) findViewById(R.id.button2);
        button.setBackgroundResource(R.drawable.ic_toolbar_tabs);
        setButton(index++, button, new View.OnClickListener() {
            public void onClick(View v) {
                resetTimeout();
                // OMS: When open new tab, the focus is not cleared. 
                // This is a workaround to clear the focus. 
                // mButtons[2].setEnabled(false);
                ((BrowserActivity)getContext()).showTabPicker();
                // mButtons[2].setEnabled(true);
            }
        });

        button = (ZoomButton) findViewById(R.id.button3);
        button.setBackgroundResource(R.drawable.ic_toolbar_bookmark);
        setButton(index++, button, new View.OnClickListener() {
            public void onClick(View v) {
                resetTimeout();
                ((BrowserActivity)getContext()).addBookmark();
            }
        });

        boolean multiTouchEnable = SystemProperties.getBoolean("sys.multitouch.enable", false);
        //multiTouchEnable = true;// OMS: We have multi-touch now. Need to add this into SystemProperties.
        button = (ZoomButton) findViewById(R.id.button4);
        if(multiTouchEnable) {
            button.setVisibility(GONE);
        }else {
            button.setBackgroundResource(R.drawable.ic_toolbar_zoomin);
            setButton(index++, button, new View.OnClickListener() {
                public void onClick(View v) {
                    resetTimeout();
                    if(!((BrowserActivity)getContext()).getTopWindow().zoomIn()) {
                        if(mPageInMaxToast == null) {
                            mPageInMaxToast = Toast.makeText(getContext(), 
                                R.string.page_in_max_size, 
                                Toast.LENGTH_SHORT);
                        }
                        mPageInMaxToast.show();
                    }
                    //updateZoomState(mBrowserActivity.getTopWindow());
                    // OMS: work-around, sometimes, button cannot release focus
                    // when touch-up event sent out. 
                    // mButtons[4].setPressed(false);
                }
            });
        }

        button = (ZoomButton) findViewById(R.id.button5);
        if(multiTouchEnable) {
            button.setVisibility(GONE);
        }else {
            button.setBackgroundResource(R.drawable.ic_toolbar_zoomout);
            setButton(index++, button, new View.OnClickListener() {
                public void onClick(View v) {
                    resetTimeout();
                    if(!((BrowserActivity)getContext()).getTopWindow().zoomOut()) {
                        if(mPageInMinToast == null) {
                            mPageInMinToast = Toast.makeText(getContext(), 
                                R.string.page_in_min_size, 
                                Toast.LENGTH_SHORT);
                        }
                        mPageInMinToast.show();
                    }
                    // OMS: work-around, sometimes, button cannot release focus
                    // when touch-up event sent out. 
                    // mButtons[5].setPressed(false);
                    //updateZoomState(mBrowserActivity.getTopWindow());
                }
            });
        }

        // collaps buttom
        button = (ZoomButton) findViewById(R.id.button6);
        button.setBackgroundResource(R.drawable.ic_toolbar_collapse);
        setButton(index++, button, new View.OnClickListener() {
            public void onClick(View v) {
                resetTimeout();
                if(mExpanded) {
                    fold();
                }else {
                    unfold();
                }
            }
        });
    }

    public void fold() {
        if (mExpanded){
            mExpanded = false;
            mButtons[6].setBackgroundResource(R.drawable.ic_toolbar_expand);

            for(int i=0; i<=5; i++) {
                mButtons[i].setVisibility(GONE);
            }
            ViewGroup.LayoutParams lp = ControlPanel.this.getLayoutParams();
            lp.width = ViewGroup.LayoutParams.WRAP_CONTENT;
            ControlPanel.this.setLayoutParams(lp);
            setControlPanelHeight();
        }
    }

    public void unfold() {
        if (!mExpanded) {
            mExpanded = true;
            mButtons[6].setBackgroundResource(R.drawable.ic_toolbar_collapse);

            for(int i=0; i<=5; i++) {
                mButtons[i].setVisibility(VISIBLE);
            }
            ViewGroup.LayoutParams lp = ControlPanel.this.getLayoutParams();
            lp.width = ViewGroup.LayoutParams.FILL_PARENT;
            ControlPanel.this.setLayoutParams(lp);
            updateIconState();
            setControlPanelHeight();
        }
    }
    //If the control panel is visible and expanded, it's working
    public boolean isWorking(){
        return mExpanded && (getVisibility() == View.VISIBLE);
    }

    //If working, set height, or set 0;
    public void setControlPanelHeight(){
    	   if(!isWorking()){
            WebView.setControlPanelHeight(0);
            return;
    	   }
        WebView.setControlPanelHeight(getHeight());
    }

    private boolean mExpanded = true;

    public void setButton(int index, ZoomButton button, OnClickListener listener) {
        if(index >= MAX_BUTTONS) {
            return;
        }
        mButtons[index] = button;
        mButtons[index].setOnClickListener(listener);
    }
/*
    public void setButtonListener(int index, OnClickListener listener) {
        if(index >= MAX_BUTTONS) {
            return;
        }
        mButtons[index].setOnClickListener(listener);
    }
 */   
    /*
     * Sets how fast you get zoom events when the user holds down the
     * zoom in/out buttons.
     */
    public void setZoomSpeed(long speed) {
        //mZoomIn.setZoomSpeed(speed);
        //mZoomOut.setZoomSpeed(speed);
    }
    
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        
        /* Consume all touch events so they don't get dispatched to the view
         * beneath this view.
         */
        return true;
    }
    
    public void onPageStarted(WebView view) {
        //updateIconState();
        updateBackForwardState(view);
        resetZoomState();
    }

    public void onPageFinished(WebView view) {
        //updateIconState();
        updateBackForwardState(view);
    }

    public void onUpdateVisitedHistory(WebView view) {
        updateIconState();
    }

    public void show() {
        //Log.e("aaa", "show: " + getVisibility());
        if(getVisibility() == View.VISIBLE) {
            return;
        }

        updateIconState();

        setVisibility(View.VISIBLE);
        //fade(View.VISIBLE, 0.0f, 1.0f);
    }
    
    public void hide() {
        //Log.e("aaa", "hide: " + getVisibility());
        if(getVisibility() != View.VISIBLE) {
            return;
        }
        setVisibility(View.GONE);
        setControlPanelHeight();
        //fade(View.GONE, 1.0f, 0.0f);
    }

    // Turn this off is we don't want the icon updated continualy.
    private static boolean UPDATE_ICON = true;
    private void updateIconState() {
        if(!UPDATE_ICON) return;

        WebView view = ((BrowserActivity)getContext()).getTopWindow();
        if(view == null) return;

        // Disable some icons if they're not available
        updateBackForwardState(view);
        updateZoomState(view);
    }

    void updateBackForwardState(WebView webView) {
        mButtons[0].setEnabled(webView.canGoBack());
        mButtons[1].setEnabled(webView.canGoForward());
    }

    void updateZoomState(WebView webView) {
if(true) return;
        mButtons[4].setEnabled(webView.canZoomIn());
        mButtons[5].setEnabled(webView.canZoomOut());
    }

    // TODO: Basically we don't need this. But we are not able to get the 
    // correct zoom status in onPageFinished(). Strangely the status 
    // is correct after called again later...
    void resetZoomState() {
if(true) return;
        mButtons[4].setEnabled(true);
        mButtons[5].setEnabled(true);
    }

    private void fade(int visibility, float startAlpha, float endAlpha) {
        AlphaAnimation anim = new AlphaAnimation(startAlpha, endAlpha);
        anim.setDuration(500);
        startAnimation(anim);
        setVisibility(visibility);
    }
    
    public void setIsZoomInEnabled(int index, boolean isEnabled) {
        if(index >= MAX_BUTTONS) {
            return;
        }
        mButtons[index].setEnabled(isEnabled);
    }
    
    @Override
    public boolean hasFocus() {
        for(int i=0; i<MAX_BUTTONS; i++) {
            if(mButtons[i] != null && mButtons[i].hasFocus()) {
                return true;
            }
        }
        return false;
    }

    public void resetTimeout() {
if(true) return;
        mMsgHandler.removeCallbacks(mTimeoutRunnable);
        mMsgHandler.postDelayed(mTimeoutRunnable, CONTROL_PANEL_TIMEOUT);
    }
}
