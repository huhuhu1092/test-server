
package com.android.browser;

import android.content.Context;

import android.util.Log;
import junit.framework.Assert;

import android.os.SystemProperties;

class SearchPortal {

    // Index for search portals. Must match with what's defined by 
    // "@array/pref_search_portal_values".
    public static final int SEARCH_PORTAL_139 = 2;
    //public static final int SEARCH_PORTAL_GOOGLE = 2;
    //public static final int SEARCH_PORTAL_YAHOO = 2;
    public static final int SEARCH_PORTAL_BAIDU = 1;

    public static String mSearchString[] = null;

    static protected SearchPortal mInstance;
    private static final String LOG_TAG = "SearchPortal"; 

    private Context mContext;

    //private static final String mDefaultSearchString = "http://www.google.com/search?q=%s";
    private static final String mDefaultSearchString = "http://www.baidu.com/s?ie=utf-8&amp;wd=%s";

    // A singleton to access SearchPortal.
    static synchronized SearchPortal getInstance() {
        if(mInstance == null) {
            mInstance = new SearchPortal();
        }
        return mInstance;
    }

    /**
     * Returns the search string by current search portal.
     * @return Returns the search string by current search portal.
     */
    public String getSearchString() {
        // Must call initSearchString beforehand.
        Assert.assertNotNull(mSearchString);

        int portal = BrowserSettings.getInstance().getSearchPortal() - 1;
        if(mSearchString != null && mSearchString.length >= portal && 
                portal >= 0 && mSearchString[portal] != null) {
            //return mSearchString[portal];
            return mSearchString[portal].replace("%l", getLanguageString());
        }

        Log.w(LOG_TAG, "returning default search string.");
        // Just return null for now.
        // Maybe we should always return a default search portal. 
        //return mDefaultSearchString;
        return null;
    }

    // Helper method to compose the language string
    private String getLanguageString() {
        StringBuffer buffer = new StringBuffer();
        String temp = SystemProperties.get("ro.product.locale.language");
        if(temp != null) {
            buffer.append(temp);
        }
        temp = SystemProperties.get("ro.product.locale.region");
        if(temp != null) {
            buffer.append("-" + temp);
        }
        return buffer.toString();
    }

    public void initSearchString(Context cxt) {
        mContext = cxt;
        if(mSearchString != null) {
            return;
        }

        CharSequence[] searchStrings = mContext.getResources().
                getTextArray(R.array.pref_search_string_values);

        if(searchStrings.length <= 0) {
            return;
        }

        mSearchString = new String[searchStrings.length];
        for(int i = 0; i < searchStrings.length; i++) {
            if(searchStrings[i] != null) {
                mSearchString[i] = new String(searchStrings[i].toString());
            }
        }
    }

    protected SearchPortal() {
    }
}
