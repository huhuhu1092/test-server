
package com.android.browser;

import android.net.http.AndroidHttpClient;

import android.util.Log;

import org.apache.http.client.methods.AbortableHttpRequest;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpHost;
import org.apache.http.conn.params.ConnRoutePNames;

import java.io.IOException;
import java.io.UnsupportedEncodingException;


public class BrowserHelper { 

    private final static String LOGTAG = "browserhelper";

    public static void sendData(String uri, String method, 
            String data, String cookies, String userAgent) {
        SendData s = new SendData(uri, method, data, cookies, 
                userAgent, null, 0);
        Thread doSendData = new Thread(s);
        doSendData.start();
    }

    public static void sendData(String uri, String method, 
            String data, String cookies, String userAgent, 
            String proxy, int port) {
        Log.d("BrowserHelper", "midlet download ********uri="+uri+", data="+data+", cookies="+cookies+", userAgent="+userAgent+", proxy="+proxy+", port="+port);
        SendData s = new SendData(uri, method, data, cookies, 
                userAgent, proxy, port);
        Thread doSendData = new Thread(s);
        doSendData.start();
    }

    // Send something to a remote server. Only used in cases that 
    // the data we send is very "small" and we don't care about the 
    // result from server.
    private static class SendData implements Runnable {
        private HttpHost mHttpHost = null;
        private String mMethod = "GET";
        private String mUri;
        private String mEntityData;
        private String mCookies;
        private String mReferer;
        private String mUserAgent = "test";

        public SendData() {}
        public SendData(String uri, String method, String data, 
                String cookies, String userAgent) {
            mUri = uri;
            mMethod = method;
            mEntityData = data;
            mCookies = cookies;
            mUserAgent = userAgent;
        }
        public SendData(String uri, String method, String data, 
                String cookies, String userAgent, String proxy, int port) {
            mUri = uri;
            mMethod = method;
            mEntityData = data;
            mCookies = cookies;
            mUserAgent = userAgent;
            if(proxy != null && proxy.length() >= 2 && port > 0) {
                mHttpHost = new HttpHost(proxy, port);
            }
        }

        public void run() {
            AndroidHttpClient client = AndroidHttpClient.newInstance(mUserAgent);
            HttpUriRequest requestU;
            AbortableHttpRequest requestA = null;
            Log.e("BrowserHelper", "run: mMethod="+mMethod+", mEntityData="+mEntityData);

            try{ 
                if (mMethod.equals("POST")) {
                    HttpPost request = new HttpPost(mUri);
                    if (mEntityData != null) {
                        try {
                            request.setEntity(new StringEntity(mEntityData));
                        } catch (UnsupportedEncodingException ex) {
                            Log.d(LOGTAG, "unsupported encoding for POST entity : " + ex); 
                        }
                    }
                    requestU = request;
                    requestA = request;
                } else {
                    HttpGet request = new HttpGet(mUri);
                    requestU = request;
                    requestA = request;
                }

                if (mCookies != null) {
                    requestU.addHeader("Cookie", mCookies);
                }
                if (mReferer != null) {
                    requestU.addHeader("Referer", mReferer);
                }

                HttpResponse response = null;

                if(mHttpHost != null) {
                    client.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, mHttpHost);
                    Log.d(LOGTAG, "Set proxy: " + mHttpHost);
                }
                response = client.execute(requestU);
                if(client != null) {
                    client.close();
                    client = null;
                }

                Log.w(LOGTAG, "status code: " + (
                        response == null ? -1 : 
                            response.getStatusLine().getStatusCode()));
            } catch (IllegalArgumentException ex) {
                if(requestA != null) requestA.abort();
            } catch (IllegalStateException ex) {
                Log.w(LOGTAG, "IllegalStateException: ", ex);
                if(requestA != null)  requestA.abort();
            } catch (IOException ex) {
                if(requestA != null) requestA.abort();
            } catch (Exception ee) {
                Log.w(LOGTAG, "failed to send data: ", ee);
            }finally {
                if(client != null) {
                    client.close();
                    client = null;
                }
            }
        }
    }
}
