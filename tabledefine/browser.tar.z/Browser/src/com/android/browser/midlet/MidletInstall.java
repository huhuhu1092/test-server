/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser.midlet;

import android.content.ContentValues;
import android.content.Context;
import android.content.res.Resources;
import android.net.Uri;
import android.provider.Downloads;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;

import com.android.browser.OmaDownloadManager.OmaDownloadManagerBroadcastReceiver;

import com.android.browser.R;


public class MidletInstall extends LinearLayout {

    private TextView mText;
    private Resources mResources;
    public Button mActionButton;
    public Button mCancelButton;
    public String mJadFile;
    public static midletStruct mMidletStruct = null;

    // constructor method.
    public MidletInstall(Context context, View.OnClickListener action,
            View.OnClickListener cancel, String filename) {
        super(context);

        mJadFile = filename;
        File file = new File(mJadFile);
        
        mResources = context.getResources();

        LayoutInflater.from(context).inflate(R.layout.midlet_install_confirm, this);
        mMidletStruct = JadParser.getJadInfo(file,true);
        if(mMidletStruct == null) {
            Log.w("midlet", "Invalid descriptor");
        }

        //setContentView(R.layout.midlet_install_confirm);
        
        //setTitle(r.getString(R.string.detailsInfo));
        String text = setDisplayinfo(mMidletStruct, true);
        mText = (TextView)findViewById(R.id.confirm_content);

        //mText.setTextColor(Color.WHITE);    
        mText.setText(text);

        mActionButton = (Button) findViewById(R.id.confirm_ok);
        mActionButton.setOnClickListener(action);

        mCancelButton = (Button) findViewById(R.id.confirm_cancel);
        mCancelButton.setOnClickListener(cancel);
    }

    public String setDisplayinfo(midletStruct midletstrtct, boolean isJad) {
        if (midletstrtct == null) {
            // TODO: should we show the error information?
            return null;
        }
        String text = mResources.getString(R.string.midlet_name) + "\t";
        
        text += midletstrtct.name + "\n"
                + mResources.getString(R.string.midlet_vendor) + "\t"
                + midletstrtct.vendor + "\n"
                + mResources.getString(R.string.midlet_version) + "\t"
                + midletstrtct.version + "\n"
                + mResources.getString(R.string.midlet_desc) + "\t"
                + midletstrtct.description;

        if (isJad) {
            text += "\n" + mResources.getString(R.string.midlet_jarurl) + "\t"
                    + midletstrtct.jarurl 
                    + "\n" + mResources.getString(R.string.midlet_size) + "\t"
                    + midletstrtct.size;
        }

        for (int i = 0; i < midletstrtct.midletnum; i++) {
            text += "\n" + mResources.getString(R.string.midlet_prefix) + (i + 1)
                    + ":\t" + midletstrtct.medletsClass[i];
        }
        return text;
    }

    public String getJadFile() {
        return mJadFile;        
    }

    public void setJadFile(String filename) {
        mJadFile = filename;
        File file = new File(mJadFile);
        mMidletStruct = JadParser.getJadInfo(file,true);
        mText.setText(setDisplayinfo(mMidletStruct, true));
    }

    public String getNotifyUri() {
        return mMidletStruct == null ? null : mMidletStruct.InstallNotify;
    }

    // response the focus changed.
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.isDown()) {
            int keyCode = event.getKeyCode();
            switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                // back key means cacel
                mCancelButton.performClick();
                return true;
            default:
                return super.dispatchKeyEvent(event);
            }
        }
        return super.dispatchKeyEvent(event);
    }

}
