/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser.midlet;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Downloads;
import android.content.ContentUris;
import android.util.Log;
import android.util.Config;
import android.widget.Toast;
import android.view.KeyEvent;
import android.view.View;
import android.view.LayoutInflater;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.text.format.Formatter;

import java.io.File;
import java.util.HashMap;

import com.android.browser.OmaDownloadManager;
import com.android.browser.BrowserDownloadPage;
import com.android.browser.BrowserHelper;
import com.android.browser.R;

/**
 * 
 * 
 */
public class MidletDownloadManager extends Activity {
    static final String TAG = "midlet";

    public static final String MIDLET_JAD_TYPE = "text/vnd.sun.j2me.app-descriptor";
    public static final String MIDLET_JAR_TYPE = "application/java-archive";

    // status/error message codes
    static final int STATUS_SUCCESS = 900;
    static final int STATUS_INSUFFICIENT_MEMORY = 901;
    static final int STATUS_USER_CANCELLED = 902;
    static final int STATUS_LOSS_OF_SERVICE = 903;
    static final int STATUS_JAR_SIZE_MISMATCH = 904;
    static final int STATUS_ATTRIBUTE_MISMATCH = 905;
    static final int STATUS_INVALID_DECRIPTOR = 906;
    static final int STATUS_JAR_NOT_AVAILABLE = 907;
    static final int STATUS_DELETION_NOTIFICATION = 912;

    /*
     * Get the response string of status code 
     * */
    private static String[] MIDLET_STATUS_STRING = {
            "900 Success", 
            "901 Insufficient Memory",
            "902 User Cancelled",
            "903 Loss of Service", 
            "904 JAR size mismatch", 
            "905 Attribute mismatch", 
            "906 Invalid Descriptor", 
            "907 JAR is not available", 
            "908 Incompatible Confuguration or Profile", 
            "909 Application authentication failure", 
            "910 Application authorization failure", 
            "911 Push registeration failure", 
            "912 Deletion Notification"
        };

    // notification status, success by default, but can be changed to an error:
    private int mStatus = STATUS_SUCCESS;

    // the URI (usually URL) to which an installation report is to be sent:
    private String mInstallNotifyUri;

    // the current.
    private String mCurrFilePath;

    // the current object url 
    private String mCurrentUrl;

    // Only used when the downloaded is a JAR and has a corresponding JAD.
    private String mJadFilePath;

    // Some network params.
    private String mInterface;
    private String mUserAgent;
    private String mProxy;
    private int mPort;

    // True if the user has clicked on any button (continue/cancel).
    private boolean mUserConfirmed = false;

    // True if the temporary jad/jar files shoule be removed when exiting.
    private boolean mShouldRemoveTempFiles = false;

    private MidletInstall mMidletInstallDialog;
    private Uri mContentUri;

    private final static String[] mProjection = { 
            Downloads._ID, Downloads.COLUMN_URI,
            Downloads.COLUMN_TITLE, Downloads._DATA,
            Downloads.COLUMN_MIME_TYPE, Downloads.COLUMN_NOTIFICATION_EXTRAS,
            Downloads.COLUMN_STATUS, 
            Downloads.COLUMN_NETWORK_INTERFACE,
            Downloads.COLUMN_PROXY_HOST, Downloads.COLUMN_PROXY_PORT,
            Downloads.COLUMN_USER_AGENT };

    private final int COL_ID = 0;
    private final int COL_URI = 1;
    private final int COL_TITLE = 2;
    private final int COL_FILE_PATH = 3;
    private final int COL_MIME_TYPE = 4;
    private final int COL_EXTRA = 5;
    private final int COL_STATUS = 6;
    private final int COL_INTERFACE = 7;
    private final int COL_HOST = 8;
    private final int COL_PORT = 9;
    private final int COL_USER_AGENT = 10;

    private final static int INSTALL_MIDLET = 5;

    /**
     * Called when this activity is created
     *
     * @param icicle - The bundle of data with the saved activity state (if any)
     */
    @Override public void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        // OMS: Request for orientation sensor
        //super.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);

        // Set a temporary title at first.
        setTitle(R.string.download_midlet_title);

        final Intent intent = getIntent();

        mContentUri = intent.getData();
        if(mContentUri == null) {
            Log.w(TAG, "mContentUri is null, will finish");
            finish();
            return;
        }

        Cursor cursor = getContentResolver().query(
                mContentUri, mProjection, null, null, null);
        if(cursor == null || !cursor.moveToFirst()) {
            Log.w(TAG, "Empty cursor found");
            finish();
            return;
        }else {
            loadNetworkParams(cursor);
        }

        mJadFilePath = null;
        mInstallNotifyUri = null;
        final String mimetype = cursor.getString(COL_MIME_TYPE);
        final String filePath = cursor.getString(COL_FILE_PATH);

        //1. In case of download error: 
        // Post status code to server if this is JAR file, 
        // do nothing if this is JAD file.
        int status = cursor.getInt(COL_STATUS);
        String params = cursor.getString(COL_EXTRA);
        extractParams(params); 
        int postCode = intent.getIntExtra("postIndicate", -1);

        Log.d("OMS", "MidletDownloadManager onCreate, postCode="+postCode);

        switch (postCode) {
        case 902:
            removeTempFiles(); //Should we put this into the cancelOnUserRequest() ?
            cancelOnUserRequest(); 
            return;

        default:
            Log.w(TAG, "Why get such a code:" + postCode);
        }

        if(status != 200) {
            if(isJarType(mimetype)) {
                removeTempFiles();
                if(mInstallNotifyUri != null) {
                    sendNotificationOnFailure(907);
                    // OMS trick: set user confirm as true as that 
                    // we will not send 902 in onDestroy().
                    mUserConfirmed = true;
                }
            }
            Toast.makeText(this, R.string.download_midlet_failed, 
                Toast.LENGTH_LONG).show();

            if(cursor != null) {
                cursor.close();
            }
            finish();
            return;
        }

        //2. Download successfully:
        mCurrentUrl = cursor.getString(COL_URI);

        if(cursor != null) {
            cursor.close();
        }

        if(isJadType(mimetype)) {
            onJadDownloaded(filePath);
        }else if(isJarType(mimetype)) {
            onJarDownloaded(filePath);
        }else {
            finish();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try{
            // Remove the download entries and files in the database.
            if(mContentUri != null) {
                getContentResolver().delete(mContentUri, null, null);
            }
                        
            Log.d(TAG, "onDestroy, mCurrFilePath="+mCurrFilePath+", mJadFilePath="+mJadFilePath);

            // Remove the jad/jar files from local storage.
            if(mCurrFilePath != mJadFilePath) {
                // This is the JAR, if it's there.
                if(mCurrFilePath != null) {
                    File f = new File(mCurrFilePath);
                    if (f.exists()) {
                        f.delete();        
                    }
                }
                // This is the JAD, if it's there.
                if(mJadFilePath != null) {
                    File f = new File(mJadFilePath);
                    if (f.exists()) {
                        f.delete();        
                    }
                }
            } else {
                if(!mUserConfirmed) {
                    // User exits the activity directly.
                    mCurrFilePath = null;
                    removeTempFiles();
                    //sendNotificationOnFailure(902);
                }
            }
        }catch(Exception ee) { 
            Log.w(TAG, "onDestroy exception="+ee);
        }finally {
            if(!mUserConfirmed) {
                // User exits the activity directly, or the Activity is
                // put to lower stack.
                sendNotificationOnFailure(902);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        Log.d(TAG, "onActivityResult: " + requestCode + "/" + resultCode);
        switch (requestCode) {
            case INSTALL_MIDLET:
                if(intent == null) {
                    break;
                }
 
                // Borqs: Always set mUserConfirmed to true as install is finished
                mUserConfirmed = true;

                CharSequence notifyUri = intent.getCharSequenceExtra("serverUrl");
                if(notifyUri == null || notifyUri.length() == 0) {
                    break;
                }

                sendNotification(this, notifyUri.toString(), resultCode);

                //Borqs:ticket#17623, what else code should be checked here?
                if (resultCode >= 903 && resultCode <=911) {
                    Log.d(TAG, "Will delete temp files"); 
                    removeTempFiles(); 
                }

                // check the delete notify
                if(intent.getBooleanExtra("deleteFlag", false) ){
                    String  Name[] = intent.getStringArrayExtra("nameArr");
                    String  Vender[] = intent.getStringArrayExtra("venderArr");
                    String  deleteurl[] = intent.getStringArrayExtra("deleteNotifyArr");
                    int indexofArr = 0;
                    int size = deleteurl.length;
                    while(indexofArr < size && deleteurl[indexofArr] != null){
                        sendNotification(this, deleteurl[indexofArr], 912);
                        indexofArr ++;
                    }
                }else {
                    //Log.i(TAG, "No delete status codes");
                }

                break;

            default:
                break;             
            } 
            MidletDownloadManager.this.finish();
        }

    private void removeTempFiles() {
        try{
            Log.d(TAG, "removeTempFiles, mCurrFilePath="+mCurrFilePath+", mJadFilePath="+mJadFilePath);
            // Remove the jad/jar files from local storage.
            // This is the JAR, if it's there.
            if(mCurrFilePath != null) {
                File f = new File(mCurrFilePath);
                if (f.exists()) {
                    f.delete();        
                }
            }
            // This is the JAD, if it's there.
            if(mJadFilePath != null && !mJadFilePath.equalsIgnoreCase(mCurrFilePath)) {
                File f = new File(mJadFilePath);
                if (f.exists()) {
                    f.delete();        
                }
            }
        }catch(Exception ee) { 
            Log.w("MidletDownloadManager", "removeTempFiles exception="+ee);
        }
    }

    /**
     * Called before this activity is suspended
     *
     * @param outState - The bundle of data used to save the activity state (if any)
     */
    /*
    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //outState.putString(KEY_DESCRIPTOR_URI, mDescriptorUri);
    }*/

    /**
     * Cancels the download on user request.
     */
    private void cancelOnUserRequest() {
        sendNotificationOnFailure(mStatus = STATUS_USER_CANCELLED);
        finish();
    }

    // Pop up notification to ask if user wants to download the JAR.
    private void onJadDownloaded(String fileName) {
        mJadFilePath = fileName;
        mCurrFilePath = fileName;
        int statuscode = 900;
        File jadFile = new File(fileName);
        statuscode = JadParser.validateJad(jadFile, true);
        if (statuscode != 900) {
            // Remove the temp file if any.
            if (jadFile != null && jadFile.exists()) {
                Log.e(TAG, "onJadDownloaded error happened statuscode="+statuscode+", will remove:"+fileName);
                jadFile.delete();
            }

            sendNotification(this, JadParser.jadMidlet.InstallNotify, statuscode);

            // TODO: here you should return code to server
            // report to server;
            new AlertDialog.Builder(this)
            .setTitle(R.string.download_failed_generic_dlg_title)
            .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
            .setMessage(R.string.oma_status_invalid_descriptor)
            .setPositiveButton(R.string.ok, 
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        MidletDownloadManager.this.finish();
                    }})
            .setCancelable(false)
            .show();
            return;
        }

        if(mMidletInstallDialog == null) {
            mMidletInstallDialog = new MidletInstall(
                    this, mActionOnMidletResponse,
                    mCancelOnMidletResponse, fileName);
        }else {
            mMidletInstallDialog.setJadFile(fileName);
        }
        mInstallNotifyUri = mMidletInstallDialog.getNotifyUri();
        setContentView(mMidletInstallDialog);
        setTitle(R.string.detailsInfo);
    }

    private void onJarDownloaded(String file) {
        Toast.makeText(this, R.string.download_midlet_finished, 
                Toast.LENGTH_SHORT).show();
        mCurrFilePath = file;

        Intent sendintent = new Intent();
        if(mJadFilePath != null) {
            sendintent.setAction("android.intent.action.BORQS_MIDLETBOX_OTA");
            sendintent.setType("application/java-archive");
            sendintent.putExtra("fileType","jadAndjar");
            sendintent.putExtra("jadPath", mJadFilePath);
            sendintent.putExtra("jarPath", file);
            sendintent.putExtra("serverUrl", "");
        }
        else {
            // We don't have a JAD.
            sendintent.setAction("android.intent.action.BORQS_MIDLETBOX_OTA");
            sendintent.setType("application/java-archive");
            sendintent.putExtra("fileType","jar");
            sendintent.putExtra("jadPath", "");
            sendintent.putExtra("jarPath", file);
            sendintent.putExtra("serverUrl",mCurrentUrl);
        }
        try {
            startActivityForResult(sendintent, INSTALL_MIDLET);
        }catch (Exception ee) {
            Toast.makeText(this, R.string.install_failed, 
                Toast.LENGTH_LONG).show();
        }
    }

    /*
     * The file name is generate from JAR_URL in the JAD file, this way 
     * we can keep in sync with MIDletBox, who is also doing the same thing.
     */
    private void  downloadJarFile(String url, String fileName) {
        // When it comes to here, there must have been a JAD file downloaded earlier.
        String mimetype = "application/java-archive";
        //String fileName = guessFileName(url, null);
        Log.w(TAG, "downloadJarFile:" + fileName);

        ContentValues values = new ContentValues();
        values.put(Downloads.COLUMN_URI, url);
        values.put(Downloads.COLUMN_NOTIFICATION_PACKAGE, "com.android.browser");
        values.put(Downloads.COLUMN_NOTIFICATION_CLASS,
                com.android.browser.BrowserDownloadPage.DownloadReceiver.class.getName());
        values.put(Downloads.COLUMN_MIME_TYPE, mimetype);
        if(fileName != null) {
            values.put(Downloads.COLUMN_FILE_NAME_HINT, fileName);
        }
        // Hack: We hide JadUri here.
        mInstallNotifyUri = mMidletInstallDialog.getNotifyUri();
        String params = buildParams();
        if(params != null) {
            values.put(Downloads.COLUMN_NOTIFICATION_EXTRAS, params);
        }

        // Don't forget to copy the network params to download the JAR file.
        values.put(Downloads.COLUMN_NETWORK_INTERFACE, mInterface);
        values.put(Downloads.COLUMN_PROXY_HOST, mProxy);
        values.put(Downloads.COLUMN_PROXY_PORT, mPort);
        values.put(Downloads.COLUMN_USER_AGENT, mUserAgent);
//Remove after redesign.
values.put(Downloads.COLUMN_STOREPATH, "/tmp");

        final Uri contentUri =
            getContentResolver().insert(Downloads.CONTENT_URI, values);
    }

    private void loadNetworkParams(Cursor c) {
        mInterface = c.getString(COL_INTERFACE);
        mProxy = c.getString(COL_HOST);
        mPort = c.getInt(COL_PORT);
        mUserAgent = c.getString(COL_USER_AGENT);
    }

    /**
     * Sends an installation notification if installation was a failure.
     * Calls finish() to exit the activity
     *
     * @param statusCode The oma-download status code (here, an error)
     */
    void sendNotificationOnFailure(int statusCode) {
        if(mInstallNotifyUri == null) {
            return;
        }
        sendNotification(this, mInstallNotifyUri, statusCode);
        //finish(); Should not call finish here.
    }

    /* package */ void sendNotification(
            Context context, String notifyUri, int statusCode) {
        if (context == null || notifyUri == null || notifyUri.length() == 0) {
            return;
        }

        Log.d(TAG, "sendNotification, statusCode="+statusCode);
        String notification = MidletDownloadManager.statusMessage(statusCode) + "\n\r";
        BrowserHelper.sendData(notifyUri, "POST", notification, 
                CookieManager.getInstance().getCookie(notifyUri), mUserAgent, mProxy, mPort);
    }

    static String statusMessage(int statusCode) {
        final int size = MIDLET_STATUS_STRING.length;
        if(statusCode < 900 || statusCode - 900 > size - 1) {
            return "";
        }
        return MIDLET_STATUS_STRING[statusCode - 900];
    }

    public String getStatuseString(int statusecode){
        if(statusecode < 900 || statusecode > 912) {
            return "";
        }
        return MIDLET_STATUS_STRING[statusecode - 900];
    }

    /**
     * On-action HTTP-download response handler: instructs the browser to
     * connect, using user-supplied credentials.
     */
    private View.OnClickListener mActionOnMidletResponse = new View.OnClickListener() {
        public void onClick(View v) {
            String curjarurl = JadParser.getJarUrl(null,
                    false);

            // This is the JAR file name used to save the file.
            String fileName = guessFileName(curjarurl, null);;

            // deal with the jar url
            if(!curjarurl.startsWith("http://")){
                String jadurl = mCurrentUrl;
                int index = jadurl.lastIndexOf('/') + 1;
                if (index >= 0 && (index + 1) < jadurl.length())
                      curjarurl= jadurl.substring(0, index) + curjarurl;
            }
            mUserConfirmed = true;
            String jadFile = mMidletInstallDialog.getJadFile();

            downloadJarFile(curjarurl, fileName);
            try {
                // Just remove the JAD record here as we found sometimes it 
                // takes a long time to run into finish().
                if(mContentUri != null) {
                    getContentResolver().delete(mContentUri, null, null);
                    mContentUri = null;
                }
            }catch(Exception ee) {
            }
            MidletDownloadManager.this.finish();
        }
    };

    /**
     * On-cancel HTTP-authentication response handler: instructs the browser to
     * stop loading and to return to the previous state.
     */
    private View.OnClickListener mCancelOnMidletResponse = new View.OnClickListener() {
        public void onClick(View v) {
            String fileName = mMidletInstallDialog.getJadFile();
            try{
                File f = new File(fileName);
                 if (f.exists()) {
                        Log.w(TAG, "mCancelOnMidletResponse onClick, will remove:"+fileName);
                        f.delete();        
                 }
            }finally{            
            }
            mUserConfirmed = true;
            sendNotificationOnFailure(902);
            //mMidletInstallDialog.dismiss();
            MidletDownloadManager.this.finish();
        }
    };

    // Helper methods to put midlet params in the download info.
    // Format: jadFile|notifyUri
    private String buildParams() {
        if(mJadFilePath == null) return null;
        mInstallNotifyUri = mMidletInstallDialog.getNotifyUri();
        String params = new String(mJadFilePath);
        params += "|" + (mInstallNotifyUri == null ? "" : mInstallNotifyUri);
        return params;
    }

    private boolean extractParams(String params) {
        if(params == null) return false;
        
        int index = params.indexOf("|");
        int length = params.length();
        if(index > 0) {
            mJadFilePath = params.substring(0, index);
            if(index < length) {
                mInstallNotifyUri = params.substring(index + 1, length);
            }else {
                mInstallNotifyUri = null;
            }
            return true;
        }
        return false;
    }

    public static boolean isJadType(String type) {
        return MIDLET_JAD_TYPE.equalsIgnoreCase(type);
    }

    public static boolean isJarType(String type) {
        return MIDLET_JAR_TYPE.equalsIgnoreCase(type);
    }
    
    public static boolean isMidletType(String type) {
        return MIDLET_JAD_TYPE.equalsIgnoreCase(type) || 
                MIDLET_JAR_TYPE.equalsIgnoreCase(type);
    }

    /**
     * Guesses canonical filename that a download would have, using
     * the URL and contentDisposition. 
     * @param url Url to the content
     * 
     * @return suggested filename
     */
    public static final String guessFileName(
            String url,
            String contentDisposition) {
        String filename = null;

        // Use the plain uri
        if (filename == null) {
            String decodedUrl = Uri.decode(url);
            if (decodedUrl != null) {
                int queryIndex = decodedUrl.indexOf('?');
                // If there is a query string strip it, same as desktop browsers
                if (queryIndex > 0) {
                    decodedUrl = decodedUrl.substring(0, queryIndex);
                }
                if (!decodedUrl.endsWith("/")) {
                    int index = decodedUrl.lastIndexOf('/');
                    if (index >= 0) {
                        filename = decodedUrl.substring(index + 1);
                    }else {
                        filename = decodedUrl;
                    } 
                }
            }
        }

        // Finally, if couldn't get filename from URI, get a generic filename
        if (filename == null) {
            filename = "downloadfile";
        }

        return filename;
    }
}
