/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser.midlet;

 import java.io.DataInputStream;
 import java.io.File;
 import java.io.FileInputStream;
 import java.io.IOException;
 import java.io.UnsupportedEncodingException;
 import java.util.Properties;
 import java.util.Vector;
 import java.util.jar.Attributes;
 import java.util.jar.JarFile;
 import java.util.jar.Manifest;


import android.util.Log;

 public class JadParser {
     //define status code
     public final static int STATUS_RETURN_SUCCESS=900;
     public final static int STATUS_INSUFFICIENT_MEMORY=901;
     public final static int STATUS_USER_CANCELLED=902;
     public final static int STATUS_LOSS_SERVICE=903;
     public final static int STATUS_SIZE_MISMATCH=904;
     public final static int STATUS_ATTRIBUTE_MISMATCH=905;
     public final static int STATUS_INVALID_DESCRIPTOR=906;
     public final static int STATUS_INVALID_JAR=907;
     public final static int STATUS_INCOMPATIBLE_CONFIGURATION=908;
     public final static int STATUS_INCOMPATIBLE_PROFILE=908;
     public final static int STATUS_AUTHENTICATION_FAILURE=909;
     public final static int STATUS_AUTHORIZATION_FAILURE=910;
     public final static int STATUS_REGISTRATION_FAILURE=911;
     public final static int STATUS_DELETION_NOTIFICATION=912;
     
     //local error code
     public  static int DETAIL_ERROR_CODE=0; //use to save detail code 
     public  static int ERROR_INSTALLED=-1;
     public  static int ERROR_NO_NAME=-2;
     public  static int ERROR_NO_VENDER=-3;
     public  static int ERROR_NO_VERSION=-4;
     public  static int ERROR_BAD_VERSION=-5;
     public  static int ERROR_NO_URL=-6;
     public  static int ERROR_BAD_URL=-7;
     public  static int ERROR_NO_SIZE=-8;
     public  static int ERROR_BAD_SIZE=-9;
     public  static int ERROR_OUTMAX_SIZE=-10;
     public  static int ERROR_NO_MILET=-11;
     private  static int ERROR_NO_CONFIGURATION=-12;
     private  static int ERROR_NO_PROFILE=-13;
     
     //Property name
     private static final String MIDLET_NAME="MIDlet-Name";
     private static final String MIDLET_VENDOR="MIDlet-Vendor";
     private static final String MIDLET_VERSION="MIDlet-Version";
     private static final String MIDLET_JARSIZE="MIDlet-Jar-Size";
     private static final String MIDLET_CONFIGURATION="MicroEdition-Configuration";
     private static final String MIDLET_PROFILE="MicroEdition-Profile";
     private static final String MIDLET_JARURL="MIDlet-Jar-URL";
     private static final String MIDLET_DESCRIPTION="MIDlet-Description";
     private static final String MIDLET_PREFIX="MIDlet-";
     private static final String MIDLET_PUSH="MIDlet-Push-";
     private static final String MIDLET_PERMISSIONS="MIDlet-Permissions";
     private static final String MIDLET_PERMISSIONS_OPT="MIDlet-Permissions-Opt";
     private static final String MIDLET_SIGNATURE="MIDlet-Jar-RSA-SHA1";
     private static final String MIDLET_CERT_PROP="MIDlet-Certificate-";
     private static final String MIDLET_ICON_PROP="MIDlet-Icon";
     //add for trusted compare
     private static final String MIDLET_INFO_URL="MIDlet-Info-URL";
     private static final String MIDLET_DATA_SIZE="MIDlet-Data-Size";
     private static final String MIDLET_DELETE_CONFIRM="MIDlet-Delete-Confirm";
     private static final String MIDLET_INSTALL_NOTIFY="MIDlet-Install-Notify";
     private static final String MIDLET_DELETE_NOTIFY="MIDlet-Delete-Notify";
     
     
     //max size
     private static int JAR_MAX_SIZE=1024*1024*3;
    //righte url prefix
     //private static String[] URL_PREFIX=new String[]{"http://","https://"};
     private static String[] URL_PREFIX=new String[]{"http://","https://","/",""};
     
     private static String[] MIDP_PROFILE = new String[] {"MIDP-2.0", "MIDP-2.1", "MIDP-1.0"};
     private static String[] CLDC_CONFIG = new String[] {"CLDC-1.0", "CLDC-1.1"};

     public static midletStruct jadMidlet = new midletStruct();
     public static midletStruct jarMidlet = new midletStruct();
     private static String midp_home_value="/data/data/oms.midletbox/midp";
     private static String midp_home_name="MIDP_HOME";
     private static int content;
   
     /**
    * step 1: validateJad
    * @param jadFile
    * @param flag:true parse file ,false not parse
    * @return status code you can get detail error form var DETAIL_ERROR_CODE
      */
     public static int validateJad(File jadFile,boolean flag){
            DETAIL_ERROR_CODE=0;
            if(flag){
            if(jadFile==null||!jadFile.exists())return STATUS_INVALID_DESCRIPTOR;
            if(getJadInfo(jadFile,true)==null)return STATUS_INVALID_DESCRIPTOR;
                         }
         //name
          if (jadMidlet.name == null || "".equals(jadMidlet.name)) {
                    DETAIL_ERROR_CODE = ERROR_NO_NAME;
                    return STATUS_INVALID_DESCRIPTOR;
                       }
         // vendor
          if (jadMidlet.vendor == null || "".equals(jadMidlet.vendor)) {
                DETAIL_ERROR_CODE = ERROR_NO_VENDER;
                return STATUS_INVALID_DESCRIPTOR;
                      }
         // version
          if (jadMidlet.version == null || "".equals(jadMidlet.version)) {
                DETAIL_ERROR_CODE = ERROR_NO_VERSION;
                return STATUS_INVALID_DESCRIPTOR;
                      }
          else{
               if(!validateVersion(jadMidlet.version)){
                   DETAIL_ERROR_CODE = ERROR_BAD_VERSION;
                   return STATUS_INVALID_DESCRIPTOR;
                             }
                 }
          
          /*//profile
          if (jadMidlet.profile == null || "".equals(jadMidlet.profile)) {
              DETAIL_ERROR_CODE = ERROR_NO_PROFILE;
              return STATUS_INVALID_DESCRIPTOR;
                  }
          //configation
          if (jadMidlet.configuration == null || "".equals(jadMidlet.configuration)) {
              DETAIL_ERROR_CODE = ERROR_NO_CONFIGURATION;
              return STATUS_INVALID_DESCRIPTOR;
                  }*/
       
        ///
        //configation and profile jad not must in JAD 
        // profile 
        if (jadMidlet.profile !=null && !"".equals(jadMidlet.profile)) {
            DETAIL_ERROR_CODE = ERROR_NO_PROFILE;
            if(!validateProfile(jadMidlet.profile))
            return STATUS_INCOMPATIBLE_PROFILE;
        }
        // configation
        if (jadMidlet.configuration != null
                &&! "".equals(jadMidlet.configuration)) {
            DETAIL_ERROR_CODE = ERROR_NO_CONFIGURATION;
            if(!validateConfig(jadMidlet.configuration))
            return STATUS_INCOMPATIBLE_CONFIGURATION;
        }
        ///

         // jarurl
          if (jadMidlet.jarurl== null || "".equals(jadMidlet.jarurl)) {
                DETAIL_ERROR_CODE = ERROR_NO_URL;
                return STATUS_INVALID_DESCRIPTOR;
                   }
          
         /* else{
             if(!validateUrl(newMidlet.jarurl)){
               DETAIL_ERROR_CODE = ERROR_BAD_URL;
               return STATUS_INVALID_DESCRIPTOR;
                         }
                  }*/
         //jarsize
          if (jadMidlet.size <=0) {
                DETAIL_ERROR_CODE = ERROR_NO_SIZE;
                return STATUS_INVALID_DESCRIPTOR;
                   }
          else{
             if(!validateSize((int)jadMidlet.size)){
                   DETAIL_ERROR_CODE = ERROR_BAD_SIZE;
                   return STATUS_INVALID_DESCRIPTOR;
                             }
                   }
      //midlets 
          if(jadMidlet.midletnum<=0){
             DETAIL_ERROR_CODE = ERROR_NO_MILET;
               return STATUS_INVALID_DESCRIPTOR;
              }
         return STATUS_RETURN_SUCCESS;
     }
     
     
     /**
      * checkOldVersion
      * @param jadFile
      * @param flag true: parse given file ,false: not parse file 
      * @return -5 error ,2 :new version ,1: same  version ,0:low version ,-1: no old version
      */
   public static int checkOldVersion(File jadFile,boolean flag){
    if(flag){
             if(jadFile==null||!jadFile.exists()){   
                 return -5;
             }
             midletStruct midlet=getJadInfo(jadFile,true);
           if(midlet==null){
               return -5;
                 }
           else{
               jadMidlet=midlet;
               return ifInstalled(jadMidlet);
           }
               
         }
    else{
       return ifInstalled(jadMidlet);
    }
        
} 
     
     
     /**
      *step2:check if have old version
      * @param midlet
      * @return 2 :new version ,1: same  version ,0:low version ,-1: no old version
      */
    public static int ifInstalled(midletStruct midlet){
         Vector mMidletList=null; 
           boolean ifhaveold=false;
         midletStruct oldMidlet=null;
         mMidletList=Read(null);
         if(mMidletList!=null&&mMidletList.size()>0){
             for(int i=0;i<mMidletList.size();i++){
                 midletStruct m=(midletStruct)mMidletList.get(i);
                 if(midlet.name.equals(m.name)
                     &&midlet.vendor.equals(m.vendor)){
                     oldMidlet=m;
                     ifhaveold=true;
                     break;
                              }
                   }
             if(ifhaveold){
                return comparversion(midlet.version,oldMidlet.version);
             }
        
     }
         Log.i("jadparser","not enter the compar list");
               
         return -1;
     }
    
     /**
   * check if trust
  * @param jadFile
  * @param flag
  * @return true iftrust
      */
   public static boolean checkIftrust(File jadFile,boolean flag){
      if(flag){
           if(jadFile==null||!jadFile.exists())return false;
           if(getJadInfo(jadFile,true)==null)return false;
                         }
        return false;
     }
   
   
    /**
  *  this method  used when validateJad return success
  * @param jadFile 
  * @param flag:true parse file ,false: not parse file 
  * @return url if not error ,null when error
     */ 
 public static String getJarUrl(File jadFile, boolean flag){
     if(flag){
          if(jadFile==null||!jadFile.exists())return null;
          if(getJadInfo(jadFile,true)==null)return null;
                     }
    return jadMidlet.jarurl;
 }



     /**
      * get the detail information of jad
      * @param jadFile
      * @return midletStruct if right and null if parse error
      */
   public static midletStruct getJadInfo(File jadFile,boolean flag) {
           if(!flag)return jadMidlet;
          jadMidlet = new midletStruct();
         if (parseJad(jadFile)) {
             return jadMidlet;
                 }
         return null;
     }
     
 /**
  * use to getFile according to given path
  * @param doc  path
  * @return File if success  null if failed
  */
     
  public static File getFile(String path){
        if(path==null||"".equals(path))return null;
        File retFile=new File(path);
        if(retFile==null||!retFile.exists())return null;
        return retFile;
     
 }
     /**
      * parse jar
      *
      * @param path
      * @return
      */
     public static midletStruct getJarInfo(String path) {
         jadMidlet = new midletStruct();
         if (parseJar(null)) {
             return jadMidlet;
         }
         return null;
     }

    
     /**
   * parse jad
   * @param File
   * @return true success
      */
     public static boolean parseJad(File file) {
         //File file = new File(path);
         if (!file.exists()) {
             return false;
         }
         Properties fonts = new Properties();
         FileInputStream fis;
         try {
             Log.i("jadparser","parseJad()");
             fis = new FileInputStream(file);
             fonts.load(fis);
             // String desc = fonts.getProperty("MIDlet-Jar-URL");
             jadMidlet.name = fonts.getProperty(MIDLET_NAME) == null ? ""
                     : dealEncode(fonts.getProperty(MIDLET_NAME).trim());
             jadMidlet.vendor = fonts.getProperty(MIDLET_VENDOR) == null ? ""
                     : dealEncode(fonts.getProperty(MIDLET_VENDOR).trim());

             jadMidlet.InstallNotify = fonts.getProperty(MIDLET_INSTALL_NOTIFY) == null ? ""
                     : dealEncode(fonts.getProperty(MIDLET_INSTALL_NOTIFY).trim());

             jadMidlet.version = fonts.getProperty(MIDLET_VERSION) == null ? ""
                     : fonts.getProperty(MIDLET_VERSION).trim();
             jadMidlet.description = fonts.getProperty(MIDLET_DESCRIPTION) == null ? ""
                     : dealEncode(fonts.getProperty(MIDLET_DESCRIPTION).trim());
             jadMidlet.jarurl = fonts.getProperty(MIDLET_JARURL) == null ? ""
                     : fonts.getProperty(MIDLET_JARURL).trim();
             jadMidlet.size = fonts.getProperty(MIDLET_JARSIZE) == null ? 0
                     : Integer.valueOf(fonts.getProperty(MIDLET_JARSIZE).trim());
             jadMidlet.configuration = fonts
                     .getProperty(MIDLET_CONFIGURATION) == null ? ""
                     : fonts.getProperty(MIDLET_CONFIGURATION).trim();
             jadMidlet.profile = fonts.getProperty(MIDLET_PROFILE) == null ? ""
                     : fonts.getProperty(MIDLET_PROFILE).trim();
             Log.i("jadparser","parseJad(): after get attrs.");
             // parse midlet-n
             Vector v_tmp = new Vector<String>();
             for (int i = 1; i < 999; i++) {
                 String tmp = fonts.getProperty(MIDLET_PREFIX + i);
                 if (tmp == null) {
                     break;
                 } else {
                     v_tmp.add(i - 1, tmp);
                         }
                 }
             // end midlet-n
             String[] s_tmp = new String[v_tmp.size()];
             for (int j = 0; j < s_tmp.length; j++) {
                 s_tmp[j] = getOnlyMidletName((String) v_tmp.get(j),true);
             }
             jadMidlet.midletnum = s_tmp.length;
             jadMidlet.medletsClass = s_tmp;

         } catch (Exception e) {
             Log.e("jadparser", "error when parse jad! e = " + e.getMessage());
             return false;
         }

         return true;
     }

     /**
      * deal jarFile 
      *
      * @param path
      * @return
      */
     public static boolean parseJar(File jarFile) {
                     
        
         if (!jarFile.exists()) {
             return false;
                      }
         JarFile jar;
         Manifest mf;
         try {
             jar = new JarFile(jarFile);
             mf = jar.getManifest();
             Attributes att = mf.getMainAttributes();
             jarMidlet.name = att.getValue(MIDLET_NAME) == null ? "" : att
                     .getValue(MIDLET_NAME);
             jarMidlet.vendor = att.getValue(MIDLET_VENDOR) == null ? "" : att
                     .getValue(MIDLET_VENDOR);
             jarMidlet.version = att.getValue(MIDLET_VERSION) == null ? ""
                     : att.getValue(MIDLET_VERSION);
             jarMidlet.description = att.getValue(MIDLET_DESCRIPTION) == null ? ""
                     : att.getValue(MIDLET_DESCRIPTION);
             jarMidlet.size = att.getValue(MIDLET_JARSIZE) == null ? 0
                     : Integer.valueOf(att.getValue(MIDLET_JARSIZE));
             jarMidlet.configuration = att
                     .getValue(MIDLET_CONFIGURATION) == null ? "" : att
                     .getValue(MIDLET_CONFIGURATION);
             jarMidlet.profile = att.getValue(MIDLET_PROFILE) == null ? ""
                     : att.getValue(MIDLET_PROFILE);
             //
             // parse midlet-n
             Vector v_tmp = new Vector<String>();
             for (int i = 1; i < 999; i++) {
                 String tmp = att.getValue(MIDLET_PREFIX + i);
                 if (tmp == null) {
                     break;
                 } else {
                     v_tmp.add(i - 1, tmp);
                 }
             }
             String[] s_tmp = new String[v_tmp.size()];
             for (int j = 0; j < s_tmp.length; j++) {
                 s_tmp[j] = getOnlyMidletName((String) v_tmp.get(j),false);
             }
             jarMidlet.midletnum = s_tmp.length;
             jarMidlet.medletsClass = s_tmp;
             // end midlet-n

         } catch (Exception e) {
             e.printStackTrace();
             return false;
         }
         return true;
     }

     /**
      *
      * @param newversion
      * @param oldversion
      * @return 2: high,1:same,0:low
      */
     public static int comparversion(String newversion, String oldversion) {
         
         if (newversion == null || "".equals(newversion) || oldversion == null
                 || "".equals(oldversion)) {
             return 0;
         }
         newversion = newversion.replace(".", "");
         oldversion = oldversion.replace(".", "");
         if (newversion.length() >= oldversion.length()) {
             oldversion = (oldversion + "000000").substring(0, newversion
                     .length() );

         } else if (newversion.length() < oldversion.length()) {
             newversion = (newversion + "000000").substring(0, oldversion
                     .length() );
         }

         try {
             if (Integer.parseInt(newversion) > Integer.parseInt(oldversion)) {
                 return 2;
                            } 
             else if(Integer.parseInt(newversion)==Integer.parseInt(oldversion)){
                return 1;
             }
             else {
                 return 0;
             }
         } catch (Exception e) {
             return 0;

         }

     }

    

 

     /**
      * note:this method is from jams but i think it is not simply if method
      * compare() has some bug ,we can change to use this method to compare
      * version.
      *
      * @param ver1
      * @param ver2
      * @return
      * @throws NumberFormatException
      */
     private static int vercmp(String ver1, String ver2) {
         String strVal1;
         String strVal2;
         int intVal1;
         int intVal2;
         int idx1 = 0;
         int idx2 = 0;
         int newidx;

         if ((ver1 == null) && (ver2 == null)) {
             return 0;
         }

         if (ver1 == null) {
             return -1;
         }

         if (ver2 == null) {
             return 1;
         }

         for (int i = 0; i < 3; i++) {
             strVal1 = "0"; // Default value
             strVal2 = "0"; // Default value
             if (idx1 >= 0) {
                 newidx = ver1.indexOf('.', idx1);
                 if (newidx < 0) {
                     strVal1 = ver1.substring(idx1);
                 } else {
                     strVal1 = ver1.substring(idx1, newidx);
                     newidx++; // Idx of '.'; need to go to next char
                 }

                 idx1 = newidx;
             }

             if (idx2 >= 0) {
                 newidx = ver2.indexOf('.', idx2);
                 if (newidx < 0) {
                     strVal2 = ver2.substring(idx2);
                 } else {
                     strVal2 = ver2.substring(idx2, newidx);
                     newidx++;
                 }

                 idx2 = newidx;
             }
             try {
                 intVal1 = Integer.parseInt(strVal1); // May throw NFE
                 intVal2 = Integer.parseInt(strVal2); // May throw NFE
                 if (intVal1 > intVal2) {
                     return 1;
                 }

                 if (intVal1 < intVal2) {
                     return -1;
                 }
             } catch (NumberFormatException e) {
                 return -2;
             }
         }

         return 0;
     }

     /**
      * use to dipaly chinese 
      * @param src
      * @return null if failed
      */
     public static String dealEncode(String src) {
         if (src == null || "".equals(src))
             return "";
         try {
             return new String(src.getBytes("iso-8859-1"), "utf-8");
         } catch (UnsupportedEncodingException e) {
             return "";
         }
     }
/**
 * 
 * @param src
 * @param ifencode
 * @return
 */
  public static String getOnlyMidletName(String src,boolean ifencode) {
        if (src == null) {
            return "";
        }
        String name = null;
        String[] tmp = src.split(",");
        if (tmp.length > 1) {
            if(ifencode)return dealEncode(tmp[0]);
            return tmp[0];
        } else {
            if(ifencode)return dealEncode(src);
            return src;
        }

    }
     
    

 /**
  * read installed midlets from file
  * @param path
  * @return 
  */

 public static Vector Read(String path){
     Vector mMidletList=new Vector<midletStruct>();
     midletStruct mMidlet=null;
     FileInputStream fis=null;
     DataInputStream dis=null;
  
     //update list
     try{
         if(path==null)path="/data/data/oms.midletbox/midp/fplistmidlets.data";
         File f=new File(path);
         if(f==null||!f.exists())return null;
         fis=new FileInputStream(path);
         dis=new DataInputStream(fis);
         if(fis==null||dis==null)return null;
         
         content=dis.read(); 
         while(content!=-1)
         {
             if(content=='@')   //midlet start flag 
             {
                 mMidlet=new midletStruct();
                 content=dis.read();
                 continue;
             }
             if(content=='#')  //midlet pro flag
             {
                 
                 mMidlet.id=readPorpertyLong(dis);
                 mMidlet.name=readPorpertyString(dis);
                 mMidlet.vendor=readPorpertyString(dis);
                 mMidlet.version=readPorpertyString(dis);
                 mMidlet.description=readPorpertyString(dis);
                 mMidlet.authpath=readPorpertyString(dis);
                 mMidlet.securitydomain=readPorpertyString(dis);
                 mMidlet.verfied=readPorpertyLong(dis);
                 mMidlet.suite=readPorpertyLong(dis);
                 mMidlet.jadurl=readPorpertyString(dis);
                 mMidlet.jarurl=readPorpertyString(dis);
                 mMidlet.size=readPorpertyLong(dis);
                 mMidlet.midletnum=readPorpertyLong(dis);
                 int midnum=Integer.parseInt(String.valueOf(mMidlet.midletnum));
                 String[] str=new String[midnum*2];
                 for(int i=0;i<midnum*2;i++){
                    str[i]=readPorpertyString(dis);
                 }
                 mMidlet.medletsClass=str;
               //  byte[] per_arr=readPorpertyByte(dis,52);
                // mMidlet.permission=per_arr;
             }
             //add into midletlist
             //Log.i("read midlets num",String.valueOf(mMidlet.midletnum));
             mMidletList.add(mMidlet);
         }    
         if(null!=fis)
         {
             fis.close();
             fis=null;
         }
         if(null!=dis)
         {
             dis.close();
             dis=null;
         }
         //Log.i("jadparser","mMidletList size:"+mMidletList.size());
         return mMidletList;
     }
     catch(IOException exception)
     {
         //Log.e("jadparse","read failed");
         return null;
     }
     finally{
         try{
             if(null!=fis)
             {
                 fis.close();
                 fis=null;
             }
             if(null!=dis)
             {
                 dis.close();
                 dis=null;
             }
         }catch(IOException exception)
         {
             Log.e("jadparser","close file failed");
         }
     }
 }

 /**
  * readPorpertyString  
  * @param in
  * @return String
  */
 private static String readPorpertyString(DataInputStream in)
 {
     try{
         String name=null;
         Vector<Byte> bl = new Vector<Byte>();
         int len = 0;
         byte b[]=new byte[3];
         int c = in.read();
         while(c!='#'&& c!='@'&& c!=-1)
         {
           b[0]=(byte)c;
           for(int j=1;j<3;j++)
           {
             b[j]=in.readByte();
           }
           String str=new String(b,"utf8");
           str=str.trim();
           byte integer = (byte)Integer.parseInt(str);
           bl.add(integer);
           c=in.read();
          }
          len = bl.size();
          if(len <= 0)
          {
              content=c;
              return null;
          }
           byte[] a = new byte[len-1];
           for(int i=0;i<len-1;i++)
           {
              a[i] = (byte)bl.get(i);
           }
           name=new String(a,"utf8");
           content=c;
           bl.removeAllElements();
           return name;
         }
         catch(IOException exception){
            return null;
         }
 }

 private static long readPorpertyLong(DataInputStream in)
 {
     long integer=0;
     char b;
     String str=new String();
     try{
     int c=in.read();
     while(c!='#'&& c!='@'&& c!=-1){
         b=(char)c;
         str+=b;
         c=in.read();
     }
     str=str.trim();
     integer=(long)Integer.parseInt(str);
     content=c;
     }
     catch(IOException exception){
         
     }
     return integer;
 }

 /**
  * validate jar size
  * @param size
  * @return true if right
  */
 private static boolean validateSize(int size){
        if(size>JAR_MAX_SIZE)return false;
      return true;
 }
 /**
  * validate url if
  * @param url
  * @return true if right
  */
 private static boolean validateUrl(String url){
    if(url.length()<1)return false;
    for(int i=0;i<URL_PREFIX.length;i++){
        String pre=URL_PREFIX[i];
        if(url.length()>=pre.length()&&url.substring(0,pre.length()).equals(pre)){
            return true;
        }
    }
    return false;
 }

    /**
     * validate MIDP profile if
     * @param profile
     * @return true if right
     */
    private static boolean validateProfile(String profile) {
        if (profile.length() < 1)
            return false;
        for (int i = 0; i < MIDP_PROFILE.length; i++) {
            String pre = MIDP_PROFILE[i];
            if (MIDP_PROFILE[i].equals(profile.trim())) {
                return true;
            }
        }
        return false;
    }
    /**
     * validate MIDP profile if
     * @param profile
     * @return true if right
     */
    private static boolean validateConfig(String config) {
        if (config.length() < 1)
            return false;
        for (int i = 0; i < CLDC_CONFIG.length; i++) {
            String pre = CLDC_CONFIG[i];
            if (CLDC_CONFIG[i].equals(config.trim())) {
                return true;
            }
        }
        return false;
    }

 /**
  * validate version 
  * @param version
  * @return true if right
  */
 private static boolean validateVersion(String version){
    version=version.replace(".", "");
    if(version.length()<=0||version.length()>3){
        return false;
    }
    else{
        try{
            Integer.parseInt(version);
        }
        catch(NumberFormatException nbe){
            return false;
        }
    }
    return true;
 }
 /**
  * verify 
  * @param jarFile
  * @param flag
  * @return
  */
 public static int validateJar(File jarFile,boolean flag){
    DETAIL_ERROR_CODE=0;
    if(flag){
     if(jarFile==null||!jarFile.exists())return STATUS_INVALID_DESCRIPTOR;
     if(!parseJar(jarFile))return STATUS_INVALID_DESCRIPTOR;
                 }
  //name
   if (jarMidlet.name == null || "".equals(jarMidlet.name)) {
                DETAIL_ERROR_CODE = ERROR_NO_NAME;
                return STATUS_INVALID_DESCRIPTOR;
                   }
  // vendor
   if (jarMidlet.vendor == null || "".equals(jarMidlet.vendor)) {
            DETAIL_ERROR_CODE = ERROR_NO_VENDER;
            return STATUS_INVALID_DESCRIPTOR;
                }
  // version
   if (jarMidlet.version == null || "".equals(jarMidlet.version)) {
            DETAIL_ERROR_CODE = ERROR_NO_VERSION;
            return STATUS_INVALID_DESCRIPTOR;
                }
   else{
       if(!validateVersion(jarMidlet.version)){
           DETAIL_ERROR_CODE = ERROR_BAD_VERSION;
           return STATUS_INVALID_DESCRIPTOR;
                     }
          }
   //profile
   if (jarMidlet.profile == null || "".equals(jarMidlet.profile)) {
       DETAIL_ERROR_CODE = ERROR_NO_PROFILE;
       return STATUS_INVALID_DESCRIPTOR;
           }
   //configation
   if (jarMidlet.configuration == null || "".equals(jarMidlet.configuration)) {
       DETAIL_ERROR_CODE = ERROR_NO_CONFIGURATION;
       return STATUS_INVALID_DESCRIPTOR;
           }
 //midlets 
   if(jarMidlet.midletnum<=0){
     DETAIL_ERROR_CODE = ERROR_NO_MILET;
           return STATUS_INVALID_DESCRIPTOR;
       }
  return STATUS_RETURN_SUCCESS;
}
 
 /**
  * use to only get the jad some info when 
  * @param path
  */
 public static midletStruct parseJadSec(String path,midletStruct midlet){
     if(path==null||"".equals(path))return null;
     File f=new File(path);
     if(!f.exists())return null;
     if(midlet==null)midlet=new midletStruct();

     return midlet;
 }
 /**
     * use to get permissions  zinahe
     * @param in
     * @param len
     * @return
     */
 
 /*
    private static byte[] readPorpertyByte(DataInputStream in,int len) {
        long integer = 0;
        byte[] ret=new byte[len];
        String str = new String();
        try {
            int c = in.read();
            int i=0;
            
            while (c != '#' && c != '@' && c != -1) {
                str += (char)c;
                //Log.i("AMS", "byte is :"+i+":"+(char)c);
                c = in.read();
                i++;
            }
            content = c;
            if(str==null||str.length()!=len*2)return AmsUtil.initPer();
            String str_tmp="";
            byte b=0;
            int k=0;
            for(int j=0;j<len*2;j+=2){
                str_tmp="";
                str_tmp+=str.substring(j, j+2);
                //Log.i("AMS", "str_tmp is :"+j+":"+str_tmp);
                b=(byte)Integer.parseInt(str_tmp.trim());
                ret[k]=b;
                k++;
            }
        } catch (IOException exception) {
            return AmsUtil.initPer();
        }
        return ret;
    }
    
    */
 
 }

 /**
  * midletStruct
  * @author archermind
    *
  */
 class midletStruct {
    public long id;
    public String name;
    public String vendor;
    public String version;
    public String description;
    public String authpath;
    public String securitydomain;
    public long verfied;
    public long suite;
    public String jadurl;
    public String jarurl;
    public long size;
    public long midletnum;
    public String[] medletsClass;
    public String configuration;
    public String profile;
    public long iconlen;
    public String perPropNames;
    public String perOptPropNames;
    //public byte[] permission=AmsUtil.initPer();
    public byte[] permission_opt;
    public byte[] iconbyte;
    public String iconName;
    public String sig=null;
    public String[][] cer=null;
    public boolean trusted=false;   
    public String[]  pushList;
    public String InfoURL;
    public String DeleteConfirm;
    public String InstallNotify;
    public String DeleteNotify;
    public String DataSize;
 }
 
