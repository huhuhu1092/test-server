/*
 * FlashBrowserActivity
 * Copyright (C) 2009 Motorola, Inc.
 * All Rights Reserved
 *
 * The contents of this file are Motorola Confidential Restricted (MCR).
 * Revision history (newest first):
 *
 * Date         CR          Author    Description
 * -----------  ----------  --------
 * ---------------------------------------------------------
 */

//ANDROID_MOT_FLASHLITE

package com.android.browser;

import com.google.android.googleapps.IGoogleLoginService;
import com.google.android.googlelogin.GoogleLoginServiceConstants;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.DialogInterface.OnCancelListener;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DrawFilter;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Picture;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.PaintDrawable;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.WebAddress;
import android.net.http.EventHandler;
import android.net.http.SslCertificate;
import android.net.http.SslError;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Debug;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.Process;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemClock;
import android.provider.Browser;
import android.provider.Contacts;
import android.provider.Downloads;
import android.provider.MediaStore;
import android.provider.Contacts.Intents.Insert;
import android.text.IClipboard;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.text.util.Regex;
import android.util.Config;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;

//ANDROID_MOT_FLASHLITE
import android.graphics.PixelFormat;
import android.telephony.TelephonyManager;
import android.view.WindowManager;
import android.view.Display;
import android.webkit.MotWebView;
import android.os.Vibrator;
import com.android.browser.BrowserActivity;
import android.media.AudioManager;
//end of ANDROID_MOT_FLASHLITE

import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.DownloadListener;
import android.webkit.HttpAuthHandler;
import android.webkit.PluginManager;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.CustomViewCallback;
import android.webkit.WebHistoryItem;
import android.webkit.WebIconDatabase;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.ParseException;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;


class FlashBrowserActivity 
{
    static final String LOGTAG = "FlashBrowserActivity";
    static final boolean DEBUG = true;
    static final boolean LOGV_ENABLED = DEBUG ? Config.LOGD : Config.LOGV;

    private Vibrator vibrator = null;

    // monitor platform changes
    private final BrowserActivity mActivity;
    private IntentFilter mFlashPhoneState;
    private BroadcastReceiver mFlashTelIntentReceiver;
    private TabControl  mTabControl;
    private TitleBar mTitleBar;

    //Flash Context Menu and Full Screen Mode
    private boolean isFlashFullScreenMode = false;
    private boolean isFlashPaused = false;
    private int whichFlashQuality = -1;
    private int pressButton = -1;


    FlashBrowserActivity(BrowserActivity activity, TabControl tabControl, TitleBar titleBar) {
        mTabControl = tabControl;
        mTitleBar = titleBar;
        mActivity = activity;
        initialization();
        //mActivity.getWindowForFlash.setFormat(PixelFormat.TRANSLUCENT);        copyPlugins(true);
        //copyPluginLibrary();
    }

    private void initialization() {
        mFlashPhoneState = new IntentFilter();
        mFlashPhoneState.addAction(TelephonyManager.ACTION_PHONE_STATE_CHANGED);

        mFlashTelIntentReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(TelephonyManager.ACTION_PHONE_STATE_CHANGED)) {
                String phoneState = intent.getStringExtra(TelephonyManager.EXTRA_STATE).toString();
                if(phoneState.equals("IDLE"))
                {
                    WebView w = mTabControl.getCurrentWebView();
                    if((w != null) && (w instanceof MotWebView)){
                        ((MotWebView)w).flashSetResume(1);
                        isFlashPaused = false;
                    }
                }
                if(phoneState.equals("RINGING"))
                {
                    WebView w = mTabControl.getCurrentWebView();
                    if((w != null) && (w instanceof MotWebView)){
                        ((MotWebView)w).flashSetPause(1);
                        isFlashPaused = true;
                    }
                }
                if(phoneState.equals("OFFHOOK"))
                {
                    Log.d(LOGTAG, "*********ACTION_PHONE_STATE_CHANGED*****CALL_STATE_OFFHOOK******");
                }
            }
         }
       };
       mActivity.registerReceiver(mFlashTelIntentReceiver, mFlashPhoneState);
    }

    boolean onKeyDown(int keyCode, KeyEvent event) {
        //Log.d(LOGTAG, ">>>>>>>>>>>FlashBrowserActivity onKeyDown() -- keyCode=" + keyCode);
        boolean handled = false;

        if (keyCode == KeyEvent.KEYCODE_BACK){
            if (isFlashFullScreenMode)
            {
                // back to regular mode from full screen mode
                // if user presses Back hardkey in Full screen mode
                switchExitFlashFullScreenMode(false);
                handled = true;
            }
            whichFlashQuality = -1;
            isFlashPaused = false;
        }

        return handled; 
    }

    boolean flashFullScreenMode() {
        return isFlashFullScreenMode;
    }

   //CR: 39256 add support of configuration update in Fullscreen triggered by Keyboard slider or G-sensor
    void onConfigurationChanged(Configuration newConfig) {
        if (true == isFlashFullScreenMode) {
            WebView w = mTabControl.getCurrentWebView();
            if(w instanceof MotWebView){
                ((MotWebView)w).flashFullScreenOrientationChanged();
            }
        }
    }

    boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.flash_quality:{
                WebView w = mTabControl.getCurrentWebView();
                if(!(w instanceof MotWebView)){
                    break;
                }
                int quality = ((MotWebView)w).flashGetDefaultQuality();
                if(quality == 0)
                    whichFlashQuality = 2;
                else if (quality == 2)
                    whichFlashQuality = 0;
                else		
                    whichFlashQuality = 1;
                new AlertDialog.Builder(mActivity)
                .setIcon(R.drawable.alert_dialog_icon)
                .setTitle(R.string.flash_quality_options)
                .setSingleChoiceItems(R.array.flash_quality_menu, whichFlashQuality, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        if(whichButton >= 0 && whichButton <= 2)
                            pressButton = whichButton;
                    }
                })
                .setPositiveButton(R.string.alert_dialog_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                            WebView w = mTabControl.getCurrentWebView();
                            whichFlashQuality = pressButton;
                            ((MotWebView)w).flashSetQuality(whichFlashQuality);
                            /* User clicked Yes so do some stuff */
                    }
                })
                .setNegativeButton(R.string.alert_dialog_cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        Toast.makeText(mActivity, "You have clicked the Cancel button ",Toast.LENGTH_SHORT).show();
                        /* User clicked No so do some stuff */
                    }
                })
               .show();
                }
                break;

            case R.id.flash_close:{
                    switchExitFlashFullScreenMode(false); //it will switch to full screen when passing "true"  
                }
                break;
        }
        return true;
    }

    boolean onPrepareOptionsMenu(Menu menu)
    {
        if(isFlashFullScreenMode)
        {
            menu.setGroupVisible(R.id.MAIN_MENU, false);
            menu.setGroupVisible(R.id.FLASH_MENU, true);
            menu.findItem(R.id.flash_quality).setVisible(true);;
            menu.findItem(R.id.flash_quality).setEnabled(true);;
            mActivity.setMenuState(R.id.FLASH_MENU);
            return true;
        }

        menu.setGroupVisible(R.id.FLASH_MENU, false);
        //is it correct to comment out?
        //menu.setGroupVisible(R.id.MAIN_MENU, true);
        return false;
    }

    void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo, int type) {
        if(isFlashFullScreenMode)
            return;

        MenuInflater inflater = mActivity.getMenuInflater();
        inflater.inflate(R.menu.browsercontext_flash, menu);

        menu.setGroupVisible(R.id.FLASH_CONTEXTMENU, true);
        menu.setGroupVisible(R.id.PHONE_MENU, false);
        menu.setGroupVisible(R.id.EMAIL_MENU, false);
        menu.setGroupVisible(R.id.GEO_MENU, false);
        menu.setGroupVisible(R.id.IMAGE_MENU, false);
        menu.setGroupVisible(R.id.ANCHOR_MENU, false);

        menu.setHeaderIcon(R.drawable.alert_dialog_icon);
        menu.setHeaderTitle(R.string.flash_actions);
        menu.findItem(R.id.flash_quality_id).setOnMenuItemClickListener(new FlashContextQuality());
        menu.findItem(R.id.flash_full_screen_menu_id).setOnMenuItemClickListener(new FlashContextFullScreen());
    }

    void onPause() {
        //Log.d(LOGTAG, "Enter onPause()");
        if(isFlashFullScreenMode == true) {
            switchExitFlashFullScreenMode(false);
        }
    }

    void onDestroy() {
        mActivity.unregisterReceiver(mFlashTelIntentReceiver);
    }

    void switchExitFlashFullScreenMode(boolean isFullScreenMode) {
        Window win = mActivity.getWindowForFlash();
        WebView w = mTabControl.getCurrentWebView();
        if(!(w instanceof MotWebView)) 
            return;

        ((MotWebView)w).flashSetIsFullScreenMode(isFullScreenMode);
        if(isFullScreenMode){
            win.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            ((MotWebView)w).flashSwitchFullScreenMode();
            mTitleBar.setVisibility(View.GONE);
            // Always try to hide the fake title bar.
            mActivity.hideFakeTitleBar();
            mActivity.hideControlPanel();
        }
        else{
            win.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            ((MotWebView)w).flashExitFullScreenMode();
            mTitleBar.setVisibility(View.VISIBLE);
        }
        setTitleVisibility(!isFullScreenMode);
        w.requestLayout();
        w.invalidate();
        isFlashFullScreenMode = isFullScreenMode;
    }
    
    private class FlashContextQuality implements OnMenuItemClickListener {
        public boolean onMenuItemClick(MenuItem item) {
                WebView w = mTabControl.getCurrentWebView();
                if(!(w instanceof MotWebView)) 
                    return false;
                int quality = ((MotWebView)w).flashGetDefaultQuality();
                if(quality== 0)
                    whichFlashQuality = 2;
                else if (quality == 2)
                    whichFlashQuality = 0;
                else
                    whichFlashQuality = 1;
                new AlertDialog.Builder(mActivity)
                .setIcon(R.drawable.alert_dialog_icon)
                .setTitle(R.string.flash_quality_options)
                .setSingleChoiceItems(R.array.flash_quality_menu, whichFlashQuality, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        if(whichButton >= 0 && whichButton <= 2 )
                            pressButton = whichButton;
                    }
                })
                .setPositiveButton(R.string.alert_dialog_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                            /* User clicked Yes so do some stuff */
                            WebView w = mTabControl.getCurrentWebView();
                            whichFlashQuality = pressButton;
                            ((MotWebView)w).flashSetQuality(whichFlashQuality);
                    }
                })
                .setNegativeButton(R.string.alert_dialog_cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        /* User clicked No so do some stuff */
                    }
                })
               .show();

            return true;
        }
    }

    private class FlashContextFullScreen implements OnMenuItemClickListener {
        public boolean onMenuItemClick(MenuItem item) {
            // hide the title bar and status bar
            switchExitFlashFullScreenMode(true); //it will switch to full screen when passing "true"  
            return true;
        }
    }

    private void setTitleVisibility(boolean visible) {
        int viewVisible;
        if (visible) viewVisible = View.VISIBLE;
        else viewVisible = View.GONE;

        Window win = mActivity.getWindowForFlash();
        // remove window title
        View title = win.findViewById(com.android.internal.R.id.title);
        if(title != null) 
            title.setVisibility(viewVisible);
        View titleContainer = mActivity.findViewById(com.android.internal.R.id.title_container);
        if(titleContainer != null) 
            titleContainer.setVisibility(viewVisible);
        
    }

    void onFlashError(WebView view, int error){
        switch (error) {
            /*
            case MotWebView.FLASH_ERROR_NEW_VERSION_CONTENT:
                 new AlertDialog.Builder(mActivity)
                      .setIcon(R.drawable.alert_dialog_icon)
                      .setTitle(R.string.flash_error)
                      .setMessage(R.string.flash_error_new_version_content)
                      .setPositiveButton(R.string.flash_ok, new DialogInterface.OnClickListener() {
                      public void onClick(DialogInterface dialog, int which) {

                      }
                      }).show();
                    break;
              
             case MotWebView.FLASH_ERROR_UNSUPPORTED_CONTENT:
                 new AlertDialog.Builder(mActivity)
                       .setIcon(R.drawable.alert_dialog_icon)
                       .setTitle(R.string.flash_error)
                       .setMessage(R.string.flash_error_unsupported_content)
                       .setPositiveButton(R.string.flash_ok, new DialogInterface.OnClickListener() {
                       public void onClick(DialogInterface dialog, int which) {
                              }
                       }).show();
                    break;
              
             case MotWebView.FLASH_ERROR_CORRUPTED_SVG_DATA :
             case MotWebView.FLASH_ERROR_CORRUPTED_SWF_DATA :
             case MotWebView.FLASH_ERROR_ROOT_MOVIE_UNLOADED:
             case MotWebView.FLASH_ERROR_STACK_LIMIT_REACHED:
                    new AlertDialog.Builder(mActivity)
                        .setIcon(R.drawable.alert_dialog_icon)
                        .setTitle(R.string.flash_error)
                        .setMessage(R.string.flash_error_corrupted_data_related)
                        .setPositiveButton(R.string.flash_ok, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                        }
                        }).show();
                      break;
              
             case MotWebView.FLASH_ERROR_OUT_OF_MEMORY      :
                new AlertDialog.Builder(mActivity)
                 .setIcon(R.drawable.alert_dialog_icon)
                 .setTitle(R.string.flash_error)
                 .setMessage(R.string.flash_error_out_of_memory)
                 .setPositiveButton(R.string.flash_ok, new DialogInterface.OnClickListener() {
                 public void onClick(DialogInterface dialog, int which) {
                                    }
                   }).show();
                   break;
               */
              
                  default:
                      // DO NOTHING
             break;

        }

     }

     void onFlashSetFullScreenMode(WebView view, boolean fullscreen) {
            switchExitFlashFullScreenMode(fullscreen);
     }

     void onFlashStartVibration(WebView view, boolean start, int timeOn, int timeOff, int repeatCount){
            long[] pattern = new long[3];
            vibrator = (Vibrator) mActivity.getSystemService(Context.VIBRATOR_SERVICE);

            AudioManager mAudioManager = (AudioManager) mActivity.getSystemService(Context.AUDIO_SERVICE);
            int  vibrateType = mAudioManager.getVibrateSetting(AudioManager.VIBRATE_TYPE_RINGER);
            if(vibrateType == AudioManager.VIBRATE_SETTING_OFF || vibrateType == AudioManager.RINGER_MODE_SILENT)
            {
                return;
            }

            if(start){
                pattern[0] =  0; //start immediately
                pattern[1] =  timeOn;
                pattern[2] =  timeOff;
                for(int i = 0; i < repeatCount; i++) {
                    vibrator.vibrate(pattern, -1); 
                }
            }
            else{
                vibrator.cancel();
            }
     }

     void setFlashQuality(int quality) {
         whichFlashQuality = quality;
     }

    /**
     * This class is in charge of installing pre-packaged plugins
     * from the Browser assets directory to the user's data partition.
     * Plugins are loaded from the "plugins" directory in the assets;
     * Anything that is in this directory will be copied over to the
     * user data partition in app_plugins.
     */
    private class CopyPlugins implements Runnable {
        final static String TAG = "PluginsInstaller";
        final static String ZIP_FILTER = "assets/plugins/";
        final static String APK_PATH = "/system/app/Browser.apk";
        final static String PLUGIN_EXTENSION = ".so";
        final static String TEMPORARY_EXTENSION = "_temp";
        final static String BUILD_INFOS_FILE = "build.prop";
        final static String SYSTEM_BUILD_INFOS_FILE = "/system/"
                              + BUILD_INFOS_FILE;
        final static String PLUGIN_FLASH_LIBRARY = "libbrwflashplugin.so";
        final static String SYSTEM_PLUGIN_FLASH_LIBRARY = "/opl/lib/plugins/"
            + PLUGIN_FLASH_LIBRARY;

        final int BUFSIZE = 4096;
        boolean mDoOverwrite = false;
        String pluginsPath;
        Context mContext;
        File pluginsDir;
        AssetManager manager;

        public CopyPlugins (boolean overwrite, Context context) {
            mDoOverwrite = overwrite;
            mContext = context;
        }

        /**
         * Returned a filtered list of ZipEntry.
         * We list all the files contained in the zip and
         * only returns the ones starting with the ZIP_FILTER
         * path.
         *
         * @param zip the zip file used.
         */
        public Vector<ZipEntry> pluginsFilesFromZip(ZipFile zip) {
            Vector<ZipEntry> list = new Vector<ZipEntry>();
            Enumeration entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = (ZipEntry) entries.nextElement();
                if (entry.getName().startsWith(ZIP_FILTER)) {
                  list.add(entry);
                }
            }
            return list;
        }

        /**
         * Utility method to copy the content from an inputstream
         * to a file output stream.
         */
        public void copyStreams(InputStream is, FileOutputStream fos) {
            BufferedOutputStream os = null;
            try {
                byte data[] = new byte[BUFSIZE];
                int count;
                os = new BufferedOutputStream(fos, BUFSIZE);
                while ((count = is.read(data, 0, BUFSIZE)) != -1) {
                    os.write(data, 0, count);
                }
                os.flush();
            } catch (IOException e) {
                Log.e(TAG, "Exception while copying: " + e);
            } finally {
              try {
                if (os != null) {
                    os.close();
                }
              } catch (IOException e2) {
                Log.e(TAG, "Exception while closing the stream: " + e2);
              }
            }
        }

        /**
         * Returns a string containing the contents of a file
         *
         * @param file the target file
         */
        private String contentsOfFile(File file) {
          String ret = null;
          FileInputStream is = null;
          try {
            byte[] buffer = new byte[BUFSIZE];
            int count;
            is = new FileInputStream(file);
            StringBuffer out = new StringBuffer();

            while ((count = is.read(buffer, 0, BUFSIZE)) != -1) {
              out.append(new String(buffer, 0, count));
            }
            ret = out.toString();
          } catch (IOException e) {
            Log.e(TAG, "Exception getting contents of file " + e);
          } finally {
            if (is != null) {
              try {
                is.close();
              } catch (IOException e2) {
                Log.e(TAG, "Exception while closing the file: " + e2);
              }
            }
          }
          return ret;
        }

        /**
         * Utility method to initialize the user data plugins path.
         */
        public void initPluginsPath() {
            BrowserSettings s = BrowserSettings.getInstance();
            pluginsPath = s.getPluginsPath();
            if (pluginsPath == null) {
                s.loadFromDb(mContext);
                pluginsPath = s.getPluginsPath();
            }
            if (LOGV_ENABLED) {
                Log.v(TAG, "Plugin path: " + pluginsPath);
            }
        }

        /**
         * Utility method to delete a file or a directory
         *
         * @param file the File to delete
         */
        public void deleteFile(File file) {
            File[] files = file.listFiles();
            if ((files != null) && files.length > 0) {
              for (int i=0; i< files.length; i++) {
                deleteFile(files[i]);
              }
            }
            if (!file.delete()) {
              Log.e(TAG, file.getPath() + " could not get deleted");
            }
        }

        /**
         * Clean the content of the plugins directory.
         * We delete the directory, then recreate it.
         */
        public void cleanPluginsDirectory() {
          if (LOGV_ENABLED) {
            Log.v(TAG, "delete plugins directory: " + pluginsPath);
          }
          File pluginsDirectory = new File(pluginsPath);
          deleteFile(pluginsDirectory);
          pluginsDirectory.mkdir();
        }


        /**
         * Copy the SYSTEM_BUILD_INFOS_FILE file containing the
         * informations about the system build to the
         * BUILD_INFOS_FILE in the plugins directory.
         */
        public void copyBuildInfos() {
          try {
            if (LOGV_ENABLED) {
              Log.v(TAG, "Copy build infos to the plugins directory");
            }
            File buildInfoFile = new File(SYSTEM_BUILD_INFOS_FILE);
            File buildInfoPlugins = new File(pluginsPath, BUILD_INFOS_FILE);
            copyStreams(new FileInputStream(buildInfoFile),
                        new FileOutputStream(buildInfoPlugins));
          } catch (IOException e) {
            Log.e(TAG, "Exception while copying the build infos: " + e);
          }
        }

        /**
         * Copy the SYSTEM_PLUGIN_FLASH_LIBRARY file to the plugins directory.
         */
        void copyPluginFlashLibrary() {
            try {
                File libraryFile = new File(SYSTEM_PLUGIN_FLASH_LIBRARY);
                File flashPlugin = new File(pluginsPath, PLUGIN_FLASH_LIBRARY);
                copyStreams(new FileInputStream(libraryFile),
                            new FileOutputStream(flashPlugin));
            } catch (IOException e) {
                Log.e(TAG, "Exception while copying the PluginFlashLibrary: " + e);
            }
        }
        /**
         * check if the flash library under pluginsPath need to update
         */
        boolean newFlashLibrary() {
            try {
                File flashPlugin = new File(pluginsPath, PLUGIN_FLASH_LIBRARY);
                if (!flashPlugin.exists()) {
                    return true;
                }
                else {
                    File libraryFile = new File(SYSTEM_PLUGIN_FLASH_LIBRARY);
                    if (libraryFile.lastModified() != flashPlugin.lastModified()) {
                        return true;
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Exc in newFlashLibrary(): " + e);
            }
            return false;
        }

        /**
         * Returns true if the current system is newer than the
         * system that installed the plugins.
         * We determinate this by checking the build number of the system.
         *
         * At the end of the plugins copy operation, we copy the
         * SYSTEM_BUILD_INFOS_FILE to the BUILD_INFOS_FILE.
         * We then just have to load both and compare them -- if they
         * are different the current system is newer.
         *
         * Loading and comparing the strings should be faster than
         * creating a hash, the files being rather small. Extracting the
         * version number would require some parsing which may be more
         * brittle.
         */
        public boolean newSystemImage() {
          try {
            File buildInfoFile = new File(SYSTEM_BUILD_INFOS_FILE);
            File buildInfoPlugins = new File(pluginsPath, BUILD_INFOS_FILE);
            if (!buildInfoPlugins.exists()) {
              if (LOGV_ENABLED) {
                Log.v(TAG, "build.prop in plugins directory " + pluginsPath
                  + " does not exist, therefore it's a new system image");
              }
              return true;
            } else {
              String buildInfo = contentsOfFile(buildInfoFile);
              String buildInfoPlugin = contentsOfFile(buildInfoPlugins);
              if (buildInfo == null || buildInfoPlugin == null
                  || buildInfo.compareTo(buildInfoPlugin) != 0) {
                if (LOGV_ENABLED) {
                  Log.v(TAG, "build.prop are different, "
                    + " therefore it's a new system image");
                }
                return true;
              }
            }
          } catch (Exception e) {
            Log.e(TAG, "Exc in newSystemImage(): " + e);
          }
          return false;
        }

        /**
         * Check if the version of the plugins contained in the
         * Browser assets is the same as the version of the plugins
         * in the plugins directory.
         * We simply iterate on every file in the assets/plugins
         * and return false if a file listed in the assets does
         * not exist in the plugins directory.
         */
        private boolean checkIsDifferentVersions() {
          try {
            ZipFile zip = new ZipFile(APK_PATH);
            Vector<ZipEntry> files = pluginsFilesFromZip(zip);
            int zipFilterLength = ZIP_FILTER.length();

            Enumeration entries = files.elements();
            while (entries.hasMoreElements()) {
              ZipEntry entry = (ZipEntry) entries.nextElement();
              String path = entry.getName().substring(zipFilterLength);
              File outputFile = new File(pluginsPath, path);
              if (!outputFile.exists()) {
                if (LOGV_ENABLED) {
                  Log.v(TAG, "checkIsDifferentVersions(): extracted file "
                    + path + " does not exist, we have a different version");
                }
                return true;
              }
            }
          } catch (IOException e) {
            Log.e(TAG, "Exception in checkDifferentVersions(): " + e);
          }
          return false;
        }

        /**
         * Copy every files from the assets/plugins directory
         * to the app_plugins directory in the data partition.
         * Once copied, we copy over the SYSTEM_BUILD_INFOS file
         * in the plugins directory.
         *
         * NOTE: we directly access the content from the Browser
         * package (it's a zip file) and do not use AssetManager
         * as there is a limit of 1Mb (see Asset.h)
         */
        public void run() {
            // Lower the priority
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            try {
                if (pluginsPath == null) {
                    Log.e(TAG, "No plugins path found!");
                    return;
                }

                ZipFile zip = new ZipFile(APK_PATH);
                Vector<ZipEntry> files = pluginsFilesFromZip(zip);
                Vector<File> plugins = new Vector<File>();
                int zipFilterLength = ZIP_FILTER.length();

                Enumeration entries = files.elements();
                while (entries.hasMoreElements()) {
                    ZipEntry entry = (ZipEntry) entries.nextElement();
                    String path = entry.getName().substring(zipFilterLength);
                    File outputFile = new File(pluginsPath, path);
                    outputFile.getParentFile().mkdirs();

                    if (outputFile.exists() && !mDoOverwrite) {
                        if (LOGV_ENABLED) {
                            Log.v(TAG, path + " already extracted.");
                        }
                    } else {
                        if (path.endsWith(PLUGIN_EXTENSION)) {
                            // We rename plugins to be sure a half-copied
                            // plugin is not loaded by the browser.
                            plugins.add(outputFile);
                            outputFile = new File(pluginsPath,
                                path + TEMPORARY_EXTENSION);
                        }
                        FileOutputStream fos = new FileOutputStream(outputFile);
                        if (LOGV_ENABLED) {
                            Log.v(TAG, "copy " + entry + " to "
                                + pluginsPath + "/" + path);
                        }
                        copyStreams(zip.getInputStream(entry), fos);
                    }
                }

                // We now rename the .so we copied, once all their resources
                // are safely copied over to the user data partition.
                Enumeration elems = plugins.elements();
                while (elems.hasMoreElements()) {
                    File renamedFile = (File) elems.nextElement();
                    File sourceFile = new File(renamedFile.getPath()
                        + TEMPORARY_EXTENSION);
                    if (LOGV_ENABLED) {
                        Log.v(TAG, "rename " + sourceFile.getPath()
                            + " to " + renamedFile.getPath());
                    }
                    sourceFile.renameTo(renamedFile);
                }

                copyBuildInfos();

                copyPluginFlashLibrary();

                // Refresh the plugin list.
                if (mTabControl.getCurrentWebView() != null) {
                    mTabControl.getCurrentWebView().refreshPlugins(false);
                }
            } catch (IOException e) {
                Log.e(TAG, "IO Exception: " + e);
            }
        }
    };

    /**
     * Copy the content of assets/plugins/ to the app_plugins directory
     * in the data partition.
     *
     * This function is called every time the browser is started.
     * We first check if the system image is newer than the one that
     * copied the plugins (if there's plugins in the data partition).
     * If this is the case, we then check if the versions are different.
     * If they are different, we clean the plugins directory in the
     * data partition, then start a thread to copy the plugins while
     * the browser continue to load.
     *
     * @param overwrite if true overwrite the files even if they are
     * already present (to let the user "reset" the plugins if needed).
     */
    private void copyPlugins(boolean overwrite) {
        boolean copyThreadStarted = false;

        CopyPlugins copyPluginsFromAssets = new CopyPlugins(overwrite, mActivity);
        copyPluginsFromAssets.initPluginsPath();
        if (copyPluginsFromAssets.newSystemImage())  {
          if (copyPluginsFromAssets.checkIsDifferentVersions()) {
            copyPluginsFromAssets.cleanPluginsDirectory();
            Thread copyplugins = new Thread(copyPluginsFromAssets);
            copyplugins.setName("CopyPlugins");
            copyplugins.start();
            copyThreadStarted = true;
          }
        }

        //do this because FlashPlugin is not in Browser APK
        if (!copyThreadStarted && copyPluginsFromAssets.newFlashLibrary()) {
            copyPluginsFromAssets.copyPluginFlashLibrary();
        }
    }
 }

