
package com.android.browser;

import java.net.Socket;
import android.text.TextUtils;
import android.os.Handler;
import android.os.Message;
import java.io.IOException;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.provider.Browser;
import android.database.Cursor;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface;
import android.content.ServiceConnection;
import android.net.ConnectivityManager;
import android.net.http.EventHandler;
import android.net.http.ExceptionHost;
import android.net.NetworkConnectivityListener;
import android.net.NetworkInfo;
import android.webkit.WebSettings;
import com.android.internal.telephony.Phone;
import android.provider.Telephony.Messaging;
import android.widget.Toast;

import android.net.Uri;
import android.provider.Telephony;
import android.provider.Telephony.Carriers;
import android.os.SystemProperties;
import android.app.AlertDialog;

import android.util.Log;
import junit.framework.Assert;

// A helper class to access network profiles.
public class NetworkManager  { 

    public static final String DEFAULT_PROFILE = BrowserSettings.DEFAULT_DATA_CONNECTION_STR;
    private final static String TAG = "NetworkManager";
    private static final int EVENT_DATA_STATE_CHANGED = 2;
    private static NetworkManager mInstance;

    //private ProfileAttibutes mProfile;
    private String mNetworkProfile = DEFAULT_PROFILE;
    private String mNetworkInterface;
    private String mNetworkApn;
    private BrowserActivity mBrowserActivity;
    boolean mConnected = false;
    private ConnectivityManager mConnMgr;
    private ProfileAttibutes mNetworkParam = new ProfileAttibutes();

    // ServiceHandler has the same lifecycle as the process. 
    // We register/unregister the listener within the lifecycle 
    // of a data connection.
    private static ServiceHandler mServiceHandler;
    private static NetworkConnectivityListener mConnectivityListener;

    public static synchronized NetworkManager createInstance(Context ctx) {
        // Destroy the listener if it's there before 
        // we create a new NetworkManager.
        // Ideally this should not happen.
        if (mConnectivityListener != null && mServiceHandler != null) {
            try {
                mConnectivityListener.stopListening();
                mConnectivityListener.unregisterHandler(mServiceHandler);
            }catch(Exception ee) {
                Log.w(TAG, "Error when removing listener: ", ee);
            }finally {
                Log.d(TAG, "set mConnectivityListener to null", new Throwable());
                mConnectivityListener = null;
                mServiceHandler = null;
            }
        }

        mInstance = new NetworkManager(ctx);
        return mInstance;
    }

    public static synchronized NetworkManager peekInstance() {
        return mInstance;
    }

    protected NetworkManager(Context ctx) {
        mServiceHandler = new ServiceHandler();
        mConnectivityListener = new NetworkConnectivityListener();

        mBrowserActivity = (BrowserActivity)ctx;
        mNetworkProfile = BrowserSettings.getInstance().getDataConnectionStr(mBrowserActivity);
    }

    public String getNetworkProfile() {
        return mNetworkProfile;
    }

    // Simply sets the network profile.
    public void setNetworkProfile(String profile) {
        mNetworkProfile = profile;

        // Update DM module.
        if(BrowserSettings.DM_ENABLED) {
            Browser.setBrowserProperty(mBrowserActivity.getContentResolver(), 
                    Browser.PROP_DATA_CONNECTION, profile);
        }
    }

    // Updates the network profile and reconnect if needed.
    public void switchNetworkProfile(String newDataConnection) {
        // TODO: Make sure we have call stopLoad() in WebView.
        if(! newDataConnection.equals(mNetworkProfile)) {
            Log.w(TAG, "DataConnection will switch from:"+mNetworkProfile+" to " + newDataConnection);
            disconnect();
            mConnected = false;
            setNetworkProfile(newDataConnection);
            Log.w(TAG, "Re-connecting...");
            connect();
        }
    }

    public boolean connected() {
        return mConnected;
    }

    public String getNetworkInterface() {
        return mNetworkInterface;
    }

    // Setup network before any new socket, e.g. Set proxy/port and 
    // bind network interface here.
    // Don't forget to setup mNetworkParam here.
    private void setupNetworkIfNeeded() {
        // See if we're using wifi now.
        if(mNetworkInterface == null && mNetworkApn == null) {
            Log.w(TAG, "*** using wifi");
            resetNetwork();

            // Try to set up proxy if needed. For CMCC WLAN Only.
            setupWlanProxyIfNeeded();

            mNetworkParam.mType = Phone.APN_TYPE_INTERNET;
            return;
        }

        Socket.setInterface(mNetworkInterface);

        //ProfileAttibutes pa = getNetworkParam();
        loadNetworkParam();
        if(mNetworkParam == null) {
            // Either something wrong happened or we're now using wifi.
            Log.w(TAG, "*** cannot get the pa");
            resetNetwork();
            return;
        }

        Log.d(TAG, "Update proxy: " + mNetworkParam.mProxyHost + ":" + 
                mNetworkParam.mProxyPort);

        if(mNetworkParam.mProxyHost == null || mNetworkParam.mProxyHost.length() <= 0) {
            // Must reset proxy.
            WebSettings.setProxy(mBrowserActivity, null, 0);
        }else {
            WebSettings.setProxy(mBrowserActivity, mNetworkParam.mProxyHost, mNetworkParam.mProxyPort);
        }
    }

    // Clear all network settings.
    private void resetNetwork() {
        Log.d(TAG, "resetNetwork");
        mNetworkInterface = null;
        Socket.setInterface(null);
        mNetworkApn = null;
        WebSettings.setProxy(mBrowserActivity, null, 0);
        // Don't forget mNetworkParam.
        if(mNetworkParam != null) {
            mNetworkParam.reset();
        }
        ExceptionHost.setEnabled(false);
    }

    // For CMCC WLAN: Set proxy if needed.
    private boolean setupWlanProxyIfNeeded() {
        String proxyAndPort = SystemProperties.get("wlan.proxy.info", null);
        Log.d(TAG, "WLAN proxy: " + proxyAndPort);
        if(proxyAndPort == null) {
            return false;
        }
        int index = proxyAndPort.indexOf(":");
        if(index <= 0) {
            return false;
        }

        String host = proxyAndPort.substring(0, index);
        int port = 0;
        try {
            port = Integer.parseInt(proxyAndPort.substring(index + 1));
        }catch(Exception ee) {
            port = 0;
        }

        if(host == null || port <= 0) {
            // Should we reset proxy here?
            return false;
        }

        // WiFi proxy is valid now.
        WebSettings.setProxy(mBrowserActivity, host, port);

        // Go ahead with the local exception address list.
        ExceptionHost.setEnabled(ExceptionHost.updateExceptionHostList());

        return true;
    }

    // TODO: Move the airplane listener here.

    boolean connect() {
        //setupNetworkIfNeeded();
        if(mBrowserActivity.isAirplaneModeOn()){
            Toast.makeText(mBrowserActivity, 
                R.string.network_connection_airplane_on, 
                Toast.LENGTH_LONG).show();
	     return false;
	 }
        mConnMgr = (ConnectivityManager) mBrowserActivity.getSystemService(Context.CONNECTIVITY_SERVICE);

        int result = -1;
        try {
            mConnectivityListener.registerHandler(mServiceHandler, EVENT_DATA_STATE_CHANGED);
            mConnectivityListener.startListening(mBrowserActivity);
            result = beginBrowserConnectivity();
        } catch (Exception e) {
            Log.e(TAG, "Failed to start browser connection!!", e);
        }
	 return true;
    }

    // Tear down the GPRS link.
    void disconnect() {
        endBrowserConnectivity();
        mConnected = false;
        if (mConnectivityListener != null) {
            try {
                //Log.e(TAG, "====unregisterHandler ====");
                mConnectivityListener.unregisterHandler(mServiceHandler);
                mConnectivityListener.stopListening();
            } catch (Exception e) {
                Log.e(TAG, "disconnect failed!!", e);
            }
        }

        // Important: reset all network params to avoid any potential errors.
        resetNetwork();
    }
 
    // Called when host app is exited and we do a cleanup here.
    void finish() {
        resetNetwork();
        // Just assume that disconnect() has been called when reached here.
        Log.d(TAG, "set mConnectivityListener to null", new Throwable());
        mConnectivityListener = null;
        mServiceHandler = null;
    }

    // Return true if we need to open data connection, false if not.
    public boolean openDataConnectionIfNeeded() {
        if(mConnected) return false;
        return connect();
    }

    // We use some static variables to retrieve network params from 
    // Telephony provider.
    static String[] CARRIER_PROJECTION = { 
            Carriers.TYPE, 
            Carriers.APN, 
            Carriers.PROXY, 
            Carriers.PORT };
    static int COL_TYPE = 0;
    static int COL_APN = 1;
    static int COL_PROXY = 2;
    static int COL_PORT = 3;

    public ProfileAttibutes getNetworkParam() {
        return mNetworkParam;
    }

    // This is to load network params from Settings and save the value locally. 
    // Only do this when needed (e.g. data connection changed).
    private void loadNetworkParam() {
// TODO: for debug only!
Log.w(TAG, "type=" + mNetworkProfile + "/" + mNetworkApn);

        mNetworkParam = null;

        final String where = "( " + Carriers.TYPE + " = '"
                        + mNetworkProfile  + "' ) AND ( "
                        + Carriers.APN + " = '"
                        + mNetworkApn + "' )";

        //Cursor c = SqliteWrapper.query(mBrowserActivity, mBrowserActivity.getContentResolver(),
        //                    Telephony.Carriers.CONTENT_URI, null, null, null, null);

        Cursor c = mBrowserActivity.getContentResolver().query(
                Telephony.Carriers.CONTENT_URI, 
                CARRIER_PROJECTION, where, null, null);

        if (c == null) {
            Log.e(TAG, "******** No proxy!");
            //return null;
            return;
        }

        try {
            while (c.moveToNext()) {
                String type = c.getString(COL_TYPE);
                String apn = c.getString(COL_APN);

                Log.d(TAG, ">>>>>>>>> type="+type+", apn="+apn);

                if (type.equals(mNetworkProfile) && mNetworkApn.equals(apn)) {
                    mNetworkParam = new ProfileAttibutes();
                    mNetworkParam.mType = mNetworkProfile; 
                    mNetworkParam.mApnName = mNetworkApn; 
                    mNetworkParam.mProxyHost = c.getString(COL_PROXY);
                    String port = c.getString(COL_PORT);
                    Log.d(TAG, ">>>>>>>>>>>>>> proxy="+mNetworkParam.mProxyHost+", port="+port);
                    mNetworkParam.mProxyPort = getPort(port);
                    c.close();
                    //return pa;
                    return;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "e = "+e);
        }finally {
            c.close();
        }
        //return null;
    }

    private int getPort(String port) {
        // Should we use always use default 80??
        if(port == null || port.length() <= 0) return 80;

        int ret = 0;
        try {
            ret = Integer.parseInt(port.trim());
        }catch(Exception ee) {
            Log.w(TAG, "Invalid port");
        }
        // Should we use always use default 80??
        return ret > 0 ? ret : 80;
    }

    // Profile attributes.
    public class ProfileAttibutes {
        //public int mId;
        public String mApnName;
        public String mType;//eg: internet/wap/mms/..
        public String mProxyHost;
        public int mProxyPort = 0;

        public void reset() {
            mApnName = "";
            mType = "";
            mProxyHost = null;
            mProxyPort = 0;
        }

        /* Some other attributes may be used later
        public String mUserName;
        public String mPassword;
        public String mHomepage;
        */
    }

    private static boolean mIsEmulator = SystemProperties.get("ro.kernel.qemu").equals("1");

    private int beginBrowserConnectivity() throws IOException {
        int result = mConnMgr.startUsingNetworkFeature(
                ConnectivityManager.TYPE_MOBILE, mNetworkProfile);
        Log.d(TAG, "beginBrowserConnectivity result="+result);

        // It's OK for emulator. 
        if(mIsEmulator) {
            mConnected = true;
            mBrowserActivity.onNetworkOpenResult(true);
            return Phone.APN_ALREADY_ACTIVE;
        }

        String errorMessage = null;

        switch (result) {
            case Phone.APN_ALREADY_ACTIVE:
                mConnected = true;
                Log.d(TAG, "APN_ALREADY_ACTIVE");

                NetworkInfo[] netInfos = mConnMgr.getAllNetworkInfo();
                boolean found = false;
                for(NetworkInfo netInfo : netInfos) {
                    if(TextUtils.equals(mNetworkProfile, 
                            netInfo.getApType()) && netInfo.isConnected()) {
                        found = true;
                        // remember this for later query
                        mNetworkApn = netInfo.getExtraInfo();
                        mNetworkInterface = netInfo.getInterfaceName();
                        break;
                    }
                }
                if(!found) {
                    Log.w(TAG, "No matched NetInfo found!");
                }

                // Learn network interface from ConnectionManager and bind it.
                if (mNetworkProfile.equals(Phone.APN_TYPE_INTERNET)) {
                    mNetworkInterface = null;
                }else {
                    Log.d(TAG, "bind socket to interface:" + mNetworkInterface + "/" + mNetworkProfile+", apn="+mNetworkApn);
                }

                setupNetworkIfNeeded();

                mBrowserActivity.onNetworkOpenResult(true);
                return result;

            case Phone.APN_REQUEST_STARTED:
                break;

            case Phone.APN_TYPE_NOT_AVAILABLE:
                errorMessage = mBrowserActivity.getResources().getString(
                        R.string.network_profile_not_found);
                break;

            case Phone.APN_REQUEST_FAILED:
                errorMessage = mBrowserActivity.getResources().getString(
                        R.string.network_connection_failed_general);
                Log.w(TAG, "Cannot establish data connection");
                break;

            default:
                Log.w(TAG, "Unhandled status: " + result);
                break;
        }

        if(errorMessage != null) {
            mBrowserActivity.onNetworkOpenResult(false);
            onNetowrkError(errorMessage);
        }

        return result;
    }
    
    private void endBrowserConnectivity() {
        Log.d(TAG, "endBrowserConnectivity");
        if (mConnMgr != null) {
            mConnMgr.stopUsingNetworkFeature(ConnectivityManager.TYPE_MOBILE, mNetworkProfile);
        }
    }

    // Don't show several dialogs at one time.
    private AlertDialog mNetworkAlertDialog;
    private void onNetowrkError(String message) {
        if(message == null) {
            message = mBrowserActivity.getResources().getString(
                    R.string.network_connection_failed_general);
        }

        if(mNetworkAlertDialog != null && mNetworkAlertDialog.isShowing()) {
            mNetworkAlertDialog.dismiss();
            mNetworkAlertDialog = null;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(mBrowserActivity)
            .setTitle(R.string.network_error_title)
            .setIcon(com.android.internal.R.drawable.cmcc_dialog_error)
            .setNeutralButton(R.string.cancel, null)
            .setCancelable(true);

        mNetworkAlertDialog = builder.create();
        mNetworkAlertDialog.setMessage(message);

        // Don't show the retry button in airplane mode
        if(mBrowserActivity.isAirplaneModeOn()) {
            mNetworkAlertDialog.setButton(null, (DialogInterface.OnClickListener)null);
        }else {
            mNetworkAlertDialog.setButton(mBrowserActivity.getString(R.string.network_connection_retry), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    mBrowserActivity.connect();
                }});
        }

        mNetworkAlertDialog.show();
    }

    // A helper method to dismiss the alert dialog if any
    /*package*/ void dismissAlertDialogIfAny() {
        if(mNetworkAlertDialog != null) {
            mNetworkAlertDialog.dismiss();
            mNetworkAlertDialog = null;
        }
    }

    private final class ServiceHandler extends Handler {
        
        public void handleMessage(Message msg) {
            Log.e(TAG, "ServiceHandler: new message: " + msg);
            switch (msg.what) {
                case EVENT_DATA_STATE_CHANGED: {
                    if (mConnectivityListener == null) {
                        Log.e(TAG, "why conn listener is null?, will return");
                        return;
                    }
                    
                    NetworkInfo info = mConnectivityListener.getNetworkInfo();
                    if (info == null) {
                        Log.e(TAG, "Network Info is null ! ");
                        return;
                    }

                    if (!TextUtils.equals(info.getApType(), mNetworkProfile)) {
                        Log.e(TAG, "The msg is for (" + info.getApType()
                                + "),  Discard this msg.");
                        return;
                    }
                    
                    if (info.getState() == NetworkInfo.State.CONNECTED) {
                        mConnected = true;
                        Log.d(TAG, "mConnected changed to CONNECTED");

                        if(info.getApType().equals(Phone.APN_TYPE_INTERNET)) {
                            mNetworkInterface = null;
                        }else {
                            mNetworkInterface = info.getInterfaceName();
                        }
                        mNetworkApn = info.getExtraInfo();

                        Log.d(TAG, "bind socket to interface:" + mNetworkInterface + "/" + info.getApType()+", apn_new="+ mNetworkApn);
                        try {
                            setupNetworkIfNeeded();
                        } catch (Exception e) {
                            // OMS: only catch this exception, wired crash need further investigation.
                            // #0107183 
                            mConnected = false;
                            Log.e(TAG, "!!! setup network failed, something really strange happened", e);
                            return ;
                        }

                        mBrowserActivity.onNetworkChanged(true);
                    } else if (info.getState() == NetworkInfo.State.DISCONNECTED) {
                        String reason = info.getReason();
                        Log.d(TAG, "mConnected changed to DISCONNECTED " + info.getDetailedState() + "/" + reason);
                        mConnected = false;

                        // OMS: There's a trick in ConnectivityManager: the msg of 
                        // DISCONNECTED/DISCONNECTED in "internet" group is a sticky 
                        // one by Android design. 
                        // So we may need to ignore it during opening data connection.
                        if(info.getDetailedState() == NetworkInfo.DetailedState.CONNECTING) {
                            // Ignore if the NetworkInfo.State is DISCONNECTED while
                            // current NetworkInfo.DetailedState is still CONNECTING.
                            Log.d(TAG, "DISCONNECTED ignored as DetailedState is CONNECTING.");
                            return;
                        }

                        // This is the case when failed to open data connection.
                        // TODO: This may come from other app...
                        if(info.getDetailedState() == NetworkInfo.DetailedState.FAILED) {
                            mBrowserActivity.onNetworkOpenResult(false);
                            onNetowrkError(null);
                            return;
                        } 

                        // Always ignor REASON_DATA_DISABLED when it's    
                        // from other network type or APN...
                        if(reason != null && reason.equals(Phone.REASON_DATA_DISABLED)) {
                            /* The following block is not used at present, hence we ignore all
                               REASON_DATA_DISABLEDs.
                            if (!TextUtils.equals(info.getApType(), mNetworkProfile)) {
                                Log.e(TAG, "Discard the msg for" + info.getApType());
                                return;
                            }
                            if (!TextUtils.equals(info.getExtraInfo(), mNetworkApn)) {
                                Log.e(TAG, "Discard the msg for" + info.getExtraInfo());
                                return;
                            }*/
                            return;
                        }
                        mBrowserActivity.onNetworkChanged(false);
                    } else {
                        Log.e(TAG, " >>>>>>> status = "+info.getDetailedState() + "/" + info.getReason());
                    }
                    break;
                }
                default:
                    Log.d(TAG, "unhandled msg, msg="+msg);
                    break;
            }
        }
    }
}
