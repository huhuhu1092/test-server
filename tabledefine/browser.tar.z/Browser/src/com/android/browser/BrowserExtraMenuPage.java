/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser;

import android.content.Context;
import android.content.pm.ActivityInfo;
//import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.PaintDrawable;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ListView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ListAdapter;
import android.app.ListActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemProperties;
import android.provider.Browser;
import android.text.Editable;
import android.text.IClipboard;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.database.DataSetObserver;

import java.util.Vector;


/*

import android.widget.ImageView;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.content.Context;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.app.ListActivity;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import android.database.Cursor;
*/
import android.util.Log;

public class BrowserExtraMenuPage extends ListActivity {
    private ExtraMenuAdapter          mAdapter;
    private boolean                 mMaxTabsOpen;
    private ListView                mListView;

    private String mFromUrl;

    private final static String LOGTAG = "browser";

    private class MenuItemData {
        int mId;
        int mIcon; // -1 means no icon for this item
        int mTitle;
        String mComment;
        MenuItemData(int id, int icon, int title, String comment) {
            mId = id;
            mIcon = icon;
            mTitle = title;
            mComment = comment;
        }
    }

    final static public int SET_AS_HOMEPAGE = 0;
    final static public int PAGE_INFO     = 1;
    final static public int SHARE_PAGE    = 2;
    final static public int FULL_SCREEN   = 3;
    final static public int LOCK_ORIENTATION = 4;
    final static public int FIND_ON_PAGE  = 5;
    final static public int SET_BRIGHTNESS = 6;

    private Vector<MenuItemData> mMenu = new Vector<MenuItemData> (5);

    @Override
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        // OMS: Request for orientation sensor
        //super.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);

        mMenu.add(new MenuItemData(SET_AS_HOMEPAGE, -1, R.string.menu_use_as_homepage, "")); //set as homepage
        mMenu.add(new MenuItemData(PAGE_INFO,    -1,  R.string.page_info, "")); //page info
        mMenu.add(new MenuItemData(SHARE_PAGE,   -1,  R.string.share_page, "")); //share page
        mMenu.add(new MenuItemData(FULL_SCREEN,  -1,  R.string.toggle_fullscreen, "")); //toggle full screen
        mMenu.add(new MenuItemData(LOCK_ORIENTATION,  -1,  R.string.lock_orientation, "")); //toggle orientaion
        mMenu.add(new MenuItemData(FIND_ON_PAGE, -1,  R.string.find_dot, "")); //find
        if (SystemProperties.getBoolean("apps.browser.enable_brightness", false)) {
            mMenu.add(new MenuItemData(SET_BRIGHTNESS, -1, R.string.brightness, "")); // set browser brightness
        }

        if (mAdapter == null) {
           mAdapter = new ExtraMenuAdapter(this);
        }

        setListAdapter(mAdapter);
        mListView = getListView();

        LayoutInflater factory = LayoutInflater.from(this);
        View v = factory.inflate(R.layout.empty_history, null);
        addContentView(v, new LayoutParams(LayoutParams.FILL_PARENT,
                LayoutParams.FILL_PARENT));
        mListView.setEmptyView(v);
        
        setResult(RESULT_CANCELED);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        Log.d("ExtraMenu", "onListItemClick position="+position);

        if (v instanceof BrowserExtraMenuItem) {
            BrowserExtraMenuItem itemView = (BrowserExtraMenuItem)v;
            Intent intent = new Intent();
            Bundle b = new Bundle();
            b.putInt("menu_index", itemView.getID());
            intent.putExtras(b);
            setResult(RESULT_OK, intent);
            finish();
        }
    }


    private class BrowserExtraMenuItem extends RelativeLayout {
        private int      mID;
        private TextView    mTitleView; 
        private String      mUrl;       
        private TextView    mUrlText;   
        private ImageView   mImageView;
    
        /* package */ BrowserExtraMenuItem(Context context, final BrowserExtraMenuPage.ExtraMenuAdapter adapter) {
            super(context);
            mAdapter = adapter;

            setWillNotDraw(false);
            LayoutInflater factory = LayoutInflater.from(context);
            //factory.inflate(android.R.layout.cmcc_list_4, this);
            factory.inflate(android.R.layout.cmcc_list_2, this);
            mTitleView = (TextView) findViewById(android.R.id.text1);
            //mUrlText = (TextView) findViewById(android.R.id.text2);
            //mUrlText.setVisibility(View.GONE);
            mImageView = (ImageView) findViewById(android.R.id.listicon1);
        }

        /* package */ String getName() {
            return mTitleView.getText().toString();
        }

        /* package */ String getUrl() {
            return mUrl;
        }

        /* package */ void setFavicon(Drawable icon) {
            Drawable[] array = new Drawable[2];
            PaintDrawable p = new PaintDrawable(Color.WHITE);
            p.setCornerRadius(3f);
            array[0] = p;
            if (icon != null) {
                array[1] = icon;
            } else {
                array[1] = new BitmapDrawable(mContext.getResources().
                    openRawResource(R.drawable.app_web_browser_sm));
            }
            LayerDrawable d = new LayerDrawable(array);
            d.setLayerInset(1, 2, 2, 2, 2);
            d.setBounds(0, 0, 20, 20);
            mImageView.setImageDrawable(d);
        }
    
        /* package */ void setName(String name) {
            mTitleView.setText(name);
        }
    
        /* package */ void setUrl(String url) {
            mUrl = url;
            mUrlText.setText(url);
        }

        /* package */ void setID(int id) {
            mID = id;
        }

        /* package */ int getID() {
            return mID;
        }
    }  



    /*private*/ class ExtraMenuAdapter implements ListAdapter {
        Vector<DataSetObserver> mObservers;
        Context mContext;
        
        ExtraMenuAdapter(Context context) {
            mContext = context;
            mObservers = new Vector<DataSetObserver>();
        }

        //Borqs: this is the template method function !!!
        public View getView(int position, View convertView, ViewGroup parent) {
            return getBrowserExtraMenuItem(position, convertView);
        }
        
        View getBrowserExtraMenuItem(int position, View convertView) {
            BrowserExtraMenuItem item = new BrowserExtraMenuItem(BrowserExtraMenuPage.this, mAdapter);
            //Log.d("BrowserExtraMenu", "Here we set the data to Item, position="+position);

            MenuItemData d = mMenu.get(position);
            String s = getResources().getString(d.mTitle);
            item.setName(s);
            //item.setUrl(d.mComment);
            item.setID(d.mId);
            
            Drawable draw = d.mIcon==-1 ? null : mContext.getResources().getDrawable(d.mIcon); 
            item.setFavicon(draw);
            return item;
        }
       
        public boolean areAllItemsEnabled() {
            return true;
        }

        public boolean isEnabled(int position) {
            return true;
        }

        public int getCount() {
            return mMenu.size();
        }

        public Object getItem(int position) {
            return null;
        }

        public long getItemId(int position) {
            return position;
        }

        public int getItemViewType(int position) {
                return 1;
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            return true;
        }

        public void registerDataSetObserver(DataSetObserver observer) {
            mObservers.add(observer);
        }

        public void unregisterDataSetObserver(DataSetObserver observer) {
            mObservers.remove(observer);
        }

        public boolean isEmpty() {
                return false;
        }
    }
}
