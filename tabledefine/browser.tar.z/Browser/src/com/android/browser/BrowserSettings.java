/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser;

import com.google.android.providers.GoogleSettings.Partner;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.SystemProperties;
import android.view.WindowManager;
import android.webkit.CacheManager;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewDatabase;
import android.webkit.WebIconDatabase;
import android.webkit.WebSettings;
import android.preference.PreferenceManager;
import android.provider.Browser;
import com.android.internal.telephony.Phone;

import java.util.HashMap;
import java.util.Observable;
import android.util.Log;
import android.provider.Settings;

/*
 * Package level class for storing various WebView and Browser settings. To use
 * this class:
 * BrowserSettings s = BrowserSettings.getInstance();
 * s.addObserver(webView.getSettings());
 * s.loadFromDb(context); // Only needed on app startup
 * s.javaScriptEnabled = true;
 * ... // set any other settings
 * s.update(); // this will update all the observers
 *
 * To remove an observer:
 * s.deleteObserver(webView.getSettings());
 */
class BrowserSettings extends Observable {

    // Public variables for settings
    // NOTE: these defaults need to be kept in sync with the XML
    // until the performance of PreferenceManager.setDefaultValues()
    // is improved.
    private boolean loadsImagesAutomatically = true;
    // private boolean fitScreenWidthEnabled = false;
    private boolean javaScriptEnabled = true;
    private boolean pluginsEnabled = false;
    private String pluginsPath;  // default value set in loadFromDb().
    private boolean javaScriptCanOpenWindowsAutomatically = false;
    private boolean showSecurityWarnings = true;
    private boolean rememberPasswords = true;
    private boolean saveFormData = true;
    private boolean openInBackground = false;
    private String defaultTextEncodingName = "AUTOSELECT";
    private String homeUrl = "file:///oms_asset/html/home.html";
    private boolean loginInitialized = false;
    private int orientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
    public int dataConnectionId = 0;
    private int searchPortal = 1;  // default as google
    private boolean autoFitPage = true;
    private boolean loadsPageInOverviewMode = false;
    private boolean showDebugSettings = false;
    private String downloadDir = "/sdcard/download";
    private boolean browserDownloadAudiovideo = true;

    private int mHistorySort = 0;

    private int mBrightness = -1; // -1 means user never set browser brightness
    // Development settings
    private static BrowserActivity mBrowserActivity = null;

    public WebSettings.LayoutAlgorithm layoutAlgorithm =
        WebSettings.LayoutAlgorithm.NARROW_COLUMNS;
    private boolean useWideViewPort = true;
    private int userAgent = 0;
    private boolean tracing = false;
    private boolean lightTouch = false;
    private boolean navDump = false;
    // Browser only settings
    private boolean doFlick = false;

    // Private preconfigured values
    private static int minimumFontSize = 8;
    private static int minimumLogicalFontSize = 8;
    private static int defaultFontSize = 16;
    private static int defaultFixedFontSize = 13;
    private static WebSettings.TextSize textSize =
        WebSettings.TextSize.NORMAL;
    private static WebSettings.ZoomDensity zoomDensity =
        WebSettings.ZoomDensity.MEDIUM;

    // Preference keys that are used outside this class
    public final static String PREF_CLEAR_CACHE = "privacy_clear_cache";
    public final static String PREF_CLEAR_COOKIES = "privacy_clear_cookies";
    public final static String PREF_CLEAR_HISTORY = "privacy_clear_history";
    public final static String PREF_HOMEPAGE = "homepage";
    public final static String PREF_RESET_HOMEPAGE = "privacy_reset_homepage";
    public final static String PREF_PRELOADED_HOMEPAGE = "preloaded_homepage";
    public final static String PREF_CLEAR_FORM_DATA = 
            "privacy_clear_form_data";
    public final static String PREF_CLEAR_PASSWORDS = 
            "privacy_clear_passwords";
    public final static String PREF_EXTRAS_RESET_DEFAULTS = 
            "reset_default_preferences";
    public final static String PREF_DEBUG_SETTINGS = "debug_menu";
    public final static String PREF_GEARS_SETTINGS = "gears_settings";
    public final static String PREF_TEXT_SIZE = "text_size";
    public final static String PREF_DEFAULT_ZOOM = "default_zoom";
    public final static String PREF_DEFAULT_TEXT_ENCODING =
            "default_text_encoding";

    public final static String PREF_BRIGHTNESS = "brightness";
    public final static int MINIMUM_BACKLIGHT = android.os.Power.BRIGHTNESS_DIM + 10;
    public final static int MAXIMUM_BACKLIGHT = android.os.Power.BRIGHTNESS_ON - 5; 
    public final static int BRIGHTNESS_STEP = 11;   

    // use the cupcake one for set-encoding 
    //public final static String PREF_CHARSET_ENCODING = "charset_encoding";

    // Value to truncate strings when adding them to a TextView within
    // a ListView
    public final static int MAX_TEXTVIEW_LEN = 80;

    private TabControl mTabControl;

    // Single instance of the BrowserSettings for use in the Browser app.
    private static BrowserSettings sSingleton;

    // Private map of WebSettings to Observer objects used when deleting an
    // observer.
    private HashMap<WebSettings,Observer> mWebSettingsToObservers =
        new HashMap<WebSettings,Observer>();

    // OMS settings begins from here:
    public static String DEFAULT_HOMEPAGE = "file:///oms_asset/html/home.html";
    //public static String DEFAULT_HOMEPAGE_SMALL = "file:///oms_asset/html/home.htm";
    public static boolean DM_ENABLED = true;

    public final static String PREF_SEARCH_PORTAL = "search_portal";
    public final static String PREF_DATA_CONNECTION = "data_connection";
    public final static String PREF_HISTORY_SORT = "history_sort";
    
    public final static String DEFAULT_TEXT_ENCODING_STR = "AUTOSELECT";
    public final static String DEFAULT_DATA_CONNECTION_STR = Phone.APN_TYPE_WAP;
    public final static String PREF_DOWNLOAD_DIR = "download_dir";

    public final static String PREF_MENU_BASIC = "menu_category_basic";
    public final static String PREF_ENABLE_PLUGINS = "enable_plugins";

    /*
     * An observer wrapper for updating a WebSettings object with the new
     * settings after a call to BrowserSettings.update().
     */
    static class Observer implements java.util.Observer {
        // Private WebSettings object that will be updated.
        private WebSettings mSettings;

        Observer(WebSettings w) {
            mSettings = w;
        }

        public void update(Observable o, Object arg) {
            BrowserSettings b = (BrowserSettings)o;
            WebSettings s = mSettings;

            s.setLayoutAlgorithm(b.layoutAlgorithm);
            // s.setUserAgent(b.userAgent);
            s.setUseWideViewPort(b.useWideViewPort);
            s.setLoadsImagesAutomatically(b.loadsImagesAutomatically);
            // s.setFitScreenWidthEnabled(b.fitScreenWidthEnabled);
            s.setJavaScriptEnabled(b.javaScriptEnabled);
            s.setPluginsEnabled(b.pluginsEnabled);
            s.setPluginsPath(b.pluginsPath);
            s.setJavaScriptCanOpenWindowsAutomatically(
                    b.javaScriptCanOpenWindowsAutomatically);

/* To reload here may be dangerous, if webviewcore is not created yet.
            String oldCharset = s.getDefaultTextEncodingName();
            if (mBrowserActivity != null && !b.defaultTextEncodingName.equals(oldCharset))
                mBrowserActivity.reload();
*/

            s.setDefaultTextEncodingName(b.defaultTextEncodingName);
            s.setMinimumFontSize(b.minimumFontSize);
            s.setMinimumLogicalFontSize(b.minimumLogicalFontSize);
            s.setDefaultFontSize(b.defaultFontSize);
            s.setDefaultFixedFontSize(b.defaultFixedFontSize);
            s.setNavDump(b.navDump);
            s.setTextSize(b.textSize);

            // OMS: use our own setDefaultZoomOMS
            // s.setDefaultZoom(b.zoomDensity);
            s.setDefaultZoomOMS(b.zoomDensity);
            
 /*           WebSettings.CharsetEncoding oldCharset = s.getCharsetEncoding();
            if (mBrowserActivity != null && b.charsetEncoding != oldCharset)
                mBrowserActivity.reload();

            s.setCharsetEncoding(b.charsetEncoding);
*/
            s.setLightTouchEnabled(b.lightTouch);
            s.setSaveFormData(b.saveFormData);
            s.setSavePassword(b.rememberPasswords);
            s.setLoadWithOverviewMode(b.loadsPageInOverviewMode);

            // WebView inside Browser doesn't want initial focus to be set.
            s.setNeedInitialFocus(false);
            // Browser supports multiple windows
            s.setSupportMultipleWindows(true);
            // OMS: Use product UA string
            WebSettings.setUseProductUserAgent(true);
        }
    }
    
    public void setBrowserActivity(BrowserActivity ba) {
        mBrowserActivity = ba;
    }
   
    /**
     * Load settings from the browser app's database.
     * NOTE: Strings used for the preferences must match those specified
     * in the browser_preferences.xml
     * @param ctx A Context object used to query the browser's settings
     *            database. If the database exists, the saved settings will be
     *            stored in this BrowserSettings object. This will update all
     *            observers of this object.
     */
    public void loadFromDb(Context ctx) {
        SharedPreferences p = 
                PreferenceManager.getDefaultSharedPreferences(ctx);

        // Set the default value for the plugins path to the application's
        // local directory.
        pluginsPath = ctx.getDir("plugins", 0).getPath();

        // OMS: We don't need this.
        //homeUrl += Partner.getString(ctx.getContentResolver(), Partner.CLIENT_ID);

        // Load the defaults from the xml
        // This call is TOO SLOW, need to manually keep the defaults
        // in sync
        //PreferenceManager.setDefaultValues(ctx, R.xml.browser_preferences);
        syncSharedPreferences(p);

        // OMS: Load DM properties to keep in sync.
        loadDMProperties(ctx);
    }

    /* package */ void syncSharedPreferences(SharedPreferences p) {

    	downloadDir = p.getString(PREF_DOWNLOAD_DIR, downloadDir);
        homeUrl =
            p.getString(PREF_HOMEPAGE, homeUrl);

        loadsImagesAutomatically = p.getBoolean("load_images",
                loadsImagesAutomatically);
        // fitScreenWidthEnabled = p.getBoolean("fit_screen_width", 
        //         fitScreenWidthEnabled);
        javaScriptEnabled = p.getBoolean("enable_javascript", 
                javaScriptEnabled);
        pluginsEnabled = p.getBoolean(BrowserSettings.PREF_ENABLE_PLUGINS,
                pluginsEnabled);
        pluginsPath = p.getString("plugins_path", pluginsPath);
        javaScriptCanOpenWindowsAutomatically = !p.getBoolean(
            "block_popup_windows",
            !javaScriptCanOpenWindowsAutomatically);
        showSecurityWarnings = p.getBoolean("show_security_warnings",
                showSecurityWarnings);
        rememberPasswords = p.getBoolean("remember_passwords",
                rememberPasswords);
        saveFormData = p.getBoolean("save_formdata",
                saveFormData);
        boolean accept_cookies = p.getBoolean("accept_cookies",
                CookieManager.getInstance().acceptCookie());
        CookieManager.getInstance().setAcceptCookie(accept_cookies);
        openInBackground = p.getBoolean("open_in_background", openInBackground);
        loginInitialized = p.getBoolean("login_initialized", loginInitialized);
        textSize = WebSettings.TextSize.valueOf(
                p.getString(PREF_TEXT_SIZE, textSize.name()));
        zoomDensity = WebSettings.ZoomDensity.valueOf(
                p.getString(PREF_DEFAULT_ZOOM, zoomDensity.name()));
        orientation = p.getInt("orientation", orientation);
        autoFitPage = p.getBoolean("autofit_pages", autoFitPage);
        loadsPageInOverviewMode = p.getBoolean("fit_screen_width",
                loadsPageInOverviewMode);
        useWideViewPort = true; // use wide view port for either setting
        if (autoFitPage) {
            layoutAlgorithm = WebSettings.LayoutAlgorithm.NARROW_COLUMNS;
        } else {
            layoutAlgorithm = WebSettings.LayoutAlgorithm.NORMAL;
        }
        defaultTextEncodingName =
                p.getString(PREF_DEFAULT_TEXT_ENCODING,
                        defaultTextEncodingName);

        showDebugSettings =
                p.getBoolean(PREF_DEBUG_SETTINGS, showDebugSettings);
        // Debug menu items have precidence if the menu is visible
        if (showDebugSettings) {
            boolean small_screen = p.getBoolean("small_screen",
                    layoutAlgorithm ==
                    WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
            if (small_screen) {
                layoutAlgorithm = WebSettings.LayoutAlgorithm.SINGLE_COLUMN;
            } else {
                boolean normal_layout = p.getBoolean("normal_layout",
                        layoutAlgorithm == WebSettings.LayoutAlgorithm.NORMAL);
                if (normal_layout) {
                    layoutAlgorithm = WebSettings.LayoutAlgorithm.NORMAL;
                } else {
                    layoutAlgorithm =
                            WebSettings.LayoutAlgorithm.NARROW_COLUMNS;
                }
            }
            useWideViewPort = p.getBoolean("wide_viewport", useWideViewPort);
            tracing = p.getBoolean("enable_tracing", tracing);
            lightTouch = p.getBoolean("enable_light_touch", lightTouch);
            navDump = p.getBoolean("enable_nav_dump", navDump);
            doFlick = p.getBoolean("enable_flick", doFlick);
            userAgent = Integer.parseInt(p.getString("user_agent", "0"));
            // merge-todo mTabControl.getBrowserActivity().setBaseSearchUrl(
                   // p.getString("search_url", ""));
        }
        String tmp = p.getString(PREF_DATA_CONNECTION, DEFAULT_DATA_CONNECTION_STR);
        Log.e("BrowserSettings", "BrowserSettings, data conn="+tmp);
       // dataConnectionId = p.getString(PREF_DATA_CONNECTION, Phone.APN_TYPE_INTERNET); 
        searchPortal = Integer.parseInt(p.getString(PREF_SEARCH_PORTAL, "1"));
        
        browserDownloadAudiovideo = p.getBoolean("browser_download_audiovideo", browserDownloadAudiovideo);

        mBrightness = p.getInt(PREF_BRIGHTNESS, mBrightness);
        
        update();
    }

    public String getPluginsPath() {
        return pluginsPath;
    }

    /*
            When the homeUrl is equals with cmcc's homepage, we will decide which page to be returned:home.htm(for the smaller screen)
          or home.html(for the larger screen)
            screenWidthThreshold is the threshold value between the "smaller" and "larger"
      */
    //private int screenWidthThreshold = 400;
    public String getHomePage() {
/* TODO:
        if(null != homeUrl && 0 != homeUrl.length() && 
            homeUrl.equalsIgnoreCase(DEFAULT_HOMEPAGE) && BrowserActivity.mScreenWidth < screenWidthThreshold){
            return DEFAULT_HOMEPAGE_SMALL;
        }
*/
        if ((null != homeUrl) && (homeUrl.length() == 0)) { // homepage is ""
            return "about:blank";
        }
        return homeUrl;
    }

    public String chooseDefaultHomePage() {
/*
        if(BrowserActivity.mScreenWidth < screenWidthThreshold){
            return DEFAULT_HOMEPAGE_SMALL;
        }
*/
        return DEFAULT_HOMEPAGE;
    }

    public void setHomePage(Context context, String url) {
        Editor ed = PreferenceManager.
                getDefaultSharedPreferences(context).edit();      
        ed.putString(PREF_HOMEPAGE, url);
        ed.commit();
        homeUrl = url;

        // OMS: Update provider if needed.
        if(DM_ENABLED) {
            Browser.setBrowserProperty(context.getContentResolver(), 
                    Browser.PROP_HOMEPAGE, url);
        }
    }

    public void setBrightness(Context context, int value) {
        Editor ed = PreferenceManager.
            getDefaultSharedPreferences(context).edit();
        ed.putInt(PREF_BRIGHTNESS, value);
        ed.commit();

        mBrightness = value;
    }

    public int getBrightness() {
        return mBrightness;
    }
    
    public int getSearchPortal() {
        return searchPortal;
    }
    
    public void setSearchPortal(Context context, int s) {
        Editor ed = PreferenceManager.
            getDefaultSharedPreferences(context).edit();      
        ed.putInt(PREF_SEARCH_PORTAL, s);
        ed.commit();
        searchPortal = s;
    }

    public int getHistorySort() {
        return mHistorySort;
    }

    public void setHistorySort(Context context, int s) {
        Editor ed = PreferenceManager.
            getDefaultSharedPreferences(context).edit();      
        ed.putInt(PREF_HISTORY_SORT, s);
        ed.commit();
        mHistorySort = s;
    }

    // Queries the data connection even before BrowserSettings is init'd.
    public String getDataConnectionStr(Context context) {
        String dc = PreferenceManager.getDefaultSharedPreferences(
                context).getString(PREF_DATA_CONNECTION, DEFAULT_DATA_CONNECTION_STR);
        return dc;
    }
    
    public boolean isLoginInitialized() {
        return loginInitialized;
    }

    public void setLoginInitialized(Context context) {
        loginInitialized = true;
        Editor ed = PreferenceManager.
                getDefaultSharedPreferences(context).edit();      
        ed.putBoolean("login_initialized", loginInitialized);
        ed.commit();
    }
    
    public int getCurrentTabMode(Context ctx){
    	   SharedPreferences p = 
            PreferenceManager.getDefaultSharedPreferences(ctx);
    	   int mode = p.getInt(BrowserTabView.TAB_PREFERENCE_STR_KEY, BrowserTabView.TAB_GALLERY_MODE);
    	   return mode;
    }

    public void setTabModePreference(Context context, int mod){
        Editor ed = PreferenceManager.
                getDefaultSharedPreferences(context).edit();
        ed.putInt(BrowserTabView.TAB_PREFERENCE_STR_KEY, mod);
        ed.commit();
    }
    
    public int getOrientation() {
        return orientation;
    }
    
    public void setOrientation(Context context, int o) {
        if (orientation == o) {
            return;
        }
        orientation = o;
        Editor ed = PreferenceManager.
                getDefaultSharedPreferences(context).edit();      
        ed.putInt("orientation", orientation);
        ed.commit();
    }
    
    public WebSettings.TextSize getTextSize() {
        return textSize;
    }

    public WebSettings.ZoomDensity getDefaultZoom() {
        return zoomDensity;
    }

    public boolean openInBackground() {
        return openInBackground;
    }

    public boolean showSecurityWarnings() {
        return showSecurityWarnings;
    }

    public boolean isTracing() {
        return tracing;
    }

    public boolean isLightTouch() {
        return lightTouch;
    }

    public boolean isNavDump() {
        return navDump;
    }

    public boolean doFlick() {
        return doFlick;
    }

    public boolean showDebugSettings() {
        return showDebugSettings;
    }

    public void toggleDebugSettings() {
        showDebugSettings = !showDebugSettings;
        navDump = showDebugSettings;
        update();
    }

    /**
     * Add a WebSettings object to the list of observers that will be updated
     * when update() is called.
     *
     * @param s A WebSettings object that is strictly tied to the life of a
     *            WebView.
     */
    public Observer addObserver(WebSettings s) {
        Observer old = mWebSettingsToObservers.get(s);
        if (old != null) {
            super.deleteObserver(old);
        }
        Observer o = new Observer(s);
        mWebSettingsToObservers.put(s, o);
        super.addObserver(o);
        return o;
    }

    /**
     * Delete the given WebSettings observer from the list of observers.
     * @param s The WebSettings object to be deleted.
     */
    public void deleteObserver(WebSettings s) {
        Observer o = mWebSettingsToObservers.get(s);
        if (o != null) {
            mWebSettingsToObservers.remove(s);
            super.deleteObserver(o);
        }
    }

    /*
     * Package level method for obtaining a single app instance of the
     * BrowserSettings.
     */
    /*package*/ static BrowserSettings getInstance() {
        if (sSingleton == null ) {
            sSingleton = new BrowserSettings();
        }
        return sSingleton;
    }

    /*
     * Package level method for associating the BrowserSettings with TabControl
     */
    /* package */void setTabControl(TabControl tabControl) {
        mTabControl = tabControl;
    }

    /*
     * Update all the observers of the object.
     */
    /*package*/ void update() {
        setChanged();
        notifyObservers();
    }

    /*package*/ void clearCache(Context context) {
        WebIconDatabase.getInstance().removeAllIcons();
        if (mTabControl != null) {
            WebView current = mTabControl.getCurrentWebView();
            if (current != null) {
                current.clearCache(true);
            }
        }
    }

    /*package*/ void clearCookies(Context context) {
        CookieManager.getInstance().removeAllCookie();
    }

    /* package */void clearHistory(Context context) {
        ContentResolver resolver = context.getContentResolver();
        Browser.clearHistory(resolver);
        Browser.clearSearches(resolver);
    }

    /* package */ void clearFormData(Context context) {
        WebViewDatabase.getInstance(context).clearFormData();
        if (mTabControl != null) {
            mTabControl.getCurrentTopWebView().clearFormData();
        }
    }

    /*package*/ void clearPasswords(Context context) {
        WebViewDatabase db = WebViewDatabase.getInstance(context);
        db.clearUsernamePassword();
        db.clearHttpAuthUsernamePassword();
    }

    /*package*/ void resetDefaultPreferences(Context context) {
        SharedPreferences p =
            PreferenceManager.getDefaultSharedPreferences(context);
        p.edit().clear().commit();
        PreferenceManager.setDefaultValues(context, R.xml.browser_preferences,
                true);

        p.edit().putString(PREF_DATA_CONNECTION, DEFAULT_DATA_CONNECTION_STR).commit();

        // OMS: We may reset network profile here; but just leave to browser activity.
        //NetworkManager.peekInstance().resetNetworkProfile();

        // OMS: Reset values for DM.
        setHomePage(context, DEFAULT_HOMEPAGE);
        Browser.setBrowserProperty(context.getContentResolver(), 
                Browser.PROP_DATA_CONNECTION, DEFAULT_DATA_CONNECTION_STR);
    }

    // Private constructor that does nothing.
    private BrowserSettings() {
        homeUrl = DEFAULT_HOMEPAGE;
        defaultFontSize = SystemProperties.getInt("apps.browser.default_font_size", 16);
    }

    // Clear browser data
    /*package*/ void clearBrowserData(Context context) {
        clearCache(context);
        clearCookies(context);
        clearHistory(context);
        clearFormData(context);
        clearPasswords(context);
    }
    
    // OMS: Load DM properties from browser provider.
    // Always call this after loadFromDb() during start-up.
    public void loadDMProperties(Context ctx) {
        if(!DM_ENABLED) {
            return;
        }
        //1. homepage
        String dmHome = Browser.getBrowserProperty(ctx.getContentResolver(), 
                Browser.PROP_HOMEPAGE);
        if(dmHome != null && !dmHome.equals(homeUrl)) {
            homeUrl = dmHome;
            Editor ed = PreferenceManager.
                    getDefaultSharedPreferences(ctx).edit();      
            ed.putString(PREF_HOMEPAGE, homeUrl);
            ed.commit();
        }
        //2. data connection
        String dmProfile = Browser.getBrowserProperty(ctx.getContentResolver(), 
                Browser.PROP_DATA_CONNECTION);
        if(dmProfile != null && 
                !dmProfile.equals(getDataConnectionStr(ctx))) {
            Editor ed = PreferenceManager.
                    getDefaultSharedPreferences(ctx).edit();      
            ed.putString(PREF_DATA_CONNECTION, dmProfile);
            ed.commit();
        }
    }

    // OMS: A wrapper method to update browser provider for DM
    public void updateDMProperties(ContentResolver cr, 
            String key, String value) {
        Browser.setBrowserProperty(cr, key, value);
    }

    public String getStorePath(){
    	return downloadDir;    	
    }

    public boolean isBrowserDownloadAudiovideo() {
        return browserDownloadAudiovideo;
    }
}
