
package com.android.browser;

import android.content.Context;
import android.preference.EditTextPreference;
import android.util.AttributeSet;
import android.text.InputType;

class BrowserEditTextPreference extends EditTextPreference {
    // This is the constructor called by the inflater
    public BrowserEditTextPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
        String key = getKey();
        if(key.equals(BrowserSettings.PREF_HOMEPAGE)) {
            // merge-todo getEditText().setContentType(TextBoxAttribute.CONTENT_TYPE_WEB_URL);
            getEditText().setInputType(InputType.TYPE_TEXT_VARIATION_URI | InputType.TYPE_CLASS_TEXT);
        }
    }

}
