
package com.android.browser;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class MonternetLauncherActivity extends Activity {

    /* package */static String DEFAULT_DATA_CONNECTION = "wap";
    /* package */static String DEFAULT_LAUNCH_PAGE = "http://wap.monternet.com/?cp22=v22monternet";

    @Override 
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        
        Intent intent = new Intent(Intent.ACTION_VIEW, 
                Uri.parse(DEFAULT_LAUNCH_PAGE));
        //intent.addCategory(Intent.CATEGORY_BROWSABLE);
        intent.putExtra("data_connection", DEFAULT_DATA_CONNECTION);
        intent.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
        try {
            //sendBroadcast(intent); 
            startActivity(intent);
        }catch(Exception ee) {
        }
        finish();
    }

}

