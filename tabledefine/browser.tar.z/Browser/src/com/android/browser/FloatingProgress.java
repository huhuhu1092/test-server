
package com.android.browser;

import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.view.animation.AlphaAnimation;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

class FloatingProgress extends LinearLayout {

    // Default layout params.
    public static final FrameLayout.LayoutParams DEFAULT_PARAMS =
        new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);

    private ProgressBar mProgress;
    protected BrowserActivity mContext;
    static private FloatingProgress mInstance;

    /*
    public static FloatingProgress getInstance(Context context) {
        if(mInstance == null) {
            mInstance = new FloatingProgress(context, null);
        }
        return mInstance;
    }*/

    FloatingProgress(Context context, AttributeSet attrs) {
        super(context, attrs);

        setLayoutParams(DEFAULT_PARAMS);
        mContext = (BrowserActivity)context;

        LayoutInflater inflater = (LayoutInflater) mContext
        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.floating_progress, this, true);
        mProgress = (ProgressBar) findViewById(R.id.progress);
        mProgress.setIndeterminate(false);
    }

    public void setProgress(int progress) {
        if(mProgress == null) {
            return;
        }

        if(getVisibility() != VISIBLE) {
            show();
        }
        mProgress.setProgress(progress);
        if(progress >= 10000) {
            hide();
        }
    }

    public void show() {
        //Log.e("aaa", "show: " + getVisibility());
        if(getVisibility() == View.VISIBLE) {
            return;
        }
        fade(View.VISIBLE, 0.0f, 1.0f);
    }
    
    public void hide() {
        //Log.e("aaa", "hide: " + getVisibility());
        if(getVisibility() != View.VISIBLE) {
            return;
        }
        fade(View.GONE, 1.0f, 0.0f);
    }
    
    private void fade(int visibility, float startAlpha, float endAlpha) {
        AlphaAnimation anim = new AlphaAnimation(startAlpha, endAlpha);
        anim.setDuration(500);
        startAnimation(anim);
        setVisibility(visibility);
    }
}
