package com.android.browser;
public interface BrowserTabViewListener {
   /**
    * Called when enter is pressed on the list.
    * @param position  The index of the selected image when
    *                  enter is pressed.
   */
    void onClick(int position);

    /**
    * Called when remove is called on the grid.
    */
    void remove(int position);
}

