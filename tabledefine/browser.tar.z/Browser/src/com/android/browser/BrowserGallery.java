package com.android.browser;

import android.widget.Gallery;
import android.widget.AdapterView.OnItemClickListener;
import android.content.Context;
import android.widget.AdapterView;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuInflater;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.view.KeyEvent;
import android.util.Log;
import android.view.MotionEvent;
import android.graphics.Rect;
import android.widget.TextView;
import android.widget.Button;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;

public class BrowserGallery extends Gallery implements BrowserTabView,OnItemClickListener,OnCreateContextMenuListener{
    private BrowserTabViewListener     mListener;
    private ImageAdapter mAdapter;
    private boolean      mIsLive;
    private BrowserActivity mActivity;
    private FrameLayout     mContentView;
    private TabControl mTabControl;
    private static final int SPACING = 35;
    private boolean mInAnimation = false;
    private static final FrameLayout.LayoutParams LAYOUT_PARAM = 
        new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                                     ViewGroup.LayoutParams.WRAP_CONTENT);
    private int mCurrentIndex = 0;
    public static boolean shouldOpen = false;
    private BrowserSettings mSettings = BrowserSettings.getInstance();
    private int mScreenHeight = 0;
    private float mGallryHeightFactor = 0.86f;
    private OnItemSelectedListener mItemSelectedListener = new AdapterView.OnItemSelectedListener(){
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id){
            setPageTextView(position+1);
            mCurrentIndex = position;
        }
        public void onNothingSelected(AdapterView<?> parent){

        }
    };

    private Button mNewTab = null;
    private Button mBack = null;
    private TextView mPageTextView = null;
    private View mGalleryBottomView = null;
    private View.OnClickListener mNewTabBtnListener = new View.OnClickListener(){
        public void onClick(View v){
        	   addEmptyTabItem();
        }
    };

    private View.OnClickListener mBackBtnListener = new View.OnClickListener(){
        public void onClick(View v){
            getListener().onClick(CANCEL);
        }
    };
            
    public void initButtons(){
        if(mGalleryBottomView != null){
        	    mContentView.removeView(mGalleryBottomView);
        }
        mGalleryBottomView = LayoutInflater.from(mActivity).inflate(R.layout.gallery_bottom_view, null);
        FrameLayout.LayoutParams params = 
            new FrameLayout.LayoutParams( 
                ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM );
        mContentView.addView(mGalleryBottomView,params);
        mGalleryBottomView.setVisibility(View.VISIBLE);
        mNewTab = (Button)mGalleryBottomView.findViewById(R.id.newtab);
        mBack = (Button)mGalleryBottomView.findViewById(R.id.back);
        mPageTextView = (TextView)mGalleryBottomView.findViewById(R.id.pageno);
        mNewTab.setOnClickListener(mNewTabBtnListener);
        mBack.setOnClickListener(mBackBtnListener);   
        updateNewTabBtn();
    }

    public void removeChildViews(){
        mContentView.removeView(mGalleryBottomView);
    }

    public void updateNewTabBtn(){
        if(mTabControl.getTabCount() == TabControl.MAX_TABS){
            mNewTab.setEnabled(false);
        }else{
            mNewTab.setEnabled(true);
        }
    }

    private void addEmptyTabItem(){
        TabControl.Tab newTab = mTabControl.createNewTab(false,null,mSettings.getHomePage());
        add(newTab);
        mActivity.loadUrlInternal(newTab.getWebView(), mSettings.getHomePage(), true);
        BrowserGallery.shouldOpen = true;
        updateNewTabBtn();
        scrollToChild(mTabControl.getTabIndex(newTab));
    }

    public void setPageTextView(int pos){
        mPageTextView.setText(pos+"/"+mTabControl.getTabCount());
    }
    

    @Override
    public void onFlingEnd() {
        super.onFlingEnd();        
        if(shouldOpen && mListener != null && mAdapter != null){
            mListener.onClick(mAdapter.getCount()-1);
            shouldOpen = false;
            mInAnimation = false;
        }
    }

    public BrowserGallery(Context context, boolean live, BrowserTabViewListener l, FrameLayout parentView, TabControl tc){
        super(context);
        mIsLive = live;
        if (live) {
            setFocusable(true);
            setFocusableInTouchMode(true);
            setOnItemClickListener(this);
            setOnCreateContextMenuListener(this);
        }
        mListener = l;
        mActivity = (BrowserActivity)context;
        mAdapter = new ImageAdapter(context, this, live);
        setAdapter(mAdapter);
        setBackgroundColor(0xFF000000);
        setSpacing(SPACING);
        setOnItemSelectedListener(mItemSelectedListener);

        mContentView = parentView;
        mTabControl = tc;
    }
	
    public void onConfigrationChanged(){
        mActivity.closeOptionsMenu();
        BrowserSettings mSettings = BrowserSettings.getInstance();
        mSettings.setTabModePreference(mActivity, BrowserTabView.TAB_GALLERY_LAND_MODE);
    }


    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        // We always consume the BACK key even if mListener is null or the
        // ImageGrid is not "live." This prevents crashes during tab animations
        // if the user presses BACK.
        if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                (event.getKeyCode() == KeyEvent.KEYCODE_BACK)) {
            if (mListener != null && mIsLive) {
                mListener.onClick(CANCEL);
                invalidate();
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }
    
    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        float fix_x=0;
        if(velocityX >1000 && velocityX <3000) 
        	    fix_x = 1200;
        else if(velocityX < -1000 && velocityX > -3000)
        	    fix_x = -1200;
        else fix_x = velocityX;
        return super.onFling( e1,  e2,  fix_x ,velocityY); 
    }

    public void add(TabControl.Tab t){
        mAdapter.add(t);
    }
 
    public void remove(int index){
        mAdapter.remove(index);
    }

    public void setCurrentIndex(int startingIndex){
        setSelection(startingIndex);
    }

    public int getCurrentIndex(){
        return mCurrentIndex;
    }

    public BrowserTabViewListener getListener() {
        return mListener;
    }

    public void setListener(BrowserTabViewListener l) {
        mListener = l;
    }

    /**
     * Return true if the ImageGrid is live. This means that tabs can be chosen
     * and the menu can be invoked.
     */
    public boolean isLive() {
        return mIsLive;
    }

    /**
     * Do some internal cleanup of the ImageGrid's adapter.
     */
    public void clear() {
        mAdapter.clear();
    }

    public void onItemClick(AdapterView parent, View v, int position, long id) {
        if (mListener != null) {
            mListener.onClick(position);
        }
    }

    private static int getCenterOfView(View view) {
        return view.getLeft() + view.getWidth() / 2;
    }

    private int getCenterOfGallery() {
        return (getWidth() - mPaddingLeft - mPaddingRight) / 2 + mPaddingLeft;
    }

    public void scrollToChild(int childPosition ) {
        mInAnimation = true;
        View v = getChildAt(0);
        int distance = (v.getWidth() + SPACING)*(mCurrentIndex -childPosition);
        int pos = Math.abs(mCurrentIndex-childPosition);
        int durFactor = 2*pos;
        setAnimationDuration(400+100*durFactor);
        flingTo( distance);
    }

    public FrameLayout.LayoutParams getLayoutParams(){
        return new FrameLayout.LayoutParams(
             ViewGroup.LayoutParams.FILL_PARENT,
             ViewGroup.LayoutParams.FILL_PARENT);
    }

    /* (non-Javadoc)
     * @see android.view.View.OnCreateContextMenuListener#onCreateContextMenu(android.view.ContextMenu, android.view.View, java.lang.Object)
     */
    public void onCreateContextMenu(ContextMenu menu, View v, 
            ContextMenuInfo menuInfo) {
        // Do not create the context menu if there is no listener or the Tab
        // overview is not "live."
        if (mListener == null || !mIsLive) {
            return;
        }
        AdapterView.AdapterContextMenuInfo info = 
                (AdapterView.AdapterContextMenuInfo) menuInfo;

        MenuInflater inflater = new MenuInflater(mContext);
        inflater.inflate(R.menu.tabscontext, menu);
        int position = info.position;
        menu.setHeaderTitle(mAdapter.mItems.get(position).getTitle());
    }

    // convert a context menu position to an actual tab position. Since context
    // menus are not created for the "New Tab" cell, this will always return a
    // valid tab position.
    public int getContextMenuPosition(MenuItem menu) {
        AdapterView.AdapterContextMenuInfo info =
                (AdapterView.AdapterContextMenuInfo) menu.getMenuInfo();
        int pos = info.position;
        return pos;
    }

    public boolean isInMoving(){
        return mInAnimation;
    }
}
