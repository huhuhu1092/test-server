/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser;

import java.util.List;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemProperties;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceCategory;
import android.preference.PreferenceManager;
import android.widget.Toast;
import android.webkit.WebView;
import android.webkit.Plugin;
import android.util.Log;
import android.provider.Browser;

import android.preference.ListPreference;

public class BrowserPreferencesPage extends PreferenceActivity
        implements Preference.OnPreferenceChangeListener, 
        Preference.OnPreferenceClickListener {

    final static int GET_DOWNLOAD_DIR = 1;

    // To tell BrowserActivity if reload() is needed.
    private boolean mCharsetEncodingChanged = false;
    private Intent mReturnedIntent;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // OMS: Request for orientation sensor
        //super.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);

        // OMS: Update from DM provider first, if needed.
        BrowserSettings.getInstance().loadDMProperties(this);

        // Load the XML preferences file
        addPreferencesFromResource(R.xml.browser_preferences);

        Preference e = findPreference(BrowserSettings.PREF_HOMEPAGE);
        e.setOnPreferenceChangeListener(this);
        String homeUrl = getPreferenceScreen().getSharedPreferences()
                .getString(BrowserSettings.PREF_HOMEPAGE, null);
        e.setSummary(homeUrl);

        /*
        e = findPreference(BrowserSettings.PREF_PRELOADED_HOMEPAGE);
        e.setOnPreferenceChangeListener(this);
        if (homeUrl != null) {
            ((ListPreference)e).setValue(homeUrl);
        }*/

        e = findPreference(BrowserSettings.PREF_EXTRAS_RESET_DEFAULTS);
        e.setOnPreferenceChangeListener(this);
/*
        e = findPreference(BrowserSettings.PREF_TEXT_SIZE);
        e.setOnPreferenceChangeListener(this);
        e.setSummary(getVisualTextSizeName(
                getPreferenceScreen().getSharedPreferences()
                .getString(BrowserSettings.PREF_TEXT_SIZE, null)) );
*/
        e = findPreference(BrowserSettings.PREF_DEFAULT_ZOOM);
        e.setOnPreferenceChangeListener(this);
        e.setSummary(getVisualDefaultZoomName(
                getPreferenceScreen().getSharedPreferences()
                .getString(BrowserSettings.PREF_DEFAULT_ZOOM, null)) );

        e = findPreference(BrowserSettings.PREF_DEFAULT_TEXT_ENCODING);
        e.setOnPreferenceChangeListener(this);
        String encoding = getPreferenceScreen().getSharedPreferences().getString(BrowserSettings.PREF_DEFAULT_TEXT_ENCODING, null);
        String defaultEncoding = getText(R.string.pref_default_text_encoding_default).toString();
        if (encoding.equals(defaultEncoding) && e instanceof ListPreference) {
            ListPreference lp = (ListPreference)e;
            //int index = lp.findIndexOfValue(encoding);
            lp.setValueIndex(0);
            e.setSummary(getVisualTextEncodingName(defaultEncoding));
        } else {
            e.setSummary(getVisualTextEncodingName(encoding));
        }

        
        if (BrowserSettings.getInstance().showDebugSettings()) {
            addPreferencesFromResource(R.xml.debug_preferences);
        }

        // OMS: Disable Gears for now.
        //e = findPreference(BrowserSettings.PREF_GEARS_SETTINGS);
        //e.setOnPreferenceClickListener(this);
        e = findPreference(BrowserSettings.PREF_DATA_CONNECTION);
        e.setOnPreferenceChangeListener(this);
        String dc = getPreferenceScreen().getSharedPreferences().getString(BrowserSettings.PREF_DATA_CONNECTION, null);
        if (dc == null && e instanceof ListPreference) {
            ListPreference lp = (ListPreference)e;
            int index = lp.findIndexOfValue(BrowserSettings.DEFAULT_DATA_CONNECTION_STR);
            Log.d("BrowserPreferencePage", "index is "+index);
            lp.setValueIndex(index);
            dc = BrowserSettings.DEFAULT_DATA_CONNECTION_STR;
        }else {
            // Show the Entry instead of EntryValue.
            dc = getDataConnectionEntry((ListPreference)e, dc);
        }
        Log.d("BrowserPreferencePage", "will set summary, dc=" + dc);
        e.setSummary(dc);

        // OMS: Search portal settings.
        e = findPreference(BrowserSettings.PREF_SEARCH_PORTAL);
        e.setOnPreferenceChangeListener(this);
        e.setSummary(getVisualSearchPortalName(
                getPreferenceScreen().getSharedPreferences()
                .getString(BrowserSettings.PREF_SEARCH_PORTAL, null)) );
        
        e = findPreference(BrowserSettings.PREF_DOWNLOAD_DIR);
        if(null!=e){
        	e.setOnPreferenceClickListener(this);
        }
        e.setSummary(getPreferenceScreen().getSharedPreferences()
                .getString(BrowserSettings.PREF_DOWNLOAD_DIR, null));

        if (!SystemProperties.getBoolean("apps.browser.flash_enable", false)) {
            // OMS: remove setting enable_plugins 
            PreferenceCategory mainPref = (PreferenceCategory) findPreference(BrowserSettings.PREF_MENU_BASIC);
            CheckBoxPreference pluginPref = (CheckBoxPreference) findPreference(BrowserSettings.PREF_ENABLE_PLUGINS);
            mainPref.removePreference(pluginPref);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        // sync the shared preferences back to BrowserSettings
        BrowserSettings.getInstance().syncSharedPreferences(
                getPreferenceScreen().getSharedPreferences());
    }
    @Override
    protected void onNewIntent(Intent intent) {
        Log.d("Preference", "onNewIntent " + intent.getAction());
        if(intent.getAction().equals("reset_homepage")) {
            Preference e = findPreference(BrowserSettings.PREF_HOMEPAGE);
            String homeUrl = getPreferenceScreen().getSharedPreferences()
                    .getString(BrowserSettings.PREF_HOMEPAGE, null);
            e.setSummary(homeUrl);
            // Don't forget to update the text in the PreerenceDialog
            ((EditTextPreference)e).setText(homeUrl);
        }
    }
    public boolean onPreferenceChange(Preference pref, Object objValue) {
        if (pref.getKey().equals(BrowserSettings.PREF_EXTRAS_RESET_DEFAULTS)) {
            Boolean value = (Boolean) objValue;
            if (value.booleanValue() == true) {
                finish();
            }
        } else if (pref.getKey().equals(BrowserSettings.PREF_HOMEPAGE)) {
            String value = (String) objValue;
            boolean needUpdate = value.indexOf(' ') != -1;
            if (needUpdate) {
                value = value.trim().replace(" ", "%20");
            }
            if (value.length() != 0 && Uri.parse(value).getScheme() == null) {
                value = "http://" + value;
                needUpdate = true;
            }
            // Set the summary value.
            pref.setSummary(value);

            boolean returnValue = true;
            if (needUpdate) {
                // Update through the EditText control as it has a cached copy
                // of the string and it will handle persisting the value
                ((EditTextPreference) pref).setText(value);

                // OMS: update the preloaded_home with the homepage value to not check the preloaded lists if homepage value not in the preloaded URLs
                /*ListPreference e; 
                e = (ListPreference)findPreference(BrowserSettings.PREF_PRELOADED_HOMEPAGE);
                if(null!=e){
                    e.setValue(value);
                }*/

                // as we update the value above, we need to return false
                // here so that setText() is not called by EditTextPref
                // with the old value.
                returnValue = false;
            } else {
                returnValue = true;
            }

            // OMS: Update provider if needed.
            if(BrowserSettings.DM_ENABLED) {
                Browser.setBrowserProperty(getContentResolver(), Browser.PROP_HOMEPAGE, value);
            }
            /*if (value.length() == 0) {
                ListPreference e; 
                e = (ListPreference)findPreference(BrowserSettings.PREF_PRELOADED_HOMEPAGE);
                if(null!=e){
                    e.setValue(null);
                }
            }*/

            return returnValue;
        } else if (pref.getKey().equals(BrowserSettings.PREF_TEXT_SIZE)) {
            pref.setSummary(getVisualTextSizeName((String) objValue));
            // Show a informational toast here. Must keep the keyword "NORMAL" 
            // in sync with definition in resource.
            if(!"NORMAL".equals((String) objValue)) {
                Toast.makeText(this, 
                    R.string.text_size_change_warning, 
                    Toast.LENGTH_LONG).show();
            }
            return true;
        } else if (pref.getKey().equals(BrowserSettings.PREF_DEFAULT_ZOOM)) {
            pref.setSummary(getVisualDefaultZoomName((String) objValue));
            return true;
        } else if (pref.getKey().equals(
                BrowserSettings.PREF_DEFAULT_TEXT_ENCODING)) {
            pref.setSummary(getVisualTextEncodingName((String) objValue));
            mCharsetEncodingChanged= true;
            if(mCharsetEncodingChanged) {
                if(mReturnedIntent == null) {
                    mReturnedIntent = new Intent();
                }
                mReturnedIntent.putExtra("charset_changed", true);
                setResult(RESULT_OK, mReturnedIntent);
            }
            return true;
        } else if (pref.getKey().equals(BrowserSettings.PREF_SEARCH_PORTAL)) {
            pref.setSummary(getVisualSearchPortalName((String) objValue));
            return true;
        } else if(pref.getKey().equals(BrowserSettings.PREF_DATA_CONNECTION)) {
            //pref.setSummary((String) objValue);
            String value = getDataConnectionEntry((ListPreference)pref, (String)objValue);
            pref.setSummary(value);

            // OMS: Update DM provider if needed.
            if(BrowserSettings.DM_ENABLED) {
                Browser.setBrowserProperty(getContentResolver(), 
                        Browser.PROP_DATA_CONNECTION, value);
            }
            Log.d("BrowserPref", "data conn summary="+objValue);
            return true;
        } /*else if(pref.getKey().equals(BrowserSettings.PREF_PRELOADED_HOMEPAGE)) {
            Preference e = findPreference(BrowserSettings.PREF_HOMEPAGE);
            e.setSummary((String)objValue);
            ((EditTextPreference)e).setText((String)objValue);

            // OMS: Update provider if needed.
            if(BrowserSettings.DM_ENABLED) {
                Browser.setBrowserProperty(getContentResolver(), Browser.PROP_HOMEPAGE, (String)objValue);
            }

            return true;
        } */
        
        return false;
    }
    
    public boolean onPreferenceClick(Preference pref) {
        if (pref.getKey().equals(BrowserSettings.PREF_GEARS_SETTINGS)) {
            List<Plugin> loadedPlugins = WebView.getPluginList().getList();
            for(Plugin p : loadedPlugins) {
                if (p.getName().equals("gears")) {
                    p.dispatchClickEvent(this);
                    return true;
                }
            }
            
        }
        
        if (pref.getKey().equals(BrowserSettings.PREF_DOWNLOAD_DIR)) {
        	Intent intent_f = new Intent(Intent.ACTION_PICK);
			intent_f.setType("oms.filemanager/folderpick");
			
			//String t = new String("tmp.txt");
			//intent_f.putExtra("name", t); 
			//intent_f.putExtra("Location", "Phone"); 
			intent_f.putExtra("rmnametext", true);
			startActivityForResult(intent_f, GET_DOWNLOAD_DIR);

        }
        
        return true;
    }
   
    //for the customed preference of setting browser download directory 
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
    	String downloadDir;
        switch (requestCode) {
            case GET_DOWNLOAD_DIR:
                Log.d("onActivityResult", "GET_DOWNLOAD_DIR");
            	if (resultCode == RESULT_OK) {
					Uri uri = data.getData();
					downloadDir =	uri.getPath();
					//remove the "/tmp.txt" from the string("/sdcard/download/tmp.txt")
					if(downloadDir.charAt(downloadDir.length()-1) == '/'){
						downloadDir = downloadDir.substring(0, downloadDir.length()-1);
					}
					Log.d("onActivityResult", "downloadDir is " + downloadDir);
            	}else{
            		Log.d("onActivityResult", "resultCode is not Result_ok");
            		return;
            	}
                Preference e; 
                e = findPreference(BrowserSettings.PREF_DOWNLOAD_DIR);
                if(null!=e){
                	e.setSummary(downloadDir);
                	SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
                	String value = sharedPref.getString(BrowserSettings.PREF_DOWNLOAD_DIR, "/sdcard/download");
                	if(null!=value){
                		SharedPreferences.Editor editor = sharedPref.edit();
                		editor.putString(BrowserSettings.PREF_DOWNLOAD_DIR, downloadDir);
                		editor.commit();
                	}	
                }
                break;
            default:
                break;
        }

    }
    
    private CharSequence getVisualTextSizeName(String enumName) {
        CharSequence[] visualNames = 
                getResources().getTextArray(R.array.pref_text_size_choices);
        CharSequence[] enumNames = 
                getResources().getTextArray(R.array.pref_text_size_values);
        
        // Sanity check
        if (visualNames.length != enumNames.length) {
            return "";
        }
        
        for (int i = 0; i < enumNames.length; i++) {
            if (enumNames[i].equals(enumName)) {
                return visualNames[i];
            }
        }
        
        return "";
    }


    private CharSequence getVisualDefaultZoomName(String enumName) {
        CharSequence[] visualNames = getResources().getTextArray(
                R.array.pref_default_zoom_choices);
        CharSequence[] enumNames = getResources().getTextArray(
                R.array.pref_default_zoom_values);

        // Sanity check
        if (visualNames.length != enumNames.length) {
            return "";
        }

        for (int i = 0; i < enumNames.length; i++) {
            if (enumNames[i].equals(enumName)) {
                return visualNames[i];
            }
        }

        return "";
    }

    private CharSequence getVisualTextEncodingName(String enumName) {
        CharSequence[] visualNames = 
                getResources().getTextArray(R.array.pref_default_text_encoding_choices);
        CharSequence[] enumNames = 
                getResources().getTextArray(R.array.pref_default_text_encoding_values);
        
        // Sanity check
        if (visualNames.length != enumNames.length) {
            return "";
        }
        
        for (int i = 0; i < enumNames.length; i++) {
            if (enumNames[i].equals(enumName)) {
                return visualNames[i];
            }
        }
        return "";
    }

    private CharSequence getVisualSearchPortalName(String enumName) {
        CharSequence[] visualNames = 
                getResources().getTextArray(R.array.pref_search_portal_choices);
        CharSequence[] enumNames = 
                getResources().getTextArray(R.array.pref_search_portal_values);
        
        // Sanity check
        if (visualNames.length != enumNames.length) {
            return "";
        }
        
        for (int i = 0; i < enumNames.length; i++) {
            if (enumNames[i].equals(enumName)) {
                return visualNames[i];
            }
        }

        return "";
    }

    // Helper method
    private String getDataConnectionEntry(ListPreference pref, String entryValue) {
        int index = pref.findIndexOfValue(entryValue);

        String entry;
        CharSequence[] entries = pref.getEntries();
        if(index >= 0 && index < entries.length) {
            entry = entries[index].toString();
        }else {
            // This should not happen!
            entry = "";
        }
        return entry;
    }
}
