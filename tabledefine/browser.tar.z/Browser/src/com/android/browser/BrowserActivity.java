/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser;

//import com.google.android.googleapps.IGoogleLoginService;
//import com.google.android.googlelogin.GoogleLoginServiceConstants;
//import com.google.android.providers.GoogleSettings.Partner;
import com.android.internal.telephony.TelephonyIntents;
import com.android.internal.telephony.Phone;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.SearchManager;
import android.app.ProgressDialog;
import android.app.SearchDialog;
import android.content.SharedPreferences.Editor;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.content.DialogInterface.OnCancelListener;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DrawFilter;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Picture;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.PaintDrawable;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.net.Uri;
import android.net.WebAddress;
import android.net.http.EventHandler;
import android.net.http.SslCertificate;
import android.net.http.SslError;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Debug;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.Process;
import android.os.Debug;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.preference.PreferenceManager;
import android.provider.Telephony.Messaging;
import android.provider.Browser;
import android.provider.Contacts.Intents.Insert;
import android.provider.Contacts;
import android.provider.Downloads;
import android.provider.Settings;
import android.provider.MediaStore;
//Add for wtai begin
import android.provider.Contacts.Intents;
import android.provider.Contacts.People;
//Add for wtai end
import android.text.IClipboard;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.text.util.Regex;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;

//ANDROID_MOT_FLASHLITE
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.os.Vibrator;
import android.telephony.TelephonyManager;
import android.view.WindowManager;
import android.view.Display;
import android.webkit.MotWebView;
//end of ANDROID_MOT_FLASHLITE

import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.DownloadListener;
import android.webkit.HttpAuthHandler;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebHistoryItem;
import android.webkit.WebIconDatabase;
import android.webkit.WebSettings;
import android.webkit.WebViewDatabase;
import android.webkit.WebView;
//import android.webkit.WebViewExt;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.telephony.ServiceState;

import com.google.android.googleapps.IGoogleLoginService;
//import com.google.android.googleapps.GoogleLoginServiceConstants;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.net.URLDecoder;
import java.text.ParseException;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.StringTokenizer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;



public class BrowserActivity extends Activity
    implements KeyTracker.OnKeyTracker,
        View.OnCreateContextMenuListener,
        DownloadListener {

    final static String DCMTAG = "Browser";
    /* Define some aliases to make these debugging flags easier to refer to.
     * This file imports android.provider.Browser, so we can't just refer to "Browser.DEBUG".
     */
    private final static boolean DEBUG = com.android.browser.Browser.DEBUG;
    private final static boolean LOGV_ENABLED = com.android.browser.Browser.LOGV_ENABLED;
    private final static boolean LOGD_ENABLED = com.android.browser.Browser.LOGD_ENABLED;

    //private IGoogleLoginService mGls = null;
    //private ServiceConnection mGlsConnection = null;

    private SensorManager mSensorManager = null;
    //ANDROID_MOT_FLASHLITE
    private FlashBrowserActivity mFlashBrowserActivity;
    //end ANDROID_MOT_FLASHLITE
    private Vibrator vibrator = null;

    // These are single-character shortcuts for searching popular sources.
    private static final int SHORTCUT_INVALID = 0;
    private static final int SHORTCUT_GOOGLE_SEARCH = 1;
    private static final int SHORTCUT_WIKIPEDIA_SEARCH = 2;
    private static final int SHORTCUT_DICTIONARY_SEARCH = 3;
    private static final int SHORTCUT_GOOGLE_MOBILE_LOCAL_SEARCH = 4;

    /* Whitelisted webpages
    private static HashSet<String> sWhiteList;

    static {
        sWhiteList = new HashSet<String>();
        sWhiteList.add("cnn.com/");
        sWhiteList.add("espn.go.com/");
        sWhiteList.add("nytimes.com/");
        sWhiteList.add("engadget.com/");
        sWhiteList.add("yahoo.com/");
        sWhiteList.add("msn.com/");
        sWhiteList.add("amazon.com/");
        sWhiteList.add("consumerist.com/");
        sWhiteList.add("google.com/m/news");
    }
    */

    Handler getHandler() {
        return mHandler;
    }

    public void onNetworkChanged(boolean status) {
        if(mActivityDestroyed) {
            Log.w(DCMTAG, "onNetworkChanged: Activity destroyed!");
            return;
        }
        mHandler.post(new OnDataConnectionStatusChange(status));
    }

    public void onNetworkOpenResult(boolean b) {
        if(mActivityDestroyed) {
            Log.w(DCMTAG, "onNetworkOpenResult: Activity destroyed!");
            return;
        }
        mHandler.post(new OnDataConnectionOpenResult(b)); 
    }

    class OnDataConnectionStatusChange implements Runnable {
        private boolean mIsUp = false;
        OnDataConnectionStatusChange(boolean status) {
            mIsUp = status;
        }

        public void run() {
            Log.d(DCMTAG, "Network status changed: "+mIsUp);
            // TODO: Should we call it here?
            resumeAfterNetwork();
            if(mIsUp) {
                mTryConnectionOnResume = false;
                if (mSuspendedUrl != null && getCurrentWebView() != null) {
                    Log.d(DCMTAG, "call mWebView.loadUrl");
                    getCurrentWebView().loadUrl(mSuspendedUrl);
                    mSuspendedUrl = null;
                }
            }else {
                if(mInLoad) {
                    // Only stop loading from network.
                    WebView mainView = mTabControl.getCurrentWebView();
                    if (null != mainView) {
                        String url = mainView.getUrl();
                        if(url != null && url.startsWith("http")) {
                            stopLoading();
                        }
                    }
                }

                // Don't reconnect if we're in the background.
                if(mActivityInPause) {
                    mTryConnectionOnResume = true;
                    Log.w(LOGTAG, "Ignore the status_down message...");
                    return;
                }
                if((++mRetryCount) >= CONN_RETRY_COUNTS) {
                    // TODO: Any notifications??
                    Log.w(LOGTAG, "stop trying re-connect...");
                    mRetryCount = 0;
                    mSuspendedUrl = null;
                    return;
                }

                //We may need to load this URL if PDP is activated in the next trial.
                //mSuspendedUrl = null;
                connect();
            }
        }
    }

    class OnDataConnectionOpenResult implements Runnable {
            private boolean mSuccess = false;
        OnDataConnectionOpenResult(boolean s) {
            mSuccess = s;
        }

        public void run() {
            mRetryCount = 0;
            resumeAfterNetwork();
            if(mSuccess) {
                if(mSuspendedUrl != null && getCurrentWebView() != null) {
                    getCurrentWebView().loadUrl(mSuspendedUrl);
                    mSuspendedUrl = null;
                }
            }else {
                // Error msg is shown in NetworkManager
                Log.d(LOGTAG, "Data conenction open failed.");
                if(mInLoad) {
                    // Only stop loading from network.
                    WebView mainView = mTabControl.getCurrentWebView();
                    if (null != mainView) {
                        String url = mainView.getUrl();
                        if(url != null && url.startsWith("http")) {
                            stopLoading();
                        }
                    }
                }
            }
        }
    }

    private void setupHomePage() {
        mSettings.setLoginInitialized(this);
        /* OMS: we don't need the check-in service.
        final Runnable getAccount = new Runnable() {
            public void run() {
                // Lower priority
                Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                // get the default home page
                String homepage = mSettings.getHomePage();

                try {
                    if (mGls == null) return;

                    if (!homepage.startsWith("http://www.google.")) return;
                    if (homepage.indexOf('?') == -1) return;

                    String hostedUser = mGls.getAccount(GoogleLoginServiceConstants.PREFER_HOSTED);
                    String googleUser = mGls.getAccount(GoogleLoginServiceConstants.REQUIRE_GOOGLE);

                    // three cases:
                    //
                    //   hostedUser == googleUser
                    //      The device has only a google account
                    //
                    //   hostedUser != googleUser
                    //      The device has a hosted account and a google account
                    //
                    //   hostedUser != null, googleUser == null
                    //      The device has only a hosted account (so far)

                    // developers might have no accounts at all
                    if (hostedUser == null) return;

                    if (googleUser == null || !hostedUser.equals(googleUser)) {
                        String domain = hostedUser.substring(hostedUser.lastIndexOf('@')+1);
                        homepage = homepage.replace("?", "/a/" + domain + "?");
                    }
                } catch (RemoteException ignore) {
                    // Login service died; carry on
                } catch (RuntimeException ignore) {
                    // Login service died; carry on
                } finally {
                    finish(homepage);
                }
            }

            private void finish(final String homepage) {
                mHandler.post(new Runnable() {
                    public void run() {
                        mSettings.setHomePage(BrowserActivity.this, homepage);
                        resumeAfterCredentials();

                        // as this is running in a separate thread,
                        // BrowserActivity's onDestroy() may have been called,
                        // which also calls unbindService().
                        if (mGlsConnection != null) {
                            // we no longer need to keep GLS open
                            unbindService(mGlsConnection);
                            mGlsConnection = null;
                        }
                    } });
            } };

        final boolean[] done = { false };

        // Open a connection to the Google Login Service.  The first
        // time the connection is established, set up the homepage depending on
        // the account in a background thread.
        mGlsConnection = new ServiceConnection() {
            public void onServiceConnected(ComponentName className, IBinder service) {
                mGls = IGoogleLoginService.Stub.asInterface(service);
                if (done[0] == false) {
                    done[0] = true;
                    Thread account = new Thread(getAccount);
                    account.setName("GLSAccount");
                    account.start();
                }
            }
            public void onServiceDisconnected(ComponentName className) {
                mGls = null;
            }
        };

        bindService(GoogleLoginServiceConstants.SERVICE_INTENT,
                    mGlsConnection, Context.BIND_AUTO_CREATE);
        */
    }

    /**
     * This class is in charge of installing pre-packaged plugins
     * from the Browser assets directory to the user's data partition.
     * Plugins are loaded from the "plugins" directory in the assets;
     * Anything that is in this directory will be copied over to the
     * user data partition in app_plugins.
     */
    private class CopyPlugins implements Runnable {
        final static String TAG = "PluginsInstaller";
//        final static String ZIP_FILTER = "assets/plugins/";
//        final static String APK_PATH = "/system/app/Browser.apk";
        final static String PLUGIN_EXTENSION = ".so";
        final static String TEMPORARY_EXTENSION = "_temp";
        final static String BUILD_INFOS_FILE = "build.prop";
        final static String SYSTEM_BUILD_INFOS_FILE = "/system/"
                              + BUILD_INFOS_FILE;
        final static String PLUGIN_PATH = "/opl/lib/plugins/";
        final int BUFSIZE = 4096;
        boolean mDoOverwrite = false;
        String pluginsPath;
        Context mContext;
        File pluginsDir;
//        AssetManager manager;

        public CopyPlugins (boolean overwrite, Context context) {
            mDoOverwrite = overwrite;
            mContext = context;
        }

        /**
         * Returned a filtered list of ZipEntry.
         * We list all the files contained in the zip and
         * only returns the ones starting with the ZIP_FILTER
         * path.
         *
         * @param zip the zip file used.

        public Vector<ZipEntry> pluginsFilesFromZip(ZipFile zip) {
            Vector<ZipEntry> list = new Vector<ZipEntry>();
            Enumeration entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = (ZipEntry) entries.nextElement();
                if (entry.getName().startsWith(ZIP_FILTER)) {
                  list.add(entry);
                }
            }
            return list;
        }
        */

        /**
         * Utility method to copy the content from an inputstream
         * to a file output stream.
         */
        public void copyStreams(InputStream is, FileOutputStream fos) {
            BufferedOutputStream os = null;
            try {
                byte data[] = new byte[BUFSIZE];
                int count;
                os = new BufferedOutputStream(fos, BUFSIZE);
                while ((count = is.read(data, 0, BUFSIZE)) != -1) {
                    os.write(data, 0, count);
                }
                os.flush();
            } catch (IOException e) {
                Log.e(TAG, "Exception while copying: " + e);
            } finally {
              try {
                if (os != null) {
                    os.close();
                }
              } catch (IOException e2) {
                Log.e(TAG, "Exception while closing the stream: " + e2);
              }
            }
        }

        /**
         * Returns a string containing the contents of a file
         *
         * @param file the target file
         */
        private String contentsOfFile(File file) {
          String ret = null;
          FileInputStream is = null;
          try {
            byte[] buffer = new byte[BUFSIZE];
            int count;
            is = new FileInputStream(file);
            StringBuffer out = new StringBuffer();

            while ((count = is.read(buffer, 0, BUFSIZE)) != -1) {
              out.append(new String(buffer, 0, count));
            }
            ret = out.toString();
          } catch (IOException e) {
            Log.e(TAG, "Exception getting contents of file " + e);
          } finally {
            if (is != null) {
              try {
                is.close();
              } catch (IOException e2) {
                Log.e(TAG, "Exception while closing the file: " + e2);
              }
            }
          }
          return ret;
        }

        /**
         * Utility method to initialize the user data plugins path.
         */
        public void initPluginsPath() {
            BrowserSettings s = BrowserSettings.getInstance();
            pluginsPath = s.getPluginsPath();
            if (pluginsPath == null) {
                s.loadFromDb(mContext);
                pluginsPath = s.getPluginsPath();
            }
            if (LOGD_ENABLED) {
                Log.v(TAG, "Plugin path: " + pluginsPath);
            }
        }

        /**
         * Utility method to delete a file or a directory
         *
         * @param file the File to delete
         */
        public void deleteFile(File file) {
            File[] files = file.listFiles();
            if ((files != null) && files.length > 0) {
              for (int i=0; i< files.length; i++) {
                deleteFile(files[i]);
              }
            }
            if (!file.delete()) {
              Log.e(TAG, file.getPath() + " could not get deleted");
            }
        }

        /**
         * Clean the content of the plugins directory.
         * We delete the directory, then recreate it.
         */
        public void cleanPluginsDirectory() {
          if (LOGD_ENABLED) {
            Log.v(TAG, "delete plugins directory: " + pluginsPath);
          }
          File pluginsDirectory = new File(pluginsPath);
          deleteFile(pluginsDirectory);
          pluginsDirectory.mkdir();
        }


        /**
         * Copy the SYSTEM_BUILD_INFOS_FILE file containing the
         * informations about the system build to the
         * BUILD_INFOS_FILE in the plugins directory.
         */
        public void copyBuildInfos() {
          try {
            if (LOGD_ENABLED) {
              Log.v(TAG, "Copy build infos to the plugins directory");
            }
            File buildInfoFile = new File(SYSTEM_BUILD_INFOS_FILE);
            File buildInfoPlugins = new File(pluginsPath, BUILD_INFOS_FILE);
            copyStreams(new FileInputStream(buildInfoFile),
                        new FileOutputStream(buildInfoPlugins));
          } catch (IOException e) {
            Log.e(TAG, "Exception while copying the build infos: " + e);
          }
        }

        /**
         * Returns true if the current system is newer than the
         * system that installed the plugins.
         * We determinate this by checking the build number of the system.
         *
         * At the end of the plugins copy operation, we copy the
         * SYSTEM_BUILD_INFOS_FILE to the BUILD_INFOS_FILE.
         * We then just have to load both and compare them -- if they
         * are different the current system is newer.
         *
         * Loading and comparing the strings should be faster than
         * creating a hash, the files being rather small. Extracting the
         * version number would require some parsing which may be more
         * brittle.
         */
        public boolean newSystemImage() {
          try {
            File buildInfoFile = new File(SYSTEM_BUILD_INFOS_FILE);
            File buildInfoPlugins = new File(pluginsPath, BUILD_INFOS_FILE);
            if (!buildInfoPlugins.exists()) {
              if (LOGD_ENABLED) {
                Log.v(TAG, "build.prop in plugins directory " + pluginsPath
                  + " does not exist, therefore it's a new system image");
              }
              return true;
            } else {
              String buildInfo = contentsOfFile(buildInfoFile);
              String buildInfoPlugin = contentsOfFile(buildInfoPlugins);
              if (buildInfo == null || buildInfoPlugin == null
                  || buildInfo.compareTo(buildInfoPlugin) != 0) {
                if (LOGD_ENABLED) {
                  Log.v(TAG, "build.prop are different, "
                    + " therefore it's a new system image");
                }
                return true;
              }
            }
          } catch (Exception e) {
            Log.e(TAG, "Exc in newSystemImage(): " + e);
          }
          return false;
        }

        /**
         * OMS: Check if the version of the plugins contained in the
         * /opl/lib/plugins is the same as the version of the plugins
         * in the plugins directory.
         * We simply iterate on every file in the assets/plugins
         * and return false if a file listed in the assets does
         * not exist in the plugins directory.
         */
        private boolean checkIsDifferentVersions() {
        /*
          try {
            ZipFile zip = new ZipFile(APK_PATH);
            Vector<ZipEntry> files = pluginsFilesFromZip(zip);
            int zipFilterLength = ZIP_FILTER.length();

            Enumeration entries = files.elements();
            while (entries.hasMoreElements()) {
              ZipEntry entry = (ZipEntry) entries.nextElement();
              String path = entry.getName().substring(zipFilterLength);
              File outputFile = new File(pluginsPath, path);
              if (!outputFile.exists()) {
                if (LOGD_ENABLED) {
                  Log.v(TAG, "checkIsDifferentVersions(): extracted file "
                    + path + " does not exist, we have a different version");
                }
                return true;
              }
            }
          } catch (IOException e) {
            Log.e(TAG, "Exception in checkDifferentVersions(): " + e);
          }
         */
            File pluginDir = new File(PLUGIN_PATH);
            if (pluginDir.exists()) {
                File[] files = pluginDir.listFiles();
                if ((files != null) && files.length > 0) {
                    for (int i=0; i<files.length; i++) {
                        String path = files[i].getPath()
                            .substring(PLUGIN_PATH.length());
                        File outputFile = new File(pluginsPath, path);
                        if (!outputFile.exists()) {
                            Log.d(TAG, "checkIsDifferentVersions(): extracted file "
                                + path + " does not exist, we have a different version");
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        /**
         * Copy every files from the assets/plugins directory
         * to the app_plugins directory in the data partition.
         * Once copied, we copy over the SYSTEM_BUILD_INFOS file
         * in the plugins directory.
         *
         * NOTE: we directly access the content from the Browser
         * package (it's a zip file) and do not use AssetManager
         * as there is a limit of 1Mb (see Asset.h)
         */
        public void run() {
            // Lower the priority
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            try {
                if (pluginsPath == null) {
                    Log.e(TAG, "No plugins path found!");
                    return;
                }
/*
                ZipFile zip = new ZipFile(APK_PATH);
                Vector<ZipEntry> files = pluginsFilesFromZip(zip);
                Vector<File> plugins = new Vector<File>();
                int zipFilterLength = ZIP_FILTER.length();

                Enumeration entries = files.elements();
                while (entries.hasMoreElements()) {
                    ZipEntry entry = (ZipEntry) entries.nextElement();
                    String path = entry.getName().substring(zipFilterLength);
                    File outputFile = new File(pluginsPath, path);
                    outputFile.getParentFile().mkdirs();

                    if (outputFile.exists() && !mDoOverwrite) {
                        if (LOGD_ENABLED) {
                            Log.v(TAG, path + " already extracted.");
                        }
                    } else {
                        if (path.endsWith(PLUGIN_EXTENSION)) {
                            // We rename plugins to be sure a half-copied
                            // plugin is not loaded by the browser.
                            plugins.add(outputFile);
                            outputFile = new File(pluginsPath,
                                path + TEMPORARY_EXTENSION);
                        }
                        FileOutputStream fos = new FileOutputStream(outputFile);
                        if (LOGD_ENABLED) {
                            Log.v(TAG, "copy " + entry + " to "
                                + pluginsPath + "/" + path);
                        }
                        copyStreams(zip.getInputStream(entry), fos);
                    }
                }
*/
                // OMS: copy plugins from /opl/lib/plugins
                Vector<File> plugins = new Vector<File>();
                File pluginDir = new File(PLUGIN_PATH);
                if (pluginDir.exists()) {
                    File[] files = pluginDir.listFiles();
                    if ((files != null) && files.length > 0) {
                        for (int i=0; i<files.length; i++) {
                            String path = files[i].getPath()
                                .substring(PLUGIN_PATH.length());
                            File outputFile = new File(pluginsPath, path);
                            outputFile.getParentFile().mkdirs();
                            
                            if (outputFile.exists() && !mDoOverwrite) {
                                Log.d(TAG, path + " already extracted.");
                            } else {
                                if (path.endsWith(PLUGIN_EXTENSION)) {
                                    plugins.add(outputFile);
                                    outputFile = new File(pluginsPath,
                                        path + TEMPORARY_EXTENSION);
                                } 
                                FileOutputStream fos = new FileOutputStream(outputFile);
                                FileInputStream fis = new FileInputStream(files[i]);
                                Log.d(TAG, "copy " + files[i].getPath() + " to "
                                    + outputFile.getPath());
                                copyStreams(fis, fos);
                            }
                        }
                    }
                }
                
                // We now rename the .so we copied, once all their resources
                // are safely copied over to the user data partition.
                Enumeration elems = plugins.elements();
                while (elems.hasMoreElements()) {
                    File renamedFile = (File) elems.nextElement();
                    File sourceFile = new File(renamedFile.getPath()
                        + TEMPORARY_EXTENSION);
                    if (LOGD_ENABLED) {
                        Log.v(TAG, "rename " + sourceFile.getPath()
                            + " to " + renamedFile.getPath());
                    }
                    sourceFile.renameTo(renamedFile);
                }

                copyBuildInfos();

                // Refresh the plugin list.
                if (mTabControl.getCurrentWebView() != null) {
                    mTabControl.getCurrentWebView().refreshPlugins(false);
                }
            } catch (IOException e) {
                Log.e(TAG, "IO Exception: " + e);
            }
        }
    };

    /**
     * Copy the content of assets/plugins/ to the app_plugins directory
     * in the data partition.
     *
     * This function is called every time the browser is started.
     * We first check if the system image is newer than the one that
     * copied the plugins (if there's plugins in the data partition).
     * If this is the case, we then check if the versions are different.
     * If they are different, we clean the plugins directory in the
     * data partition, then start a thread to copy the plugins while
     * the browser continue to load.
     *
     * @param overwrite if true overwrite the files even if they are
     * already present (to let the user "reset" the plugins if needed).
     */
    private void copyPlugins(boolean overwrite) {
        CopyPlugins copyPluginsFromAssets = new CopyPlugins(overwrite, this);
        copyPluginsFromAssets.initPluginsPath();
        if (copyPluginsFromAssets.newSystemImage())  {
          if (copyPluginsFromAssets.checkIsDifferentVersions()) {
            copyPluginsFromAssets.cleanPluginsDirectory();
            Thread copyplugins = new Thread(copyPluginsFromAssets);
            copyplugins.setName("CopyPlugins");
            copyplugins.start();
          }
        }
    }

    private static class ClearThumbnails extends AsyncTask<File, Void, Void> {
        @Override
        public Void doInBackground(File... files) {
            if (files != null) {
                for (File f : files) {
                    if (!f.delete()) {
                      Log.e(LOGTAG, f.getPath() + " was not deleted");
                    }
                }
            }
            return null;
        }
    }

    // OMS: We only so some light-weight initialization in onCreate(); do the
    // rests after onWindowFocusChanged(), i.e. basic UI is visible to users.
    boolean STARTUP_ENHANCEMENT = true;
    boolean mInitialized = false;
    Bundle mStartupBundle;

    /**
     * This layout holds everything you see below the status bar, including the
     * error console, the custom view container, and the webviews.
     */
    private FrameLayout mBrowserFrameLayout;

    @Override public void onCreate(Bundle icicle) {
        if (LOGV_ENABLED) {
            Log.v(LOGTAG, this + " onStart");
        }
        long start = SystemClock.uptimeMillis();// for debug only

        super.onCreate(icicle);
        Log.e(LOGTAG, "BrowserActivity.onCreate: this = " + this);

        //ANDROID_MOT_FLASHLITE
        getWindow().setFormat(PixelFormat.TRANSLUCENT);
        //end of ANDROID_MOT_FLASHLITE

        mKillProcessAfterExited = false;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_MULTI_TOUCH);

        // OMS: Request for orientation sensor
        //super.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);

        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // test the browser in OpenGL
        // requestWindowFeature(Window.FEATURE_OPENGL);

        setDefaultKeyMode(DEFAULT_KEYS_SEARCH_LOCAL);
        mResolver = getContentResolver();

        //
        // start MASF proxy service
        //
        //Intent proxyServiceIntent = new Intent();
        //proxyServiceIntent.setComponent
        //    (new ComponentName(
        //        "com.android.masfproxyservice",
        //        "com.android.masfproxyservice.MasfProxyService"));
        //startService(proxyServiceIntent, null);

        mSecLockIcon = Resources.getSystem().getDrawable(
                android.R.drawable.ic_secure);
        mMixLockIcon = Resources.getSystem().getDrawable(
                android.R.drawable.ic_partial_secure);

        FrameLayout frameLayout = (FrameLayout) getWindow().getDecorView()
                .findViewById(com.android.internal.R.id.content);
        mBrowserFrameLayout = (FrameLayout) LayoutInflater.from(this)
                .inflate(R.layout.custom_screen, null);
        mContentView = (FrameLayout) mBrowserFrameLayout.findViewById(
                R.id.main_content);
        mErrorConsoleContainer = (LinearLayout) mBrowserFrameLayout
                .findViewById(R.id.error_console);
        mCustomViewContainer = (FrameLayout) mBrowserFrameLayout
                .findViewById(R.id.fullscreen_custom_content);

        frameLayout.addView(mBrowserFrameLayout, COVER_SCREEN_PARAMS);
        mTitleBar = new TitleBar(this);
        //mContentView = (FrameLayout) getWindow().getDecorView().findViewById(
        //        com.android.internal.R.id.content);

        // Create the tab control and our initial tab
        mTabControl = new TabControl(this);

        // Open the icon database and retain all the bookmark urls for favicons
        retainIconsOnStartup();

        mCurrentOrientation = this.getResources().getConfiguration().orientation;
        // Keep a settings instance handy.
        mSettings = BrowserSettings.getInstance();
        mSettings.setBrowserActivity(this);
        mSettings.setTabControl(mTabControl);
        mSettings.loadFromDb(this);

        // OMS: Init search portal before hand.
        SearchPortal.getInstance().initSearchString(BrowserActivity.this);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Browser");

        // OMS: read opl, whether to enable set brightness in browser
        mEnableSetBrightness = SystemProperties.getBoolean("apps.browser.enable_brightness", false);
        if (mEnableSetBrightness) {
            mBrowserBrightness = new BrowserBrightness(this);
        }

        // Save the icicle and break here so that the activity UI can be 
        // shown in a short time to users. We break here simply because
        // this introduces no change in onResume() when STARTUP_ENHANCEMENT 
        // is enabled, e.g. mTabControl & mWakeLock have been created.
        if(STARTUP_ENHANCEMENT) {
            mInitialized = false;
            mStartupBundle = icicle;
            Log.d(LOGTAG, "---- onCreate cost: " + (SystemClock.uptimeMillis() - start));
            return;
        }

        // OMS: Use our control panel and init it here before attachTabToContentView.
        initControlPanel();

        //mFloatingProgress = new FloatingProgress(this, null);
        //mFloatingProgress.setVisibility(View.GONE);

        final Intent intent = getIntent();
        if (!mTabControl.restoreState(icicle)) {
            // clear up the thumbnail directory if we can't restore the state as
            // none of the files in the directory are referenced any more.
            new ClearThumbnails().execute(
                    mTabControl.getThumbnailDir().listFiles());
            // there is no quit on Android. But if we can't restore the state,
            // we can treat it as a new Browser, remove the old session cookies.
            // OMS: Do this when destroyed.
            //CookieManager.getInstance().removeSessionCookie();
            final Bundle extra = intent.getExtras();
            // Create an initial tab.
            // If the intent is ACTION_VIEW and data is not null, the Browser is
            // invoked to view the content by another application. In this case,
            // the tab will be close when exit.
            final TabControl.Tab t = mTabControl.createNewTab();
            mTabControl.setCurrentTab(t);
            // This is one of the only places we call attachTabToContentView
            // without animating from the tab picker.
            attachTabToContentView(t);
            WebView webView = t.getWebView();
            //ANDROID_MOT_FLASHLITE
            if(webView instanceof MotWebView){
                mFlashBrowserActivity = new FlashBrowserActivity(BrowserActivity.this, mTabControl, mTitleBar);
            }else{
                mFlashBrowserActivity = null;
            }
            //ANDROID_MOT_FLASHLITE End

            if (extra != null) {
                int scale = extra.getInt(Browser.INITIAL_ZOOM_LEVEL, 0);
                if (scale > 0 && scale <= 1000) {
                    webView.setInitialScale(scale);
                }
            }
            // If we are not restoring from an icicle, then there is a high
            // likely hood this is the first run. So, check to see if the
            // homepage needs to be configured and copy any plugins from our
            // asset directory to the data partition.
            if ((extra == null || !extra.getBoolean("testing"))
                    && !mSettings.isLoginInitialized()) {
                setupHomePage();
            }
            copyPlugins(true);

            // OMS: Start loading the URL after data connection is ready.
            String url = getUrlFromIntent(intent);

            if (TextUtils.isEmpty(url)) {
                mSuspendedUrl = mSettings.getHomePage();
                /*
                if (mSettings.isLoginInitialized()) {
                    webView.loadUrl(mSettings.getHomePage());
                } else {
                    waitForCredentials();
                }
                */
            } else {
                //webView.loadUrl(url);
                mSuspendedUrl = url;
            }

            // Load the page right now if it's local file.
            if(mSuspendedUrl.startsWith("file://") || mSuspendedUrl.startsWith("content://")) {
                webView.loadUrl(mSuspendedUrl);
                mSuspendedUrl = null;
            }
        } else {
            final TabControl.Tab t = mTabControl.getCurrentTab();
            WebView webView = t.getWebView();
            if(webView instanceof MotWebView && mFlashBrowserActivity == null){
                mFlashBrowserActivity = new FlashBrowserActivity(BrowserActivity.this, mTabControl, mTitleBar);
            }else{
                mFlashBrowserActivity = null;
            }

            // TabControl.restoreState() will create a new tab even if
            // restoring the state fails.
            attachTabToContentView(mTabControl.getCurrentTab());
        }

        // OMS: The following block is to open data connection. Do this after the 
        // WebViewCore thread created. As we need to access the Network instance,
        // which should be created in WebViewCore thread.
        {
            // OMS: Very tricky and ONLY for cmcc...
            //if(mSuspendedUrl != null && 
            //        mSuspendedUrl.startsWith("http://s.139.com")) {
            //    intent.putExtra("data_connection", "wap");
            //}

            mNetworkManager = NetworkManager.createInstance(BrowserActivity.this);
            mUserPreferredProfile = mNetworkManager.getNetworkProfile();
            String newProfile = chooseDataConnectionFromIntent(intent);
            if(newProfile != null) {
                mNetworkManager.setNetworkProfile(newProfile);
            }
            connect();
        }

        registerIntentReceivers();

        mInitialized = true;
        Log.d(LOGTAG, "---- onCreate cost: " + (SystemClock.uptimeMillis() - start));
    }

    AlertDialog mWifiPromptDialog;

    // Register all interested Intents here.
    private void registerIntentReceivers() {
        // For moto flash
        initReceiverForFlash();

        // For DRM download.
        mDrmChangedFilter = new IntentFilter();
        mDrmChangedFilter.addAction(
                "android.drmservice.intent.action.LICENSE_INSTALL_COMPLETE");
        mDrmIntentReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(
                        "android.drmservice.intent.action.LICENSE_INSTALL_COMPLETE")) {
                    String cid = intent.getStringExtra("DRM_FILE_CID"); 
                    BrowserActivity.this.showDrmDlg(cid); 
                }
            }
        };
        registerReceiver(mDrmIntentReceiver,
                         mDrmChangedFilter);

        // OMS: enables registration for airplane mode changes.
        mBrowserIntentFilter = new IntentFilter(
                Intent.ACTION_AIRPLANE_MODE_CHANGED);
        mBrowserIntentReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    if(mActivityDestroyed) {
                        return;
                    }

                    String action = intent.getAction();
                    if (action.equals(Intent.ACTION_AIRPLANE_MODE_CHANGED)) {
                        Boolean on = (Boolean)intent.getExtra("state");
                        onAirplaneModeChanged(on);
                    }else if(action.equals(WifiManager.NETWORK_STATE_CHANGED_ACTION)) {
                        final NetworkInfo networkInfo = (NetworkInfo) 
                                intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);

                        if (networkInfo != null && networkInfo.isConnected()) {
Log.e("**********", "wifi connected");
                            // For CMCC: Prompt use to switch to wifi if needed.
                            if(mWifiNotified ||
                                    Phone.APN_TYPE_INTERNET.equals(mNetworkManager.getNetworkProfile())) {
                                return;
                            }

                            // Show the prompt only if there's none
                            if(mWifiPromptDialog != null && mWifiPromptDialog.isShowing()) {
                                Log.e("wifi", "wifi prompt is showing");
                                return;
                            }

                            // Use postDelay() otherwise the dialog will not show in some case when Activity is not created yet.
                            mHandler.postDelayed(new Runnable() {
                                public void run() {
                                    if(mNetworkManager != null) {
                                        mNetworkManager.dismissAlertDialogIfAny();
                                    }
                                    mWifiPromptDialog =  new AlertDialog.Builder(BrowserActivity.this)
                                        .setIcon(com.android.internal.R.drawable.cmcc_dialog_question)
                                        .setTitle(R.string.switch_wifi_title)
                                        .setMessage(R.string.switch_wifi_message)
                                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                // In case browser has been destroyed.
                                                if(mActivityDestroyed) {
                                                    return;
                                                }
                                                mWifiNotified = true;
                                                mUserPreferredProfile = Phone.APN_TYPE_INTERNET;
                                                if(mInLoad) {
                                                    stopLoading();
                                                }
                                                mSuspendedUrl = null;
                                                mRetryCount = 0;
                                                waitForNetwork();
                                                mNetworkManager.switchNetworkProfile(mUserPreferredProfile);
                                                Log.d(LOGTAG, "======= switch to wifi");
                                            }})
                                        .setNegativeButton(R.string.cancel, null).create();
                                    mWifiPromptDialog.show();
                                }
                            }, 1000); 
                        }
                    }
                }
            };

        mBrowserIntentFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        //mBrowserIntentFilter.addAction(TelephonyIntents.ACTION_SERVICE_STATE_CHANGED);
        //mBrowserIntentFilter.addAction(TelephonyIntents.ACTION_ANY_DATA_CONNECTION_STATE_CHANGED);
        registerReceiver(mBrowserIntentReceiver, mBrowserIntentFilter);
    }


    // Do some lazy initialization after app UI is shown. The code snippet
    // is a simple copy from onCreate().
class DoLazyInitializtion implements Runnable {
    public void run() {

        long start = SystemClock.uptimeMillis();

        Bundle icicle = mStartupBundle;

        // OMS: Use our control panel and init it here before attachTabToContentView.
        initControlPanel();

        //mFloatingProgress = new FloatingProgress(this, null);
        //mFloatingProgress.setVisibility(View.GONE);

        final Intent intent = getIntent();

        if (!mTabControl.restoreState(icicle)) {
            // clear up the thumbnail directory if we can't restore the state as
            // none of the files in the directory are referenced any more.
            new ClearThumbnails().execute(
                    mTabControl.getThumbnailDir().listFiles());
            // there is no quit on Android. But if we can't restore the state,
            // we can treat it as a new Browser, remove the old session cookies.
            // OMS: Do this when destroyed.
            //CookieManager.getInstance().removeSessionCookie();
            final Bundle extra = intent.getExtras();
            // Create an initial tab.
            // If the intent is ACTION_VIEW and data is not null, the Browser is
            // invoked to view the content by another application. In this case,
            // the tab will be close when exit.
            final TabControl.Tab t = mTabControl.createNewTab();
            mTabControl.setCurrentTab(t);
            // This is one of the only places we call attachTabToContentView
            // without animating from the tab picker.
            attachTabToContentView(t);

            WebView webView = t.getWebView();
            //ANDROID_MOT_FLASHLITE
            if(webView instanceof MotWebView){
                mFlashBrowserActivity = new FlashBrowserActivity(BrowserActivity.this, mTabControl, mTitleBar);
            }else{
                mFlashBrowserActivity = null;
            }
            //ANDROID_MOT_FLASHLITE End

            if (extra != null) {
                int scale = extra.getInt(Browser.INITIAL_ZOOM_LEVEL, 0);
                if (scale > 0 && scale <= 1000) {
                    webView.setInitialScale(scale);
                }
            }
            // If we are not restoring from an icicle, then there is a high
            // likely hood this is the first run. So, check to see if the
            // homepage needs to be configured and copy any plugins from our
            // asset directory to the data partition.
            if ((extra == null || !extra.getBoolean("testing"))
                    && !mSettings.isLoginInitialized()) {
                setupHomePage();
            }
            copyPlugins(true);

            // OMS: Start loading the URL after data connection is ready.
            String url = getUrlFromIntent(intent);

            if (TextUtils.isEmpty(url)) {
                mSuspendedUrl = mSettings.getHomePage();
                /*
                if (mSettings.isLoginInitialized()) {
                    webView.loadUrl(mSettings.getHomePage());
                } else {
                    waitForCredentials();
                }
                */
            } else {
                //webView.loadUrl(url);
                mSuspendedUrl = url;
            }

            // Load the page right now if it's local file.
            if(mSuspendedUrl.startsWith("file://") || mSuspendedUrl.startsWith("content://")) {
                webView.loadUrl(mSuspendedUrl);
                mSuspendedUrl = null;
            }
        } else {
            final TabControl.Tab t = mTabControl.getCurrentTab();
            WebView webView = t.getWebView();
            if(webView instanceof MotWebView && mFlashBrowserActivity == null){
                mFlashBrowserActivity = new FlashBrowserActivity(BrowserActivity.this, mTabControl, mTitleBar);
            }else{
                mFlashBrowserActivity = null;
            }

            // TabControl.restoreState() will create a new tab even if
            // restoring the state fails.
            attachTabToContentView(mTabControl.getCurrentTab());
        }

        // OMS: The following block is to open data connection. Do this after the 
        // WebViewCore thread created. As we need to access the Network instance,
        // which should be created in WebViewCore thread.
        {
            // OMS: Very tricky and ONLY for cmcc...
            //if(mSuspendedUrl != null && 
            //        mSuspendedUrl.startsWith("http://s.139.com")) {
            //    intent.putExtra("data_connection", "wap");
            //}

            mNetworkManager = NetworkManager.createInstance(BrowserActivity.this);
            mUserPreferredProfile = mNetworkManager.getNetworkProfile();
            String newProfile = chooseDataConnectionFromIntent(intent);
            if(newProfile != null) {
                mNetworkManager.setNetworkProfile(newProfile);
            }
            connect();
        }


        registerIntentReceivers();

        mInitialized = true;
        Log.d(LOGTAG, "-- lazy init cost: " + (SystemClock.uptimeMillis() - start));

        // OMS: if we have mLazyNewIntent, execute it
        if (null != mLazyNewIntent) {
            BrowserActivity.this.onNewIntent(mLazyNewIntent);
            mLazyNewIntent = null;
        }

    }
}

    private boolean USE_CONTROL_PANEL = true;
    private ControlPanel mControlPanel;
    private void initControlPanel() {
        if(!USE_CONTROL_PANEL) {
            return;
        }

        // We don't use singleton here as it may bring NPE when adding view 
        // to the content view; mControlPanel may have parent at the moment.
        //mControlPanel = ControlPanel.getInstance(this, mHandler);
        mControlPanel = new ControlPanel(this, mHandler);
        //mSettings.setBuiltInZoomControls(false);
        mControlPanel.hide();
    }

    static boolean mFlashEnabled = true; //TODO: SystemProperties.getBoolean("apps.browser.flash_enable", false);
    private void initReceiverForFlash() {
        if(!mFlashEnabled) {
            return;
        }

 
    }

    // OMS: We may set BrowserActivity an Observer of BrowserSettings to monitor
    // the charset changes later. Only called by BrowserSettings for now!
    public void reload() {
        WebView webView = getTopWindow();
        if(webView == null) {
            return;
        }

        webView.stopLoading();
        webView.reload();
    }

    @Override
    public void titleSelected() {
        super.titleSelected();
        if(R.id.MAIN_MENU == mMenuState) {
            if(mNetworkConnecting) {
                Toast.makeText(this, R.string.network_connect_msg, Toast.LENGTH_SHORT).show();
                return;
            }
            String url = getTopWindow().getUrl();
            startSearch(mSettings.getHomePage().equals(url) ? null : url, true,
                    createGoogleSearchSourceBundle(GOOGLE_SEARCH_SOURCE_GOTO), false);
            //startSearch(null, true, createGoogleSearchSourceBundle(GOOGLE_SEARCH_SOURCE_GOTO), false);
        }
    }

    private Intent mLazyNewIntent = null;
    @Override
    protected void onNewIntent(Intent intent) {
        TabControl.Tab current = mTabControl.getCurrentTab();
        // When a tab is closed on exit, the current tab index is set to -1.
        // Reset before proceed as Browser requires the current tab to be set.
        if (current == null) {
            // Try to reset the tab in case the index was incorrect.
            current = mTabControl.getTab(0);
            if (current == null) {
                // Android original design: No tabs at all so just ignore this intent.
                // OMS: since we have enhanced startup, so when we get here, browser may not 
                // initialized. We save the intent and do onNewIntent again after initialized 
                // successfully. 
                if(STARTUP_ENHANCEMENT && !mInitialized) {
                    Log.d(LOGTAG, "onNewIntent, but browser is not initialized yet, save the intent and re-execute");
                    mLazyNewIntent = intent;
                }
                return;
            }
            mTabControl.setCurrentTab(current);
            attachTabToContentView(current);
            resetTitleAndIcon(current.getWebView());
        }
        final String action = intent.getAction();
        final int flags = intent.getFlags();
        if (Intent.ACTION_MAIN.equals(action) ||
                (flags & Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0) {
            // just resume the browser
            return;
        }
        if (Intent.ACTION_VIEW.equals(action)
                || Intent.ACTION_SEARCH.equals(action)
                || MediaStore.INTENT_ACTION_MEDIA_SEARCH.equals(action)
                || Intent.ACTION_WEB_SEARCH.equals(action)) {
            String url = getUrlFromIntent(intent);


            if (url == null || url.length() == 0) {
                url = mSettings.getHomePage();
            }

            // OMS: Try to start media player if this is rtsp streaming.
            if (launchRtspIfNeeded(url)) {
                Log.i("OMS", "RTSP: will launch media player.");
                return;
            }

            // OMS: Very tricky and ONLY for cmcc...
            //if(Intent.ACTION_WEB_SEARCH.equals(action) && 
            //        url.startsWith("http://s.139.com")) {
            //    intent.putExtra("data_connection", "wap");
            //}

            // OMS: Other applications may want to launch browser to open 
            // some web pages over specific data connection, 
            // such as DCD, Monternet. We will detect if the specified
            // data connection is different from what's currently used, and 
            // re-open data connectio if NO.
            if(//Intent.ACTION_VIEW.equals(action) && 
                        intent.getStringExtra("data_connection") != null) {
                String newProfile = chooseDataConnectionFromIntent(intent);
                if(newProfile != null) {
                    mSuspendedUrl = url;
                    waitForNetwork();
                    mNetworkManager.switchNetworkProfile(newProfile);
                }
            }

            if (Intent.ACTION_VIEW.equals(action) &&
                    (flags & Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT) != 0) {
                final String appId =
                        intent.getStringExtra(Browser.EXTRA_APPLICATION_ID);
                final TabControl.Tab appTab = mTabControl.getTabFromId(appId);
                if (appTab != null) {
                    Log.i(LOGTAG, "Reusing tab for " + appId);
                    // Dismiss the subwindow if applicable.
                    dismissSubWindow(appTab);
                    // Since we might kill the WebView, remove it from the
                    // content view first.
                    removeTabFromContentView(appTab);
                    // Recreate the main WebView after destroying the old one.
                    // If the WebView has the same original url and is on that
                    // page, it can be reused.
                    boolean needsLoad =
                            mTabControl.recreateWebView(appTab, url);
                    if (current != appTab) {
                        showTab(appTab, needsLoad ? url : null);
                    } else {
                        if (mTabOverview != null && mAnimationCount == 0) {
                            sendAnimateFromOverview(appTab, false,
                                    needsLoad ? url : null, TAB_OVERVIEW_DELAY,
                                    null);
                        } else {
                            // If the tab was the current tab, we have to attach
                            // it to the view system again.
                            attachTabToContentView(appTab);
                            if (needsLoad) {
                                //appTab.getWebView().loadUrl(url);
                                loadUrlInternal(appTab.getWebView(), url, true);
                            }
                        }
                    }
                    return;
                }
                // if FLAG_ACTIVITY_BROUGHT_TO_FRONT flag is on, the url will be
                // opened in a new tab unless we have reached MAX_TABS. Then the
                // url will be opened in the current tab. If a new tab is
                // created, it will have "true" for exit on close.
                openTabAndShow(url, null, true, appId);
            } else {
                if ("about:debug".equals(url)) {
                    mSettings.toggleDebugSettings();
                    return;
                }
                // If the Window overview is up and we are not in the midst of
                // an animation, animate away from the Window overview.
                if (mTabOverview != null && mAnimationCount == 0) {
                    sendAnimateFromOverview(current, false, url,
                            TAB_OVERVIEW_DELAY, null);
                } else {
                    // Get rid of the subwindow if it exists
                    dismissSubWindow(current);
                    loadUrlInternal(current.getWebView(), url, true);
                    //current.getWebView().loadUrl(url);
                }
            }
        }
    }

    private boolean launchRtspIfNeeded(String url) {
        if (!url.startsWith("rtsp://")) {
            return false;
        }
        Log.i("OMS", "onNewIntent, starts with rtsp, will launch media player.");
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url) );
        i.addCategory(Intent.CATEGORY_BROWSABLE);
        i.putExtra("data_connection", mNetworkManager.getNetworkProfile());
        //sendBroadcast(i); 
        try {
            startActivityIfNeeded(i, -1);
        } catch (ActivityNotFoundException ex) {
            // ignore the error. If no application can handle the URL,
            // eg about:blank, assume the browser can handle it.
            Toast.makeText(this, 
                    com.android.internal.R.string.httpErrorUnsupportedScheme, 
                    Toast.LENGTH_LONG).show();
        }
        return true;
    }

    private String getUrlFromIntent(Intent intent) {
        String url = null;
        if (intent != null) {
            final String action = intent.getAction();
            if (Intent.ACTION_VIEW.equals(action)) {
                url = smartUrlFilter(intent.getData());
                if (url != null && url.startsWith("content:")) {
                    /* Append mimetype so webview knows how to display */
                    String mimeType = intent.resolveType(getContentResolver());
                    if (mimeType != null) {
                        url += "?" + mimeType;
                    }
                }
            } else if (Intent.ACTION_SEARCH.equals(action)
                    || MediaStore.INTENT_ACTION_MEDIA_SEARCH.equals(action)
                    || Intent.ACTION_WEB_SEARCH.equals(action)) {
                url = intent.getStringExtra(SearchManager.QUERY);
                if (url != null) {
                    mLastEnteredUrl = url;
                    // Don't add Urls, just search terms.
                    // Urls will get added when the page is loaded.
                    if (!Regex.WEB_URL_PATTERN.matcher(url).matches()) {
                        Browser.updateVisitedHistory(mResolver, url, false);
                    }
                    // In general, we shouldn't modify URL from Intent.
                    // But currently, we get the user-typed URL from search box as well.
                    url = fixUrl(url);
                    url = smartUrlFilter(url);
                }
            }
        }
        return url;
    }

    /* package */ static String fixUrl(String inUrl) {
        if (inUrl.startsWith("http://") || inUrl.startsWith("https://"))
            return inUrl;
        if (inUrl.startsWith("http:") ||
                inUrl.startsWith("https:")) {
            if (inUrl.startsWith("http:/") || inUrl.startsWith("https:/")) {
                inUrl = inUrl.replaceFirst("/", "//");
            } else inUrl = inUrl.replaceFirst(":", "://");
        }
        return inUrl;
    }

    /**
     * Looking for the pattern like this
     *
     *          *
     *         * *
     *      ***   *     *******
     *             *   *
     *              * *
     *               *
     */
    private final SensorListener mSensorListener = new SensorListener() {
        private long mLastGestureTime;
        private float[] mPrev = new float[3];
        private float[] mPrevDiff = new float[3];
        private float[] mDiff = new float[3];
        private float[] mRevertDiff = new float[3];

        public void onSensorChanged(int sensor, float[] values) {
            boolean show = false;
            float[] diff = new float[3];

            for (int i = 0; i < 3; i++) {
                diff[i] = values[i] - mPrev[i];
                if (Math.abs(diff[i]) > 1) {
                    show = true;
                }
                if ((diff[i] > 1.0 && mDiff[i] < 0.2)
                        || (diff[i] < -1.0 && mDiff[i] > -0.2)) {
                    // start track when there is a big move, or revert
                    mRevertDiff[i] = mDiff[i];
                    mDiff[i] = 0;
                } else if (diff[i] > -0.2 && diff[i] < 0.2) {
                    // reset when it is flat
                    mDiff[i] = mRevertDiff[i]  = 0;
                }
                mDiff[i] += diff[i];
                mPrevDiff[i] = diff[i];
                mPrev[i] = values[i];
            }

            if (false) {
                // only shows if we think the delta is big enough, in an attempt
                // to detect "serious" moves left/right or up/down
                Log.d("BrowserSensorHack", "sensorChanged " + sensor + " ("
                        + values[0] + ", " + values[1] + ", " + values[2] + ")"
                        + " diff(" + diff[0] + " " + diff[1] + " " + diff[2]
                        + ")");
                Log.d("BrowserSensorHack", "      mDiff(" + mDiff[0] + " "
                        + mDiff[1] + " " + mDiff[2] + ")" + " mRevertDiff("
                        + mRevertDiff[0] + " " + mRevertDiff[1] + " "
                        + mRevertDiff[2] + ")");
            }

            long now = android.os.SystemClock.uptimeMillis();
            if (now - mLastGestureTime > 1000) {
                mLastGestureTime = 0;

                float y = mDiff[1];
                float z = mDiff[2];
                float ay = Math.abs(y);
                float az = Math.abs(z);
                float ry = mRevertDiff[1];
                float rz = mRevertDiff[2];
                float ary = Math.abs(ry);
                float arz = Math.abs(rz);
                boolean gestY = ay > 2.5f && ary > 1.0f && ay > ary;
                boolean gestZ = az > 3.5f && arz > 1.0f && az > arz;

                if ((gestY || gestZ) && !(gestY && gestZ)) {
                    WebView view = mTabControl.getCurrentWebView();

                    if (view != null) {
                        if (gestZ) {
                            if (z < 0) {
                                view.zoomOut();
                            } else {
                                view.zoomIn();
                            }
                        } else {
                            view.flingScroll(0, Math.round(y * 100));
                        }
                    }
                    mLastGestureTime = now;
                }
            }
        }

        public void onAccuracyChanged(int sensor, int accuracy) {
            // TODO Auto-generated method stub

        }
    };

    /*
     * This is the best indicator of whether this activity is visible 
     * to the users, after onResume().
     */
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if(!STARTUP_ENHANCEMENT) return;

        if(!mInitialized && hasFocus) {
            Log.d(LOGTAG, "---- onWindowFocusChanged ");
            mHandler.post(new DoLazyInitializtion());
            // Set mInitialized as true when DoLazyInitializtion() is finished.
            //mInitialized = true;
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (LOGV_ENABLED) {
            Log.v(LOGTAG, "BrowserActivity.onResume: this=" + this);
        }

        if (!mActivityInPause) {
            Log.e(LOGTAG, "BrowserActivity is already resumed.");
            return;
        }

        mTabControl.resumeCurrentTab();
        mActivityInPause = false;
        resumeWebViewTimers();

        // OMS: Re-connection in case the PDP was broken.
        if(isAirplaneModeOn()) {
            Toast.makeText(BrowserActivity.this, 
                R.string.network_connection_airplane_on, 
                Toast.LENGTH_LONG).show();
        }else {
            if(mTryConnectionOnResume) {
                Log.w(LOGTAG, "re-connecting when resumed...");
                mTryConnectionOnResume = false;
                //oms:65221. 
                //when resume from the 3rd app, we must go to the right url after reconnect.
                //mSuspendedUrl = null;
                connect();
            }else {
                // The last chance the try anyway.
                //if(!mNetworkConnecting)
                //    mNetworkManager.openDataConnectionIfNeeded();
            }
        }

        if (mWakeLock.isHeld()) {
            mHandler.removeMessages(RELEASE_WAKELOCK);
            mWakeLock.release();
        }

        if (mCredsDlg != null) {
            if (!mHandler.hasMessages(CANCEL_CREDS_REQUEST)) {
             // In case credential request never comes back
                mHandler.sendEmptyMessageDelayed(CANCEL_CREDS_REQUEST, 6000);
            }
        }

        /* OMS: remove it for now
        registerReceiver(mNetworkStateIntentReceiver,
                         mNetworkStateChangedFilter);
        WebView.enablePlatformNotifications();
        */

        if (mSettings.doFlick()) {
            if (mSensorManager == null) {
                mSensorManager = (SensorManager) getSystemService(
                        Context.SENSOR_SERVICE);
            }
            mSensorManager.registerListener(mSensorListener,
                    SensorManager.SENSOR_ACCELEROMETER,
                    SensorManager.SENSOR_DELAY_FASTEST);
        } else {
            mSensorManager = null;
        }
    }

    /**
     * Since the actual title bar is embedded in the WebView, and removing it
     * would change its appearance, create a temporary title bar to go at
     * the top of the screen while the menu is open.
     */
    private TitleBar mFakeTitleBar;

    /**
     * Holder for the fake title bar.  It will have a foreground shadow, as well
     * as a white background, so the fake title bar looks like the real one.
     */
    private ViewGroup mFakeTitleBarHolder;

    /**
     * Layout parameters for the fake title bar within mFakeTitleBarHolder
     */
    private FrameLayout.LayoutParams mFakeTitleBarParams
            = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.FILL_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT);
    /**
     * Keeps track of whether the options menu is open.  This is important in
     * determining whether to show or hide the title bar overlay.
     */
    private boolean mOptionsMenuOpen;

    /**
     * Only meaningful when mOptionsMenuOpen is true.  This variable keeps track
     * of whether the configuration has changed.  The first onMenuOpened call
     * after a configuration change is simply a reopening of the same menu
     * (i.e. mIconView did not change).
     */
    private boolean mConfigChanged;

    /**
     * Whether or not the options menu is in its smaller, icon menu form.  When
     * true, we want the title bar overlay to be up.  When false, we do not.
     * Only meaningful if mOptionsMenuOpen is true.
     */
    private boolean mIconView;

    @Override
    public boolean onMenuOpened(int featureId, Menu menu) {
        // Do nothing when browser is not initialized.
        if(!mInitialized) {
            return true;
        }

        if(mActivityInPause) {
            Log.d(LOGTAG ,"onMenuOpened: browser exited.");
            return true;
        }

        if (Window.FEATURE_OPTIONS_PANEL == featureId) {
            if (mOptionsMenuOpen) {
                if (mConfigChanged) {
                    // We do not need to make any changes to the state of the
                    // title bar, since the only thing that happened was a
                    // change in orientation
                    mConfigChanged = false;
                } else {
                    if (mIconView) {
                        // Switching the menu to expanded view, so hide the
                        // title bar.
                        hideFakeTitleBar();
                        mIconView = false;
                    } else {
                        // Switching the menu back to icon view, so show the
                        // title bar once again.
                        showFakeTitleBar();
                        mIconView = true;
                    }
                }
            } else {
                // The options menu is closed, so open it, and show the title
                showFakeTitleBar();
                mOptionsMenuOpen = true;
                mConfigChanged = false;
                mIconView = true;
            }
        }
        return true;
    }

    /**
     * Special class used exclusively for the shadow drawn underneath the fake
     * title bar.  The shadow does not need to be drawn if the WebView
     * underneath is scrolled to the top, because it will draw directly on top
     * of the embedded shadow.
     */
    private static class Shadow extends View {
        private WebView mWebView;

        public Shadow(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        public void setWebView(WebView view) {
            mWebView = view;
        }

        @Override
        public void draw(Canvas canvas) {
            // In general onDraw is the method to override, but we care about
            // whether or not the background gets drawn, which happens in draw()
            if (mWebView == null || mWebView.getScrollY() > getHeight()) {
                super.draw(canvas);
            }
            // Need to invalidate so that if the scroll position changes, we
            // still draw as appropriate.
            invalidate();
        }
    }

    private void showFakeTitleBar() {
        // Only show when we're in main
        if(mMenuState != R.id.MAIN_MENU) {
            return;
        }

        final View decor = getWindow().peekDecorView();
        if (mFakeTitleBar == null /*&& mActiveTabsPage == null*/
                && !mActivityInPause && decor != null
                && decor.getWindowToken() != null) {
            Rect visRect = new Rect();
            if (!mBrowserFrameLayout.getGlobalVisibleRect(visRect)) {
                if (LOGD_ENABLED) {
                    Log.d(LOGTAG, "showFakeTitleBar visRect failed");
                }
                return;
            }
            final WebView webView = getTopWindow();
            if(null == webView){
                Log.e("BrwException","showFakeTitleBar:The top window is null");
                return;
            }
            mFakeTitleBar = new TitleBar(this);
            // We try to show the same content in mFakeTitleBar as in mTitleBar.
            if(mTitleBar != null) {
                mFakeTitleBar.setTitleAndUrl(mTitleBar.getTitleAndUrl());
            }else {
                mFakeTitleBar.setTitleAndUrl(webView.getTitle(), webView.getUrl());
            }
            mFakeTitleBar.setProgress(webView.getProgress());
            mFakeTitleBar.setFavicon(webView.getFavicon());
            updateLockIconToLatest();

            WindowManager manager
                    = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

            // Add the title bar to the window manager so it can receive touches
            // while the menu is up
            WindowManager.LayoutParams params
                    = new WindowManager.LayoutParams(
                    ViewGroup.LayoutParams.FILL_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_SUB_PANEL,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP;
            WebView mainView = mTabControl.getCurrentWebView();
            boolean atTop = mainView != null && mainView.getScrollY() == 0;
            params.windowAnimations = atTop ? 0 : R.style.TitleBar;
            // XXX : Without providing an offset, the fake title bar will be
            // placed underneath the status bar.  Use the global visible rect
            // of mBrowserFrameLayout to determine the bottom of the status bar
            params.y = visRect.top;
            // Add a holder for the title bar.  It also holds a shadow to show
            // below the title bar.
            if (mFakeTitleBarHolder == null) {
                mFakeTitleBarHolder = (ViewGroup) LayoutInflater.from(this)
                    .inflate(R.layout.title_bar_bg, null);
            }
            Shadow shadow = (Shadow) mFakeTitleBarHolder.findViewById(
                    R.id.shadow);
            shadow.setWebView(mainView);
            mFakeTitleBarHolder.addView(mFakeTitleBar, 0, mFakeTitleBarParams);
            manager.addView(mFakeTitleBarHolder, params);
        }
    }

    @Override
    public void onOptionsMenuClosed(Menu menu) {
        mOptionsMenuOpen = false;
        if (!mInLoad) {
            hideFakeTitleBar();
        } else if (!mIconView) {
            // The page is currently loading, and we are in expanded mode, so
            // we were not showing the menu.  Show it once again.  It will be
            // removed when the page finishes.
            showFakeTitleBar();
        }
    }
    /*package*/ void hideFakeTitleBar() {
        if (mFakeTitleBar == null) return;
        WindowManager.LayoutParams params = (WindowManager.LayoutParams)
                mFakeTitleBarHolder.getLayoutParams();
        WebView mainView = mTabControl.getCurrentWebView();
        // Although we decided whether or not to animate based on the current
        // scroll position, the scroll position may have changed since the
        // fake title bar was displayed.  Make sure it has the appropriate
        // animation/lack thereof before removing.
        params.windowAnimations = mainView != null && mainView.getScrollY() == 0
                ? 0 : R.style.TitleBar;
        WindowManager manager
                    = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        manager.updateViewLayout(mFakeTitleBarHolder, params);
        mFakeTitleBarHolder.removeView(mFakeTitleBar);
        manager.removeView(mFakeTitleBarHolder);
        mFakeTitleBar = null;
    }

    void hideControlPanel() {
        if (mControlPanel != null) {
            mControlPanel.hide();
        }
    }

    /**
     * Special method for the fake title bar to call when displaying its context
     * menu, since it is in its own Window, and its parent does not show a
     * context menu.
     */
    /* package */ void showTitleBarContextMenu() {
        if (null == mTitleBar.getParent()) {
            return;
        }
        mWillShowTitleBarContextMenu = true;
        openContextMenu(mTitleBar);
    }
    // Used for Titlebar's context menu: we want to show title_bar_copy_page_url only.
    private boolean mWillShowTitleBarContextMenu = false;

    /**
     *  onSaveInstanceState(Bundle map)
     *  onSaveInstanceState is called right before onStop(). The map contains
     *  the saved state.
     */
    @Override protected void onSaveInstanceState(Bundle outState) {
        if (LOGV_ENABLED) {
            Log.v(LOGTAG, "BrowserActivity.onSaveInstanceState: this=" + this);
        }
        // the default implementation requires each view to have an id. As the
        // browser handles the state itself and it doesn't use id for the views,
        // don't call the default implementation. Otherwise it will trigger the
        // warning like this, "couldn't save which view has focus because the
        // focused view XXX has no id".

        // Save all the tabs
        mTabControl.saveState(outState);
    }
    
    @Override protected void onStart() {
        super.onStart();

        if (mEnableSetBrightness) {
            mBrowserBrightness.enterBrowserBrightness();
            // mBrowserBrightness.turnOffPowerSaveMode();
        }        
    }

	@Override protected void onStop() {
        super.onStop();

        if (mEnableSetBrightness) {
            mBrowserBrightness.exitBrowserBrightness();
            // mBrowserBrightness.turnOnPowerSaveMode();
        }
    }

    @Override protected void onPause() {
        super.onPause();

        if (mActivityInPause) {
            Log.e(LOGTAG, "BrowserActivity is already paused.");
            return;
        }
        
        //ANDROID_MOT_FLASHLITE
        //When flashlite lose focus, it will change from full screen mode
        //to normal mode.
        if(mFlashBrowserActivity != null ) {
            mFlashBrowserActivity.onPause();
        }
        //end of ANDROID_MOT_FLASHLITE

        mActivityInPause = true;
        if (mTabControl.getCurrentIndex() >= 0 && !pauseWebViewTimers()) {
            mWakeLock.acquire();
            mHandler.sendMessageDelayed(mHandler
                    .obtainMessage(RELEASE_WAKELOCK), WAKELOCK_TIMEOUT);
        }

        // Clear the credentials toast if it is up
        if (mCredsDlg != null && mCredsDlg.isShowing()) {
            mCredsDlg.dismiss();
        }
        mCredsDlg = null;

        cancelStopToast();

        /* OMS: remove it for now
        // unregister network state listener
        unregisterReceiver(mNetworkStateIntentReceiver);
        WebView.disablePlatformNotifications();
        */

        if (mSensorManager != null) {
            mSensorManager.unregisterListener(mSensorListener);
        }
    }

    void showDrmDlg(String cid) {
        Intent intent = new Intent(this,
                BrowserDownloadPage.class);
        intent.putExtra("drm_cid", cid);
        //intent.setData(downloadRecord);
        startActivity(intent);
    }

    // OMS: Whether or not we should kill browser process in the background.
    static boolean mKillProcessAfterExited = false;
    @Override protected void onDestroy() {
        mActivityDestroyed = true;
        super.onDestroy();
        Log.d(LOGTAG, "BrowserActivity.onDestroy: this=" + this);

        // TODO: In some very rare case we found onDestroy() is called 
        // before lazy initialization is done (mInitialized == true).
        if(!mInitialized) {
            Log.w(LOGTAG, "Why onDestroy is called during initialization...?");
            // MNC/MCC changes may cause activity recreation, let's quit here
            // if not initialized. Any better solutions?
            System.exit(0);
            return;
        }

        //ANDROID_MOT_FLASHLITE
        //When flashlite lose focus, it will change from full screen mode
        //to normal mode.
        if(mFlashBrowserActivity != null ) {
            mFlashBrowserActivity.onDestroy();
        }
        //end of ANDROID_MOT_FLASHLITE

        unregisterReceiver(mBrowserIntentReceiver);
        unregisterReceiver(mDrmIntentReceiver);
        //if(mFlashEnabled) {
        //    unregisterReceiver(mFlashTelIntentReceiver);
        //}

        // OMS TODO: stop data connection
        // We disconnect when we call finish(), as in some rare cases we find that 
        // onDestroy() is not called after we call finish(). 
        // See #14052, #3736(fbw).
        // OMS: We still try to stop the data connection again; in some rare case 
        // we saw in offline log onDestroy is called right after ActivityManager 
        // switches to Browser from DCD, and then onCreate is seen.
        // Just close it in case; seems harmless.  See jadespring:20946.
        if(mNetworkManager.connected()) {
            // OMS: to be removed; not used now.
            //disconnect();
        }
        // Tell network manager to clean up.
        mNetworkManager.finish();

        // Kill control panel singleton.
        //ControlPanel.finish();
        //OMS 0101568
        if (mTabControl == null) return;
        // Remove the current tab and sub window
        TabControl.Tab t = mTabControl.getCurrentTab();
        try {
            if(t != null){
                dismissSubWindow(t);
                removeTabFromContentView(t);
            }
        } catch (NullPointerException e) {
            Log.e(LOGTAG, "Null pointer ");
        }
        // Destroy all the tabs
        mTabControl.destroy();
        WebIconDatabase.getInstance().close();
        //if (mGlsConnection != null) {
        //    unbindService(mGlsConnection);
        //    mGlsConnection = null;
        //}

        // OMS: Remove any session cookies when exited.
        // TODO: Will this block the UI thread??
        CookieManager.getInstance().removeSessionCookie();

        //
        // stop MASF proxy service
        //
        //Intent proxyServiceIntent = new Intent();
        //proxyServiceIntent.setComponent
        //   (new ComponentName(
        //        "com.android.masfproxyservice",
        //        "com.android.masfproxyservice.MasfProxyService"));
        //stopService(proxyServiceIntent);

        // onDestroy() sometimes is not call right after finish(); it may get 
        // called after a new browser activity is created. See #85383.
        // We reset mKillProcessAfterExited in onCreate() to avoid process 
        // gets killed after new activity is created.
        if(mKillProcessAfterExited) {
            Log.d(LOGTAG, "Exiting browser");
            String model = SystemProperties.get("ro.product.model");
            if ("MT716".equals(model)) {
                Log.d(LOGTAG, "Will not exit the process");
            } else {
                System.exit(0);
            }
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        
        if ((mCurrentOrientation != newConfig.orientation) 
            && (null != mControlPanel) && 
            (View.VISIBLE == mControlPanel.getVisibility())) {
            // OMS: 1. orientation changed; 2. control panel is created; 
            // 3. control panel is visible
            // then, we fold control panel for better UE.
            mControlPanel.fold();
        }
        
        mCurrentOrientation = newConfig.orientation;

        // OMS: Close the context menu in case it's there. Otherwise
        // we will fail to retrieve the focus node.
        closeContextMenu();

        if (mFindDialog != null && mFindDialog.isShowing()) {
            mFindDialog.onConfigurationChanged(newConfig);
        }

        tabViewConfigurationChanged();
        
        //ANDROID_MOT_FLASHLITE
        if(mFlashBrowserActivity != null )
            mFlashBrowserActivity.onConfigurationChanged(newConfig);
        //end ANDROID_MOT_FLASHLITE
    }

    @Override public void onLowMemory() {
        Log.e(MEMLOG, "BrowserActivity.onLowMemory enter ****");
        super.onLowMemory();
        mTabControl.freeMemory();
        // mTabControl.clearHistory();
        //getTopWindow().debugDump();
    }

    private void tabViewConfigurationChanged(){
        if (mAnimationCount == 0 && mTabOverview != null && mTabListener != null){
           if(mTabOverview.isInMoving())
    	          return;
           mHandler.removeMessages(SHOW_TAB_VIEW);
           mTabOverview.onConfigrationChanged();
           mTabOverview.removeChildViews();
           mContentView.removeView((View)mTabOverview);
           tabPicker(true, mTabControl.getCurrentIndex(), false, false, false);
        }
    }

    private boolean resumeWebViewTimers() {
        if ((!mActivityInPause && !mPageStarted) ||
                (mActivityInPause && mPageStarted)) {
            CookieSyncManager.getInstance().startSync();
            WebView w = mTabControl.getCurrentWebView();
            if (w != null) {
                w.resumeTimers();
            }
            return true;
        } else {
            return false;
        }
    }

    private boolean pauseWebViewTimers() {
        if (mActivityInPause && !mPageStarted) {
            CookieSyncManager.getInstance().stopSync();
            WebView w = mTabControl.getCurrentWebView();
            if (w != null) {
                w.pauseTimers();
            }
            return true;
        } else {
            return false;
        }
    }

    /*
     * This function is called when we are launching for the first time. We
     * are waiting for the login credentials before loading Google home
     * pages. This way the user will be logged in straight away.
     */
    private void waitForCredentials() {
        // Show a toast
        mCredsDlg = new ProgressDialog(this);
        mCredsDlg.setIndeterminate(true);
        mCredsDlg.setMessage(getText(R.string.retrieving_creds_dlg_msg));
        // If the user cancels the operation, then cancel the Google
        // Credentials request.
        mCredsDlg.setCancelMessage(mHandler.obtainMessage(CANCEL_CREDS_REQUEST));
        mCredsDlg.show();

        // We set a timeout for the retrieval of credentials in onResume()
        // as that is when we have freed up some CPU time to get
        // the login credentials.
    }

    /*
     * If we have received the credentials or we have timed out and we are
     * showing the credentials dialog, then it is time to move on.
     */
    private void resumeAfterCredentials() {
        if (mCredsDlg == null) {
            return;
        }

        // Clear the toast
        if (mCredsDlg.isShowing()) {
            mCredsDlg.dismiss();
        }
        mCredsDlg = null;

        // Clear any pending timeout
        mHandler.removeMessages(CANCEL_CREDS_REQUEST);

        // Load the page
        WebView w = mTabControl.getCurrentWebView();
        if (w != null) {
            w.loadUrl(mSettings.getHomePage());
        }

        // Update the settings, need to do this last as it can take a moment
        // to persist the settings. In the mean time we could be loading
        // content.
        mSettings.setLoginInitialized(this);
    }

    // Open the icon database and retain all the icons for visited sites.
    private void retainIconsOnStartup() {
        final WebIconDatabase db = WebIconDatabase.getInstance();
        db.open(getDir("icons", 0).getPath());
        try {
            Cursor c = Browser.getAllBookmarks(mResolver);
            if (!c.moveToFirst()) {
                c.deactivate();
                return;
            }
            int urlIndex = c.getColumnIndexOrThrow(Browser.BookmarkColumns.URL);
            do {
                String url = c.getString(urlIndex);
                db.retainIconForPageUrl(url);
            } while (c.moveToNext());
            c.deactivate();
        } catch (IllegalStateException e) {
            Log.e(LOGTAG, "retainIconsOnStartup", e);
        }
    }

    // Dial the GPRS link.
    /*package*/ void connect() {
        if(isAirplaneModeOn()) {
            Toast.makeText(BrowserActivity.this, 
                R.string.network_connection_airplane_on, 
                Toast.LENGTH_LONG).show();
            return;
        }

        // Reset the flag here anyway. Otherwise there may be re-entry for 
        // onNewIntent and onResume.
        mTryConnectionOnResume = false;

        waitForNetwork();

        Log.w(DCMTAG, "connect() enter");
        mNetworkManager.connect();
    }

    private void disconnect() {
        Log.d(DCMTAG, "disconnect");
        mNetworkManager.disconnect();
    }

    // Helper method for getting the top window.
    /* package */WebView getTopWindow() {
        return mTabControl.getCurrentTopWebView();
    }

    // Helper method for getting the current window.
    /* package */WebView getCurrentWebView() {
        if (mTabControl == null || mTabControl.getCurrentTab() == null) {
            Log.w(LOGTAG, "Current webview is null!");
            return null;
        }

        return mTabControl.getCurrentTab().getWebView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.browser, menu);
        mMenu = menu;
        try {
            updateInLoadMenuItems();
        } catch (NullPointerException e) {
            Log.e(LOGTAG, "NullPointerException ", e);
            return false;
        }
        return true;
    }

    /**
     * As the menu can be open when loading state changes
     * we must manually update the state of the stop/reload menu
     * item
     */
    private void updateInLoadMenuItems() {
        if (mMenu == null) {
            return;
        }
        MenuItem src = mInLoad ?
                mMenu.findItem(R.id.stop_menu_id):
                    mMenu.findItem(R.id.reload_menu_id);
        MenuItem dest = mMenu.findItem(R.id.stop_reload_menu_id);
        dest.setIcon(src.getIcon());
        dest.setTitle(src.getTitle());
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        // chording is not an issue with context menus, but we use the same
        // options selector, so set mCanChord to true so we can access them.
        mCanChord = true;
        int id = item.getItemId();
        final WebView webView = getTopWindow();
        final HashMap hrefMap = new HashMap();
        hrefMap.put("webview", webView);
        final Message msg = mHandler.obtainMessage(
                FOCUS_NODE_HREF, id, 0, hrefMap);
        switch (id) {
            // For the context menu from the title bar
            case R.id.title_bar_copy_page_url:
                WebView mainView = mTabControl.getCurrentWebView();
                if (null == mainView) {
                    return false;
                }
                copy(mainView.getUrl());
                break;
            // -- Browser context menu
            //case R.id.open_context_menu_id:
            case R.id.open_newtab_context_menu_id:
            case R.id.bookmark_context_menu_id:
            case R.id.save_link_context_menu_id:
            case R.id.share_link_context_menu_id:
            case R.id.copy_link_context_menu_id:
                webView.requestFocusNodeHref(msg);
                break;

            case R.id.download_context_menu_id:
            case R.id.view_image_context_menu_id:
//            	case R.id.share_image_context_menu_id:
                webView.requestImageRef(msg);
                break;
            default:
                // For other context menus
                return onOptionsItemSelected(item);
        }
        mCanChord = false;
        return true;
    }

    private Bundle createGoogleSearchSourceBundle(String source) {
        Bundle bundle = new Bundle();
        bundle.putString(SearchManager.SOURCE, source);
        return bundle;
    }

    /**
     * Overriding this to insert a local information bundle
     */
    @Override
    public boolean onSearchRequested() {
        if (mOptionsMenuOpen) closeOptionsMenu();
        String url = (getTopWindow() == null) ? null : getTopWindow().getUrl();
        startSearch(mSettings.getHomePage().equals(url) ? null : url, true,
                createGoogleSearchSourceBundle(GOOGLE_SEARCH_SOURCE_SEARCHKEY), false);
        return true;
    }

    @Override
    public void startSearch(String initialQuery, boolean selectInitialQuery,
            Bundle appSearchData, boolean globalSearch) {
        if (appSearchData == null) {
            appSearchData = createGoogleSearchSourceBundle(GOOGLE_SEARCH_SOURCE_TYPE);
        }
        super.startSearch(initialQuery, selectInitialQuery, appSearchData, globalSearch);
    }

    /**
     * Switch tabs.  Called by the TitleBarSet when sliding the title bar
     * results in changing tabs.
     * @param index Index of the tab to change to, as defined by
     *              mTabControl.getTabIndex(Tab t).
     * @return boolean True if we successfully switched to a different tab.  If
     *                 the indexth tab is null, or if that tab is the same as
     *                 the current one, return false.
     */
    /* package */ boolean switchToTab(int index) {
        TabControl.Tab tab = mTabControl.getTab(index);
        TabControl.Tab currentTab = mTabControl.getCurrentTab();
        if (tab == null || tab == currentTab) {
            return false;
        }
        if (currentTab != null) {
            // currentTab may be null if it was just removed.  In that case,
            // we do not need to remove it
            removeTabFromContentView(currentTab);
        }
        mTabControl.setCurrentTab(tab);
        attachTabToContentView(tab);
        resetTitleIconAndProgress();
        updateLockIconToLatest();
        return true;
    }
    //ANDROID_MOT_FLASHLITE
    // monitor platform changes
    //private IntentFilter mFlashResumePauseErrorMsgFilter;
    //private BroadcastReceiver mFlashTelIntentReceiver;

    //Flash Context Menu and Full Screen Mode
    //private static boolean isFlashFullScreenMode = false;
    //private static boolean isFlashPaused = false;
    //private static int whichFlashQuality = -1;
    //int pressButton = -1;
    //end of ANDROID_MOT_FLASHLITE

    //private ActiveTabsPage mActiveTabsPage;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (!mCanChord) {
            // The user has already fired a shortcut with this hold down of the
            // menu key.
            return false;
        }
        switch (item.getItemId()) {
            // -- Main menu
            case R.id.goto_menu_id: {
                if(mNetworkConnecting) {
                    Toast.makeText(this, R.string.network_connect_msg, Toast.LENGTH_SHORT).show();
                    break;
                }
                String url = getTopWindow().getUrl();
                startSearch(mSettings.getHomePage().equals(url) ? null : url, true,
                        createGoogleSearchSourceBundle(GOOGLE_SEARCH_SOURCE_GOTO), false);
                //startSearch(null, true,
                //        createGoogleSearchSourceBundle(GOOGLE_SEARCH_SOURCE_GOTO), false);
                }
                break;

            case R.id.bookmarks_menu_id:
                bookmarksPicker();
                break;
            /*
            case R.id.windows_menu_id:
                tabPicker(true, mTabControl.getCurrentIndex(), false);
                break;*/

            /*case R.id.zoom_scroll_menu_id:
                getTopWindow().ajustScreenToOverView(); 
                break;
*/

            case R.id.stop_reload_menu_id:
                if (mInLoad) {
                    stopLoading();
                } else {
                    //ANDROID_MOT_FLASHLITE
                    if(mFlashBrowserActivity != null)
                        mFlashBrowserActivity.setFlashQuality(-1);
                    //end of ANDROID_MOT_FLASHLITE
                    if (getTopWindow() != null) {
                        getTopWindow().reload();
                    }
                }
                break;

            case R.id.back_menu_id:
                getTopWindow().goBack();
                break;

            case R.id.forward_menu_id:
                getTopWindow().goForward();
                break;

            /* OMS: remove this for now.
            case R.id.close_menu_id:
                // Close the subwindow if it exists.
                if (mTabControl.getCurrentSubWindow() != null) {
                    dismissSubWindow(mTabControl.getCurrentTab());
                    break;
                }
                final int currentIndex = mTabControl.getCurrentIndex();
                final TabControl.Tab parent =
                        mTabControl.getCurrentTab().getParentTab();
                int indexToShow = -1;
                if (parent != null) {
                    indexToShow = mTabControl.getTabIndex(parent);
                } else {
                    // Get the last tab in the list. If it is the current tab,
                    // subtract 1 more.
                    indexToShow = mTabControl.getTabCount() - 1;
                    if (currentIndex == indexToShow) {
                        indexToShow--;
                    }
                }
                removeTabAndShow(currentIndex, indexToShow);
                break;
*/
            case R.id.homepage_menu_id:
                TabControl.Tab current = mTabControl.getCurrentTab();
                if (current != null) {
                    dismissSubWindow(current);
                    String home = mSettings.getHomePage();
                    if(home == null || home.length() <= 0) {
                        home = "about:blank";
                    }
                    loadUrlInternal(current.getWebView(), home, true);
                }
                break;

            case R.id.preferences_menu_id:
                Intent intent = new Intent(this,
                        BrowserPreferencesPage.class);
                startActivityForResult(intent, PREFERENCES_PAGE);
                break;

            case R.id.exit_menu_id:
                confirmToQuit();//goQuit();
                return true; // Or break ?

            case R.id.advanced_menu_id: {
                Intent i = new Intent(this, BrowserExtraMenuPage.class);
                String url = getTopWindow().getUrl();
                i.putExtra("from_url", url); 
                startActivityForResult(i, EXTRA_MENU);
                break;
            }

            case R.id.find_menu_id:
                if (null == mFindDialog) {
                    mFindDialog = new FindDialog(this);
                }
                mFindDialog.setWebView(getTopWindow());
                mFindDialog.show();
                mMenuState = EMPTY_MENU;
                break;

            case R.id.classic_history_menu_id: {
                    Intent i = new Intent(this, BrowserHistoryPage.class);
                    i.putExtra("maxTabsOpen",
                            mTabControl.getTabCount() >=
                            TabControl.MAX_TABS);
                    startActivityForResult(i, CLASSIC_HISTORY_PAGE);
                }
                break;
            
            case R.id.copy_and_paste_id: {
                    if (getTopWindow() != null) {
                        getTopWindow().emulateShiftHeld();
                    }
                }
                break;

            case R.id.unknown_type_copy_text_menu_id:
                Log.e("Browser", "unknown type, will copy text");
                getTopWindow().emulateShiftHeld();
                break;

            case R.id.dump_nav_menu_id:
                getTopWindow().debugDump();
                break;

            /* OMS: remove this
            case R.id.page_info_menu_id:
                showPageInfo(mTabControl.getCurrentTab(), false);
                break;

            case R.id.bookmark_page_menu_id:
                Browser.saveBookmark(this, getTopWindow().getTitle(),
                        getTopWindow().getUrl());
                break;
                
            case R.id.share_page_menu_id:
                Browser.sendString(this, getTopWindow().getUrl());
                break;

            case R.id.zoom_menu_id:
                // FIXME: Can we move this out of WebView? How does this work
                // for a subwindow?
                getTopWindow().invokeZoomPicker();
                break;

            case R.id.zoom_in_menu_id:
                getTopWindow().zoomIn();
                break;

            case R.id.zoom_out_menu_id:
                getTopWindow().zoomOut();
                break;
                */

            case R.id.view_downloads_menu_id:
                viewDownloads(null);
                break;

            // -- Tab menu
            /*
            case R.id.view_tab_menu_id:
                if (mTabListener != null && mTabOverview != null) {
                    int pos = mTabOverview.getContextMenuPosition(item);
                    mTabOverview.setCurrentIndex(pos);
                    mTabListener.onClick(pos);
                }
                break;

            case R.id.remove_tab_menu_id:
                if (mTabListener != null && mTabOverview != null) {
                    int pos = mTabOverview.getContextMenuPosition(item);
                    mTabListener.remove(pos);
                }
                break;*/

            case R.id.new_tab_menu_id:
                // No need to check for mTabOverview here since we are not
                // dependent on it for a position.
                if (mTabListener != null) {
                    // If the overview happens to be non-null, make the "New
                    // Tab" cell visible.
                    if (mTabOverview != null) {
                        mTabOverview.setCurrentIndex(BrowserTabView.NEW_TAB);
                    }
                    mTabListener.onClick(BrowserTabView.NEW_TAB);
                }
                break;
            case R.id.switch_tab_mod:
                int curMod = mSettings.getCurrentTabMode(this);
                if( curMod != BrowserTabView.TAB_GALLERY_MODE) {
                    mSettings.setTabModePreference(this, 
                        BrowserTabView.TAB_GALLERY_MODE);
                }else {
                    mSettings.setTabModePreference(this, 
                        BrowserTabView.TAB_GIRD_MODE);
                }
                tabPicker(true, mTabControl.getCurrentIndex(), false, true, false);
                break;
            case R.id.bookmark_tab_menu_id:
                if (mTabListener != null && mTabOverview != null) {
                    int pos = mTabOverview.getContextMenuPosition(item);
                    TabControl.Tab t = mTabControl.getTab(pos);
                    // Since we called populatePickerData for all of the
                    // tabs, getTitle and getUrl will return appropriate
                    // values.
                    Browser.saveBookmark(BrowserActivity.this, t.getTitle(),
                        t.getUrl());
                }
                break;

            case R.id.history_tab_menu_id: {
                    Intent i = new Intent(this, BrowserHistoryPage.class);
                    i.putExtra("maxTabsOpen",
                            mTabControl.getTabCount() >=
                            TabControl.MAX_TABS);
                    startActivityForResult(i, CLASSIC_HISTORY_PAGE);
                }
                break;

            case R.id.bookmarks_tab_menu_id:
                bookmarksPicker();
                break;

            case R.id.properties_tab_menu_id:
                if (mTabListener != null && mTabOverview != null) {
                    int pos = mTabOverview.getContextMenuPosition(item);
                    showPageInfo(mTabControl.getTab(pos), false);
                }
                break;

            //ANDROID_MOT_FLASHLITE
            case R.id.flash_quality:
            case R.id.flash_close:
                if(mFlashBrowserActivity != null)
                    mFlashBrowserActivity.onOptionsItemSelected(item);
                break;
                //end of ANDROID_MOT_FLASHLITE

            default:
                if (!super.onOptionsItemSelected(item)) {
                    return false;
                }
                // Otherwise fall through.
        }
     
        mCanChord = false;
        return true;
    }

    public void closeFind() {
        Animation anim = AnimationUtils.loadAnimation(this,
                R.anim.find_dialog_exit);
        getTopWindow().requestFocus();
        mMenuState = R.id.MAIN_MENU;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if(!mInitialized || mAnimationCount > 0) return true;

        if(USE_CONTROL_PANEL && ! mFlashBrowserActivity.flashFullScreenMode()) {
            mControlPanel.showIfNeeded(event);
        }

        return super.dispatchTouchEvent(event);
    }

    @Override public boolean onPrepareOptionsMenu(Menu menu)
    {
        // This happens when the user begins to hold down the menu key, so
        // allow them to chord to get a shortcut.
        mCanChord = true;
        // Note: setVisible will decide whether an item is visible; while
        // setEnabled() will decide whether an item is enabled, which also means
        // whether the matching shortcut key will function.
        super.onPrepareOptionsMenu(menu);

        //ANDROID_MOT_FLASHLITE
        if(mFlashBrowserActivity != null)
        {
            if(mFlashBrowserActivity.onPrepareOptionsMenu(menu))
                return true;
        }
        //End of ANDROID_MOT_FLASHLITE

        switch (mMenuState) {
            case R.id.TAB_MENU:
                if (mCurrentMenuState != mMenuState) {
                    menu.setGroupVisible(R.id.MAIN_MENU, false);
                    menu.setGroupEnabled(R.id.MAIN_MENU, false);
                    //menu.setGroupEnabled(R.id.MAIN_SHORTCUT_MENU, false);
                    menu.setGroupVisible(R.id.TAB_MENU, true);
                    menu.setGroupEnabled(R.id.TAB_MENU, true);
                }
                boolean newT = mTabControl.getTabCount() < TabControl.MAX_TABS;
                final MenuItem tab = menu.findItem(R.id.new_tab_menu_id);
                final MenuItem mod = menu.findItem(R.id.switch_tab_mod);
                if(isInLandscapeOrientation()){
                    mod.setVisible(false);
                }else{
                    mod.setVisible(true);
                }
                int curMod = mSettings.getCurrentTabMode(this);
                if( curMod != BrowserTabView.TAB_GALLERY_MODE){
                    tab.setVisible(newT);
                    tab.setEnabled(newT);
                }else{
                    tab.setVisible(false);
                    tab.setEnabled(false);
                }
                break;
            case R.id.OVERVIEW_MENU:
                if (mCurrentMenuState != mMenuState) {
                    menu.setGroupVisible(R.id.MAIN_MENU, false);
                    menu.setGroupEnabled(R.id.MAIN_MENU, false);
                    menu.setGroupVisible(R.id.TAB_MENU, false);
                    menu.setGroupEnabled(R.id.TAB_MENU, false);
                }
                break;

            case EMPTY_MENU:
                if (mCurrentMenuState != mMenuState) {
                    menu.setGroupVisible(R.id.MAIN_MENU, false);
                    menu.setGroupEnabled(R.id.MAIN_MENU, false);
                    //menu.setGroupEnabled(R.id.MAIN_SHORTCUT_MENU, false);
                    menu.setGroupVisible(R.id.TAB_MENU, false);
                    menu.setGroupEnabled(R.id.TAB_MENU, false);
                }
                break;
            default:
                if (mCurrentMenuState != mMenuState) {
                    menu.setGroupVisible(R.id.MAIN_MENU, true);
                    menu.setGroupEnabled(R.id.MAIN_MENU, true);
                    //menu.setGroupEnabled(R.id.MAIN_SHORTCUT_MENU, true);
                    menu.setGroupVisible(R.id.TAB_MENU, false);
                    menu.setGroupEnabled(R.id.TAB_MENU, false);
                }
                final WebView w = getTopWindow();
                boolean canGoBack = false;
                boolean canGoForward = false;
                boolean isHome = false;
                if (w != null) {
                    canGoBack = w.canGoBack();
                    canGoForward = w.canGoForward();
                    isHome = mSettings.getHomePage().equals(w.getUrl());
                }
                final MenuItem back = menu.findItem(R.id.back_menu_id);
                back.setVisible(!USE_CONTROL_PANEL && canGoBack);

                /* OMS: remove for now.
                final MenuItem close = menu.findItem(R.id.close_menu_id);
                close.setVisible(mTabControl != null && mTabControl.getTabCount() > 1);
                close.setEnabled(mTabControl != null && mTabControl.getTabCount() > 1);
                */
                final MenuItem home = menu.findItem(R.id.homepage_menu_id);
                home.setVisible(!isHome);
                //home.setEnabled(!isHome);

                final MenuItem forward = menu.findItem(R.id.forward_menu_id);
                forward.setVisible(!USE_CONTROL_PANEL && canGoForward);

                menu.findItem(R.id.goto_menu_id).setVisible(false);

                if(USE_CONTROL_PANEL) {
                    //menu.findItem(R.id.overview_menu_id).setVisible(false);
                }

// TODO: Remove the menu items.
menu.findItem(R.id.windows_menu_id).setVisible(false);
//menu.findItem(R.id.exit_menu_id).setVisible(false);

                //menu.findItem(R.id.zoom_in_menu_id).setVisible(false);
                //menu.findItem(R.id.zoom_out_menu_id).setVisible(false);
                
                // decide whether to show the share link option
                /* OMS: remove for now
                PackageManager pm = getPackageManager();
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                List<ResolveInfo> list = pm.queryIntentActivities(send,
                        PackageManager.MATCH_DEFAULT_ONLY);
                menu.findItem(R.id.share_page_menu_id).setVisible(
                        list.size() > 0);
                */

                boolean isNavDump = mSettings.isNavDump();
                final MenuItem nav = menu.findItem(R.id.dump_nav_menu_id);
                nav.setVisible(isNavDump);
                nav.setEnabled(isNavDump);
                // OMS: disable some items for CMCC customization.
                menu.findItem(R.id.zoom_menu_id).setVisible(false);
                menu.findItem(R.id.find_menu_id).setVisible(false);
                //menu.findItem(R.id.advanced_menu_id).setVisible(true);
                //menu.findItem(R.id.page_info_menu_id).setVisible(false);
                //menu.findItem(R.id.bookmark_page_menu_id).setVisible(false);
                //menu.findItem(R.id.share_page_menu_id).setVisible(false);
                break;
        }
        mCurrentMenuState = mMenuState;
        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
            ContextMenuInfo menuInfo) {
        if(mWillShowTitleBarContextMenu) {
            mWillShowTitleBarContextMenu = false;
            return;
        }

        WebView webview = (WebView) v;
        WebView.HitTestResult result = webview.getHitTestResult();
        if (result == null) {
            return;
        }

        int type = result.getType();
        if (type == WebView.HitTestResult.UNKNOWN_TYPE) {
            Log.w(LOGTAG,
                    "We should also  show context menu when nothing is touched");
            // will not return here
            // return;
        }
        if (type == WebView.HitTestResult.EDIT_TEXT_TYPE) {
            // let TextView handles context menu
            return;
        }

        //ANDROID_MOT_FLASHLITE
        Log.d(LOGTAG, ">>>BrowserActivity.java>>>>>>>>>onCreateContextMenu when nothing is touched>>>>>>>>>>>>, type="+type);
        if(mFlashBrowserActivity != null && type == WebView.HitTestResult.FLASH_TYPE)
        {
            //OMS 98603:When the flash is downloading, we won't show any menu
            if (webview.getProgress() == 100)
                mFlashBrowserActivity.onCreateContextMenu(menu, v, menuInfo, type);
            return;
        }
        //END of ANDROID_MOT_FLASHLITE

        // Note, http://b/issue?id=1106666 is requesting that
        // an inflated menu can be used again. This is not available
        // yet, so inflate each time (yuk!)
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.browsercontext, menu);

        // Show the correct menu group
        String extra = result.getExtra();
        menu.setGroupVisible(R.id.PHONE_MENU,
                type == WebView.HitTestResult.PHONE_TYPE);
        menu.setGroupVisible(R.id.EMAIL_MENU,
                type == WebView.HitTestResult.EMAIL_TYPE);
        menu.setGroupVisible(R.id.GEO_MENU,
                type == WebView.HitTestResult.GEO_TYPE);
        menu.setGroupVisible(R.id.IMAGE_MENU,
                type == WebView.HitTestResult.IMAGE_TYPE
                || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE);
        menu.setGroupVisible(R.id.ANCHOR_MENU,
                type == WebView.HitTestResult.SRC_ANCHOR_TYPE
                || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE);
        menu.setGroupVisible(R.id.COPYTEXT_MENU, 
                type == WebView.HitTestResult.UNKNOWN_TYPE 
                || type == WebView.HitTestResult.SRC_ANCHOR_TYPE);

        // We don't want to show "download" for local resources.
        //OMS 0103717
        if(type == WebView.HitTestResult.IMAGE_TYPE
                || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE){
            boolean isNetwork = extra != null && extra.startsWith("http");
            menu.findItem(R.id.download_context_menu_id).setVisible(isNetwork);
        }

        // Setup custom handling depending on the type
        switch (type) {
            case WebView.HitTestResult.PHONE_TYPE:
                menu.setHeaderTitle(Uri.decode(extra));
                menu.findItem(R.id.dial_context_menu_id).setIntent(
                        new Intent(Intent.ACTION_VIEW, Uri
                                .parse(WebView.SCHEME_TEL + extra)));
                Intent addIntent = new Intent(Intent.ACTION_INSERT_OR_EDIT);
                addIntent.putExtra(Insert.PHONE, Uri.decode(extra));
                addIntent.setType(Contacts.People.CONTENT_ITEM_TYPE);
                menu.findItem(R.id.add_contact_context_menu_id).setIntent(
                        addIntent);
                menu.findItem(R.id.copy_phone_context_menu_id).setOnMenuItemClickListener(
                        new Copy(extra));
                break;

            case WebView.HitTestResult.EMAIL_TYPE:
                int index = extra.indexOf("?");
                menu.setHeaderTitle(index > 0 ? extra.substring(0, index) : extra);
                menu.findItem(R.id.email_context_menu_id).setIntent(
                        new Intent(Intent.ACTION_VIEW, Uri
                                .parse(WebView.SCHEME_MAILTO + extra)));
                menu.findItem(R.id.copy_mail_context_menu_id).setOnMenuItemClickListener(
                        new Copy(extra));
                break;

            case WebView.HitTestResult.GEO_TYPE:
                menu.setHeaderTitle(extra);
                menu.findItem(R.id.map_context_menu_id).setIntent(
                        new Intent(Intent.ACTION_VIEW, Uri
                                .parse(WebView.SCHEME_GEO
                                        + URLEncoder.encode(extra))));
                menu.findItem(R.id.copy_geo_context_menu_id).setOnMenuItemClickListener(
                        new Copy(extra));
                break;

            case WebView.HitTestResult.SRC_ANCHOR_TYPE:
            case WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE:
                // decide whether to show the open link in new tab option
                menu.findItem(R.id.open_newtab_context_menu_id).setVisible(
                        mTabControl.getTabCount() < TabControl.MAX_TABS);
                PackageManager pm = getPackageManager();
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                ResolveInfo ri = pm.resolveActivity(send, PackageManager.MATCH_DEFAULT_ONLY);
                menu.findItem(R.id.share_link_context_menu_id).setVisible(ri != null);
                if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
                    break;
                }
                // otherwise fall through to handle image part
            case WebView.HitTestResult.IMAGE_TYPE:
                /* OMS: Sometimes, extra may contain invalid URL. So emnu action will
                 * be taken in onContextItemSelected. URL will be retrieved there.
                if (type == WebView.HitTestResult.IMAGE_TYPE) {
                    menu.setHeaderTitle(extra);
                }
                menu.findItem(R.id.view_image_context_menu_id).setIntent(
                        new Intent(Intent.ACTION_VIEW, Uri.parse(extra)));
                menu.findItem(R.id.download_context_menu_id).
                        setOnMenuItemClickListener(new Download(extra));
                */
                break;

            case WebView.HitTestResult.UNKNOWN_TYPE:
                if (mFlashBrowserActivity == null || ! mFlashBrowserActivity.flashFullScreenMode()) {
                    menu.findItem(R.id.unknown_type_copy_text_menu_id).setVisible(true);
                }
                break;

            default:
                Log.w(LOGTAG, "We should not get here.");
                break;
        }
    }

    // OMS: A simple wrapper for setProgress() as it's a final method.
    // We may chane the progress in title bar, or in the floating one 
    // in case of full screen.
    // @param progress: 0-100
    //private FloatingProgress mFloatingProgress;
    private void setProgressInternal(int progress) {
        if(false && mFullScreen) {
            //if(mFloatingProgress != null) {
            //    mFloatingProgress.setProgress(progress*100);
            //}
        }else {
            mTitleBar.setProgress(progress);
            if (mFakeTitleBar != null) {
                mFakeTitleBar.setProgress(progress);
            }
            // Remove this as we don't use title bar.
            //super.setProgress(progress*100);

            // We may need to hide mFloatingProgress if it's there.
            // Now we do it when exiting fullscreen mode.
        }
    }

    // Used by attachTabToContentView for the WebView's ZoomControl widget.
    private static final FrameLayout.LayoutParams ZOOM_PARAMS =
            new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.FILL_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM);

    // Attach the given tab to the content view.
    private void attachTabToContentView(TabControl.Tab t) {
        final WebView main = t.getWebView();
        //OMS 0100985:when have parent, do nothing
        if(main.getParent() != null){
            return;
        }
        // Attach the main WebView.
        mContentView.addView(main, COVER_SCREEN_PARAMS);
        // Attach the Zoom control widget and hide it.
        if(USE_CONTROL_PANEL) {
            //OMS 0098312:when have parent, should not be add again.
            if(mControlPanel != null) {
            	   if(mControlPanel.getParent() == null){
                    mContentView.addView(mControlPanel);
                    mControlPanel.hide();
                }else{
                    Log.e("BrwException","The control panel have more than one parent ",new Throwable());    
                }
            }
        }else {
            final View zoom = main.getZoomControls();
            mContentView.addView(zoom, ZOOM_PARAMS);
            zoom.setVisibility(View.GONE);
        }

        // Attach progress view.
        //if(mFloatingProgress != null) {
        //    mContentView.addView(mFloatingProgress);
        //}

        // Attach the sub window if necessary
        attachSubWindow(t);
        WebView view = t.getWebView();
        view.setEmbeddedTitleBar(mTitleBar);
        // Request focus on the top window.
        t.getTopWindow().requestFocus();
    }

    // Attach a sub window to the main WebView of the given tab.
    private void attachSubWindow(TabControl.Tab t) {
        // If a sub window exists, attach it to the content view.
        final WebView subView = t.getSubWebView();
        if (subView != null) {
            final View container = t.getSubWebViewContainer();
            mContentView.addView(container, COVER_SCREEN_PARAMS);
            subView.requestFocus();
        }
    }

    // Remove the given tab from the content view.
    private void removeTabFromContentView(TabControl.Tab t) {
        // Remove the Zoom widget and the main WebView.
        if(USE_CONTROL_PANEL) {
            // Remove the control panel if any.
            if(mControlPanel != null) {
                mControlPanel.hide();
                mContentView.removeView(mControlPanel);
            }
        }else {
            mContentView.removeView(t.getWebView().getZoomControls());
        }
        mContentView.removeView(t.getWebView());

        // Remove progress view
        //if(mFloatingProgress != null) {
        //    mContentView.removeView(mFloatingProgress);
        //}

        WebView view = t.getWebView();
        if (view != null) {
            view.setEmbeddedTitleBar(null);
        }

        // Remove the sub window if it exists.
        if (t.getSubWebView() != null) {
            mContentView.removeView(t.getSubWebViewContainer());
        }
    }

    // Remove the sub window if it exists. Also called by TabControl when the
    // user clicks the 'X' to dismiss a sub window.
    /* package */ void dismissSubWindow(TabControl.Tab t) {
        if (null == t) return;
        
        final WebView mainView = t.getWebView();
        if (t.getSubWebView() != null) {
            // Remove the container view and request focus on the main WebView.
            mContentView.removeView(t.getSubWebViewContainer());
            mainView.requestFocus();
            // Tell the TabControl to dismiss the subwindow. This will destroy
            // the WebView.
            mTabControl.dismissSubWindow(t);
        }
    }

    // Send the ANIMTE_FROM_OVERVIEW message after changing the current tab.
    private void sendAnimateFromOverview(final TabControl.Tab tab,
            final boolean newTab, final String url, final int delay,
            final Message msg) {
        // Set the current tab.
        mTabControl.setCurrentTab(tab);
        // Attach the WebView so it will layout.
        attachTabToContentView(tab);
        // Set the view to invisibile for now.
        tab.getWebView().setVisibility(View.INVISIBLE);
        // If there is a sub window, make it invisible too.
        if (tab.getSubWebView() != null) {
            tab.getSubWebViewContainer().setVisibility(View.INVISIBLE);
        }
        int ty = tab.getTranslateY();
        WebView w = tab.getTopWindow();
        //OMS 0107366
        if(w.getScrollY() != ty){
            w.pinScrollTo(w.getScrollX(), ty, false, 0);
        }
        // Create our fake animating view.
        final AnimatingView view = new AnimatingView(this, tab);
        // Attach it to the view system and make in invisible so it will
        // layout but not flash white on the screen.
        mContentView.addView(view, COVER_SCREEN_PARAMS);
        view.setVisibility(View.INVISIBLE);
        // Send the animate message.
        final HashMap map = new HashMap();
        map.put("view", view);
        // Load the url after the AnimatingView has captured the picture. This
        // prevents any bad layout or bad scale from being used during
        // animation.
        if (url != null) {
            dismissSubWindow(tab);
            //tab.getWebView().loadUrl(url);
            loadUrlInternal(tab.getWebView(), url, true);
        }
        map.put("url", url);
        map.put("msg", msg);
        mHandler.sendMessageDelayed(mHandler.obtainMessage(
                ANIMATE_FROM_OVERVIEW, newTab ? 1 : 0, 0, map), delay);
        // Increment the count to indicate that we are in an animation.
        mAnimationCount++;
        // Remove the listener so we don't get any more tab changes.
        if (mTabOverview != null) {
            mTabOverview.setListener(null);
        }
        mTabListener = null;
        // Make the menu empty until the animation completes.
        mMenuState = EMPTY_MENU;
        // OMS: Update the webviewcore reference.
        if (tab.getTopWindow() != null) {
//            tab.getTopWindow().updateCurrentWebViewCore();
        }
    }

    // 500ms animation with 800ms delay
    private static final int TAB_ANIMATION_DURATION = 200;
    private static final int TAB_OVERVIEW_DELAY     = 500;

    // Called by TabControl when a tab is requesting focus
    /* package */ void showTab(TabControl.Tab t) {
        showTab(t, null);
    }

    private void showTab(TabControl.Tab t, String url) {
        // Disallow focus change during a tab animation.
        if (mAnimationCount > 0) {
            return;
        }
        int delay = 0;
        if (mTabOverview == null) {
            // Add a delay so the tab overview can be shown before the second
            // animation begins.
            delay = TAB_ANIMATION_DURATION + TAB_OVERVIEW_DELAY;
            tabPicker(false, mTabControl.getTabIndex(t), false, true, false);
        }
        sendAnimateFromOverview(t, false, url, delay, null);
    }

    // This method does a ton of stuff. It will attempt to create a new tab
    // if we haven't reached MAX_TABS. Otherwise it uses the current tab. If
    // url isn't null, it will load the given url. If the tab overview is not
    // showing, it will animate to the tab overview, create a new tab and
    // animate away from it. After the animation completes, it will dispatch
    // the given Message. If the tab overview is already showing (i.e. this
    // method is called from TabListener.onClick(), the method will animate
    // away from the tab overview.
    private void openTabAndShow(String url, final Message msg,
            boolean closeOnExit, String appId) {
        final boolean newTab = mTabControl.getTabCount() != TabControl.MAX_TABS;
        final TabControl.Tab currentTab = mTabControl.getCurrentTab();
        if (newTab) {
            int delay = 0;
            // If the tab overview is up and there are animations, just load
            // the url.
            if (mTabOverview != null && mAnimationCount > 0) {
                if (url != null) {
                    // We should not have a msg here since onCreateWindow
                    // checks the animation count and every other caller passes
                    // null.
                    assert msg == null;
                    // just dismiss the subwindow and load the given url.
                    dismissSubWindow(currentTab);
                    //currentTab.getWebView().loadUrl(url);
                    loadUrlInternal(currentTab.getWebView(), url, true);
                }
            } else {
                // show mTabOverview if it is not there.
                if (mTabOverview == null) {
                    // We have to delay the animation from the tab picker by the
                    // length of the tab animation. Add a delay so the tab
                    // overview can be shown before the second animation begins.
                    delay = TAB_ANIMATION_DURATION + TAB_OVERVIEW_DELAY;
                    tabPicker(false, BrowserTabView.NEW_TAB, false, true, false);
                }
                // Animate from the Tab overview after any animations have
                // finished.
                sendAnimateFromOverview(
                        mTabControl.createNewTab(closeOnExit, appId, url), true,
                        url, delay, msg);
            }
        } else if (url != null) {
            // We should not have a msg here.
            assert msg == null;
            if (mTabOverview != null && mAnimationCount == 0) {
                sendAnimateFromOverview(currentTab, false, url,
                        TAB_OVERVIEW_DELAY, null);
            } else {
                // Get rid of the subwindow if it exists
                dismissSubWindow(currentTab);
                // Load the given url.
                //currentTab.getWebView().loadUrl(url);
                loadUrlInternal(currentTab.getWebView(), url, true);
            }
        }
    }

    private Animation createTabAnimation(final AnimatingView view,
            final View cell, boolean scaleDown) {
        final AnimationSet set = new AnimationSet(true);
        final float scaleX = (float) cell.getWidth() / view.getWidth();
        final float scaleY = (float) cell.getHeight() / view.getHeight();
        if (scaleDown) {
            set.addAnimation(new ScaleAnimation(1.0f, scaleX, 1.0f, scaleY));
            set.addAnimation(new TranslateAnimation(0, cell.getLeft(), 0,
                    cell.getTop()));
        } else {
            set.addAnimation(new ScaleAnimation(scaleX, 1.0f, scaleY, 1.0f));
            set.addAnimation(new TranslateAnimation(cell.getLeft(), 0,
                    cell.getTop(), 0));
        }
        set.setDuration(TAB_ANIMATION_DURATION);
        set.setInterpolator(new DecelerateInterpolator());
        return set;
    }

    // Animate to the tab overview. currentIndex tells us which position to
    // animate to and newIndex is the position that should be selected after
    // the animation completes.
    // If remove is true, after the animation stops, a confirmation dialog will
    // be displayed to the user.
    private void animateToTabOverview(final int newIndex, final boolean remove,
            final AnimatingView view) {
        // Find the view in the BrowserTabView allowing for the "New Tab" cell.
        int position = mTabControl.getTabIndex(view.mTab);
        if (!((ImageAdapter) mTabOverview.getAdapter()).maxedOut() && 
        	   BrowserTabView.TAB_GALLERY_MODE != mSettings.getCurrentTabMode(this)) {
            position++;
        }

        // Offset the tab position with the first visible position to get a
        // number between 0 and 3.
        position -= mTabOverview.getFirstVisiblePosition();

        // Grab the view that we are going to animate to.
        final View v = mTabOverview.getChildAt(position);

        final Animation.AnimationListener l =
                new Animation.AnimationListener() {
                    public void onAnimationStart(Animation a) {
                        saveLockIcon();
                        if(mTabOverview == null){
                            Log.e("BrwException","mTabOverview was dismissed or not init");
                            return;
                        }
                        mTabOverview.requestFocus();
                        // Clear the listener so we don't trigger a tab
                        // selection.
                        mTabOverview.setListener(null);
                    }
                    public void onAnimationRepeat(Animation a) {}
                    public void onAnimationEnd(Animation a) {
                        // We are no longer animating so decrement the count.
                        mAnimationCount--;
                        // Make the view GONE so that it will not draw between
                        // now and when the Runnable is handled.
                        view.setVisibility(View.GONE);
                        // Post a runnable since we can't modify the view
                        // hierarchy during this callback.
                        mHandler.post(new Runnable() {
                            public void run() {
                                // Remove the AnimatingView.
                                mContentView.removeView(view);
                                if (mTabOverview != null) {
                                    // Make newIndex visible.
                                    mTabOverview.setCurrentIndex(newIndex);
                                    // Restore the listener.
                                    mTabOverview.setListener(mTabListener);
                                    // Change the menu to TAB_MENU if the
                                    // BrowserTabView is interactive.
                                    if (mTabOverview.isLive()) {
                                        mMenuState = R.id.TAB_MENU;
                                        mTabOverview.requestFocus();
                                    }
                                }
                                // If a remove was requested, remove the tab.
                                if (remove) {
                                    // During a remove, the current tab has
                                    // already changed. Remember the current one
                                    // here.
                                    final TabControl.Tab currentTab =
                                            mTabControl.getCurrentTab();
                                    // Remove the tab at newIndex from
                                    // TabControl and the tab overview.
                                    final TabControl.Tab tab =
                                            mTabControl.getTab(newIndex);
                                    mTabControl.removeTab(tab);
                                    // Restore the current tab.
                                    if (currentTab != tab) {
                                        mTabControl.setCurrentTab(currentTab);
                                    }
                                    if (mTabOverview != null) {
                                        mTabOverview.remove(newIndex);
                                        // Make the current tab visible.
                                        mTabOverview.setCurrentIndex(
                                                mTabControl.getCurrentIndex());
                                    }
                                }
                            }
                        });
                        //OMS 0095669:unlock the orientation(if locked for tabview) when the animation ends.
                        if(mLockOrientationForTabView){
                            toggleLockOrientation();
                            mLockOrientationForTabView = false;
                        }
                    }
                };

        // Do an animation if there is a view to animate to.
        if (v != null) {
            // Create our animation
            final Animation anim = createTabAnimation(view, v, true);
            anim.setAnimationListener(l);
            // Start animating
            view.startAnimation(anim);
        } else {
            //OMS 0095669:unlock the orientation(if locked for tabview) when the animation ends.
            if(mLockOrientationForTabView){
                toggleLockOrientation();
                mLockOrientationForTabView = false;
            }
            // If something goes wrong and we didn't find a view to animate to,
            // just do everything here.
            l.onAnimationStart(null);
            l.onAnimationEnd(null);
        }
    }

    // Animate from the tab picker. The index supplied is the index to animate
    // from.
    private void animateFromTabOverview(final AnimatingView view,
            final boolean newTab, final Message msg) {
        // firstVisible is the first visible tab on the screen.  This helps
        // to know which corner of the screen the selected tab is.
        int firstVisible = mTabOverview.getFirstVisiblePosition();
        // tabPosition is the 0-based index of of the tab being opened
        int tabPosition = mTabControl.getTabIndex(view.mTab);
        if (!((ImageAdapter) mTabOverview.getAdapter()).maxedOut()  && 
        	   BrowserTabView.TAB_GALLERY_MODE != mSettings.getCurrentTabMode(this)) {
            // Add one to make room for the "New Tab" cell.
            tabPosition++;
        }
        // If this is a new tab, animate from the "New Tab" cell.
        if (newTab) {
            tabPosition = 0;
        }
        // Location corresponds to the four corners of the screen.
        // A new tab or 0 is upper left, 0 for an old tab is upper
        // right, 1 is lower left, and 2 is lower right
        int location = tabPosition - firstVisible;

        // Find the view at this location.
        final View v = mTabOverview.getChildAt(location);

        // Wait until the animation completes to replace the AnimatingView.
        final Animation.AnimationListener l =
                new Animation.AnimationListener() {
                    public void onAnimationStart(Animation a) {}
                    public void onAnimationRepeat(Animation a) {}
                    public void onAnimationEnd(Animation a) {
                        mHandler.post(new Runnable() {
                            public void run() {
                                mContentView.removeView(view);
                                // Dismiss the tab overview. If the cell at the
                                // given location is null, set the fade
                                // parameter to true.
                                dismissTabOverview(v == null);
                                TabControl.Tab t =
                                        mTabControl.getCurrentTab();
                                mMenuState = R.id.MAIN_MENU;
                                // Resume regular updates.
                                t.getWebView().resumeTimers();
                                // Dispatch the message after the animation
                                // completes.
                                if (msg != null) {
                                    msg.sendToTarget();
                                }
                                // The animation is done and the tab overview is
                                // gone so allow key events and other animations
                                // to begin.
                                mAnimationCount--;
                                // Reset all the title bar info.
                                //revertLockIcon();
                                resetLockIcon(t.getUrl());
                                resetTitleIconAndProgress();
                            }
                        });
                    }
                };

        if (v != null) {
            final Animation anim = createTabAnimation(view, v, false);
            // Set the listener and start animating
            anim.setAnimationListener(l);
            view.startAnimation(anim);
            // Make the view VISIBLE during the animation.
            view.setVisibility(View.VISIBLE);
        } else {
            // Go ahead and do all the cleanup.
            l.onAnimationEnd(null);
        }
    }

    // Dismiss the tab overview applying a fade if needed.
    private void dismissTabOverview(final boolean fade) {
        //Log.d(LOGTAG,"dismissing tab view... fade = "+fade);
        if (fade) {
            AlphaAnimation anim = new AlphaAnimation(1.0f, 0.0f);
            anim.setDuration(500);
            anim.startNow();
            mTabOverview.startAnimation(anim);
        }
        // Just in case there was a problem with animating away from the tab
        // overview
        WebView current = mTabControl.getCurrentWebView();
        if (current != null) {
            current.setVisibility(View.VISIBLE);
        } else {
            Log.e(LOGTAG, "No current WebView in dismissTabOverview");
        }
        // Make the sub window container visible.
        if (mTabControl.getCurrentSubWindow() != null) {
            mTabControl.getCurrentTab().getSubWebViewContainer()
                    .setVisibility(View.VISIBLE);
        }
        mTabOverview.removeChildViews();
        mContentView.removeView((View)mTabOverview);
        // Clear all the data for tab picker so next time it will be
        // recreated.
        mTabControl.wipeAllPickerData();
        mTabOverview.clear();
        mTabOverview = null;
        mTabListener = null;
    }

    private void openTab(String url) {
        if (mSettings.openInBackground()) {
            TabControl.Tab t = mTabControl.createNewTab();
            if (t != null) {
                //t.getWebView().loadUrl(url);
                loadUrlInternal(t.getWebView(), url, true);
            }
        } else {
            openTabAndShow(url, null, false, null);
        }
    }

    /*private class BrowserShowDlg extends Activity {
        @Override public void onCreate(Bundle icicle) {
            Log.e("BrowserShowDlg", "onCreate . ..............");
            super.onCreate(icicle);

            final Intent intent = getIntent();
            final String cid = intent.getStringExtra("DRM_FILE_CID");
            new AlertDialog.Builder(this)
                    .setTitle("TODO: this is title")
                    .setMessage("TODO: this is msg")
                    .setPositiveButton(R.string.ok, 
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    String file = OmaDownloadManager.mDrmCidMap.get(cid)[0]; 
                                    String mime = OmaDownloadManager.mDrmCidMap.get(cid)[1];  
                                    Uri contentUri = Uri.parse(file);
                                    Log.d("Browser", "file="+file+", mime="+mime+", contentUri="+contentUri);
                                    Intent i = new Intent();
                                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    i.setAction(Intent.ACTION_VIEW);
                                    i.setDataAndType(contentUri, mime);
                                    Log.d("Browser", "file="+file+", mime="+mime);
                                    startActivity(i); 
                                }
                           })
                    .setNegativeButton(R.string.cancel, null)
                    .show();

        }
    }*/

    private class Copy implements OnMenuItemClickListener {
        private CharSequence mText;

        public boolean onMenuItemClick(MenuItem item) {
            copy(mText);
            return true;
        }

        public Copy(CharSequence toCopy) {
            mText = toCopy;
        }
    }

    private class Download implements OnMenuItemClickListener {
        private String mText;

        public boolean onMenuItemClick(MenuItem item) {
            onDownloadStartNoStream(mText, null, null, null, -1);
            return true;
        }

        public Download(String toDownload) {
            mText = toDownload;
        }
    }

    private void copy(CharSequence text) {
        try {
            IClipboard clip = IClipboard.Stub.asInterface(ServiceManager.getService("clipboard"));
            if (clip != null) {
                clip.setClipboardText(text);
            }
        } catch (android.os.RemoteException e) {
            Log.e(LOGTAG, "Copy failed", e);
        }
    }

    /**
     * Resets the browser title-view to whatever it must be (for example, if we
     * load a page from history).
     */
    private void resetTitle() {
        resetLockIcon();
        resetTitleIconAndProgress();
    }

    /**
     * Resets the browser title-view to whatever it must be
     * (for example, if we had a loading error)
     * When we have a new page, we call resetTitle, when we
     * have to reset the titlebar to whatever it used to be
     * (for example, if the user chose to stop loading), we
     * call resetTitleAndRevertLockIcon.
     */
    /* package */ void resetTitleAndRevertLockIcon() {
        revertLockIcon();
        resetTitleIconAndProgress();
    }

    /**
     * Reset the title, favicon, and progress.
     */
    private void resetTitleIconAndProgress() {
        WebView current = mTabControl.getCurrentWebView();
        if (current == null) {
            return;
        }
        resetTitleAndIcon(current);
        int progress;
        if (mInLoad) { 
            progress = current.getProgress();
        } else {
            // OMS: for other cases (e.g. APM), when reset title, 
            // the page may be not in load, so set progress to 100 percent.
            progress = 100;
        }
        mWebChromeClient.onProgressChanged(current, progress);
    }

    // Reset the title and the icon based on the given item.
    private void resetTitleAndIcon(WebView view) {
        WebHistoryItem item = view.copyBackForwardList().getCurrentItem();
        if (item != null) {
            setUrlTitle(item.getUrl(), item.getTitle());
            setFavicon(item.getFavicon());
        } else {
            setUrlTitle(null, null);
            setFavicon(null);
        }
    }

    // Reset progress bar for data connection when local file is loaded.
    private void resetTitleForDataConenction() {
        synchronized (this) {
            if(mNetworkConnecting) {
                WebView view = getCurrentWebView();
                String url = view == null ? null : view.getUrl();
                if(url != null && url.startsWith("file://")) {
                    waitForNetwork();
                }
            }
        }
    }

    /**
     * Sets a title composed of the URL and the title string.
     * @param url The URL of the site being loaded.
     * @param title The title of the site being loaded.
     */
    private void setUrlTitle(String url, String title) {
        mUrl = url;
        mTitle = title;

        mTitleBar.setTitleAndUrl(title, url);

        if (mFakeTitleBar != null) {
            mFakeTitleBar.setTitleAndUrl(title, url);
        }
    }

    private void setUrlTitle(String urlAndTitle) {
        mTitleBar.setTitleAndUrl(urlAndTitle);
        if (mFakeTitleBar != null) {
            mFakeTitleBar.setTitleAndUrl(urlAndTitle);
        }
    }

    /**
     * Builds and returns the page title, which is some
     * combination of the page URL and title.
     * @param url The URL of the site being loaded.
     * @param title The title of the site being loaded.
     * @return The page title.
     */
    private String buildUrlTitle(String url, String title) {
        String urlTitle = "";

        if (url != null) {
            String titleUrl = buildTitleUrl(url);

            if (title != null && 0 < title.length()) {
                if (titleUrl != null && 0 < titleUrl.length()) {
                    urlTitle = titleUrl + ": " + title;
                } else {
                    urlTitle = title;
                }
            } else {
                if (titleUrl != null) {
                    urlTitle = titleUrl;
                }
            }
        }

        return urlTitle;
    }

    /**
     * @param url The URL to build a title version of the URL from.
     * @return The title version of the URL or null if fails.
     * The title version of the URL can be either the URL hostname,
     * or the hostname with an "https://" prefix (for secure URLs),
     * or an empty string if, for example, the URL in question is a
     * file:// URL with no hostname.
     */
    /* package */ static String buildTitleUrl(String url) {
        String titleUrl = null;

        if (url != null) {
            try {
                // parse the url string
                URL urlObj = new URL(url);
                if (urlObj != null) {
                    titleUrl = "";

                    String protocol = urlObj.getProtocol();
                    String host = urlObj.getHost();

                    if (host != null && 0 < host.length()) {
                        titleUrl = host;
                        if (protocol != null) {
                            // if a secure site, add an "https://" prefix!
                            if (protocol.equalsIgnoreCase("https")) {
                                titleUrl = protocol + "://" + host;
                            }
                        }
                    }
                }
            } catch (MalformedURLException e) {}
        }

        return titleUrl;
    }

    // Set the favicon in the title bar.
    private void setFavicon(Bitmap icon) {
        mTitleBar.setFavicon(icon);
        if (mFakeTitleBar != null) {
            mFakeTitleBar.setFavicon(icon);
        }
    }

    /**
     * Saves the current lock-icon state before resetting
     * the lock icon. If we have an error, we may need to
     * roll back to the previous state.
     */
    private void saveLockIcon() {
        mPrevLockType = mLockIconType;
    }

    /**
     * Reverts the lock-icon state to the last saved state,
     * for example, if we had an error, and need to cancel
     * the load.
     */
    private void revertLockIcon() {
        mLockIconType = mPrevLockType;

        if (LOGV_ENABLED) {
            Log.v(LOGTAG, "BrowserActivity.revertLockIcon:" +
                  " revert lock icon to " + mLockIconType);
        }

        updateLockIconImage(mLockIconType);
    }

    /**
     * Close the tab, remove its associated title bar, and adjust mTabControl's
     * current tab to a valid value.
     */
    /* package */ void closeTab(TabControl.Tab t) {
        int currentIndex = mTabControl.getCurrentIndex();
        int removeIndex = mTabControl.getTabIndex(t);
        mTabControl.removeTab(t);
        if (currentIndex >= removeIndex && currentIndex != 0) {
            currentIndex--;
        }
        mTabControl.setCurrentTab(mTabControl.getTab(currentIndex));
        resetTitleIconAndProgress();
    }

    private void removeTabAndShow(int indexToRemove, int indexToShow) {
        int delay = TAB_ANIMATION_DURATION + TAB_OVERVIEW_DELAY;
        // Animate to the tab picker, remove the current tab, then
        // animate away from the tab picker to the parent WebView.
        tabPicker(false, indexToRemove, true, true, false);
        // Change to the parent tab
        final TabControl.Tab tab = mTabControl.getTab(indexToShow);
        if (tab != null) {
            sendAnimateFromOverview(tab, false, null, delay, null);
        } else {
         
            // Send a message to open a new tab.
            mHandler.sendMessageDelayed(
                    mHandler.obtainMessage(OPEN_TAB_AND_SHOW,
                        mSettings.getHomePage()), delay);
        }
    }

    private AlertDialog mExitDialog;
    public void confirmToQuit() {
        // In some very rare case or monkey test, we may receive 2 or more 
        // BACK key events in a short seconds.
        if(mExitDialog != null && mExitDialog.isShowing()) {
            return;
        }
        mExitDialog = new AlertDialog.Builder(BrowserActivity.this)
            .setIcon(com.android.internal.R.drawable.cmcc_dialog_question)
            .setTitle(R.string.exit_message)
            //.setMessage(R.string.exit_message)
            .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    mKillProcessAfterExited = true;
                    BrowserActivity.this.goQuit();
                }})
            .setNegativeButton(R.string.cancel, null)
            .create();
        // OMS: refer to #0096476. 
        // Since browser will exit its process when onDestroy, we don't expect 
        // exit dialog animation. Just disable it. 
        mExitDialog.getWindow().setWindowAnimations(-1);
        
        mExitDialog.show();
    }

    private void goBackOnePageOrQuit() {
        TabControl.Tab current = mTabControl.getCurrentTab();
        if (current == null) {
            /*
             * Instead of finishing the activity, simply push this to the back
             * of the stack and let ActivityManager to choose the foreground
             * activity. As BrowserActivity is singleTask, it will be always the
             * root of the task. So we can use either true or false for
             * moveTaskToBack().
             */
            moveTaskToBack(true);
            return;
        }
        WebView w = current.getWebView();
        if (w.canGoBack()) {
            w.goBack();
        } else {
            // Check to see if we are closing a window that was created by
            // another window. If so, we switch back to that window.
            TabControl.Tab parent = current.getParentTab();
            if (parent != null) {
                switchToTab(mTabControl.getTabIndex(parent));
                // Now we close the other tab
                closeTab(current);
            } else {
                boolean tabRemoved = false;
                if (current.closeOnExit()) {
                    // force mPageStarted to be false as we are going to either
                    // finish the activity or remove the tab. This will ensure
                    // pauseWebView() taking action.
                    mPageStarted = false;
                    if (mTabControl.getTabCount() == 1) {
                        // OMS TODO: should we exit the process in such case?
                        //mKillProcessAfterExited = true;
                        finish();
                        return;
                    }
                    // call pauseWebViewTimers() now, we won't be able to call
                    // it in onPause() as the WebView won't be valid.
                    // Temporarily change mActivityInPause to be true as
                    // pauseWebViewTimers() will do nothing if mActivityInPause
                    // is false.
                    boolean savedState = mActivityInPause;
                    if (savedState) {
                        Log.e(LOGTAG, "BrowserActivity is already paused "
                                + "while handing goBackOnePageOrQuit.");
                    }
                    mActivityInPause = true;
                    pauseWebViewTimers();
                    mActivityInPause = savedState;
                    removeTabFromContentView(current);
                    mTabControl.removeTab(current);
                    tabRemoved = true;
                }

                // OMS: closeOnExit() means browser is launched from other app 
                // such as MMS to open a link, and we want to close this tab
                // after exiting it. But we don't exit browser process as user 
                // may want to open another link soon.
                // In other cases it should go to the same path as 
                // confirmToQuit().
                if(!tabRemoved) {
                    // OMS: we go quit.
                    confirmToQuit();//goQuit();
                    return;
                }

                /*
                 * Instead of finishing the activity, simply push this to the back
                 * of the stack and let ActivityManager to choose the foreground
                 * activity. As BrowserActivity is singleTask, it will be always the
                 * root of the task. So we can use either true or false for
                 * moveTaskToBack().
                 */
                moveTaskToBack(true);
                Log.d(LOGTAG, "Browser moved to back...");
            }
        }
    }

    public void goQuit() {
        Log.d(LOGTAG, "Browser is about to quit...");
        
        // Move to back when there's ongoing download task.
        if(BrowserDownloadPage.unfinishedDownload(this)) {
            Log.d(LOGTAG, "Move to back as there's ongoing download task...");
            moveTaskToBack(true);
            return;
        }

        if(mInLoad) {
            stopLoading();
        }

        // Call this before restoring the user preferred profile.
        disconnect();

        // OMS: restore the user preferred data connection here.
        if(mUserPreferredProfile != null && 
                !mUserPreferredProfile.equals(mNetworkManager.getNetworkProfile())) {
            mNetworkManager.setNetworkProfile(mUserPreferredProfile);
            Editor sp = PreferenceManager.getDefaultSharedPreferences(this).edit();
            sp.putString("data_connection", mUserPreferredProfile);
        }
        BrowserActivity.this.finish();

        //final ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        //Log.e(LOGTAG, "restartPackage...");
        //am.restartPackage(getPackageName());
    }

    public void goHide() {
        Log.d(LOGTAG, "Move to back...");
        moveTaskToBack(true);
        return;
    }

    /*package*/ void onBackKey() {
        // Do something same as on KEYCODE_BACK

        // Dismiss page overview if it's there...
        if(clearSubViewsOnBackKey()) {
            return;
        }

        // FIXME: Currently, we do not have a notion of the
        // history picker for the subwindow, but maybe we
        // should?
        WebView subwindow = mTabControl.getCurrentSubWindow();
        if (subwindow != null) {
            if (subwindow.canGoBack()) {
                subwindow.goBack();
            } else {
                dismissSubWindow(mTabControl.getCurrentTab());
            }
        } else {
            goBackOnePageOrQuit();
        }
    }

    public KeyTracker.State onKeyTracker(int keyCode,
                                         KeyEvent event,
                                         KeyTracker.Stage stage,
                                         int duration) {
        // if onKeyTracker() is called after activity onStop()
        // because of accumulated key events,
        // we should ignore it as browser is not active any more.
        WebView topWindow = getTopWindow();
        if (topWindow == null)
            return KeyTracker.State.NOT_TRACKING;

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // During animations, block the back key so that other animations
            // are not triggered and so that we don't end up destroying all the
            // WebViews before finishing the animation.
            if (mAnimationCount > 0) {
                return KeyTracker.State.DONE_TRACKING;
            }
            if (stage == KeyTracker.Stage.UP) {
                // Dismiss page overview if it's there...
                if(clearSubViewsOnBackKey()) {
                    return KeyTracker.State.DONE_TRACKING;
                }

                // FIXME: Currently, we do not have a notion of the
                // history picker for the subwindow, but maybe we
                // should?
                WebView subwindow = mTabControl.getCurrentSubWindow();
                if (subwindow != null) {
                    if (subwindow.canGoBack()) {
                        subwindow.goBack();
                    } else {
                        dismissSubWindow(mTabControl.getCurrentTab());
                    }
                } else {
                    goBackOnePageOrQuit();
                }
                return KeyTracker.State.DONE_TRACKING;
            }
            return KeyTracker.State.KEEP_TRACKING;
        }
        return KeyTracker.State.NOT_TRACKING;
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        // OMS: In case not initialized...
        if(!mInitialized) return true;

        if (keyCode == KeyEvent.KEYCODE_MENU) {
            mMenuIsDown = true;
        }

        //ANDROID_MOT_FLASHLITE modified
        boolean handled = false;
        if(mFlashBrowserActivity != null )
            handled = mFlashBrowserActivity.onKeyDown(keyCode, event);
        if(handled)
            return true;
        //end of ANDROID_MOT_FLASHLITE
        if(!handled) 
            handled =  mKeyTracker.doKeyDown(keyCode, event);

        if (!handled) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_SPACE:
                    if (mMenuState != R.id.MAIN_MENU){
                        break;
                    }
                    if (event.isShiftPressed()) {
                        getTopWindow().pageUp(false);
                    } else {
                        getTopWindow().pageDown(false);
                    }
                    handled = true;
                    break;

                default:
                    break;
            }
        }
        return handled || super.onKeyDown(keyCode, event);
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        // OMS: In case not initialized...
        if(!mInitialized) return true;

        if (keyCode == KeyEvent.KEYCODE_MENU) {
            mMenuIsDown = false;
        }
        return mKeyTracker.doKeyUp(keyCode, event) || super.onKeyUp(keyCode, event);
    }

    /* package */ void stopLoading() {
        WebView w = getTopWindow();
        if(w == null){
            Log.e("BrwExcepction","tow window is null");
            return;
        }
        mDidStopLoad = true;
        resetTitleAndRevertLockIcon();
        w.stopLoading();
        mWebViewClient.onPageFinished(w, w.getUrl());

        cancelStopToast();
        mStopToast = Toast
                .makeText(this, R.string.stopping, Toast.LENGTH_SHORT);
        mStopToast.show();
    }

    private void cancelStopToast() {
        if (mStopToast != null) {
            mStopToast.cancel();
            mStopToast = null;
        }
    }

    // called by a non-UI thread to post the message
    public void postMessage(int what, int arg1, int arg2, Object obj) {
        mHandler.sendMessage(mHandler.obtainMessage(what, arg1, arg2, obj));
    }

    // public message ids
    public final static int LOAD_URL                = 1001;
    public final static int STOP_LOAD               = 1002;
    
    // Message Ids
    private static final int JS_CONFIRM              = 101;
    private static final int FOCUS_NODE_HREF         = 102;
    private static final int CANCEL_CREDS_REQUEST    = 103;
    private static final int ANIMATE_FROM_OVERVIEW   = 104;
    private static final int ANIMATE_TO_OVERVIEW     = 105;
    private static final int OPEN_TAB_AND_SHOW       = 106;
    private static final int CHECK_MEMORY            = 107;
    private static final int RELEASE_WAKELOCK        = 108;
    private static final int SHOW_TAB_VIEW        = 109;


    // How many times we will keep retry when data connection is broken.
    static final int CONN_RETRY_COUNTS = 2;
    static int mRetryCount = 0;

    // Private handler for handling javascript and saving passwords
    private Handler mHandler = new Handler() {

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case JS_CONFIRM:
                    JsResult res = (JsResult) msg.obj;
                    if (msg.arg1 == 0) {
                        res.cancel();
                    } else {
                        res.confirm();
                    }
                    break;

                case ANIMATE_FROM_OVERVIEW:
                    final HashMap map = (HashMap) msg.obj;
                    animateFromTabOverview((AnimatingView) map.get("view"),
                            msg.arg1 == 1, 
                            (Message) map.get("msg"));
                    break;

                case ANIMATE_TO_OVERVIEW:
                    animateToTabOverview(msg.arg1, msg.arg2 == 1,
                            (AnimatingView) msg.obj);
                    break;

                case OPEN_TAB_AND_SHOW:
                    // Decrement mAnimationCount before openTabAndShow because
                    // the method relies on the value being 0 to start the next
                    // animation.
                    mAnimationCount--;
                    openTabAndShow((String) msg.obj, null, false, null);
                    break;

                case FOCUS_NODE_HREF:
                    String url = (String) msg.getData().get("url");
                    if (url == null || url.length() == 0) {
                        break;
                    }
                    HashMap focusNodeMap = (HashMap) msg.obj;
                    WebView view = (WebView) focusNodeMap.get("webview");
                    // Only apply the action if the top window did not change.
                    if (getTopWindow() != view) {
                        break;
                    }
                    switch (msg.arg1) {
                        //case R.id.open_context_menu_id:
                        case R.id.view_image_context_menu_id:
                            loadURL(getTopWindow(), url);
                            break;
/*
                        case R.id.share_image_context_menu_id:
                            BrowserShareImage bsi = new  BrowserShareImage(BrowserActivity.this, url);
                            bsi.share();
                            break;
*/
                        case R.id.open_newtab_context_menu_id:
                            openTab(url);
                            break;
                        case R.id.bookmark_context_menu_id:
                            Intent intent = new Intent(BrowserActivity.this,
                                    com.android.browser.cmcc.CMCCAddBookmarkPage.class);
                            intent.putExtra("url", url);
                            startActivity(intent);
                            break;
                        case R.id.share_link_context_menu_id:
                            Browser.sendString(BrowserActivity.this, url);
                            break;
                        case R.id.copy_link_context_menu_id:
                            copy(url);
                            break;
                        case R.id.save_link_context_menu_id:
                        case R.id.download_context_menu_id:
                            onDownloadStartNoStream(url, null, null, null, -1);
                            break;
                    }
                    break;

                case LOAD_URL:
                    loadURL(getTopWindow(), (String) msg.obj);
                    break;

                case STOP_LOAD:
                    stopLoading();
                    break;

                case CANCEL_CREDS_REQUEST:
                    resumeAfterCredentials();
                    break;

                case CHECK_MEMORY:
                    // reschedule to check memory condition
                    mHandler.removeMessages(CHECK_MEMORY);
                    mHandler.sendMessageDelayed(mHandler.obtainMessage
                            (CHECK_MEMORY), CHECK_MEMORY_INTERVAL);
                    Log.e(MEMLOG, "BrowserActivity CHECK_MEMORY, will call checkMemory");
                    checkMemory();
                    break;

                case RELEASE_WAKELOCK:
                    int n = mTabControl.getTabCount();
                    for (int i=0; i<n; i++) {
                        TabControl.Tab t = mTabControl.getTab(i);
                        Log.d("BrowserActivity", "------wake lock, t="+t);
                        if (t != null && t.getTopWindow() != null) {
                            t.getTopWindow().stopLoading();
                        }
                    }

                    if (mWakeLock.isHeld()) {
                        mWakeLock.release();
                    }
                    break;
                case SHOW_TAB_VIEW:
                    //OMS 0095669:unlock the orientation(if locked for tabview) when scroll ends.
                    if(mLockOrientationForTabView){
                        toggleLockOrientation();
                        mLockOrientationForTabView = false;
                    }
         	        showTabView(msg.arg1, msg.arg2 == 1, true);
                	break;
            }
        }
    };

    //ANDROID_MOT_FLASHLITE
   /* private void SwitchExitFlashFullScreenMode(boolean isFullScreenMode) {
        if(!mFlashEnabled) {
            return;
        }

        Log.d("MOT-Flash", "SwitchExitFlashFullScreenMode, TODO: hide/show the status bar");
        Window win = getWindow();
        WebView w = mTabControl.getCurrentWebView();
        WebViewExt.getWebViewExtImpl(w).setIsFlashFullScreenMode(isFullScreenMode);
        if(isFullScreenMode){
            win.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            WebViewExt.getWebViewExtImpl(w).switchFlashFullScreenMode();
        }
        else{
            win.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            WebViewExt.getWebViewExtImpl(w).exitFlashFullScreenMode();
        }
        setTitleVisibility(!isFullScreenMode);
        w.requestLayout();
        w.invalidate();
        isFlashFullScreenMode = isFullScreenMode;
   }

   private void setTitleVisibility(boolean visible) {
       int viewVisible;
       if (visible) viewVisible = View.VISIBLE;
       else viewVisible = View.GONE;

       Window win = getWindow();
       // remove window title
       View title = win.findViewById(com.android.internal.R.id.title);
       if(title != null) 
           title.setVisibility(viewVisible);
       View titleContainer = findViewById(com.android.internal.R.id.title_container);
       if(titleContainer != null) 
           titleContainer.setVisibility(viewVisible);
       
   }

    private void setFlashQuality() {
        if(!mFlashEnabled) {
            return;
        }

        Log.e("MOT-Flash", "in setFlashQuality");
        CharSequence[] qualityItems = new CharSequence[3];
        qualityItems[0] = "High";
        qualityItems[1] = "Medium";
        qualityItems[2] = "Low";

        if (-1 == whichFlashQuality) {
            WebView w = mTabControl.getCurrentWebView();
            int quality = WebViewExt.getWebViewExtImpl(w).getDefaultFlashQuality();
            if (0 == quality) {
                whichFlashQuality = 2;
            } else if (2 == quality) {
                whichFlashQuality = 0;
            } else {
                whichFlashQuality = 1;
            }
            Log.e("MOT-Flash", "set default flash quality="+whichFlashQuality);
        }
        
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setSingleChoiceItems(qualityItems, whichFlashQuality, 
            new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Log.e("MOT-Flash", "in setFlashQuality, onClick, which = "+which);
                    WebView w = mTabControl.getCurrentWebView();
                    WebViewExt.getWebViewExtImpl(w).setFlashQuality(which);
                    whichFlashQuality = which;
                    dialog.dismiss();
                }
        }).show();
    } */
   //end of ANDROID_MOT_FLASHLITE

    // -------------------------------------------------------------------------
    // WebViewClient implementation.
    //-------------------------------------------------------------------------

    // Use in overrideUrlLoading
    /* package */ final static String SCHEME_WTAI = "wtai://wp/";
    /* package */ final static String SCHEME_WTAI_MC = "wtai://wp/mc;";
    /* package */ final static String SCHEME_WTAI_SD = "wtai://wp/sd;";
    /* package */ final static String SCHEME_WTAI_AP = "wtai://wp/ap;";

    //ANDROID_MOT_FLASHLITE
    /* CR18963--WQP378--FlashLite: The word development which is not visible in
    * the message filed is visible in the multimedia message application. */
    /* package */ final static String SCHEME_SMS = "sms";
    /* package */ final static String SCHEME_MMS = "mms";
    /* package */ final static String SCHEME_MAILTO = "mailto";
    /* package */ final static String SCHEME_VTEL = "vtel:";
    //END of ANDROID_MOT_FLASHLITE


    /* package */ WebViewClient getWebViewClient() {
        return mWebViewClient;
    }

    private void updateIcon(String url, Bitmap icon) {
        if (icon != null) {
            BrowserBookmarksAdapter.updateBookmarkFavicon(mResolver,
                    url, icon);
        }
        setFavicon(icon);
    }

    private final WebViewClient mWebViewClient = new WebViewClient() {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            resetLockIcon(url);
            setUrlTitle(url, null);
            // Call updateIcon instead of setFavicon so the bookmark
            // database can be updated.
            updateIcon(url, favicon);

            // Update button status on control panel if needed.
            if(mControlPanel != null) {
                mControlPanel.onPageStarted(view);
            }

            if (mSettings.isTracing() == true) {
                // FIXME: we should save the trace file somewhere other than data.
                // I can't use "/tmp" as it competes for system memory.
                File file = getDir("browserTrace", 0);
                String baseDir = file.getPath();
                if (!baseDir.endsWith(File.separator)) baseDir += File.separator;
                String host;
                try {
                    WebAddress uri = new WebAddress(url);
                    host = uri.mHost;
                } catch (android.net.ParseException ex) {
                    host = "unknown_host";
                }
                host = host.replace('.', '_');
                baseDir = baseDir + host;
                file = new File(baseDir+".data");
                if (file.exists() == true) {
                    file.delete();
                }
                file = new File(baseDir+".key");
                if (file.exists() == true) {
                    file.delete();
                }
                mInTrace = true;
                Debug.startMethodTracing(baseDir, 8 * 1024 * 1024);
            }

            // Performance probe
            /* OMS: remove for now.
            if (false) {
                mStart = SystemClock.uptimeMillis();
                mProcessStart = Process.getElapsedCpuTime();
                long[] sysCpu = new long[7];
                if (Process.readProcFile("/proc/stat", SYSTEM_CPU_FORMAT, null,
                        sysCpu, null)) {
                    mUserStart = sysCpu[0] + sysCpu[1];
                    mSystemStart = sysCpu[2];
                    mIdleStart = sysCpu[3];
                    mIrqStart = sysCpu[4] + sysCpu[5] + sysCpu[6];
                }
                mUiStart = SystemClock.currentThreadTimeMillis();
            }*/

            if (!mPageStarted) {
                mPageStarted = true;
                // if onResume() has been called, resumeWebViewTimers() does
                // nothing.
                resumeWebViewTimers();
            }

            // reset sync timer to avoid sync starts during loading a page
            CookieSyncManager.getInstance().resetSync();

            mInLoad = true;
            mDidStopLoad = false;
            showFakeTitleBar();
            updateInLoadMenuItems();

            // schedule to check memory condition
            mHandler.sendMessageDelayed(mHandler.obtainMessage(CHECK_MEMORY),
                    CHECK_MEMORY_INTERVAL);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            // Reset the title and icon in case we stopped a provisional
            // load.
            resetTitleAndIcon(view);

            // Update button status on control panel if needed.
            if(mControlPanel != null) {
                mControlPanel.onPageFinished(view);
            }

            if (!mDidStopLoad) {
                // Only update the bookmark screenshot if the user did not
                // cancel the load early.
//                Message updateScreenshot = Message.obtain(mHandler, UPDATE_BOOKMARK_THUMBNAIL, view);
//                mHandler.sendMessageDelayed(updateScreenshot, 500);
            }

            // Update the lock icon image only once we are done loading
            updateLockIconImage(mLockIconType);

            // Performance probe
            /* OMS: remove for now.
             if (false) {
                long[] sysCpu = new long[7];
                if (Process.readProcFile("/proc/stat", SYSTEM_CPU_FORMAT, null,
                        sysCpu, null)) {
                    String uiInfo = "UI thread used "
                            + (SystemClock.currentThreadTimeMillis() - mUiStart)
                            + " ms";
                    if (LOGD_ENABLED) {
                        Log.d(LOGTAG, uiInfo);
                    }
                    //The string that gets written to the log
                    String performanceString = "It took total "
                            + (SystemClock.uptimeMillis() - mStart)
                            + " ms clock time to load the page."
                            + "\nbrowser process used "
                            + (Process.getElapsedCpuTime() - mProcessStart)
                            + " ms, user processes used "
                            + (sysCpu[0] + sysCpu[1] - mUserStart) * 10
                            + " ms, kernel used "
                            + (sysCpu[2] - mSystemStart) * 10
                            + " ms, idle took " + (sysCpu[3] - mIdleStart) * 10
                            + " ms and irq took "
                            + (sysCpu[4] + sysCpu[5] + sysCpu[6] - mIrqStart)
                            * 10 + " ms, " + uiInfo;
                    if (LOGD_ENABLED) {
                        Log.d(LOGTAG, performanceString + "\nWebpage: " + url);
                    }
                    if (url != null) {
                        // strip the url to maintain consistency
                        String newUrl = new String(url);
                        if (newUrl.startsWith("http://www.")) {
                            newUrl = newUrl.substring(11);
                        } else if (newUrl.startsWith("http://")) {
                            newUrl = newUrl.substring(7);
                        } else if (newUrl.startsWith("https://www.")) {
                            newUrl = newUrl.substring(12);
                        } else if (newUrl.startsWith("https://")) {
                            newUrl = newUrl.substring(8);
                        }
                        if (LOGD_ENABLED) {
                            Log.d(LOGTAG, newUrl + " loaded");
                        }
                    }
                }
             }*/

            if (mInTrace) {
                mInTrace = false;
                Debug.stopMethodTracing();
            }

            if (mPageStarted) {
                mPageStarted = false;
                // pauseWebViewTimers() will do nothing and return false if
                // onPause() is not called yet.
                if (pauseWebViewTimers()) {
                    if (mWakeLock.isHeld()) {
                        mHandler.removeMessages(RELEASE_WAKELOCK);
                        mWakeLock.release();
                    }
                }
            }

            // OMS: When main page load finished, we need to update option menu item
            if (mInLoad) {
                mInLoad = false;
                updateInLoadMenuItems();
            }

            // OMS: Reset progress bar in case we are loading local files and
            // still waiting for data connection. This is a work-around.
            if(mNetworkConnecting) {
                resetTitleForDataConenction();
            }

            mHandler.removeMessages(CHECK_MEMORY);
            Log.e(MEMLOG, "222 will call checkMemory");
            checkMemory();
        }

        // par url for mms or sms
        private boolean  parseUrlForXMS(String Url){
            String url = Url.toLowerCase();
            String prefix = null;
            String target = null;
            String subject = null;
            String body = null;

            if (null == url) 
                return false;

            // OMS: should we care about the capital case?? Not now...
            if (!(url.startsWith("sms") || 
                    url.startsWith("mms") || 
                    url.startsWith("mailto"))) 
                return false;

            try {
                String delim = ":?&";
                StringTokenizer st = new StringTokenizer(url, delim, true);
        
                if (st.hasMoreTokens()) {
                    prefix = st.nextToken(":").trim().toLowerCase();
                    st.nextToken(":");
                }

                if (st.hasMoreTokens()) {
                    target = st.nextToken("?").trim();
                    st.nextToken("?");
                }
                while (st.hasMoreTokens()) {
                    String part = st.nextToken("&");
                    
                    int idx = part.indexOf('=');
                    if (-1 != idx) {
                        if (part.substring(0, idx).trim().toLowerCase().equals("subject")) {
                            subject = URLDecoder.decode(part.substring(idx+1).trim(), "utf-8");
                        }
                        if (part.substring(0, idx).trim().toLowerCase().equals("body")) {
                            body = URLDecoder.decode(part.substring(idx+1).trim(), "utf-8");
                        }
                    }
                    //st.nextToken("&");
                }
            } catch (java.io.UnsupportedEncodingException e) {
                Log.d(LOGTAG, "URLDecoder.decode error", e);
            } catch (java.util.NoSuchElementException e) {
                // ignore parse error.
                ;
            }

            if ((null != target) && 
                ((target.matches("[+]?[\\d]+")) || // e.g. +86139xxxxxxxx
                (prefix != null && target.matches("\\w+(\\.\\w+)*@\\w+(\\.\\w+)+") && (prefix.startsWith("mms"))))) // for mms, email is also valid
            {
                if (prefix.startsWith("mailto")) 
                    prefix = "sms";
                String schem = prefix.startsWith("mms")? "mmsto":"smsto";
                Intent intent = new Intent(Intent.ACTION_SENDTO, 
                        Uri.fromParts(schem, target, null));
                if (null != subject) 
                    intent.putExtra(Messaging.KEY_ACTION_SENDTO_MESSAGE_SUBJECT, subject);
                if (null != body)
                    intent.putExtra(Messaging.KEY_ACTION_SENDTO_MESSAGE_BODY, body);
                Log.d(LOGTAG, "parseUrlForXms send="+prefix+", target="+target+", subject="+subject+", body="+body);                
                startActivity(intent);
                return true;
            } else {
                Log.d(LOGTAG ,"parseUrlForXms format error, cannot post intent");
                return false;
            }
        }
        //OMS:handel vtel:1232343 case
        private void handleVtelScheme(String url){
            String number = url.substring(SCHEME_VTEL.length());
            Intent intent = new Intent(Intent.ACTION_DIAL,Uri.parse(WebView.SCHEME_TEL+number));
            startActivity(intent);
        }

        // return true if want to hijack the url to let another app to handle it
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if(mActivityDestroyed) {
                Log.d(LOGTAG ,"shouldOverrideUrlLoading: browser exited.");
                return true;
            }
            if (url.startsWith(SCHEME_WTAI)) {
                // wtai://wp/mc;number
                // number=string(phone-number)
                if (url.startsWith(SCHEME_WTAI_MC)) {
                    Intent intent = new Intent(Intent.ACTION_VIEW,
                            Uri.parse(WebView.SCHEME_TEL +
                            url.substring(SCHEME_WTAI_MC.length())));
                    startActivity(intent);
                    return true;
                }
                // wtai://wp/sd;dtmf
                // dtmf=string(dialstring)
                if (url.startsWith(SCHEME_WTAI_SD)) {
                    Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse(WebView.SCHEME_TEL +
                        url.substring(SCHEME_WTAI_MC.length()).replace('*','P')));
                    startActivity(intent);
                    return true;
                }
                // wtai://wp/ap;number;name
                // number=string(phone-number)
                // name=string
                if (url.startsWith(SCHEME_WTAI_AP)) {
                    String number;
                    String name;
                    String content = url.substring(SCHEME_WTAI_AP.length());
                    int pos = content.indexOf(";");
                    if (pos > 0) {
                        number = content.substring(0,pos);
                        if(number != null) {
                            number = number.trim();
                        } else {
                            number = "";
                        }
                        name = content.substring(pos+1);
                        if(name != null) {
                            name = name.trim();
                        }
                    }else {
                        number = content.trim();
                        name = number;
                    }
                    number = number.replace("%20", "");
                    // OMS: Decode the URL to restore e.g. spaces.
                    name = URLDecoder.decode(name);
                    Log.d(LOGTAG,"wtai,number = " + number + ", name = " + name);
                    Intent newIntent = new Intent(Intent.ACTION_INSERT, People.CONTENT_URI);
                    newIntent.putExtra(Intents.Insert.PHONE, number);
                    newIntent.putExtra(Intents.Insert.NAME, name);
                    startActivity(newIntent);
                    return true;
                }
            }

            if(url.startsWith(SCHEME_VTEL)){
                handleVtelScheme(url);
                return true;
            }

            // OMS: click url MMS:13810173376  or MMSTO:13810173376 or 
            // mms:13810834826?subject=MMS+Testing&body=MMS  to call 
            // message app to send message
            if(this.parseUrlForXMS(url)){
            	return true;
            }

            // See if any other apps to handle:
            if (!(url.startsWith("http") || url.startsWith("file://"))) {
                Uri uri;
                try {
                    uri = Uri.parse(url);
                } catch (IllegalArgumentException ex) {
                    return false;
                }

                // check whether other activities want to handle this url
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.putExtra("data_connection", mNetworkManager.getNetworkProfile());

                try {
                    if (startActivityIfNeeded(intent, -1)) {
                        return true;
                    }
                } catch (ActivityNotFoundException ex) {
                    // ignore the error. If no application can handle the URL,
                    // eg about:blank, assume the browser can handle it.
                }
                return false;
            }


            if(isAirplaneModeOn()){
                Toast.makeText(BrowserActivity.this, 
                    R.string.network_connection_airplane_on, 
                    Toast.LENGTH_LONG).show();
	         return true;
	     }

            // Do not go ahead when we're in progress of connecting.
            if(mNetworkConnecting) {
                Log.d(LOGTAG, "waiting for data connection...");
                Toast.makeText(BrowserActivity.this, 
                        R.string.network_connect_msg, 
                        Toast.LENGTH_SHORT).show();
                return true;
            }

            // Try to open data connection in case it's broken.
            if(mNetworkManager.openDataConnectionIfNeeded() || isAirplaneModeOn()) {
                mSuspendedUrl = url;
                waitForNetwork();
                return true;
            }

            if (mMenuIsDown) {
                openTab(url);
                closeOptionsMenu();
                return true;
            }

            return false;
        }

        /**
         * Updates the lock icon. This method is called when we discover another
         * resource to be loaded for this page (for example, javascript). While
         * we update the icon type, we do not update the lock icon itself until
         * we are done loading, it is slightly more secure this way.
         */
        @Override
        public void onLoadResource(WebView view, String url) {
            if (url != null && url.length() > 0) {
                // It is only if the page claims to be secure
                // that we may have to update the lock:
                if (mLockIconType == LOCK_ICON_SECURE) {
                    // If NOT a 'safe' url, change the lock to mixed content!
                    if (!(URLUtil.isHttpsUrl(url) || URLUtil.isDataUrl(url) || URLUtil.isAboutUrl(url))) {
                        mLockIconType = LOCK_ICON_MIXED;
                        if (LOGV_ENABLED) {
                            Log.v(LOGTAG, "BrowserActivity.updateLockIcon:" +
                                  " updated lock icon to " + mLockIconType + " due to " + url);
                        }
                    }
                }
            }
        }

        /**
         * Show the dialog, asking the user if they would like to continue after
         * an excessive number of HTTP redirects.
         */
        @Override
        public void onTooManyRedirects(WebView view, final Message cancelMsg,
                final Message continueMsg) {
            new AlertDialog.Builder(BrowserActivity.this)
                .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                .setTitle(R.string.browserFrameRedirect)
                .setMessage(R.string.browserFrame307Post)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        continueMsg.sendToTarget();
                    }})
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        cancelMsg.sendToTarget();
                    }})
                .setOnCancelListener(new OnCancelListener() {
                    public void onCancel(DialogInterface dialog) {
                        cancelMsg.sendToTarget();
                    }})
                .show();
        }

        /*
        // Container class for the next error dialog that needs to be
        // displayed.
        class ErrorDialog {
            public final int mTitle;
            public final String mDescription;
            public final int mError;
            ErrorDialog(int title, String desc, int error) {
                mTitle = title;
                mDescription = desc;
                mError = error;
            }
        };

        private void processNextError() {
            if (mQueuedErrors == null) {
                return;
            }
            // The first one is currently displayed so just remove it.
            mQueuedErrors.removeFirst();
            if (mQueuedErrors.size() == 0) {
                mQueuedErrors = null;
                return;
            }
            showError(mQueuedErrors.getFirst());
        }

        private DialogInterface.OnDismissListener mDialogListener =
                new DialogInterface.OnDismissListener() {
                    public void onDismiss(DialogInterface d) {
                        processNextError();
                    }
                };
        private LinkedList<ErrorDialog> mQueuedErrors;

        private void queueError(int err, String desc) {
            if (mQueuedErrors == null) {
                mQueuedErrors = new LinkedList<ErrorDialog>();
            }
            for (ErrorDialog d : mQueuedErrors) {
                if (d.mError == err) {
                    // Already saw a similar error, ignore the new one.
                    return;
                }
            }
            ErrorDialog errDialog = new ErrorDialog(
                    err == EventHandler.FILE_NOT_FOUND_ERROR ?
                    R.string.browserFrameFileErrorLabel :
                    R.string.browserFrameNetworkErrorLabel,
                    desc, err);
            mQueuedErrors.addLast(errDialog);

            // Show the dialog now if the queue was empty.
            if (mQueuedErrors.size() == 1) {
                showError(errDialog);
            }
        }

        private void showError(ErrorDialog errDialog) {
            AlertDialog d = new AlertDialog.Builder(BrowserActivity.this)
                    .setTitle(errDialog.mTitle)
                    .setMessage(errDialog.mDescription)
                    .setPositiveButton(R.string.ok, null)
                    .create();
            d.setOnDismissListener(mDialogListener);
            d.show();
        } */

        /**
         * Show a dialog informing the user of the network error reported by
         * WebCore.
         */
        @Override
        public void onReceivedError(WebView view, int errorCode,
                String description, String failingUrl) {
            Log.w(LOGTAG, "onReceivedError code:"+errorCode+" "+description);

            // Do not show error dialog for some cases.
            boolean showErrorDialog = true;

            // Do nothing if the failing URL is not for main window.
            if(errorCode < 0) {
                String url = view.getUrl();
                if(url != null && url.length() != failingUrl.length()) {
                    showErrorDialog = false;
                    return;
                }
            }

            if(isAirplaneModeOn()){
                Toast.makeText(BrowserActivity.this, 
                    R.string.network_connection_airplane_on, 
                    Toast.LENGTH_LONG).show();
	         return;
	     }

            // Show a toast instead of error dialog when we are in 
            // the procedure of opening data connection.
            if(mNetworkConnecting) {
                Toast.makeText(BrowserActivity.this, 
                        R.string.network_connect_msg, 
                        Toast.LENGTH_SHORT).show();
                //mSuspendedUrl = failingUrl;
                showErrorDialog = false;
                return;
            }

            // OMS: See if we need to open data connection. 
            // Don't auto-reload the URL in such case.
            // TODO: This block may be removed as we do this now
            // in shouldOverrideUrl().
            if(mNetworkManager.openDataConnectionIfNeeded()) {
                //mSuspendedUrl = failingUrl;
                waitForNetwork();
            }

            //1. Notify all HTTP errors for now.
            //2. The description string is passed from native webkit and 
            //   may be corrupted for non-ASC characters, So we learn it 
            //   from the original source.
            if (showErrorDialog) {
                String msg = description;
                if(errorCode < 0) {
                    msg = BrowserActivity.this.getString(
                        EventHandler.errorStringResources[-errorCode]);
                }

                new AlertDialog.Builder(BrowserActivity.this)
                        .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                        .setTitle((errorCode == EventHandler.FILE_ERROR ||
                                errorCode == EventHandler.FILE_NOT_FOUND_ERROR) ?
                                         R.string.browserFrameFileErrorLabel :
                                         R.string.browserFrameNetworkErrorLabel)
                        .setMessage(msg)
                        .setPositiveButton(R.string.ok, null)
                        .show();
            }

            // We need to reset the title after an error.
            //resetTitleAndRevertLockIcon(); 
            stopLoading();
        }

        /**
         * Check with the user if it is ok to resend POST data as the page they
         * are trying to navigate to is the result of a POST.
         */
        @Override
        public void onFormResubmission(WebView view, final Message dontResend,
                                       final Message resend) {
            new AlertDialog.Builder(BrowserActivity.this)
                .setTitle(R.string.browserFrameFormResubmitLabel)
                .setMessage(R.string.browserFrameFormResubmitMessage)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        resend.sendToTarget();
                    }})
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dontResend.sendToTarget();
                    }})
                .setOnCancelListener(new OnCancelListener() {
                    public void onCancel(DialogInterface dialog) {
                        dontResend.sendToTarget();
                    }})
                .show();
        }

        /**
         * Insert the url into the visited history database.
         * @param url The url to be inserted.
         * @param isReload True if this url is being reloaded.
         * FIXME: Not sure what to do when reloading the page.
         */
        @Override
        public void doUpdateVisitedHistory(WebView view, String url,
                boolean isReload) {
            if (url.regionMatches(true, 0, "about:", 0, 6)) {
                return;
            }
            Browser.updateVisitedHistory(mResolver, url, true);
            WebIconDatabase.getInstance().retainIconForPageUrl(url);

            // Update button status on control panel if needed.
            if(mControlPanel != null) {
                mControlPanel.onUpdateVisitedHistory(view);
            }
        }

        /**
         * Displays SSL error(s) dialog to the user.
         */
        @Override
        public void onReceivedSslError(
            final WebView view, final SslErrorHandler handler, final SslError error) {

            if (mSettings.showSecurityWarnings()) {
                final LayoutInflater factory =
                    LayoutInflater.from(BrowserActivity.this);
                final View warningsView =
                    factory.inflate(R.layout.ssl_warnings, null);
                final LinearLayout placeholder =
                    (LinearLayout)warningsView.findViewById(R.id.placeholder);

                if (error.hasError(SslError.SSL_UNTRUSTED)) {
                    LinearLayout ll = (LinearLayout)factory
                        .inflate(R.layout.ssl_warning, null);
                    ((TextView)ll.findViewById(R.id.warning))
                        .setText(R.string.ssl_untrusted);
                    placeholder.addView(ll);
                }

                if (error.hasError(SslError.SSL_IDMISMATCH)) {
                    LinearLayout ll = (LinearLayout)factory
                        .inflate(R.layout.ssl_warning, null);
                    ((TextView)ll.findViewById(R.id.warning))
                        .setText(R.string.ssl_mismatch);
                    placeholder.addView(ll);
                }

                if (error.hasError(SslError.SSL_EXPIRED)) {
                    LinearLayout ll = (LinearLayout)factory
                        .inflate(R.layout.ssl_warning, null);
                    ((TextView)ll.findViewById(R.id.warning))
                        .setText(R.string.ssl_expired);
                    placeholder.addView(ll);
                }

                if (error.hasError(SslError.SSL_NOTYETVALID)) {
                    LinearLayout ll = (LinearLayout)factory
                        .inflate(R.layout.ssl_warning, null);
                    ((TextView)ll.findViewById(R.id.warning))
                        .setText(R.string.ssl_not_yet_valid);
                    placeholder.addView(ll);
                }

                new AlertDialog.Builder(BrowserActivity.this)
                    .setTitle(R.string.security_warning)
                    .setIcon(com.android.internal.R.drawable.cmcc_dialog_question2)
                    .setView(warningsView)
                    .setPositiveButton(R.string.ssl_continue,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    handler.proceed();
                                }
                            })
                    .setNeutralButton(R.string.view_certificate,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    showSSLCertificateOnError(view, handler, error);
                                }
                            })
                    .setNegativeButton(R.string.cancel,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    handler.cancel();
                                    if(mInLoad) {
                                        stopLoading();
                                    }
                                    BrowserActivity.this.resetTitleAndRevertLockIcon();
                                }
                            })
                    .setOnCancelListener(
                            new DialogInterface.OnCancelListener() {
                                public void onCancel(DialogInterface dialog) {
                                    handler.cancel();
                                    if(mInLoad) {
                                        stopLoading();
                                    }
                                    BrowserActivity.this.resetTitleAndRevertLockIcon();
                                }
                            })
                    .show();
            } else {
                handler.proceed();
            }
        }

        /**
         * Handles an HTTP authentication request.
         *
         * @param handler The authentication handler
         * @param host The host
         * @param realm The realm
         */
        @Override
        public void onReceivedHttpAuthRequest(WebView view,
                final HttpAuthHandler handler, final String host, final String realm) {
            String username = null;
            String password = null;

            boolean reuseHttpAuthUsernamePassword =
                handler.useHttpAuthUsernamePassword();

            if (reuseHttpAuthUsernamePassword &&
                    (mTabControl.getCurrentWebView() != null)) {
                String[] credentials =
                        mTabControl.getCurrentWebView()
                                .getHttpAuthUsernamePassword(host, realm);
                if (credentials != null && credentials.length == 2) {
                    username = credentials[0];
                    password = credentials[1];
                }
            }

            if (username != null && password != null) {
                handler.proceed(username, password);
            } else {
                showHttpAuthentication(handler, host, realm, null, null, null, 0);
            }
        }

        @Override
        public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
            if (mMenuIsDown) {
                // only check shortcut key when MENU is held
                return getWindow().isShortcutKey(event.getKeyCode(), event);
            } else {
                return false;
            }
        }

        @Override
        public void onUnhandledKeyEvent(WebView view, KeyEvent event) {
            if (view != mTabControl.getCurrentTopWebView()) {
                return;
            }
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                BrowserActivity.this.onKeyDown(event.getKeyCode(), event);
            } else {
                BrowserActivity.this.onKeyUp(event.getKeyCode(), event);
            }
        }
        //ANDROID_MOT_FLASHLITE Begin
        @Override
        public void onFlashError(WebView view, int error){
            if(!(view instanceof MotWebView) || mFlashBrowserActivity == null)
                return;
            else
                mFlashBrowserActivity.onFlashError(view, error);
        }
        @Override
        public void onFlashSetFullScreenMode(WebView view, boolean fullscreen) {
            if(!(view instanceof MotWebView) || mFlashBrowserActivity == null)
                return;
            else
                mFlashBrowserActivity.switchExitFlashFullScreenMode(fullscreen);
        }

        @Override
        public void onFlashStartVibration(WebView view, boolean start, int timeOn, int timeOff, int repeatCount){
            Log.d(LOGTAG, ">>>>>>>>> BrowserActivity >>>>>>>>>>>> onFlashStartVibration");
            if(!(view instanceof MotWebView) || mFlashBrowserActivity == null)
                return;
            else
                mFlashBrowserActivity.onFlashStartVibration(view, start, timeOn, timeOff, repeatCount);
        }
        //ANDROID_MOT_FLASHLITE End
    };

    //--------------------------------------------------------------------------
    // WebChromeClient implementation
    //--------------------------------------------------------------------------

    /* package */ WebChromeClient getWebChromeClient() {
        return mWebChromeClient;
    }

    private final WebChromeClient mWebChromeClient = new WebChromeClient() {
        // Helper method to create a new tab or sub window.
        private void createWindow(final boolean dialog, final Message msg) {
            if (dialog) {
                mTabControl.createSubWindow();
                final TabControl.Tab t = mTabControl.getCurrentTab();
                attachSubWindow(t);
                WebView.WebViewTransport transport =
                        (WebView.WebViewTransport) msg.obj;
                transport.setWebView(t.getSubWebView());
                msg.sendToTarget();
            } else {
                final TabControl.Tab parent = mTabControl.getCurrentTab();
                // openTabAndShow will dispatch the message after creating the
                // new WebView. This will prevent another request from coming
                // in during the animation.
                openTabAndShow(null, msg, false, null);
                parent.addChildTab(mTabControl.getCurrentTab());
                WebView.WebViewTransport transport =
                        (WebView.WebViewTransport) msg.obj;
                transport.setWebView(mTabControl.getCurrentWebView());
            }
        }

        @Override
        public boolean onCreateWindow(WebView view, final boolean dialog,
                final boolean userGesture, final Message resultMsg) {
            // Ignore these requests during tab animations or if the tab
            // overview is showing.
            if (mAnimationCount > 0 || mTabOverview != null) {
                return false;
            }
            // Short-circuit if we can't create any more tabs or sub windows.
            if (dialog && mTabControl.getCurrentSubWindow() != null) {
                new AlertDialog.Builder(BrowserActivity.this)
                        .setTitle(R.string.too_many_subwindows_dialog_title)
                        .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                        .setMessage(R.string.too_many_subwindows_dialog_message)
                        .setPositiveButton(R.string.ok, null)
                        .show();
                return false;
            } else if (mTabControl.getTabCount() >= TabControl.MAX_TABS) {
                new AlertDialog.Builder(BrowserActivity.this)
                        .setTitle(R.string.too_many_windows_dialog_title)
                        .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                        .setMessage(R.string.too_many_windows_dialog_message)
                        .setPositiveButton(R.string.view_tabs, 
                                new AlertDialog.OnClickListener() {
                                    public void onClick(DialogInterface d, 
                                            int which) {
                                        BrowserActivity.this.tabPicker(true, mTabControl.getCurrentIndex(), false ,true, false);
                                    }
                            })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
                return false;
            }

            // Short-circuit if this was a user gesture.
            if (userGesture) {
                // createWindow will call openTabAndShow for new Windows and
                // that will call tabPicker which will increment
                // mAnimationCount.
                createWindow(dialog, resultMsg);
                return true;
            }

            // Allow the popup and create the appropriate window.
            final AlertDialog.OnClickListener allowListener =
                    new AlertDialog.OnClickListener() {
                        public void onClick(DialogInterface d,
                                int which) {
                            // Same comment as above for setting
                            // mAnimationCount.
                            createWindow(dialog, resultMsg);
                            // Since we incremented mAnimationCount while the
                            // dialog was up, we have to decrement it here.
                            mAnimationCount--;
                        }
                    };

            // Block the popup by returning a null WebView.
            final AlertDialog.OnClickListener blockListener =
                    new AlertDialog.OnClickListener() {
                        public void onClick(DialogInterface d, int which) {
                            resultMsg.sendToTarget();
                            // We are not going to trigger an animation so
                            // unblock keys and animation requests.
                            mAnimationCount--;
                        }
                    };

            // Build a confirmation dialog to display to the user.
            final AlertDialog d =
                    new AlertDialog.Builder(BrowserActivity.this)
                    .setTitle(R.string.attention)
                    .setIcon(com.android.internal.R.drawable.cmcc_dialog_question)
                    .setMessage(R.string.popup_window_attempt)
                    .setPositiveButton(R.string.allow, allowListener)
                    .setNegativeButton(R.string.block, blockListener)
                    .setCancelable(false)
                    .create();

            // Show the confirmation dialog.
            d.show();
            // We want to increment mAnimationCount here to prevent a
            // potential race condition. If the user allows a pop-up from a
            // site and that pop-up then triggers another pop-up, it is
            // possible to get the BACK key between here and when the dialog
            // appears.
            mAnimationCount++;
            return true;
        }

        @Override
        public void onCloseWindow(WebView window) {
            final int currentIndex = mTabControl.getCurrentIndex();
            final TabControl.Tab parent =
                    mTabControl.getCurrentTab().getParentTab();
            if (parent != null) {
                // JavaScript can only close popup window.
                removeTabAndShow(currentIndex, mTabControl.getTabIndex(parent));
            }
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            // Block progress updates to the title bar while the tab overview
            // is animating or being displayed.
            //SetProgress will turn on the progress bar in any case. See #7338.
            if(canUpdateTitleBar()) {
                setProgressInternal(newProgress);

                //mTitleBar.setProgress(newProgress);
                //if (mFakeTitleBar != null) {
                //    mFakeTitleBar.setProgress(newProgress);
                //}
            }
//Log.e(">>>>>>>>>", "downloaded: " + view.getLoadedDataSize() + " / " + view.getLoadedFiles());

            if (newProgress == 100) {
                // onProgressChanged() may continue to be called after the main
                // frame has finished loading, as any remaining sub frames
                // continue to load. We'll only get called once though with
                // newProgress as 100 when everything is loaded.
                // (onPageFinished is called once when the main frame completes
                // loading regardless of the state of any sub frames so calls
                // to onProgressChanges may continue after onPageFinished has
                // executed)

                // sync cookies and cache promptly here.
                CookieSyncManager.getInstance().sync();
                if (mInLoad) {
                    mInLoad = false;
                    updateInLoadMenuItems();
                }
	         // If the options menu is open, leave the title bar
	         //When load complete we should hide the fake title bar ignore the mInLoad,
	         //because if we stop load manually the mInLoad will be false
                if (!mOptionsMenuOpen || !mIconView) {
                      hideFakeTitleBar();
                }

                // OMS: Reset progress bar in case we are loading local files and
                // still waiting for data connection. This is a work-around.
                if(mNetworkConnecting) {
                    resetTitleForDataConenction();
                }
            } else if (!mInLoad) {
                // onPageFinished may have already been called but a subframe
                // is still loading and updating the progress. Reset mInLoad
                // and update the menu items.
                mInLoad = true;
                updateInLoadMenuItems();
                if (!mOptionsMenuOpen || mIconView) {
                    // This page has begun to load, so show the title bar
                    showFakeTitleBar();
                }
            }
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            String url = view.getOriginalUrl();

            // here, if url is null, we want to reset the title
            setUrlTitle(url, title);

            if (url == null ||
                url.length() >= SQLiteDatabase.SQLITE_MAX_LIKE_PATTERN_LENGTH) {
                return;
            }
            if (url.startsWith("http://www.")) {
                url = url.substring(11);
            } else if (url.startsWith("http://")) {
                url = url.substring(4);
            }
            try {
                url = "%" + url;
                String [] selArgs = new String[] { url };

                String where = Browser.BookmarkColumns.URL + " LIKE ? AND "
                        + Browser.BookmarkColumns.BOOKMARK + " = 0";
                Cursor c = mResolver.query(Browser.BOOKMARKS_URI,
                    Browser.HISTORY_PROJECTION, where, selArgs, null);
                if(c == null) {
                    Log.e(LOGTAG, "brwException: Why the bookmark cursor is null?");
                    return;
                }
                if (c.moveToFirst()) {
                    // Current implementation of database only has one entry per
                    // url.
                    int titleIndex =
                            c.getColumnIndexOrThrow(Browser.BookmarkColumns.TITLE);
                    c.updateString(titleIndex, title);
                    c.commitUpdates();
                }
                c.close();
            } catch (IllegalStateException e) {
                Log.e(LOGTAG, "BrowserActivity onReceived title", e);
            } catch (SQLiteException ex) {
                Log.e(LOGTAG, "onReceivedTitle() caught SQLiteException: ", ex);
            }
        }

        @Override
        public void onReceivedIcon(WebView view, Bitmap icon) {
            updateIcon(view.getUrl(), icon);
        }

        @Override
        public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback) {
            if (mCustomView != null)
                return;

            // Add the custom view to its container.
            mCustomViewContainer.addView(view, COVER_SCREEN_GRAVITY_CENTER);
            mCustomView = view;
            mCustomViewCallback = callback;
            // Save the menu state and set it to empty while the custom
            // view is showing.
            mOldMenuState = mMenuState;
            mMenuState = EMPTY_MENU;
            // Hide the content view.
            mContentView.setVisibility(View.GONE);
            // Finally show the custom view container.
            mCustomViewContainer.setVisibility(View.VISIBLE);
            mCustomViewContainer.bringToFront();
        }

        @Override
        public void onHideCustomView() {
            if (mCustomView == null)
                return;

            // Hide the custom view.
            mCustomView.setVisibility(View.GONE);
            // Remove the custom view from its container.
            mCustomViewContainer.removeView(mCustomView);
            mCustomView = null;
            // Reset the old menu state.
            mMenuState = mOldMenuState;
            mOldMenuState = EMPTY_MENU;
            mCustomViewContainer.setVisibility(View.GONE);
            mCustomViewCallback.onCustomViewHidden();
            // Show the content view.
            mContentView.setVisibility(View.VISIBLE);
        }

         @Override
         // OMS: support upload file feature
         public boolean onFileChooser(String suggested, Message resultMsg) {
            // OMS: send intent to file manager to select file and wait result at onActivityResult
            filePickCallback = resultMsg;
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("oms.filemanager/filepick");
            //if (0 != suggested.length())
            //    intent.setData(Uri.parse(suggested));
            startActivityForResult(intent, FILE_PICK_UI);
            return true;
         }
    };

    /**
     * Notify the host application a download should be done, or that
     * the data should be streamed if a streaming viewer is available.
     * @param url The full url to the content that should be downloaded
     * @param contentDisposition Content-disposition http header, if
     *                           present.
     * @param mimetype The mimetype of the content reported by the server
     * @param contentLength The file size reported by the server
     */
    public void onDownloadStart(String url, String userAgent,
            String contentDisposition, String mimetype, long contentLength) {
    	
    	boolean isAudioVideoFile = mimetype.startsWith("audio") ||mimetype.startsWith("video");
    	boolean isBrowserDownloadAudioVideo = isAudioVideoFile && mSettings.isBrowserDownloadAudiovideo();
    	// if we're dealing wih A/V content that's not explicitly marked
        //     for download, check if it's streamable.
        if( (!isBrowserDownloadAudioVideo) && 
            (contentDisposition == null || !contentDisposition.regionMatches(true, 0, "attachment", 0, 10)) && 
            (!mimetype.equalsIgnoreCase("application/x-shockwave-flash"))) {
            
            // query the package manager to see if there's a registered handler
            //     that matches.
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.parse(url), mimetype);
            if (getPackageManager().resolveActivity(intent,
                        PackageManager.MATCH_DEFAULT_ONLY) != null) {
                // someone knows how to handle this mime type with this scheme, don't download.
                try {
                    intent.putExtra("data_connection", mNetworkManager.getNetworkProfile());
                    startActivity(intent);
                    return;
                } catch (ActivityNotFoundException ex) {
                    if (LOGD_ENABLED) {
                        Log.d(LOGTAG, "activity not found for " + mimetype
                                + " over " + Uri.parse(url).getScheme(), ex);
                    }
                    // Best behavior is to fall back to a download in this case
                }
            }
        }
        onDownloadStartNoStream(url, userAgent, contentDisposition, mimetype, contentLength);
    }

    private boolean checkMidletDownload(String mimetype, String url) {
        boolean ismidlet = false;
        if (mimetype != null) {
            ismidlet = BrowserDownloadPage.isMidlet(mimetype);
        } else if (url.endsWith(".jad") || url.endsWith(".jar")) {
            ismidlet = true;
        }
        if (ismidlet && BrowserDownloadPage.unfinishedMidlet(this)) {
            Toast.makeText(this, 
                R.string.unfinished_midlet_downloading_exist, 
                Toast.LENGTH_LONG).show();
            return true;
        }
        return false;
    }


    /**
     * Notify the host application a download should be done, even if there
     * is a streaming viewer available for thise type.
     * @param url The full url to the content that should be downloaded
     * @param contentDisposition Content-disposition http header, if
     *                           present.
     * @param mimetype The mimetype of the content reported by the server
     * @param contentLength The file size reported by the server
     */
    /*package */ void onDownloadStartNoStream(String url, String userAgent,
            String contentDisposition, String mimetype, long contentLength) {
        String filename = URLUtil.guessFileNameOms(url,
                contentDisposition, mimetype, false);

        // Check to see if we have an SDCard
        String status = Environment.getExternalStorageState();
        if (!status.equals(Environment.MEDIA_MOUNTED)) {
            int title;
            String msg;

            // Check to see if the SDCard is busy, same as the music app
            if (status.equals(Environment.MEDIA_SHARED)) {
                msg = getString(R.string.download_sdcard_busy_dlg_msg);
                title = R.string.download_sdcard_busy_dlg_title;
            } else {
                msg = getString(R.string.download_no_sdcard_dlg_msg, filename);
                title = R.string.download_no_sdcard_dlg_title;
            }

            new AlertDialog.Builder(this)
                .setTitle(title)
                .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                .setMessage(msg)
                .setPositiveButton(R.string.ok, null)
                .show();
            return;
        }

        // OMS: One midlet for a time.
        if (checkMidletDownload(mimetype, url)) {
            // Can not download this midlet as there is unfinished midlet downloading.
            return;
        }

        // java.net.URI is a lot stricter than KURL so we have to undo
        // KURL's percent-encoding and redo the encoding using java.net.URI.
        /* OMS: We don't have to use the following block, as many web servers
           in practice do not support "http://user@host", and they may get 
           confused when percent-encoding is decoded, e.g. from "%26" to "&".
        URI uri = null;
        try {
            // Undo the percent-encoding that KURL may have done.
            String newUrl = new String(URLUtil.decode(url.getBytes()));
            // Parse the url into pieces
            WebAddress w = new WebAddress(newUrl);
            String frag = null;
            String query = null;
            String path = w.mPath;
            // Break the path into path, query, and fragment
            if (path.length() > 0) {
                // Strip the fragment
                int idx = path.lastIndexOf('#');
                if (idx != -1) {
                    frag = path.substring(idx + 1);
                    path = path.substring(0, idx);
                }

                // OMS: We should search for the first "?" for query string.
                // See #9065@borqsbt.
                //idx = path.lastIndexOf('?');
                idx = path.indexOf('?');
                if (idx != -1) {
                    query = path.substring(idx + 1);
                    path = path.substring(0, idx);
                }
            }
            uri = new URI(w.mScheme, w.mAuthInfo, w.mHost, w.mPort, path,
                    query, frag);
        } catch (Exception e) {
            Log.e(LOGTAG, "Could not parse url for download: " + url, e);
            return;
        }
        */

        // XXX: Have to use the old url since the cookies were stored using the
        // old percent-encoded url.
        String cookies = CookieManager.getInstance().getCookie(url);

        ContentValues values = new ContentValues();
        // Remove "@" in case of empty auth info as some gateway/proxy
        // does not support this.
        //values.put(Downloads.URI, uri.toString().replace("http://@", "http://"));
        values.put(Downloads.COLUMN_URI, url);
        values.put(Downloads.COLUMN_COOKIE_DATA, cookies);
        values.put(Downloads.COLUMN_USER_AGENT, userAgent);
        values.put(Downloads.COLUMN_NOTIFICATION_PACKAGE,
                getPackageName());
        values.put(Downloads.COLUMN_NOTIFICATION_CLASS,
                BrowserDownloadPage.DownloadReceiver.class.getName());
        values.put(Downloads.COLUMN_VISIBILITY, Downloads.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        values.put(Downloads.COLUMN_MIME_TYPE, mimetype);
        values.put(Downloads.COLUMN_FILE_NAME_HINT, filename);
        //values.put(Downloads.DESCRIPTION, uri.getHost());
        values.put(Downloads.COLUMN_DESCRIPTION, Uri.parse(url).getHost());
        // OMS: Network specific. This will: 
        // 1. Bind download task to a specific network interface (default none);
        // 2. Bind download task to a specific proxy (default none).
        values.put(Downloads.COLUMN_NETWORK_INTERFACE, mNetworkManager.getNetworkInterface() );
        NetworkManager.ProfileAttibutes pa = mNetworkManager.getNetworkParam();
        if(pa != null && pa.mProxyHost != null && pa.mProxyPort > 0) {
            Log.w(LOGTAG, "download proxy: " + pa.mProxyHost + ":" + pa.mProxyPort);
            values.put(Downloads.COLUMN_PROXY_HOST, pa.mProxyHost);
            values.put(Downloads.COLUMN_PROXY_PORT, pa.mProxyPort);
        }

        if (contentLength > 0) {
            values.put(Downloads.COLUMN_TOTAL_BYTES, contentLength);
        }
        // OMS: Allow user to specify a storage path
        if(mimetype != null && BrowserDownloadPage.isMidlet(mimetype)) {
            //TODO: Remove after redesign.
            values.put(Downloads.COLUMN_STOREPATH, "/tmp");
        }else {
            values.put(Downloads.COLUMN_STOREPATH, mSettings.getStorePath());
        }

        if (false && mimetype == null) {
            // We must have long pressed on a link or image to download it. We
            // are not sure of the mimetype in this case, so do a head request
            new FetchUrlMimeType(this).execute(values);
        } else {
            final Uri contentUri =
                    getContentResolver().insert(Downloads.CONTENT_URI, values);
            viewDownloads(contentUri);
        }

    }

    /**
     * Resets the lock icon. This method is called when we start a new load and
     * know the url to be loaded.
     */
    private void resetLockIcon(String url) {
        // Save the lock-icon state (we revert to it if the load gets cancelled)
        saveLockIcon();
        mLockIconType = LOCK_ICON_UNSECURE;
        if (URLUtil.isHttpsUrl(url)) {
            mLockIconType = LOCK_ICON_SECURE;
            if (LOGV_ENABLED) {
                Log.v(LOGTAG, "BrowserActivity.resetLockIcon:" +
                      " reset lock icon to " + mLockIconType);
            }
        }

        updateLockIconImage(mLockIconType);
    }

    /**
     * Resets the lock icon.  This method is called when the icon needs to be
     * reset but we do not know whether we are loading a secure or not secure
     * page.
     */
    private void resetLockIcon() {
        // Save the lock-icon state (we revert to it if the load gets cancelled)
        saveLockIcon();
        mLockIconType = LOCK_ICON_UNSECURE;

        if (LOGD_ENABLED) {
          Log.v(LOGTAG, "BrowserActivity.resetLockIcon:" +
                " reset lock icon to " + mLockIconType);
        }

        updateLockIconImage(LOCK_ICON_UNSECURE);
    }

    /**
     * Update the lock icon to correspond to our latest state.
     */
    /* package */ void updateLockIconToLatest() {
        updateLockIconImage(mLockIconType);
    }

    /**
     * Updates the lock-icon image in the title-bar.
     */
    private void updateLockIconImage(int lockIconType) {
        Drawable d = null;
        if (lockIconType == LOCK_ICON_SECURE) {
            d = mSecLockIcon;
        } else if (lockIconType == LOCK_ICON_MIXED) {
            d = mMixLockIcon;
        }
        // If the tab overview is animating or being shown, do not update the
        // lock icon.
        if(canUpdateTitleBar() || true) {
//            getWindow().setFeatureDrawable(Window.FEATURE_RIGHT_ICON, d);
//merge todo:
        mTitleBar.setLock(d);
        if (mFakeTitleBar != null) {
            mFakeTitleBar.setLock(d);
        }
        }
    }

    /**
     * Displays a page-info dialog.
     * @param tab The tab to show info about
     * @param fromShowSSLCertificateOnError The flag that indicates whether
     * this dialog was opened from the SSL-certificate-on-error dialog or
     * not. This is important, since we need to know whether to return to
     * the parent dialog or simply dismiss.
     */
    private void showPageInfo(final TabControl.Tab tab,
                              final boolean fromShowSSLCertificateOnError) {
        final LayoutInflater factory = LayoutInflater
                .from(this);

        final View pageInfoView = factory.inflate(R.layout.page_info, null);

        final WebView view = tab.getWebView();

        String url = null;
        String title = null;

        if (view == null) {
            url = tab.getUrl();
            title = tab.getTitle();
        } else if (view == mTabControl.getCurrentWebView()) {
             // Use the cached title and url if this is the current WebView
            url = mUrl;
            title = mTitle;
        } else {
            url = view.getUrl();
            title = view.getTitle();
        }

        if (url == null) {
            url = getResources().getString(R.string.page_info_url_unknown);
        }
        if (title == null) {
            title = getResources().getString(R.string.page_info_title_unknown);
        }

        // OMS: Hide "android" keyword for CMCC.
        if(url != null && url.startsWith("file://")) {
            url = url.replace("file:///android_asset", "file:///oms_asset");
        }

        ((TextView) pageInfoView.findViewById(R.id.address)).setText(url);
        ((TextView) pageInfoView.findViewById(R.id.title)).setText(title);

        mPageInfoView = tab;
        mPageInfoFromShowSSLCertificateOnError = new Boolean(fromShowSSLCertificateOnError);

        AlertDialog.Builder alertDialogBuilder =
            new AlertDialog.Builder(this)
            .setTitle(R.string.page_info)
            .setIcon(com.android.internal.R.drawable.cmcc_dialog_information)
            .setView(pageInfoView)
            .setPositiveButton(
                R.string.ok,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int whichButton) {
                        mPageInfoDialog = null;
                        mPageInfoView = null;
                        mPageInfoFromShowSSLCertificateOnError = null;

                        // if we came here from the SSL error dialog
                        if (fromShowSSLCertificateOnError) {
                            // go back to the SSL error dialog
                            showSSLCertificateOnError(
                                mSSLCertificateOnErrorView,
                                mSSLCertificateOnErrorHandler,
                                mSSLCertificateOnErrorError);
                        }
                    }
                })
            .setOnCancelListener(
                new DialogInterface.OnCancelListener() {
                    public void onCancel(DialogInterface dialog) {
                        mPageInfoDialog = null;
                        mPageInfoView = null;
                        mPageInfoFromShowSSLCertificateOnError = null;

                        // if we came here from the SSL error dialog
                        if (fromShowSSLCertificateOnError) {
                            // go back to the SSL error dialog
                            showSSLCertificateOnError(
                                mSSLCertificateOnErrorView,
                                mSSLCertificateOnErrorHandler,
                                mSSLCertificateOnErrorError);
                        }
                    }
                });

        // if we have a main top-level page SSL certificate set or a certificate
        // error
        if (fromShowSSLCertificateOnError ||
                (view != null && view.getCertificate() != null)) {
            // add a 'View Certificate' button
            alertDialogBuilder.setNeutralButton(
                R.string.view_certificate,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int whichButton) {
                        mPageInfoDialog = null;
                        mPageInfoView = null;
                        mPageInfoFromShowSSLCertificateOnError = null;

                        // if we came here from the SSL error dialog
                        if (fromShowSSLCertificateOnError) {
                            // go back to the SSL error dialog
                            showSSLCertificateOnError(
                                mSSLCertificateOnErrorView,
                                mSSLCertificateOnErrorHandler,
                                mSSLCertificateOnErrorError);
                        } else {
                            // otherwise, display the top-most certificate from
                            // the chain
                            if (view.getCertificate() != null) {
                                showSSLCertificate(tab);
                            }
                        }
                    }
                });
        }

        mPageInfoDialog = alertDialogBuilder.show();
    }

       /**
     * Displays the main top-level page SSL certificate dialog
     * (accessible from the Page-Info dialog).
     * @param tab The tab to show certificate for.
     */
    private void showSSLCertificate(final TabControl.Tab tab) {
        final View certificateView =
                inflateCertificateView(tab.getWebView().getCertificate());
        if (certificateView == null) {
            return;
        }

        LayoutInflater factory = LayoutInflater.from(this);

        final LinearLayout placeholder =
                (LinearLayout)certificateView.findViewById(R.id.placeholder);

        LinearLayout ll = (LinearLayout) factory.inflate(
            R.layout.ssl_success, placeholder);
        ((TextView)ll.findViewById(R.id.success))
            .setText(R.string.ssl_certificate_is_valid);

        mSSLCertificateView = tab;
        mSSLCertificateDialog =
            new AlertDialog.Builder(this)
                .setTitle(R.string.ssl_certificate).setIcon(
                    R.drawable.ic_dialog_browser_certificate_secure)
                .setView(certificateView)
                .setPositiveButton(R.string.ok,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                    int whichButton) {
                                mSSLCertificateDialog = null;
                                mSSLCertificateView = null;

                                showPageInfo(tab, false);
                            }
                        })
                .setOnCancelListener(
                        new DialogInterface.OnCancelListener() {
                            public void onCancel(DialogInterface dialog) {
                                mSSLCertificateDialog = null;
                                mSSLCertificateView = null;

                                showPageInfo(tab, false);
                            }
                        })
                .show();
    }

    /**
     * Displays the SSL error certificate dialog.
     * @param view The target web-view.
     * @param handler The SSL error handler responsible for cancelling the
     * connection that resulted in an SSL error or proceeding per user request.
     * @param error The SSL error object.
     */
    private void showSSLCertificateOnError(
        final WebView view, final SslErrorHandler handler, final SslError error) {

        final View certificateView =
            inflateCertificateView(error.getCertificate());
        if (certificateView == null) {
            return;
        }

        LayoutInflater factory = LayoutInflater.from(this);

        final LinearLayout placeholder =
                (LinearLayout)certificateView.findViewById(R.id.placeholder);

        if (error.hasError(SslError.SSL_UNTRUSTED)) {
            LinearLayout ll = (LinearLayout)factory
                .inflate(R.layout.ssl_warning, placeholder);
            ((TextView)ll.findViewById(R.id.warning))
                .setText(R.string.ssl_untrusted);
        }

        if (error.hasError(SslError.SSL_IDMISMATCH)) {
            LinearLayout ll = (LinearLayout)factory
                .inflate(R.layout.ssl_warning, placeholder);
            ((TextView)ll.findViewById(R.id.warning))
                .setText(R.string.ssl_mismatch);
        }

        if (error.hasError(SslError.SSL_EXPIRED)) {
            LinearLayout ll = (LinearLayout)factory
                .inflate(R.layout.ssl_warning, placeholder);
            ((TextView)ll.findViewById(R.id.warning))
                .setText(R.string.ssl_expired);
        }

        if (error.hasError(SslError.SSL_NOTYETVALID)) {
            LinearLayout ll = (LinearLayout)factory
                .inflate(R.layout.ssl_warning, placeholder);
            ((TextView)ll.findViewById(R.id.warning))
                .setText(R.string.ssl_not_yet_valid);
        }

        mSSLCertificateOnErrorHandler = handler;
        mSSLCertificateOnErrorView = view;
        mSSLCertificateOnErrorError = error;
        mSSLCertificateOnErrorDialog =
            new AlertDialog.Builder(this)
                .setTitle(R.string.ssl_certificate).setIcon(
                    R.drawable.ic_dialog_browser_certificate_partially_secure)
                .setView(certificateView)
                .setPositiveButton(R.string.ok,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                    int whichButton) {
                                mSSLCertificateOnErrorDialog = null;
                                mSSLCertificateOnErrorView = null;
                                mSSLCertificateOnErrorHandler = null;
                                mSSLCertificateOnErrorError = null;

                                mWebViewClient.onReceivedSslError(
                                    view, handler, error);
                            }
                        })
                 .setNeutralButton(R.string.page_info_view,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                    int whichButton) {
                                mSSLCertificateOnErrorDialog = null;

                                // do not clear the dialog state: we will
                                // need to show the dialog again once the
                                // user is done exploring the page-info details

                                showPageInfo(mTabControl.getTabFromView(view),
                                        true);
                            }
                        })
                .setOnCancelListener(
                        new DialogInterface.OnCancelListener() {
                            public void onCancel(DialogInterface dialog) {
                                mSSLCertificateOnErrorDialog = null;
                                mSSLCertificateOnErrorView = null;
                                mSSLCertificateOnErrorHandler = null;
                                mSSLCertificateOnErrorError = null;

                                mWebViewClient.onReceivedSslError(
                                    view, handler, error);
                            }
                        })
                .show();
    }

    /**
     * Inflates the SSL certificate view (helper method).
     * @param certificate The SSL certificate.
     * @return The resultant certificate view with issued-to, issued-by,
     * issued-on, expires-on, and possibly other fields set.
     * If the input certificate is null, returns null.
     */
    private View inflateCertificateView(SslCertificate certificate) {
        if (certificate == null) {
            return null;
        }

        LayoutInflater factory = LayoutInflater.from(this);

        View certificateView = factory.inflate(
            R.layout.ssl_certificate, null);

        // issued to:
        SslCertificate.DName issuedTo = certificate.getIssuedTo();
        if (issuedTo != null) {
            ((TextView) certificateView.findViewById(R.id.to_common))
                .setText(issuedTo.getCName());
            ((TextView) certificateView.findViewById(R.id.to_org))
                .setText(issuedTo.getOName());
            ((TextView) certificateView.findViewById(R.id.to_org_unit))
                .setText(issuedTo.getUName());
        }

        // issued by:
        SslCertificate.DName issuedBy = certificate.getIssuedBy();
        if (issuedBy != null) {
            ((TextView) certificateView.findViewById(R.id.by_common))
                .setText(issuedBy.getCName());
            ((TextView) certificateView.findViewById(R.id.by_org))
                .setText(issuedBy.getOName());
            ((TextView) certificateView.findViewById(R.id.by_org_unit))
                .setText(issuedBy.getUName());
        }

        // issued on:
        String issuedOn = reformatCertificateDate(
            certificate.getValidNotBefore());
        ((TextView) certificateView.findViewById(R.id.issued_on))
            .setText(issuedOn);

        // expires on:
        String expiresOn = reformatCertificateDate(
            certificate.getValidNotAfter());
        ((TextView) certificateView.findViewById(R.id.expires_on))
            .setText(expiresOn);

        return certificateView;
    }

    /**
     * Re-formats the certificate date (Date.toString()) string to
     * a properly localized date string.
     * @return Properly localized version of the certificate date string and
     * the original certificate date string if fails to localize.
     * If the original string is null, returns an empty string "".
     */
    private String reformatCertificateDate(String certificateDate) {
      String reformattedDate = null;

      if (certificateDate != null) {
          Date date = null;
          try {
              date = java.text.DateFormat.getInstance().parse(certificateDate);
          } catch (ParseException e) {
              date = null;
          }

          if (date != null) {
              reformattedDate =
                  DateFormat.getDateFormat(this).format(date);
          }
      }

      return reformattedDate != null ? reformattedDate :
          (certificateDate != null ? certificateDate : "");
    }

    /**
     * Displays an http-authentication dialog.
     */
    private void showHttpAuthentication(final HttpAuthHandler handler,
            final String host, final String realm, final String title,
            final String name, final String password, int focusId) {
        LayoutInflater factory = LayoutInflater.from(this);
        final View v = factory
                .inflate(R.layout.http_authentication, null);
        if (name != null) {
            ((EditText) v.findViewById(R.id.username_edit)).setText(name);
        }
        if (password != null) {
            ((EditText) v.findViewById(R.id.password_edit)).setText(password);
        }

        /* OMS: Just use simple title.
        String titleText = title;
        if (titleText == null) {
            titleText = getText(R.string.sign_in_to).toString().replace(
                    "%s1", host).replace("%s2", realm);
        }*/

        mHttpAuthHandler = handler;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(R.string.sign_in)
                //.setIcon(com.android.internal.R.drawable.cmcc_dialog_information)
                .setView(v)
                .setPositiveButton(R.string.action,
                        new DialogInterface.OnClickListener() {
                             public void onClick(DialogInterface dialog,
                                     int whichButton) {
                                String nm = ((EditText) v
                                        .findViewById(R.id.username_edit))
                                        .getText().toString();
                                String pw = ((EditText) v
                                        .findViewById(R.id.password_edit))
                                        .getText().toString();
                                BrowserActivity.this.setHttpAuthUsernamePassword
                                        (host, realm, nm, pw);
                                handler.proceed(nm, pw);
                                mHttpAuthenticationDialog = null;
                                mHttpAuthHandler = null;
                            }})
                .setNegativeButton(R.string.cancel,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                    int whichButton) {
                                handler.cancel();
                                BrowserActivity.this.resetTitleAndRevertLockIcon();
                                mHttpAuthenticationDialog = null;
                                mHttpAuthHandler = null;
                            }})
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                        public void onCancel(DialogInterface dialog) {
                            handler.cancel();
                            BrowserActivity.this.resetTitleAndRevertLockIcon();
                            mHttpAuthenticationDialog = null;
                            mHttpAuthHandler = null;
                        }})
                .create();
        // Make the IME appear when the dialog is displayed if applicable.
        dialog.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        dialog.show();
        if (focusId != 0) {
            dialog.findViewById(focusId).requestFocus();
        } else {
            v.findViewById(R.id.username_edit).requestFocus();
        }
        mHttpAuthenticationDialog = dialog;
    }

    public int getProgress() {
        WebView w = mTabControl.getCurrentWebView();
        if (w != null) {
            return w.getProgress();
        } else {
            return 100;
        }
    }

    /**
     * Set HTTP authentication password.
     *
     * @param host The host for the password
     * @param realm The realm for the password
     * @param username The username for the password. If it is null, it means
     *            password can't be saved.
     * @param password The password
     */
    public void setHttpAuthUsernamePassword(String host, String realm,
                                            String username,
                                            String password) {
        WebView w = mTabControl.getCurrentWebView();
        if (w != null) {
            w.setHttpAuthUsernamePassword(host, realm, username, password);
        }
    }

    /**
     * connectivity manager says net has come or gone... inform the user
     * @param up true if net has come up, false if net has gone down
     */
    public void onNetworkToggle(boolean up) {
        if (up == mIsNetworkUp) {
            return;
        } else if (up) {
            mIsNetworkUp = true;
            if (mAlertDialog != null) {
                mAlertDialog.cancel();
                mAlertDialog = null;
            }
        } else {
            mIsNetworkUp = false;
            if (mInLoad && mAlertDialog == null) {
                mAlertDialog = new AlertDialog.Builder(this)
                        .setTitle(R.string.loadSuspendedTitle)
                        .setMessage(R.string.loadSuspended)
                        .setPositiveButton(R.string.ok, null)
                        .show();
            }
        }
    }

    /**
     * System reports airplane mode is on or off.
     * @param up true if airplane mode is on, false if off.
     */
    private void onAirplaneModeChanged(boolean on) {
        if (on) {
            if (mAirplaneOffDialog != null) {
                mAirplaneOffDialog.cancel();
                mAirplaneOffDialog = null;
            }
            mAirplaneOnDialog = new AlertDialog.Builder(BrowserActivity.this)
                    .setTitle(R.string.network_airplane_on)
                    .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                    .setMessage(R.string.network_connection_airplane_on)
                    .setNeutralButton(R.string.ok, null)
                    .setCancelable(false)
                    .show();
        } else {
            if (mAirplaneOnDialog != null) {
                mAirplaneOnDialog.cancel();
                mAirplaneOnDialog = null;
            }
            mReconnectForAirplaneOff = true;
            mAirplaneOffDialog = new AlertDialog.Builder(BrowserActivity.this)
                    .setTitle(R.string.network_airplane_off)
                    .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                    .setMessage(R.string.network_connection_airplane_off)
                    .setPositiveButton(R.string.ok, 
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                mSuspendedUrl = null;
                                // Do not connect until PS is ready.
                                //connect();
                            }})
                    //.setNeutralButton(R.string.cancel, null)
                    .setCancelable(false)
                    .show();
        }
    }
    // Use this flag to open data connection when we receive STATE_IN_SERVICE.
    // We don't open data connection at the moment aieplane mode is OFF.
    private boolean mReconnectForAirplaneOff = false;

    /**
     * See if we are under airplane mode.
     * #return Return true if airplane mode is on.
     */
    /* package */ boolean isAirplaneModeOn() {
        if(Settings.System.getInt(getContentResolver(), 
                Settings.System.AIRPLANE_MODE_ON, 0) == 1) {
            return true;
        }
        return false;
    }

    // OMS: A monitor flag to use in case of PDP broken when browser is on 
    // the background. Then we can re-connection when resumed.
    boolean mTryConnectionOnResume = false;

    // OMS: 
    // Browser data connection may be reset by other apps sych as DCD, MMS to 
    // access Operator owned contents via e.g. cmwap. So we need to restore 
    // the user preferred one if there's any.
    private String mUserPreferredProfile;

    private void onPreferenceResult(Intent intent) {
        if(mActivityDestroyed) {
            Log.w(DCMTAG, "onPreferenceResult: Activity destroyed!");
            return;
        }

        boolean charsetChanged = intent == null ? false : intent.getBooleanExtra("charset_changed", false);

        String dc = BrowserSettings.getInstance().getDataConnectionStr(this);
Log.d("===========", "dc: " + dc + "/" + mNetworkManager.getNetworkProfile());
        if(!dc.equals(mNetworkManager.getNetworkProfile())) {
            mUserPreferredProfile = dc;
            if(mInLoad) {
                stopLoading();
            }
            mSuspendedUrl = null;
            mRetryCount = 0;
            waitForNetwork();
            mNetworkManager.switchNetworkProfile(dc);
        } else {
            if(charsetChanged) {
                reload();
            }
        }

        // OMS: when user returned from preference setting page, we think user may
        // make some changes, so we request webviewcore to update cache. 
        // e.g. user change font size, we need update cache to make focus ring correct.
        getCurrentWebView().requestUpdateCacheNodes();
    }

    private void handleExtraMenu(int index) {
        WebView webview = mTabControl.getCurrentWebView();

        switch(index) {
            case BrowserExtraMenuPage.SET_AS_HOMEPAGE:
            String home = getTopWindow().getUrl();
            if(home == null || home.trim().length() == 0) {
                break;
            }
            home = smartUrlFilter(home);
            if(home != null) {
                mSettings.setHomePage(this, home);
                Toast.makeText(this, R.string.homepage_set, 
                        Toast.LENGTH_SHORT).show();
            }
            break;

            case BrowserExtraMenuPage.PAGE_INFO: {//Page info
                showPageInfo(mTabControl.getCurrentTab(), false);
            }
            break;

            case BrowserExtraMenuPage.SHARE_PAGE: {//share
                Browser.sendString(this, getTopWindow().getUrl());
            }
            break;

            case BrowserExtraMenuPage.FULL_SCREEN: {//fullscreen
                toggleFullScreen();
            }
            break;

            case BrowserExtraMenuPage.LOCK_ORIENTATION: {
                if(!mLockOrientation) {
                    Toast.makeText(this, R.string.lock_orientation_prompt, 
                            Toast.LENGTH_SHORT).show();
                }
                toggleLockOrientation();
            }
            break;

            case BrowserExtraMenuPage.FIND_ON_PAGE: {//find
                if (null == mFindDialog) {
                    mFindDialog = new FindDialog(this);
                }
                mFindDialog.setWebView(getTopWindow());
                mFindDialog.show();
                mMenuState = EMPTY_MENU;
            }
            break;

            case BrowserExtraMenuPage.SET_BRIGHTNESS: {
                mBrowserBrightness.showBrightnessDialog();
            }
            break;

            default:
            Log.w("handleExtraMenu", "Why this menu item can not be handled?"); 
            break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        // OMS: In case browser is killed by OOM killer.
        if(!mInitialized) {
            Log.d(LOGTAG, "Do nothing for onActivityResult as browser is not initialized.");
            return;
        }

        switch (requestCode) {
            case BOOKMARKS_PAGE:
            case CLASSIC_HISTORY_PAGE:
                if (resultCode == RESULT_OK && intent != null) {
                    String data = intent.getAction();
                    Bundle extras = intent.getExtras();
                    //OMS 0098996:We must count the three factors into account:
                    //1.newTab 2.openBackground 3.mTabOverview
                    boolean openBackground = mSettings.openInBackground();
                    boolean newTab = extras != null && extras.getBoolean("new_window", false);
                    final TabControl.Tab currentTab = mTabControl.getCurrentTab();
                    if (newTab && mTabOverview == null) {
                        openTab(data);
                    } else if(newTab && mTabOverview != null && mAnimationCount == 0){
                        openTab(data);
                        if(openBackground){
                            sendAnimateFromOverview(currentTab, false, null,
                                TAB_OVERVIEW_DELAY, null);
                        }
                    } else{
                        // If the Window overview is up and we are not in the
                        // middle of an animation, animate away from it to the
                        // current tab.
                        if (mTabOverview != null && mAnimationCount == 0) {
                            sendAnimateFromOverview(currentTab, false, data,
                                    TAB_OVERVIEW_DELAY, null);
                        } else {
                            dismissSubWindow(currentTab);
                            loadURL(getTopWindow(), data);
                        }
                    }
                }
                break;

            case PREFERENCES_PAGE:
                onPreferenceResult(intent);
                break;

            case FILE_PICK_UI:
                if(filePickCallback != null)
                {
                    HashMap<String, Object> map =
                            (HashMap<String, Object>) filePickCallback.obj;
                    StringBuilder resultFile = (StringBuilder)map.get("result");
                    String suggestedFile = (String)map.get("suggested");
                    if (resultCode == RESULT_OK) {
                        String filepath;
                        try {
                            filepath = URLDecoder.decode(intent.getData().toString(), "utf-8");
                        } catch (java.io.UnsupportedEncodingException e) {
                            Log.e(LOGTAG, "decode filepath from FileManager failed. ");
                            filepath = intent.getData().toString();
                        }
                        if (filepath.startsWith("file://")) {
                            filepath = filepath.substring(7);
                        }
                        File f = new File(filepath);
                        if (f.length() > MAX_FILE_UPLOAD_SIZE) {
                            // OMS: Need to pop up alert dialog.
                            Log.d(LOGTAG, "selected upload file size is over MAX_FILE_UPLOAD_SIZE/"+
                                MAX_FILE_UPLOAD_SIZE);
                            resultFile.append(suggestedFile);
                            new AlertDialog.Builder(this)
                                .setTitle(R.string.over_max_fileupload_size_title)
                                .setMessage(BrowserActivity.this.getString(R.string.over_max_fileupload_size_msg,
                                            MAX_FILE_UPLOAD_SIZE/1024))
                                .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                                .setPositiveButton(R.string.ok, 
                                        new DialogInterface.OnClickListener(){
                                            public void onClick(DialogInterface dialog, int which) {
                                                filePickCallback.sendToTarget();
                                            }
                                        })
                                .setCancelable(false)
                                .show();
                            // OMS: here we break directly, resultMsg will be sent out until user 
                            // confirm the alert dialog
                            break;
                        } else {
                            resultFile.append(filepath);
                        }
                    }
                    else 
                        resultFile.append(suggestedFile);
                    filePickCallback.sendToTarget();
                }
                break;
            case EXTRA_MENU: 
                if (intent != null) {
                    Bundle extras = intent.getExtras();
                    int index = extras.getInt("menu_index");
                    handleExtraMenu(index);
                }
                break;
            default:
                break;
        }
        getTopWindow().requestFocus();
    }

    /*
     * This method is called as a result of the user selecting the options
     * menu to see the download window, or when a download changes state. It
     * shows the download window ontop of the current window.
     */
    /* package */ void viewDownloads(Uri downloadRecord) {
        Intent intent = new Intent(this,
                BrowserDownloadPage.class);
        intent.setData(downloadRecord);
        startActivityForResult(intent, this.DOWNLOAD_PAGE);
    }

    /**
     * Handle results from Tab Switcher mTabOverview tool
     */
    private class TabListener implements BrowserTabViewListener {
        public void remove(int position) {
            // Note: Remove is not enabled if we have only one tab.
            //if (LOGD_ENABLED && mTabControl.getTabCount() == 1) {
                //throw new AssertionError();
            //}

            // Remember the current tab.
            TabControl.Tab current = mTabControl.getCurrentTab();
            final TabControl.Tab remove = mTabControl.getTab(position);
            mTabControl.removeTab(remove);
            // If we removed the current tab, use the tab at position - 1 if
            // possible.
            if (current == remove) {
                // If the user removes the last tab, act like the New Tab item
                // was clicked on.
                if (mTabControl.getTabCount() == 0) {
                    current = mTabControl.createNewTab();
                    sendAnimateFromOverview(current, true,
                            mSettings.getHomePage(), TAB_OVERVIEW_DELAY, null);
                } else {
                    final int index = position > 0 ? (position - 1) : 0;
                    current = mTabControl.getTab(index);
                }
            }

            // The tab overview could have been dismissed before this method is
            // called.
            if (mTabOverview != null) {
                // Remove the tab and change the index.
                mTabOverview.remove(position);
                if(((ImageAdapter) mTabOverview.getAdapter()).maxedOut())
                	   position --;
                mTabOverview.setCurrentIndex(position);
            }
            // Only the current tab ensures its WebView is non-null. This
            // implies that we are reloading the freed tab.
            mTabControl.setCurrentTab(current);
            mTabOverview.updateNewTabBtn();
            mTabOverview.setPageTextView(mTabOverview.getCurrentIndex()+1);
        }
        
        public void onClick(int index) {
            // Change the tab if necessary.
            // Index equals BrowserTabView.CANCEL when pressing back from the tab
            // overview.
            if (index == BrowserTabView.CANCEL) {
                index = mTabControl.getCurrentIndex();
                // The current index is -1 if the current tab was removed.
                if (index == -1) {
                    // Take the last tab as a fallback.
                    index = mTabControl.getTabCount() - 1;
                }
            }

            // NEW_TAB means that the "New Tab" cell was clicked on.
            if (index == BrowserTabView.NEW_TAB) {
                openTabAndShow(mSettings.getHomePage(), null, false, null);
                // Enhancement: In case home page is empty, show nothingin title bar.
                mTitleBar.setTitleAndUrl(mSettings.getHomePage());
            } else {
                if(isInLandscapeOrientation() && mTabOverview.isInMoving()){
                    // Set the current tab.
                    TabControl.Tab tab = mTabControl.getTab(index);
                    mTabControl.setCurrentTab(tab);
                    dismissTabOverview(false);
                    // Attach the WebView so it will layout.
                    attachTabToContentView(tab);
                    tab.getWebView().resumeTimers();
                    mMenuState = R.id.MAIN_MENU;
                    // Reset all the title bar info.
                    //revertLockIcon();
                    resetLockIcon(tab.getUrl());
                    resetTitleIconAndProgress();
                }
                else{
                    sendAnimateFromOverview(mTabControl.getTab(index),
                        false, null, 0, null);
                }
            }
        }
    }

    // A fake View that draws the WebView's picture with a fast zoom filter.
    // The View is used in case the tab is freed during the animation because
    // of low memory.
    private static class AnimatingView extends View {
        private static final int ZOOM_BITS = Paint.FILTER_BITMAP_FLAG |
                Paint.DITHER_FLAG | Paint.SUBPIXEL_TEXT_FLAG;
        private static final DrawFilter sZoomFilter =
                new PaintFlagsDrawFilter(ZOOM_BITS, Paint.LINEAR_TEXT_FLAG);
        private final Picture mPicture;
        private float   mScale;
        private float     mScrollX;
        private float     mScrollY;
        final TabControl.Tab  mTab;

        AnimatingView(Context ctxt, TabControl.Tab t) {
            super(ctxt);
            mTab = t;
            // Use the top window in the animation since the tab overview will
            // display the top window in each cell.
            final WebView w = t.getTopWindow();
            mPicture = w.capturePicture();
            mScale = w.getScale() / w.getWidth();
            //OMS 94594:We should keep the scroll coordinate the same as FakeWebView's
            mScrollX = w.getScrollX()/w.getScale();
            View titlebar = w.getTitleBar();
            int h = titlebar != null ? titlebar.getHeight():0;
            mScrollY = (w.getScrollY()-h)/w.getScale();	
            t.setTranslateY(w.getScrollY());
            t.setTitleBarHeight(h);
            Log.e("liz",mScrollY+" animatingview............");
        }

        @Override
        protected void onDraw(Canvas canvas) {
            canvas.save();
            canvas.drawColor(Color.WHITE);
            if (mPicture != null) {
                canvas.setDrawFilter(sZoomFilter);
                float scale = getWidth() * mScale;
                canvas.scale(scale, scale);
                canvas.translate(-mScrollX, -mScrollY);
                canvas.drawPicture(mPicture);
            }
            canvas.restore();
        }
    }
    
    //OMS 94594:the time duration of titlebar scrolls
    private final int TITLEBAR_SCROLL_DURATION = 500;//ms
    private boolean mLockOrientationForTabView = false;
    /**
     *  Open the tab picker. This function will always use the current tab in
     *  its animation.
     *  @param stay boolean stating whether the tab picker is to remain open
     *          (in which case it needs a listener and its menu) or not.
     *  @param index The index of the tab to show as the selection in the tab
     *               overview.
     *  @param remove If true, the tab at index will be removed after the
     *                animation completes.
     */
    /* package */ void tabPicker(final boolean stay, final int index,
            final boolean remove, final boolean animation, final boolean scrollTitleBar) {
        hideFakeTitleBar();
        
        final TabControl.Tab current = mTabControl.getCurrentTab();

        int size = mTabControl.getTabCount();

        TabListener l = null;
        if (stay) {
            l = mTabListener = new TabListener();
        }

         // Hide IME if any.
         if(getTopWindow() != null) {
             InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
             imm.hideSoftInputFromWindow(getTopWindow().getWindowToken(), 0);
        }

        if(mTabOverview != null){
            mTabOverview.removeChildViews();
            mContentView.removeView((View)mTabOverview);
        }
        int mod = mSettings.getCurrentTabMode(this);
        if(isInLandscapeOrientation()){
           if(mod == BrowserTabView.TAB_GALLERY_MODE){
                mod = BrowserTabView.TAB_GALLERY_LAND_MODE;
                mSettings.setTabModePreference(this,BrowserTabView.TAB_GALLERY_LAND_MODE);
           }
        }else{
            if(mod == BrowserTabView.TAB_GALLERY_LAND_MODE){
                mod = BrowserTabView.TAB_GALLERY_MODE;
                mSettings.setTabModePreference(this,BrowserTabView.TAB_GALLERY_MODE);
            }
        }
        
        if(mod != BrowserTabView.TAB_GALLERY_MODE){
            mTabOverview = new ImageGrid(this, stay, l);
        }
        else{
            mTabOverview = new BrowserGallery(this, stay, l, mContentView, mTabControl); 
        }
        for (int i = 0; i < size; i++) {
            final TabControl.Tab t = mTabControl.getTab(i);
            mTabControl.populatePickerData(t);
            mTabOverview.add(t);
        }
        //OMS 94594&96949:if we can see the titlebar, we will scroll it until it's invisiable.
        WebView webview = current.getWebView();
        View titlebar = webview.getTitleBar();
        int titlebarHeight = titlebar != null ? titlebar.getHeight():0;
        int visibleTitlebarHeight = Math.max(titlebarHeight-webview.getScrollY(),0);
        if(visibleTitlebarHeight > 0 && animation && scrollTitleBar){
            //OMS 0095669:lock the orientation change when in scroll,if have locked, do nothing.
            if(!mLockOrientation){
                toggleLockOrientation();
                mLockOrientationForTabView = true;
            }
            webview.pinScrollTo(webview.getScrollX(),titlebarHeight,true,TITLEBAR_SCROLL_DURATION);
            //OMS 0098312:remove the same message first before send it.
            mHandler.removeMessages(SHOW_TAB_VIEW);
            //send a message, wait for scrolling's end.
            mHandler.sendMessageDelayed(mHandler.obtainMessage(
                SHOW_TAB_VIEW,index,remove ?1:0),TITLEBAR_SCROLL_DURATION + 50);
            return;
        }else{
            showTabView( index,  remove, animation);
        }
    }

    //OMS 94594:before show the tab view, we will do something else.
    private void showTabView(int index, boolean remove, boolean animation){
     //OMS 0098312:if have parent already, do nothing
     if(((View)mTabOverview).getParent() != null){
         Log.e("BrwException","The tab view have more than one parent ",new Throwable());
         return;
     }
     // Tell the tab overview to show the current tab, the tab overview will
     // handle the "New Tab" case.
     int currentIndex = mTabControl.getCurrentIndex();
     mTabOverview.setCurrentIndex(currentIndex);
     // Attach the tab overview.
     mContentView.addView((View)mTabOverview,COVER_SCREEN_PARAMS);
     mTabOverview.initButtons();
     final TabControl.Tab current = mTabControl.getCurrentTab();
     if(animation){
         ////OMS 0095669:lock the orientaion change when in animation,if have locked, do nothing.
         if(!mLockOrientation){
             toggleLockOrientation();
             mLockOrientationForTabView = true;
         }
         // Create a fake AnimatingView to animate the WebView's picture.
         final AnimatingView v = new AnimatingView(this, current);
         mContentView.addView(v, COVER_SCREEN_PARAMS);
         removeTabFromContentView(current);
         // Pause timers to get the animation smoother.
         current.getWebView().pauseTimers();
     
         // Send a message so the tab picker has a chance to layout and get
         // positions for all the cells.
         mHandler.sendMessage(mHandler.obtainMessage(ANIMATE_TO_OVERVIEW,
                 index, remove ? 1 : 0, v));
         // Setting this will indicate that we are animating to the overview. We
         // set it here to prevent another request to animate from coming in
         // between now and when ANIMATE_TO_OVERVIEW is handled.
         mAnimationCount++;
         // Always change the title bar to the window overview title while
         // animating.
         //getWindow().setFeatureDrawable(Window.FEATURE_LEFT_ICON, null);
         //setDefaultFavicon();
         //getWindow().setFeatureDrawable(Window.FEATURE_RIGHT_ICON, null);
         //getWindow().setFeatureInt(Window.FEATURE_PROGRESS,
         //Window.PROGRESS_VISIBILITY_OFF);
         setTitle(R.string.tab_picker_title);
         // Make the menu empty until the animation completes.
         mMenuState = EMPTY_MENU;
     }
     else{
         removeTabFromContentView(current);
         // Restore the listener.
         mTabOverview.setListener(mTabListener);
         // Change the menu to TAB_MENU if the
         // BrowserTabView is interactive.
         if (mTabOverview.isLive()) {
             mMenuState = R.id.TAB_MENU;
             mTabOverview.requestFocus();
         }
     }
    }

    /*
     * Add current URL to bookmark.
     */
    /* package */void addBookmark() {
        Intent intent = new Intent(this,
            com.android.browser.cmcc.CMCCAddBookmarkPage.class);

        WebView webView = getCurrentWebView();
        String title = webView == null ? null : webView.getTitle();
        String url = webView == null ? null : webView.getUrl();
        // Just in case the user opens bookmarks before a page finishes loading
        // so the current history item, and therefore the page, is null.
        if (null == url) {
            url = mLastEnteredUrl;
        }
        // In case the web page has not yet received its associated title.
        if (title == null) {
            title = url;
        }
        intent.putExtra("title", title);
        intent.putExtra("url", url);
        startActivityForResult(intent, -1);
    }

    /*package*/ void bookmarksPicker() {
        Intent intent = new Intent(this,
            com.android.browser.cmcc.CMCCBrowserBookmarksPage.class);

        WebView webView = getCurrentWebView();
        String title = webView.getTitle();
        String url = webView.getUrl();
        // Just in case the user opens bookmarks before a page finishes loading
        // so the current history item, and therefore the page, is null.
        if (null == url) {
            url = mLastEnteredUrl;
            // This can happen.
            if (null == url) {
                url = mSettings.getHomePage();
            }
        }
        // In case the web page has not yet received its associated title.
        if (title == null) {
            title = url;
        }
        intent.putExtra("title", title);
        intent.putExtra("url", url);
        intent.putExtra("maxTabsOpen",
                mTabControl.getTabCount() >= TabControl.MAX_TABS);
        startActivityForResult(intent, BOOKMARKS_PAGE);
    }

    // This is for CMCC specific, when launched from Monternet shortcut 
    // on Home. We look into the Intent to see if therer's specified
    // data connection. If yes and if it's different from what we're using, 
    // we use the specified one and save it to Preference.
    // Return null if there's no data connection in the Intent, or it's the
    // same as what we're using.
    private boolean SPECIFIED_DATA_CONNECTION_IN_INTENT = true;
    private String chooseDataConnectionFromIntent(Intent intent) {
       if(!SPECIFIED_DATA_CONNECTION_IN_INTENT) return null;

        String profile = intent.getStringExtra("data_connection");
        if(profile != null) {
            // HACK: Do not prompt wifi any more.
            if(!profile.equals(Phone.APN_TYPE_INTERNET)) {
                mWifiNotified = true;
            }

            String oldProfile = mNetworkManager.getNetworkProfile();
            Log.d(LOGTAG, "profile=" + profile + "/" + oldProfile);
            if(oldProfile.equals(profile)) {
                return null;
            }

            Editor sp = PreferenceManager.getDefaultSharedPreferences(this).edit();
            sp.putString("data_connection", profile);
            sp.commit();

            //mNetworkManager.switchNetworkProfile(profile);
            // Save the user preferred data conenction ID to restore later, if needed.
            mUserPreferredProfile = oldProfile;
            return profile;
        }

        // OMS: If the Intent is from MMS then use cmwap for all URL.
        // For CMCC ONLY.
        String applicationID = intent.getStringExtra(Browser.EXTRA_APPLICATION_ID);
        if(applicationID != null && applicationID.equals("com.android.mms")) {
            String oldProfile = mNetworkManager.getNetworkProfile();
            if(oldProfile.equals("wap")) {
                return null;
            }

            Log.d(LOGTAG, "Switch to wap for MMS...");
            Editor sp = PreferenceManager.getDefaultSharedPreferences(this).edit();
            sp.putString("data_connection", "wap");
            sp.commit();

            // Save the user preferred data conenction ID to restore later, if needed.
            mUserPreferredProfile = oldProfile;
            return "wap";
        }

        return null;
    }

    //Page overview
    private void overview() {
        if( mOverviewPage != null ) {
            Log.w(LOGTAG, "Overview() Why mOverviewPage is not null!!");
            mOverviewPage = null;
        }

        if( mOverViewListener == null ) {
            mOverViewListener = new OvListener();
        }

        // Restore the zoom level for a better user experience.
        WebView webView = mTabControl.getCurrentWebView();
        if(webView.getScale() != 1) {
//merge-todo
            //webView.zoomRestore();
            webView.computeScroll();
        }

        mOverviewPage = new OverviewPage(BrowserActivity.this, webView);
        mOverviewPage.setListener(mOverViewListener);

        mContentView.addView(mOverviewPage, COVER_SCREEN_PARAMS);
        mMenuState = R.id.OVERVIEW_MENU;
        //setProgressBarVisibility(false);
        mOverviewPage.requestFocus();
        //mMenuState = R.id.EMPTY_MENU;
    }

    private OvListener mOverViewListener;

    private class OvListener implements OverviewPage.OverviewListener {
        public void onClick(int x, int y) {
            if(LOGD_ENABLED) {
                Log.e(LOGTAG, "onClick() " + x + "/" + y + " @" + 
                        mOverviewPage);
            }
            if( mOverviewPage != null ) {
                mContentView.removeView(mOverviewPage);
                mOverviewPage = null;
            }

            //restore all we should...
            //BrowserActivity.this.setProgressBarVisibility(true);
            //BrowserActivity.this.getTopWindow().setFocusable(true);
            BrowserActivity.this.getTopWindow().requestFocus();
            BrowserActivity.this.resetTitle();
            BrowserActivity.this.mMenuState = R.id.MAIN_MENU;

            BrowserActivity.this.getCurrentWebView().scrollTo(x, y);
        }
    }

    // This is called when we want to hide/dismiss some views on BACK key 
    // which are previously shown by mContentView.addView(), such as: 
    //   - Page overview
    //   - Find dialog, etc.
    // Return true if any view is dismissed.
    // @Deprecated
    private boolean clearSubViewsOnBackKey() {    
        if(mOverviewPage != null) {
            mContentView.removeView(mOverviewPage);
            mOverviewPage = null;

            //restore all we should...
            //mWebView.setFocusable(true);
            setProgressBarVisibility(true);
            getCurrentWebView().requestFocus();
            resetTitle();
            mMenuState = R.id.MAIN_MENU;
            return true;
        }
        return false;
    }

    // Return true if there're sub view on top, which are shown previously 
    // by mContentView.addView().
    /* package */ boolean hasSubViews() {
        if(mOverviewPage != null) {
            return true;
        }
        if(mFindDialog != null && mFindDialog.isShowing()) {
            return true;
        }
        if(mTabOverview != null) {
            return true;
        }

        // Hack: return true when we're still trying to conenct to network
        if(mNetworkConnecting) return true;

        // TODO: any view else...

        return false;
    }

    // See if we can update the title bar, such as set favicon, 
    // progress, or title.
    private boolean canUpdateTitleBar() {
        if(mAnimationCount == 0 && mTabOverview == null) {
            return true;
        }
        return false;
    }

    private boolean mFullScreen = false;
    private void toggleFullScreen() {
        // Always try to hide the fake title bar.
        hideFakeTitleBar();
        mFullScreen = !mFullScreen;
        if(mFullScreen) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }else {
            // Dismiss the floating progress bar anyway.
            //if(mFloatingProgress != null) {
            //    mFloatingProgress.hide();
            //}

            getWindow().setFlags(~WindowManager.LayoutParams.FLAG_FULLSCREEN, 
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        getWindow().setTitleViewVisible(!mFullScreen);
    }

    private boolean mLockOrientation = false;
    private int mCurrentOrientation = Configuration.ORIENTATION_PORTRAIT;
    private void toggleLockOrientation() {
        mLockOrientation = !mLockOrientation;
        if(mLockOrientation) {
            if(mCurrentOrientation == Configuration.ORIENTATION_PORTRAIT) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }else if(mCurrentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            }
        }else {
            //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        }
    }


    boolean isInLandscapeOrientation(){
        return mCurrentOrientation == Configuration.ORIENTATION_LANDSCAPE;
    }

    // Called when loading from context menu or LOAD_URL message
    private void loadURL(WebView view, String url) {
        // In case the user enters nothing.
        if (url != null && url.length() != 0) {
            url = smartUrlFilter(url);
            if (!mWebViewClient.shouldOverrideUrlLoading(view, url)) {
                //view.loadUrl(url);
                loadUrlInternal(view, url, true);
            }
        }
    }

    // OMS: A simple warpper for WebView.loadUrl(); just have a peek at the  
    // data connection to see if it's available. 
    // We always trust the input params (view & url) are valid.
    public void loadUrlInternal(WebView view, String url, 
            boolean checkNetwork) {
        Log.d("loadurl", "loadUrlInternal , url="+url);
        // See if we need to open the connection
        boolean suspend = false;
        if(checkNetwork && !isLocalResource(url)) {
            if(mNetworkConnecting) {
                suspend = true;
            }else {
                suspend = mNetworkManager.openDataConnectionIfNeeded();
            }
        }

        if(suspend || isAirplaneModeOn()) {
            mSuspendedUrl = url;
        }else {
            view.loadUrl(url);
        }
    }

    // See if the URL is trying to load a local resource.
    private boolean isLocalResource(String url) {
        if(url == null) {
            return true; //What about?
        }

        // TODO: Any other schemas?
        if(url.startsWith("file://") || url.startsWith("data://") || 
                url.startsWith("about://") || url.startsWith("content://")) {
            return true;
        }
        return false;
    }

    private void checkMemory() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) getSystemService(ACTIVITY_SERVICE))
                .getMemoryInfo(mi);
        // FIXME: mi.lowMemory is too aggressive, use (mi.availMem <
        // mi.threshold) for now
        //        if (mi.lowMemory) {
        Log.e(MEMLOG, "Browser memory usage is: available="
                            + (mi.availMem / 1024) + "K threshold="
                            + (mi.threshold / 1024) + "K");

        final int debugAdd_Size = 0; //M, only for debug
        Debug.MemoryInfo self_mi = new Debug.MemoryInfo(); 
        Debug.getMemoryInfo(self_mi); 
        Log.e(MEMLOG, "***** totalPrivateDirty=" + self_mi.getTotalPrivateDirty() + 
                     ", getTotalSharedDirty=" + self_mi.getTotalSharedDirty() +
                     ", getTotalPss=" + self_mi.getTotalPss());

        if (/*self_mi.getTotalPrivateDirty()> 50000 || */mi.availMem < mi.threshold + debugAdd_Size) {
            //int myProcessID = Process.myPid();
            mTabControl.freeMemory();
            //onLowMemory();
        }
    }

    private String smartUrlFilter(Uri inUri) {
        if (inUri != null) {
            return smartUrlFilter(inUri.toString());
        }
        return null;
    }


    // get window count

    int getWindowCount(){
      if(mTabControl != null){
        return mTabControl.getTabCount();
      }
      return 0;
    }

    static final Pattern ACCEPTED_URI_SCHEMA = Pattern.compile(
            "(?i)" + // switch on case insensitive matching
            "(" +    // begin group for schema
            "(?:http|https|file|rtsp):\\/\\/" +
            "|(?:data|about|content|javascript):" +
            ")" +
            "(.*)" );

    /**
     * Attempts to determine whether user input is a URL or search
     * terms.  Anything with a space is passed to search.
     *
     * Converts to lowercase any mistakenly uppercased schema (i.e.,
     * "Http://" converts to "http://"
     *
     * @return Original or modified URL
     *
     */
    String smartUrlFilter(String url) {

        String inUrl = url.trim();
        boolean hasSpace = inUrl.indexOf(' ') != -1;

        Matcher matcher = ACCEPTED_URI_SCHEMA.matcher(inUrl);
        if (matcher.matches()) {
            if (hasSpace) {
                inUrl = inUrl.replace(" ", "%20");
            }
            // force scheme to lowercase
            String scheme = matcher.group(1);
            String lcScheme = scheme.toLowerCase();
            if (!lcScheme.equals(scheme)) {
                return lcScheme + matcher.group(2);
            }
            return inUrl;
        }
        if (hasSpace) {
            // FIXME: quick search, need to be customized by setting
            if (inUrl.length() > 2 && inUrl.charAt(1) == ' ') {
                // FIXME: Is this the correct place to add to searches?
                // what if someone else calls this function?
                char char0 = inUrl.charAt(0);

                if (char0 == 'g') {
                    Browser.addSearchUrl(mResolver, inUrl);
                    return composeSearchUrl(inUrl.substring(2));

                } else if (char0 == 'w') {
                    Browser.addSearchUrl(mResolver, inUrl);
                    return URLUtil.composeSearchUrl(inUrl.substring(2),
                            QuickSearch_W,
                            QUERY_PLACE_HOLDER);

                } else if (char0 == 'd') {
                    Browser.addSearchUrl(mResolver, inUrl);
                    return URLUtil.composeSearchUrl(inUrl.substring(2),
                            QuickSearch_D,
                            QUERY_PLACE_HOLDER);

                } else if (char0 == 'l') {
                    Browser.addSearchUrl(mResolver, inUrl);
                    // FIXME: we need location in this case
                    return URLUtil.composeSearchUrl(inUrl.substring(2),
                            QuickSearch_L,
                            QUERY_PLACE_HOLDER);
                }
            }
        } else {
            if (Regex.WEB_URL_PATTERN.matcher(inUrl).matches()) {
                return URLUtil.guessUrl(inUrl);
            }
        }

        Browser.addSearchUrl(mResolver, inUrl);
        return composeSearchUrl(inUrl);
    }

    /* package */ String composeSearchUrl(String search) {
        // OMS: Use user-defined search portal if any.
        String s = SearchPortal.getInstance().getSearchString();
        if (s == null) {
            s = QuickSearch_G;
        }

        return URLUtil.composeSearchUrl(search, s,
                QUERY_PLACE_HOLDER);
    }

    /* ========================================================
     * OMS interfaces. BEGIN
     * 
     * ======================================================== */

    private boolean mNetworkConnecting = false;
    /*package*/ void waitForNetwork() {
        if(isAirplaneModeOn()) return;
        // Wait until network is available.
        mNetworkConnecting = true;
        if(canUpdateTitleBar()) {
            setUrlTitle(getString(R.string.network_connect_msg));
//setDefaultFavicon();
            setProgress(500);
        }
    }

    /*package*/ void resumeAfterNetwork() {
        if(canUpdateTitleBar()) {
            //setTitle("");
            setUrlTitle("");
            setProgress(10000);
        }
        mNetworkConnecting = false;

        // Reset page titles if needed. Do not call resetTitle as it may 
        // trigger onProgressChanged which we don't want to see.
        //resetLockIcon();
        WebView current = mTabControl.getCurrentWebView();
        if (current != null) {
            resetTitleAndIcon(current);
        }
    }

    /*
     * A wrapper for ControlPanel.
     */
    /* package */void showTabPicker() {
        tabPicker(true, mTabControl.getCurrentIndex(), false, true, true);
    }
    /* ========================================================
     * OMS interfaces. END
     * 
     * ======================================================== */


    private final static int LOCK_ICON_UNSECURE = 0;
    private final static int LOCK_ICON_SECURE   = 1;
    private final static int LOCK_ICON_MIXED    = 2;

    private int mLockIconType = LOCK_ICON_UNSECURE;
    private int mPrevLockType = LOCK_ICON_UNSECURE;

    private BrowserSettings mSettings;
    private TabControl      mTabControl;
    private ContentResolver mResolver;
    private FrameLayout     mContentView;
    private BrowserTabView mTabOverview;
    private View            mCustomView;
    private FrameLayout     mCustomViewContainer;
    private WebChromeClient.CustomViewCallback mCustomViewCallback;

    // FIXME, temp address onPrepareMenu performance problem. When we move everything out of
    // view, we should rewrite this.
    private int mCurrentMenuState = 0;
    private int mMenuState = R.id.MAIN_MENU;
    private int mOldMenuState = EMPTY_MENU;
    private static final int EMPTY_MENU = -1;
    private Menu mMenu;

    private FindDialog mFindDialog;
    // Used to prevent chording to result in firing two shortcuts immediately
    // one after another.  Fixes bug 1211714.
    boolean mCanChord;

    private boolean mInLoad;
    private boolean mIsNetworkUp;
    private boolean mDidStopLoad;

    private boolean mPageStarted;
    private boolean mActivityInPause = true;

    //Do nothing after activity is destroyed.
    private boolean mActivityDestroyed = false;

    private boolean mMenuIsDown;

    private final KeyTracker mKeyTracker = new KeyTracker(this);

    // As trackball doesn't send repeat down, we have to track it ourselves
    private boolean mTrackTrackball;

    private static boolean mInTrace;

    // Performance probe
    private static final int[] SYSTEM_CPU_FORMAT = new int[] {
        /* OMS: remove for now.
            Process.PROC_SPACE_TERM | Process.PROC_COMBINE,
            Process.PROC_SPACE_TERM | Process.PROC_OUT_LONG, // 1: user time
            Process.PROC_SPACE_TERM | Process.PROC_OUT_LONG, // 2: nice time
            Process.PROC_SPACE_TERM | Process.PROC_OUT_LONG, // 3: sys time
            Process.PROC_SPACE_TERM | Process.PROC_OUT_LONG, // 4: idle time
            Process.PROC_SPACE_TERM | Process.PROC_OUT_LONG, // 5: iowait time
            Process.PROC_SPACE_TERM | Process.PROC_OUT_LONG, // 6: irq time
            Process.PROC_SPACE_TERM | Process.PROC_OUT_LONG  // 7: softirq time
            */
    };

    private long mStart;
    private long mProcessStart;
    private long mUserStart;
    private long mSystemStart;
    private long mIdleStart;
    private long mIrqStart;

    private long mUiStart;

    private Drawable    mMixLockIcon;
    private Drawable    mSecLockIcon;

    // Do not send out any request to network before connection is ready.
    private boolean mNetworkUp = false;
    private String mSuspendedUrl;
    private AlertDialog mAirplaneOnDialog;
    private AlertDialog mAirplaneOffDialog;

    // For CMCC: Prompt for wifi connected, just one shot.
    private boolean mWifiNotified = false;

    /* hold a ref so we can auto-cancel if necessary */
    private AlertDialog mAlertDialog;

    // Wait for credentials before loading google.com
    private ProgressDialog mCredsDlg;

    // The up-to-date URL and title (these can be different from those stored
    // in WebView, since it takes some time for the information in WebView to
    // get updated)
    private String mUrl;
    private String mTitle;

    // As PageInfo has different style for landscape / portrait, we have
    // to re-open it when configuration changed
    private AlertDialog mPageInfoDialog;
    private TabControl.Tab mPageInfoView;
    // If the Page-Info dialog is launched from the SSL-certificate-on-error
    // dialog, we should not just dismiss it, but should get back to the
    // SSL-certificate-on-error dialog. This flag is used to store this state
    private Boolean mPageInfoFromShowSSLCertificateOnError;

    // as SSLCertificateOnError has different style for landscape / portrait,
    // we have to re-open it when configuration changed
    private AlertDialog mSSLCertificateOnErrorDialog;
    private WebView mSSLCertificateOnErrorView;
    private SslErrorHandler mSSLCertificateOnErrorHandler;
    private SslError mSSLCertificateOnErrorError;

    // as SSLCertificate has different style for landscape / portrait, we
    // have to re-open it when configuration changed
    private AlertDialog mSSLCertificateDialog;
    private TabControl.Tab mSSLCertificateView;

    // as HttpAuthentication has different style for landscape / portrait, we
    // have to re-open it when configuration changed
    private AlertDialog mHttpAuthenticationDialog;
    private HttpAuthHandler mHttpAuthHandler;

    /*package*/ static final FrameLayout.LayoutParams COVER_SCREEN_PARAMS =
                                            new FrameLayout.LayoutParams(
                                            ViewGroup.LayoutParams.FILL_PARENT,
                                            ViewGroup.LayoutParams.FILL_PARENT);
    /*package*/ static final FrameLayout.LayoutParams COVER_SCREEN_GRAVITY_CENTER =
                                            new FrameLayout.LayoutParams(
                                            ViewGroup.LayoutParams.FILL_PARENT,
                                            ViewGroup.LayoutParams.FILL_PARENT,
                                            Gravity.CENTER);
    // Google search
    final static String QuickSearch_G = "http://www.google.com/m?q=%s";
    // Wikipedia search
    final static String QuickSearch_W = "http://en.wikipedia.org/w/index.php?search=%s&go=Go";
    // Dictionary search
    final static String QuickSearch_D = "http://dictionary.reference.com/search?q=%s";
    // Google Mobile Local search
    final static String QuickSearch_L = "http://www.google.com/m/search?site=local&q=%s&near=mountain+view";

    final static String QUERY_PLACE_HOLDER = "%s";

    // "source" parameter for Google search through search key
    final static String GOOGLE_SEARCH_SOURCE_SEARCHKEY = "browser-key";
    // "source" parameter for Google search through goto menu
    final static String GOOGLE_SEARCH_SOURCE_GOTO = "browser-goto";
    // "source" parameter for Google search through simplily type
    final static String GOOGLE_SEARCH_SOURCE_TYPE = "browser-type";
    // "source" parameter for Google search suggested by the browser
    final static String GOOGLE_SEARCH_SOURCE_SUGGEST = "browser-suggest";
    // "source" parameter for Google search from unknown source
    final static String GOOGLE_SEARCH_SOURCE_UNKNOWN = "unknown";

    private final static String LOGTAG = "browser";
    private final static String MEMLOG = "memlog";

    private TabListener mTabListener;
    private OverviewPage mOverviewPage;
    private NetworkManager mNetworkManager;

    private String mLastEnteredUrl;

    private PowerManager.WakeLock mWakeLock;
    private final static int WAKELOCK_TIMEOUT = 50 * 1000;

    private Toast mStopToast;

    private TitleBar mTitleBar;

    private LinearLayout mErrorConsoleContainer = null;
    private boolean mShouldShowErrorConsole = false;

    // Used during animations to prevent other animations from being triggered.
    // A count is used since the animation to and from the Window overview can
    // overlap. A count of 0 means no animation where a count of > 0 means
    // there are animations in progress.
    private int mAnimationCount;

    // As the ids are dynamically created, we can't guarantee that they will
    // be in sequence, so this static array maps ids to a window number.
/*    final static private int[] WINDOW_SHORTCUT_ID_ARRAY =
    { R.id.window_one_menu_id, R.id.window_two_menu_id, R.id.window_three_menu_id,
      R.id.window_four_menu_id, R.id.window_five_menu_id, R.id.window_six_menu_id,
      R.id.window_seven_menu_id, R.id.window_eight_menu_id };
*/
    // monitor platform changes
    private IntentFilter mNetworkStateChangedFilter;
    private BroadcastReceiver mNetworkStateIntentReceiver;

    private IntentFilter mDrmChangedFilter;
    private BroadcastReceiver mDrmIntentReceiver;
    
    private IntentFilter mBrowserIntentFilter;
    private BroadcastReceiver mBrowserIntentReceiver;

    // activity requestCode
    final static int BOOKMARKS_PAGE         = 1;
    final static int CLASSIC_HISTORY_PAGE   = 2;
    final static int DOWNLOAD_PAGE          = 3;
    final static int PREFERENCES_PAGE       = 4;
    final static int SEARCH_PAGE            = 5;
    final static int EXTRA_MENU             = 10;
    // OMS: support upload file and restrict max file size to 512K
    final static int FILE_PICK_UI           = 21;
    private Message  filePickCallback;
    final static long MAX_FILE_UPLOAD_SIZE  = 512*1024; // 512K

    // the frenquency of checking whether system memory is low
    final static int CHECK_MEMORY_INTERVAL = 30000;

    // the default <video> poster
    private Bitmap mDefaultVideoPoster;
    // the video progress view
    private View mVideoProgressView;

    // the flag about whether to enable setting browser brightness
    private boolean mEnableSetBrightness;
    private BrowserBrightness mBrowserBrightness;

    /**
     * A UrlData class to abstract how the content will be set to WebView.
     * This base class uses loadUrl to show the content.
     */
    private static class UrlData {
        String mUrl;
        byte[] mPostData;

        UrlData(String url) {
            this.mUrl = url;
        }

        void setPostData(byte[] postData) {
            mPostData = postData;
        }

        boolean isEmpty() {
            return mUrl == null || mUrl.length() == 0;
        }

        public void loadIn(WebView webView) {
            if (mPostData != null) {
                webView.postUrl(mUrl, mPostData);
            } else {
                webView.loadUrl(mUrl);
            }
        }
    };

    /**
     * A subclass of UrlData class that can display inlined content using
     * {@link WebView#loadDataWithBaseURL(String, String, String, String, String)}.
     */
    private static class InlinedUrlData extends UrlData {
        InlinedUrlData(String inlined, String mimeType, String encoding, String failUrl) {
            super(failUrl);
            mInlined = inlined;
            mMimeType = mimeType;
            mEncoding = encoding;
        }
        String mMimeType;
        String mInlined;
        String mEncoding;
        @Override
        boolean isEmpty() {
            return mInlined == null || mInlined.length() == 0 || super.isEmpty();
        }

        @Override
        public void loadIn(WebView webView) {
            webView.loadDataWithBaseURL(null, mInlined, mMimeType, mEncoding, mUrl);
        }
    }

    /* package */ static final UrlData EMPTY_URL_DATA = new UrlData(null);    //ANDROID_MOT_FLASHLITE
    //ANDROID_MOT_FLASHLITE
    public Window getWindowForFlash()
    {
        return getWindow();
    }

    public void setMenuState(int state)
    {
        mCurrentMenuState = state;
    }
    //End of ANDROID_MOT_FLASHLITE
}
