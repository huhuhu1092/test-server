/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ActivityInfo;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.ServiceManager;
import android.provider.Browser;
import android.text.IClipboard;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ContextMenu.ContextMenuInfo;
import android.webkit.DateSorter;
import android.webkit.WebIconDatabase.IconListener;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

import android.product.config.ProductConfig;
import oms.app.FrameListActivity;
import oms.app.AbsFrameView;

import android.widget.RelativeLayout;

/**
 * Activity for displaying the browser's history, divided into
 * days of viewing.
 */
public class BrowserHistoryPage extends FrameListActivity {
    final static String PREF_HISTORY_SORT = "history_sort";
    final static String whereClause = Browser.BookmarkColumns.VISITS + " > 0 ";
    final static String orderByDate  = Browser.BookmarkColumns.DATE + " DESC";
    final static String orderByTitle = Browser.BookmarkColumns.TITLE + " ASC";
    final static String orderByUrl   = Browser.BookmarkColumns.URL + " ASC";
    final static String orderByVisits   = Browser.BookmarkColumns.VISITS + " DESC";
    static String curOrderBy = orderByDate;
        
    private HistoryAdapter          mAdapter;
    private DateSorter              mDateSorter;
    private boolean                 mMaxTabsOpen;
    private boolean                 mInDeleteView = false;
    private boolean                 mSortByDate = true;
    private int                     mDefaultSort = 0;
    private ListView                mListView;

    private final static String LOGTAG = "browser";

    // FIXME: Make this a part of Browser so we do not have more than one
    // copy (other copy is in BrowserBookmarksAdapter).
    // Used to store favicons as we get them from the database
    private final HashMap<String, Bitmap> mUrlsToIcons =
            new HashMap<String, Bitmap>();
    // Implementation of WebIconDatabase.IconListener
    private class IconReceiver implements IconListener {
        public void onReceivedIcon(String url, Bitmap icon) {
            mUrlsToIcons.put(url, icon);
            setListAdapter(mAdapter);
        }
    }
    // Instance of IconReceiver
    private final IconReceiver mIconReceiver = new IconReceiver();

    /**
     * Report back to the calling activity to load a site.
     * @param url   Site to load.
     * @param newWindow True if the URL should be loaded in a new window
     */
    private void loadUrl(String url, boolean newWindow) {
        Intent intent = new Intent().setAction(url);
        if (newWindow) {
            Bundle b = new Bundle();
            b.putBoolean("new_window", true);
            intent.putExtras(b);
        }
        setResult(RESULT_OK, intent);
        finish();
    }
    
    private void copy(CharSequence text) {
        try {
            IClipboard clip = IClipboard.Stub.asInterface(ServiceManager.getService("clipboard"));
            if (clip != null) {
                clip.setClipboardText(text);
            }
        } catch (android.os.RemoteException e) {
            Log.e(LOGTAG, "Copy failed", e);
        }
    }

    @Override
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        // OMS: Request for orientation sensor
        //super.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);

        mDateSorter = new DateSorter(this);

        curOrderBy = getSortString(getDefaultSort());
        mSortByDate = curOrderBy.equals(orderByDate);

        if (mAdapter == null) {
           mAdapter = new HistoryAdapter();
        }

        setListAdapter(mAdapter);
        mListView = getListView();
        if (mInDeleteView)
            mListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        mListView.setOnCreateContextMenuListener(this);
        LayoutInflater factory = LayoutInflater.from(this);
        View v = factory.inflate(R.layout.empty_history, null);
        addContentView(v, new LayoutParams(LayoutParams.FILL_PARENT,
                LayoutParams.FILL_PARENT));
        mListView.setEmptyView(v);

        mMaxTabsOpen = getIntent().getBooleanExtra("maxTabsOpen", false);
        Browser.requestAllIcons(getContentResolver(), null, mIconReceiver);
        resetTitle();
        initButtons();
        setButtons();
        // initialize the result to canceled, so that if the user just presses
        // back then it will have the correct result
        //setResult(RESULT_CANCELED);
    }

    private AbsFrameView mClrHistoryBtn = null;
	   private AbsFrameView mSortBtn = null;
	   private AbsFrameView mClrTodayBtn = null;
	   private int mClrTodayBtnStat = 0;//0:clear today history, 1:select all , 2:deselectall
	   private View.OnClickListener mClrHisBtnListener = new View.OnClickListener(){
        public void onClick(View v){
        	   mClrHistoryBtn.setEnabled(false);
            showDeleteView();
        }
	   };

	   private View.OnClickListener mSortBtnListener = new View.OnClickListener(){
        public void onClick(View v){
           	if(mInDeleteView){
           		   if(!mAdapter.isItemSelected()) {
                //if(mAdapter.getSelectedCount() <= 0) {
                    Toast.makeText(BrowserHistoryPage.this, R.string.history_no_checked, 
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                deleteSelectedItems();
           	}
           	else{
           		   sort();
           	}
         }
	   };

	   private View.OnClickListener mClrTodayBtnListener = new View.OnClickListener(){
        public void onClick(View v){
            switch(mClrTodayBtnStat){   
            	case 0:
           	    new AlertDialog.Builder(BrowserHistoryPage.this)
                    .setTitle(R.string.history_delete)
                    .setIcon(com.android.internal.R.drawable.cmcc_dialog_question2)
                    .setMessage(R.string.history_delete_today)
                    .setPositiveButton(R.string.ok,
                        new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            // Delete the items and back to main view.
                            mAdapter.deleteTodayItems();
                            showMainView();
                        }
                    })
                    .setNegativeButton(R.string.cancel, null)
                    .show();
                break;
            case 1:
                  mListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                  //mAdapter.refreshData();
                  mListView.selectAll();
                  setButtons();
                  break;
            case 2:
                  mListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                  //mAdapter.refreshData();
                  mListView.unSelectAll();
                  setButtons();
                  break;
                default:
                   	break;
        	   }
        }
	   };

	   private void setOriginalTitleContainer(){
        RelativeLayout titleContainer = (RelativeLayout)findViewById(com.android.internal.R.id.title_container);
        RelativeLayout frameTitleContainer = (RelativeLayout)findViewById(com.oms.internal.R.id.frame_title_container);
        if(titleContainer == null && frameTitleContainer == null)
        	   return;
        if(mAdapter.isEmpty()){
            titleContainer.setVisibility(View.VISIBLE);
            frameTitleContainer.setVisibility(View.GONE);
        }else{
            titleContainer.setVisibility(View.GONE);
            frameTitleContainer.setVisibility(View.VISIBLE);
        }
	   }

	   private void initButtons(){
           mClrHistoryBtn = findWinViewById(FRAMENEW);
           mSortBtn = findWinViewById(FRAMEONE);
           mClrTodayBtn = findWinViewById(FRAMETWO);
           mClrHistoryBtn.setOnClickListener(mClrHisBtnListener);
           mClrHistoryBtn.setVisibility(View.VISIBLE);
           mClrHistoryBtn.setText(R.string.clear_history);	
       
           mSortBtn.setOnClickListener(mSortBtnListener);
           mSortBtn.setVisibility(View.VISIBLE);
       
           mClrTodayBtn.setOnClickListener(mClrTodayBtnListener);
           mClrTodayBtn.setVisibility(View.VISIBLE); 
           setBottomVisibility(true);
	   }

	   
    private void setButtons(){
       setOriginalTitleContainer();
       if(mInDeleteView){
       	   mClrHistoryBtn.setEnabled(false);
           mSortBtn.setText(R.string.history_delete);
           //OMS 0098365
           int selectedCount = mAdapter.getSelectedCount();
           if(selectedCount >0){
               mSortBtn.setEnabled(true);
           }else{
               mSortBtn.setEnabled(false);
           }
           //OMS 95767:When all items are selected,the btn should be unselectall.
           if(mAdapter.getCount() == selectedCount){
               mClrTodayBtn.setText(R.string.history_delete_unselectall);
               mClrTodayBtnStat = 2;
           }else{
               mClrTodayBtn.setText(R.string.history_delete_selectall);
               mClrTodayBtnStat = 1;
           }
           mClrTodayBtn.setEnabled(true);
       }
       else{
       	   if(mAdapter.isEmpty()){
               mClrTodayBtn.setVisibility(View.GONE);
               mSortBtn.setVisibility(View.GONE);
               return;
       	   }
       	   mSortBtn.setEnabled(true);
       	   mClrHistoryBtn.setEnabled(true);
           mSortBtn.setText(R.string.sort_history);
           mClrTodayBtn.setText(R.string.clear_today_history);
           if(mAdapter.todayItemsExist())
           	   mClrTodayBtn.setEnabled(true);
           else
           	   mClrTodayBtn.setEnabled(false);
           mClrTodayBtnStat = 0;
       }
    }

    @Override
    public void titleSelected() {
        super.titleSelected();

        // OMS1.2.1: the title should toggle between main view and delete view.
        if(mInDeleteView) {
            if(mAdapter.getSelectedCount() <= 0) {
                Toast.makeText(this, R.string.history_no_checked, 
                        Toast.LENGTH_SHORT).show();
                return;
            }
            deleteSelectedItems();
        }else {
            showDeleteView();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK) {
            if(mInDeleteView) {
                showMainView();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //we use the btn from FrameListActivity,so the option menu is unnecessary
        super.onCreateOptionsMenu(menu);
        //MenuInflater inflater = getMenuInflater();
        //inflater.inflate(R.menu.history, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
   //we use the btn from FrameListActivity,so the option menu is unnecessary
   /*
        // No options menu if it's empty.
        if(mAdapter == null || mAdapter.isEmpty()) {
            //Log.i("BrowserHistoryPage", "onPrepareOptionsMenu will return false");
            return false;
        }

        if (mInDeleteView) {
            menu.setGroupVisible(R.id.HISTORY_MAIN, false);
            menu.setGroupVisible(R.id.HISTORY_DELETE, true);
        } else {
            menu.setGroupVisible(R.id.HISTORY_MAIN, true);
            menu.setGroupVisible(R.id.HISTORY_DELETE, false);
        }

        boolean exist = mAdapter.todayItemsExist();
        menu.findItem(R.id.clear_today_history_menu_id).setVisible(exist && !mInDeleteView);

        if(false) {
            // Disable as these items are on title view.
            menu.findItem(R.id.clear_history_menu_id).setVisible(false);
            menu.findItem(R.id.remove_multiple_history_menu_id).setVisible(false);
        }
      */
        return true;
    }
   
    private void resetTitle() {
        if(false) {
            if(mInDeleteView) {
                setTitle(R.string.history_delete);
            }else {
                setTitle(R.string.clear_history);
            }
        }else {
            setTitle(R.string.browser_history);
        }
    }

    // Called in delete view to navigate back to history main view.
    private void showMainView() {
        mInDeleteView = false;
        mAdapter.refreshData();
        this.getListView().unSelectAll();
        resetTitle();
        setButtons();
    }

    private void showDeleteView() {
        mInDeleteView = true;
        resetTitle();
        mAdapter.refreshData();
        mListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        setButtons();
    }

    private void deleteSelectedItems() {
        new AlertDialog.Builder(BrowserHistoryPage.this)
            .setTitle(R.string.history_delete)
            .setIcon(com.android.internal.R.drawable.cmcc_dialog_question2)
            .setMessage(R.string.history_delete_warning)
            .setPositiveButton(R.string.ok,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            // Delete the items and back to main view.
                            mAdapter.deleteSelectedItems();
                            showMainView();
                        }
                    })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void sort() {
        new AlertDialog.Builder(BrowserHistoryPage.this)
            //.setTitle(R.string.alert_dialog_single_choice)
            .setSingleChoiceItems(R.array.history_sortby, mDefaultSort, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    setDefatultSort(whichButton);
                    BrowserHistoryPage.this.mAdapter.refreshData(whichButton);
                    dialog.dismiss();
                }
            })
           .show();
    }

    private int getDefaultSort() {
        mDefaultSort = (PreferenceManager.
                getDefaultSharedPreferences(this).
                getInt(PREF_HISTORY_SORT, 0));
        return mDefaultSort;
    }

    private void setDefatultSort(int s) {
        Editor ed = PreferenceManager.
            getDefaultSharedPreferences(this).edit();      
        ed.putInt(PREF_HISTORY_SORT, s);
        ed.commit();
        mDefaultSort = s;
    }

    static String getSortString(int index) {
        switch(index) {
        case 0:
            curOrderBy = orderByDate;
            break;
        case 1:
            //curOrderBy = orderByTitle;
            curOrderBy = orderByVisits;
            break;
        case 2:
            curOrderBy = orderByUrl;
            break;
        default:
            break;
        }
        return curOrderBy;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.clear_history_menu_id:
                // FIXME: Need to clear the tab control in browserActivity 
                // as well
                //Browser.clearHistory(getContentResolver());
                //startMultiSelectionActivity(REQUEST_CODE_MULTI_DELETE);
                //finish();
                //mAdapter.refreshData();
                showDeleteView();
                return true;

            case R.id.clear_today_history_menu_id:
                new AlertDialog.Builder(BrowserHistoryPage.this)
                    .setTitle(R.string.history_delete)
                    .setIcon(com.android.internal.R.drawable.cmcc_dialog_question2)
                    .setMessage(R.string.history_delete_today)
                    .setPositiveButton(R.string.ok,
                        new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            // Delete the items and back to main view.
                            mAdapter.deleteTodayItems();
                            showMainView();
                        }
                    })
                    .setNegativeButton(R.string.cancel, null)
                    .show();
 
                return true;

            case R.id.remove_multiple_history_menu_id:
                if(!mAdapter.isItemSelected()) {
                //if(mAdapter.getSelectedCount() <= 0) {
                    Toast.makeText(this, R.string.history_no_checked, 
                            Toast.LENGTH_SHORT).show();
                    return true;
                }
                deleteSelectedItems();
                return true;

            case R.id.sort_history_menu_id:
                sort();
                return true;

            case R.id.select_all_history_menu_id:
                mListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                //mAdapter.refreshData();
                mListView.selectAll();
                return true;

            case R.id.unselect_all_history_menu_id:
                mListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                //mAdapter.refreshData();
                mListView.unSelectAll();
                return true;

            default:
                break;
        }  
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
            ContextMenuInfo menuInfo) {
        // Show no menu items when we're in Delete Mode.
        if(mInDeleteView) {
            return;
        }

        AdapterView.AdapterContextMenuInfo i = 
            (AdapterView.AdapterContextMenuInfo)
            menuInfo;

        // Inflate the menu
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.historycontext, menu);

        // Only show open in new tab if we have not maxed out available tabs
        menu.findItem(R.id.new_window_context_menu_id).setVisible(!mMaxTabsOpen);
        
     // decide whether to show the share link option
        PackageManager pm = getPackageManager();
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        List<ResolveInfo> list = pm.queryIntentActivities(send,
                PackageManager.MATCH_DEFAULT_ONLY);
        menu.findItem(R.id.share_link_context_menu_id).setVisible(
                list.size() > 0);
        
        // Setup the header and hide some items
        if(false) {
            menu.setHeaderTitle(((HistoryItem)i.targetView).getName());
            menu.findItem(R.id.share_link_context_menu_id).setVisible(false);
        }else {
            //menu.setHeaderTitle(((HistoryItem)i.targetView).getUrl());
        }
        super.onCreateContextMenu(menu, v, menuInfo);
    }
    
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo i = 
            (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        // OMS: when switch between landscape mode and portrait mode,
        // i.targetView may change to different item. 
        // final String url = ((HistoryItem)i.targetView).getUrl();
        final String url = mAdapter.getHistoryItemUrl(i.position);
        String title = ((HistoryItem)i.targetView).getName();
        switch (item.getItemId()) {
            /* Borqs: Not necessary in this context
            case R.id.open_context_menu_id:
                loadUrl(url, false);
                return true;
                */
            case R.id.new_window_context_menu_id:
                loadUrl(url, true);
                return true;
            case R.id.save_to_bookmarks_menu_id:
                Browser.saveBookmark(this, title, url);
                return true;
            case R.id.share_link_context_menu_id:
                Browser.sendString(this, url);
                return true;
            case R.id.copy_context_menu_id:
                copy(url);
                return true;
            case R.id.delete_context_menu_id:
                new AlertDialog.Builder(BrowserHistoryPage.this)
                    .setIcon(com.android.internal.R.drawable.cmcc_dialog_question2)
                    .setTitle(R.string.history_delete)
                    .setMessage(R.string.history_delete_warning)
                    .setPositiveButton(R.string.ok,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            Browser.deleteFromHistory(getContentResolver(), url);
                            mAdapter.refreshData();
                        }
                    })
                    .setNegativeButton(R.string.cancel, null)
                    .show();
                return true;
            default:
                break;
        }
        return super.onContextItemSelected(item);
    }
    /*
    @Override public boolean performItemClick(View view, int position, long id) {
        return super.performItemClick(view, position, id);
    }*/
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        if (mInDeleteView) {
            //getListView().performItemClick(v, position, id);
            //getListView().invalidateViews();
            //OMS 95767:Maybe we should change the btns' state
            setButtons();
            return;
        }

        if (v instanceof HistoryItem) {
            loadUrl(((HistoryItem) v).getUrl(), false);
        }
    }

    /*private*/ class HistoryAdapter implements ListAdapter {
        
        // Map of items. Negative values are labels, positive values
        // and zero are cursor offsets.
        int mItemMap[];
        Vector<DataSetObserver> mObservers;
        Cursor mCursor;
        //private ArrayList<String> mCheckedIDlist;

        static final int MAX_BATCH_DELETE_ITEM_COUNT = 200;
        
        HistoryAdapter() {
            mObservers = new Vector<DataSetObserver>();
           
            mCursor = managedQuery(
                    Browser.BOOKMARKS_URI,
                    Browser.HISTORY_PROJECTION,
                    whereClause, null, curOrderBy);
            
            buildMap();
        }

        boolean todayItemsExist() {
            mCursor.requery();
            if (mCursor.moveToFirst() && mCursor.getCount() > 0) {
                while (!mCursor.isAfterLast()) {
                    long date = mCursor.getLong(Browser.HISTORY_PROJECTION_DATE_INDEX);
                    int index = mDateSorter.getIndex(date);                         
                    if (index == 0) {
                        return true;
                    }
                    mCursor.moveToNext();
                }
            } 
            return false;
        }

        private void deleteTodayItems() {        

            mCursor.requery();

            // Calcuate 12:00am by zeroing out hour, minute, second, millisecond
            Calendar c = Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY, 0);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            long todayBin = c.getTimeInMillis(); // Today
            String where = "date > "+todayBin;
            try {
                Browser.deleteHistoryWhere(getContentResolver(), where);
            }catch(Exception ee) {
                Log.w("BrowserHistoryPage", "Fail to delete history items", ee);
                Toast.makeText(BrowserHistoryPage.this, R.string.remove_today_history_fail, Toast.LENGTH_LONG)
                        .show();
            }
            return;          
        }

        public void deleteSelectedItems() {
            StringBuilder where = new StringBuilder();
            boolean firstTime = true;
            int batch_count = MAX_BATCH_DELETE_ITEM_COUNT;

            ListView list = BrowserHistoryPage.this.getListView();
            for (int i = 0; i < getCount(); i++) {
                if (list.isItemChecked(i)) {
                    //removeItem(i);
                    if (batch_count > 0) {
                        batch_count--;
                    } else {
                        // execute delet opation. 
                        Log.d("BrowserHistoryPage", "where="+where.toString());
                        Browser.deleteHistoryWhere(getContentResolver(), where.toString());
                        // initial state
                        batch_count = MAX_BATCH_DELETE_ITEM_COUNT;
                        firstTime = true;
                        where = new StringBuilder();
                    }
                    
                    if (firstTime) {
                        firstTime = false;
                    } else {
                        where.append(" OR ");
                    }
                    mCursor.moveToPosition(mItemMap[i]);
                    int id = mCursor.getInt(Browser.HISTORY_PROJECTION_ID_INDEX);
 
                    where.append("(_id=");
                    where.append(id);
                    where.append(")");
                }
            }
            // execute delet opation. 
            Log.d("BrowserHistoryPage", "where="+where.toString());
            Browser.deleteHistoryWhere(getContentResolver(), where.toString());
        }

        public void removeItem(int position) {
            mCursor.moveToPosition(mItemMap[position]);
            String url = mCursor.getString(Browser.HISTORY_PROJECTION_URL_INDEX);
            //Log.e("remove",  "url = " + url);
            Browser.deleteFromHistory(getContentResolver(), url);
        }

        public int getSelectedCount() {
            ListView list = BrowserHistoryPage.this.getListView();
            int count = 0;
            for(int i = 0; i < getCount(); i++) {
                if(list.isItemChecked(i)) {
                    count++;
                }
            }
            return count;
        }

        public boolean isItemSelected() {
            SparseBooleanArray checked = 
                BrowserHistoryPage.this.getListView().getCheckedItemPositions();

            if(checked == null) return false;
            if(checked.indexOfValue(true) >= 0) {
                return true;
            }
            return false;
        }

        void refreshData() {
            //mCursor.requery();
            BrowserHistoryPage.this.stopManagingCursor(mCursor);//Must remove it from ManagedCursor list.
            mCursor.close();
            mCursor = null;

            mCursor = managedQuery(Browser.BOOKMARKS_URI, Browser.HISTORY_PROJECTION, whereClause, null, curOrderBy);

            buildMap();
            for (DataSetObserver o : mObservers) {
                o.onChanged();
            }
        }
       
        void refreshDataByUrl() {
            curOrderBy = orderByUrl;
            refreshData();
        }

        void refreshDataByDate() {
            curOrderBy = orderByDate;
            refreshData();
        } 

        //sortBy must be consistent with defined in res/values/history_sortby.
        void refreshData(int sortBy) {
            curOrderBy = getSortString(sortBy);
            mSortByDate = curOrderBy.equals(orderByDate);
            refreshData();
        } 

        public void buildMap() {
            // The cursor is sorted by date
            // Make one pass to build up the ItemMap with the inserted 
            // section separators. 
            int n = mCursor.getCount();
            if (!mInDeleteView && mSortByDate)
                n += DateSorter.DAY_COUNT;
            int array[] = new int[n];

            if (!mInDeleteView && mSortByDate) {
					//Borqs: Take into account the empty bins (labels) 
					//before the first item.  
					boolean emptyBins[] = new boolean[DateSorter.DAY_COUNT];
					for(int i=0; i<DateSorter.DAY_COUNT; i++) {
						emptyBins[i] = true;
					}

					int dateIndex = -1;
					if (mCursor.moveToFirst() && mCursor.getCount() > 0) {
						int itemIndex = 0;
						while (!mCursor.isAfterLast()) {
							long date = mCursor.getLong(Browser.HISTORY_PROJECTION_DATE_INDEX);
							int index = mDateSorter.getIndex(date);
							if (index > dateIndex) {
								dateIndex = index;
								array[itemIndex] = dateIndex - DateSorter.DAY_COUNT;
								itemIndex++;
								emptyBins[index] = false;
							}
							array[itemIndex] = mCursor.getPosition();
							itemIndex++;
							mCursor.moveToNext();
						}
					} else {
						// The db is empty, just add the heading for the first item
						dateIndex = 0;
						array[0] = dateIndex - DateSorter.DAY_COUNT;
					}
					// Compress the array as the trailing date sections may be
					// empty
					int empty_labels = 0;
					for(int i=0; dateIndex>=0 && i<dateIndex; i++) {
						if(emptyBins[i]) {
							empty_labels ++;
						}
					}
					int extraEntries = DateSorter.DAY_COUNT - dateIndex - 1 + empty_labels;
					if (extraEntries > 0) {
						int newArraySize = array.length - extraEntries;
						mItemMap = new int[newArraySize];
						System.arraycopy(array, 0, mItemMap, 0, newArraySize);
					} else {
						mItemMap = array;
					} 
            } else {
				 if (mCursor.moveToFirst() && mCursor.getCount() > 0) {
					 int itemIndex = 0;
					 while (!mCursor.isAfterLast()) {
		                 array[itemIndex] = mCursor.getPosition();
	                     //Log.e("BrowserHistoryPage", "buildMap: itemIndex="+itemIndex+",item="+array[itemIndex]);
						 itemIndex++;
						 mCursor.moveToNext();
					 }
	            } 
	            mItemMap = array;
            }
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (mItemMap[position] < 0) {
                if (mInDeleteView || !mSortByDate)
                    return null;
                else
                    return getHeaderView(position, convertView);
            }
            return getHistoryItem(position, convertView);
        }
        
        View getHistoryItem(int position, View convertView) {
            HistoryItem item;
            if (null == convertView || !(convertView instanceof HistoryItem)) {
                //item = new HistoryItem(BrowserHistoryPage.this);
                //Borqs: mMultiSelection means in delete mode, unify later
                item = new HistoryItem(BrowserHistoryPage.this, mAdapter, mInDeleteView);
            } else {
                item = (HistoryItem) convertView;
                item.setSelectMode(mInDeleteView);
                item.setChecked(item.isChecked());
            }
            mCursor.moveToPosition(mItemMap[position]);
            item.setName(mCursor.getString(Browser.HISTORY_PROJECTION_TITLE_INDEX));
            String url = mCursor.getString(Browser.HISTORY_PROJECTION_URL_INDEX);
            item.setUrl(url);
            item.setFavicon((Bitmap) mUrlsToIcons.get(url));
            return item;
        }

        public String getHistoryItemUrl(int position) {
            mCursor.moveToPosition(mItemMap[position]);
            return mCursor.getString(Browser.HISTORY_PROJECTION_URL_INDEX);
        }
        
        View getHeaderView(int position, View convertView) {
            if (mInDeleteView || ! mSortByDate)
                return null;

            TextView item;
            if (null == convertView || !(convertView instanceof TextView)) {
                LayoutInflater factory = 
                        LayoutInflater.from(BrowserHistoryPage.this);
                item = (TextView) 
                        factory.inflate(android.R.layout.preference_category, null);
            } else {
                item = (TextView) convertView;
            }
            item.setText(mDateSorter.getLabel(
                    mItemMap[position] + DateSorter.DAY_COUNT));
            return item;
        }

        public boolean areAllItemsEnabled() {
            return true /*false*/ ;
        }

        public boolean isEnabled(int position) {
            return mItemMap[position] >= 0;
        }

        public int getCount() {
            return mItemMap.length;
        }

        public Object getItem(int position) {
            return null;
        }

        public long getItemId(int position) {
            return mItemMap[position];
        }

        // 0 for TextView, 1 for HistoryItem
        public int getItemViewType(int position) {
            if (mInDeleteView || ! mSortByDate)
                return 1;
            else
                return mItemMap[position] < 0 ? 0 : 1;
        }

        public int getViewTypeCount() {
            if (mInDeleteView || ! mSortByDate)
                return 1;
            else
                return 2;
        }

        public boolean hasStableIds() {
            return true;
        }

        public void registerDataSetObserver(DataSetObserver observer) {
            mObservers.add(observer);
        }

        public void unregisterDataSetObserver(DataSetObserver observer) {
            mObservers.remove(observer);
        }

        public boolean isEmpty() {
            //Log.i("BrowserHistory", "isEmpty,mInDeleteView="+mInDeleteView+", mSortByDate="+mSortByDate+", getCount()="+getCount());
            if (mInDeleteView || ! mSortByDate)
                return getCount() == 0;
            else
                return getCount() == 1;
        }
    }
}
