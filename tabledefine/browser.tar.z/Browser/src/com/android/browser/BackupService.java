package com.android.browser;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Reader;

import oms.android.backup.BackupResult;
import oms.android.backup.BaseBackupService;
import oms.android.backup.RestoreResult;

import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVStrategy;

import android.content.ContentValues;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import android.provider.Browser;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

public class BackupService extends BaseBackupService {
	private static final String TAG = "BrowserBackup";
	private final String FILE_BOOKMARK_CSV = "bookmark.csv";
    private final String FILE_CATEGORY_CSV = "category.csv";
    private final String FILE_SETTING_CSV = "setting.csv";

	private static final Uri BOOKMARKS_URI = android.provider.Browser.BOOKMARKS_URI;
    private static final Uri CATEGORY_URI = android.provider.Browser.CATEGORY_URI;

	private static final String[] mBookmarkHeaders = {
	/*
	 * title|url|visits|date|created|description|bookmark|favicon|catid
	 */
	"title", "url", "visits", "date", "created", "description", "bookmark",
			"favicon", "catid" };

    private static final String[] mCategoryHeaders = {"_id", "name"};

    private static final String[] mSettingHeaders = {
        "search_portal", "remember_passwords", "default_text_encoding", 
        "enable_javascript", "homepage", "save_formdata", "load_images", 
        "data_connection", "text_size", "show_security_warnings", 
        "accept_cookies", "login_initialized", "block_popup_windows",
        "download_dir", "fit_screen_width", "browser_download_audiovideo", 
        "default_zoom"};

	@Override
	public void backup(Bundle extra) {
		BackupResult result = new BackupResult();

		Cursor mCursor = getContentResolver().query(BOOKMARKS_URI, null, null,
				null, null);

		try {
			OutputStream fWriter = openBackupFile(FILE_BOOKMARK_CSV);
			CSVPrinter csvPrinter = new CSVPrinter(fWriter);
			csvPrinter.setStrategy(CSVStrategy.EXCEL_STRATEGY);
			// write headers
			csvPrinter.println(mBookmarkHeaders);

			if (mCursor != null && mCursor.moveToFirst()) {
				int count = mCursor.getCount();
				msgPrepareBackup(count);
				for (int i = 0; i < count; i++, mCursor.moveToNext()) {
					if(isCanceledBackup()){
						break;
					}

					String title = mCursor.getString(mCursor
							.getColumnIndexOrThrow(mBookmarkHeaders[0]));
					if (title == null) {
						title = "";
					}
					String url = mCursor.getString(mCursor
							.getColumnIndexOrThrow(mBookmarkHeaders[1]));
					if (url == null) {
						url = "";
					}
					String description = mCursor.getString(mCursor
							.getColumnIndexOrThrow(mBookmarkHeaders[5]));
					if (description == null) {
						description = "";
					}
					byte[] byte1 = mCursor.getBlob(mCursor
							.getColumnIndexOrThrow(mBookmarkHeaders[7]));
					String favicon = "";
					if (byte1 != null) {
						favicon = byte1.toString();
					}
					if (favicon == null) {
						favicon = "";
					}
					String[] values = {
							title,
							url,
							""
									+ mCursor
											.getInt(mCursor
													.getColumnIndexOrThrow(mBookmarkHeaders[2])),
							""
									+ mCursor
											.getLong(mCursor
													.getColumnIndexOrThrow(mBookmarkHeaders[3])),
							""
									+ mCursor
											.getLong(mCursor
													.getColumnIndexOrThrow(mBookmarkHeaders[4])),
							description,
							""
									+ mCursor
											.getInt(mCursor
													.getColumnIndexOrThrow(mBookmarkHeaders[6])),
							favicon,
							""
									+ mCursor
											.getInt(mCursor
													.getColumnIndexOrThrow(mBookmarkHeaders[8])), };
					csvPrinter.println(values);
					msgProcessingBackup(i + 1);
				}
			}
			fWriter.flush();
			fWriter.close();
			result.result = RESULT_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			result.result = RESULT_ERROR;
		}finally{
			if(mCursor != null){
				mCursor.close();
			}
		}

        mCursor = getContentResolver().query(CATEGORY_URI, null, null,
				null, null);
        try {
            OutputStream fWriter = openBackupFile(FILE_CATEGORY_CSV);
            CSVPrinter csvPrinter = new CSVPrinter(fWriter);
            csvPrinter.setStrategy(CSVStrategy.EXCEL_STRATEGY);
			// write headers
			csvPrinter.println(mCategoryHeaders);
            if (mCursor != null && mCursor.moveToFirst()) {
                int count = mCursor.getCount();
				msgPrepareBackup(count);

                for (int i = 0; i < count; i++, mCursor.moveToNext()) {
                    if(isCanceledBackup()){
                        break;
                    }
                    String[] values = {
                        "" + mCursor.getInt(mCursor.getColumnIndexOrThrow(mCategoryHeaders[0])),
                        "" + mCursor.getString(mCursor.getColumnIndexOrThrow(mCategoryHeaders[1]))
                    };
                    csvPrinter.println(values);
                    msgProcessingBackup(i + 1);
                }
            }
            fWriter.flush(); 
            fWriter.close();
            result.result = RESULT_SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            result.result = RESULT_ERROR;
        } finally {
            if(mCursor != null) {
                mCursor.close();
            }
        }

        // OMS: backup Browser settings
        try {
            OutputStream fWriter = openBackupFile(FILE_SETTING_CSV);
            CSVPrinter csvPrinter = new CSVPrinter(fWriter);
            csvPrinter.setStrategy(CSVStrategy.EXCEL_STRATEGY);
            // write header
            csvPrinter.println(mSettingHeaders);

            SharedPreferences p = 
                PreferenceManager.getDefaultSharedPreferences(this);

            // OMS: for homepge, we read it from BrowserProperty. So that we can always
            // get correct value. 
            String values[] = {
                p.getString(mSettingHeaders[0], "1"),
                p.getBoolean(mSettingHeaders[1], true) ? "true" : "false",
                p.getString(mSettingHeaders[2], "AUTOSELECT"),
                p.getBoolean(mSettingHeaders[3], true) ? "true" : "false",
                p.getString(mSettingHeaders[4], 
                    Browser.getBrowserProperty(getContentResolver(), Browser.PROP_HOMEPAGE)),
                p.getBoolean(mSettingHeaders[5], true) ? "true" : "false",
                p.getBoolean(mSettingHeaders[6], true) ? "true" : "false",
                p.getString(mSettingHeaders[7], 
                    Browser.getBrowserProperty(getContentResolver(), Browser.PROP_DATA_CONNECTION)),
                p.getString(mSettingHeaders[8], "NORMAL"),
                p.getBoolean(mSettingHeaders[9], true) ? "true" : "false",
                p.getBoolean(mSettingHeaders[10], true) ? "true" : "false",
                p.getBoolean(mSettingHeaders[11], true) ? "true" : "false",
                p.getBoolean(mSettingHeaders[12], true) ? "true" : "false",
                p.getString(mSettingHeaders[13], "/sdcard/download"),
                p.getBoolean(mSettingHeaders[14], false) ? "true" : "false",
                p.getBoolean(mSettingHeaders[15], true) ? "true" : "false",
                p.getString(mSettingHeaders[16], "MEDIUM")
            };
            csvPrinter.println(values);
            for (int i=0; i<values.length; i++) {
                Log.d(TAG, "setting backup: "+i+" - "+values[i]);
            }
            fWriter.flush();
            fWriter.close();
            result.result = RESULT_SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            result.result = RESULT_ERROR;
        }

		msgBackupEnd(result);
	}

	@Override
	public void restore(Bundle extra) {
		RestoreResult result = new RestoreResult();

		getContentResolver().delete(BOOKMARKS_URI, null, null);
        getContentResolver().delete(CATEGORY_URI, null, null);

		int n = 0;
		try {
			Reader fReader = openRestoreFileReader(FILE_BOOKMARK_CSV);
			CSVStrategy strategy = new CSVStrategy(',', '"',
					CSVStrategy.COMMENTS_DISABLED, '\\', false, false, false,
					false);
			CSVParser csvParser = new CSVParser(fReader, strategy);
			// Skip the title line
			csvParser.getLine();

			while (true) {
				String[] value = csvParser.getLine();
				if (value == null) {
					break;
				}
				if (value.length == mBookmarkHeaders.length) {
					n++;
					/*
					 * "title TEXT," + "url TEXT," + "visits INTEGER," +
					 * "date LONG," + "created LONG," + "description TEXT," +
					 * "bookmark INTEGER," + "favicon BLOB DEFAULT NULL," +
					 * "catid INTEGER DEFAULT 1" + ");");
					 */
					String title = value[0];
					String url = value[1];
					String visits = value[2];
					String date = value[3];
					String created = value[4];
					String description = value[5];
					String bookmark = value[6];
					String favicon = value[7];
					String catid = value[8];
					Log.d(TAG, "title: " + title);
					Log.d(TAG, "url: " + url);
					Log.d(TAG, "visits: " + visits);
					Log.d(TAG, "date: " + date);
					Log.d(TAG, "created: " + created);
					Log.d(TAG, "description: " + description);
					Log.d(TAG, "bookmark: " + bookmark);
					Log.d(TAG, "favicon: " + favicon);
					Log.d(TAG, "catid: " + catid);

					ContentValues cv = new ContentValues();
					cv.put(mBookmarkHeaders[0], title);
					cv.put(mBookmarkHeaders[1], url);
					cv.put(mBookmarkHeaders[2], Integer.valueOf(visits));
					cv.put(mBookmarkHeaders[3], Long.valueOf(date));
					cv.put(mBookmarkHeaders[4], Long.valueOf(created));
					cv.put(mBookmarkHeaders[5], description);
					cv.put(mBookmarkHeaders[6], Integer.valueOf(bookmark));
					cv.put(mBookmarkHeaders[7], favicon);
					cv.put(mBookmarkHeaders[8], Integer.valueOf(catid));
					Uri _uri = getContentResolver().insert(BOOKMARKS_URI, cv);
					Log.i(TAG, "insert bookmark " + _uri + " into DB");
					msgProcessingRestore(n);
				}
			}
			fReader.close();
			result.result = RESULT_SUCCESS;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			result.result = RESULT_ERROR;
		} catch (IOException e) {
			e.printStackTrace();
			result.result = RESULT_ERROR;
		}

        n=0;
        try {
            Reader fReader = openRestoreFileReader(FILE_CATEGORY_CSV);
            CSVStrategy strategy = new CSVStrategy(',', '"',
                CSVStrategy.COMMENTS_DISABLED, '\\', false, false, false,
                false);
            CSVParser csvParser = new CSVParser(fReader, strategy);
            csvParser.getLine();

            while (true) {
                String[] value = csvParser.getLine();
                if (value == null) {
                    break;
                }
                if (value.length == mCategoryHeaders.length) {
                    n++;
                    ContentValues cv = new ContentValues();
                    cv.put(mCategoryHeaders[0], value[0]);
                    cv.put(mCategoryHeaders[1], value[1]);
                    Log.d(TAG, "_id: " + value[0]);
                    Log.d(TAG, "name: " + value[1]);
                    Uri _uri = getContentResolver().insert(CATEGORY_URI, cv);
                    Log.d(TAG, "insert category " + _uri + " into DB");
                    msgProcessingRestore(n);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            result.result = RESULT_ERROR;
        } catch (IOException e) {
            e.printStackTrace();
            result.result = RESULT_ERROR;
        }

        // restore Browser setting
        Editor ed = null;
        try {
            Reader fReader = openRestoreFileReader(FILE_SETTING_CSV);
            CSVStrategy strategy = new CSVStrategy(',', '"',
                CSVStrategy.COMMENTS_DISABLED, '\\', false, false, false,
                false);
            CSVParser csvParser = new CSVParser(fReader, strategy);
            csvParser.getLine(); // first line is headers.

            // second line is setting
            String[] value = csvParser.getLine();
            if (value != null) {
                Boolean b;
                ed= PreferenceManager.getDefaultSharedPreferences(this).edit();      

                ed.putString(mSettingHeaders[0], value[0]);

                if (value[1].equals("true")) b = true;
                else b = false;
                ed.putBoolean(mSettingHeaders[1], b);

                ed.putString(mSettingHeaders[2], value[2]);

                if (value[3].equals("true")) b = true;
                else b = false;
                ed.putBoolean(mSettingHeaders[3], b);

                ed.putString(mSettingHeaders[4], value[4]);
                // OMS: since we support DM_SERVICE, we also need to update homepage 
                // and data connection intto db properties.
                if (BrowserSettings.DM_ENABLED) {
                    // homepage
                    Browser.setBrowserProperty(getContentResolver(), 
                        Browser.PROP_HOMEPAGE, value[4]);
                }

                if (value[5].equals("true")) b = true;
                else b = false;
                ed.putBoolean(mSettingHeaders[5], b);
                
                if (value[6].equals("true")) b = true;
                else b = false;
                ed.putBoolean(mSettingHeaders[6], b);

                ed.putString(mSettingHeaders[7], value[7]);
                if (BrowserSettings.DM_ENABLED) {
                    // data connection
                    Browser.setBrowserProperty(getContentResolver(), 
                        Browser.PROP_DATA_CONNECTION, value[7]);
                }
                
                ed.putString(mSettingHeaders[8], value[8]);

                if (value[9].equals("true")) b = true;
                else b = false;
                ed.putBoolean(mSettingHeaders[9], b);

                if (value[10].equals("true")) b = true;
                else b = false;
                ed.putBoolean(mSettingHeaders[10], b);

                if (value[11].equals("true")) b = true;
                else b = false;
                ed.putBoolean(mSettingHeaders[11], b);

                if (value[12].equals("true")) b = true;
                else b = false;
                ed.putBoolean(mSettingHeaders[12], b);

                ed.putString(mSettingHeaders[13], value[13]);

                if (value[14].equals("true")) b = true;
                else b = false;
                ed.putBoolean(mSettingHeaders[14], b);

                if (value[15].equals("true")) b = true;
                else b = false;
                ed.putBoolean(mSettingHeaders[15], b);

                ed.putString(mSettingHeaders[16], value[16]);
                
                ed.commit();
            }
        } catch (FileNotFoundException e) {
            // OMS: If we cannot find find setting.csv, we just skip restore browser settings            
            Log.e(TAG, "Cannot find setting.csv, skip restore settings");
        } catch (ArrayIndexOutOfBoundsException e) {
            // OMS: if backup fields is less than what we want to restore, just skip the missing fields. 
            Log.e(TAG, "Some fields are not fully restored.");
            if (null != ed) ed.commit();
        } catch (Exception e) {
            e.printStackTrace();
            result.result = RESULT_ERROR;
        }
        
		msgRestoreEnd(result);
	}

}
