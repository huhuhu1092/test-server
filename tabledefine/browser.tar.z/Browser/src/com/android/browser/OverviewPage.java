
package com.android.browser;

import android.webkit.WebView;
import android.content.Context;
import android.widget.ImageView;
import android.graphics.Rect;
import android.graphics.Paint;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.KeyEvent;

import android.util.Config;
import android.util.Log;

import junit.framework.Assert;

/**
 * View to navigate the whole page in thumbnail view. 
 */
class OverviewPage extends ImageView {

    private Bitmap mThumbnail = null;
    private Bitmap mBackupThumbnail = null;
    private WebView mWebView;
    private Rect mWinRect = null;
    private Rect mPageRect = null;
    private Paint mRectPaint;
    private float mScale;
    //private Canvas canvas;

    private static final int WIN_RECT_STROKE = 1;

    private final static String LOGTAG = "browser";

    //TODO: Tune the values for better user experience.
    private int RECT_MOVE_STRIDE_H = 20;  //in pixels
    private int RECT_MOVE_STRIDE_V = 30;  //in pixels
    private static final int DEFAULT_ALPHA = 0xF0;
    private static final int DEFAULT_BACKGROUND_COLOR = 0xAA444444;



    public OverviewPage (Context ctx, WebView view) {
        super(ctx);

        setFocusable(true);
        requestFocus();

        Assert.assertNotNull(view);
        mWebView = view;
        setBackgroundColor(DEFAULT_BACKGROUND_COLOR);

        int W = mWebView.getWidth() / 3 * 2;
        int H = mWebView.getHeight();
        int cw = mWebView.getContentWidth();
        int ch = mWebView.getContentHeight();
        if(cw <= 0 || ch <= 0) {
            return;
        }

        mScale = Math.min((float)W / cw, (float)H / ch);

        if(Config.LOGV) {
            Log.v(LOGTAG, "OverviewPage:" + mWebView.getWidth() + 
                    "/" + mWebView.getHeight() + " scale: " + 
                    mScale + " W/H:" + W + "/" + H + " focused: " + 
                    isFocused());
        }

        // Don't leave white spaces around
        W = W > Math.round((float)cw * mScale) ? 
                Math.round((float)cw * mScale) : W;
        H = H > Math.round((float)ch * mScale) ? 
                Math.round((float)ch * mScale) : H;

        mThumbnail = mWebView.createOverview(W, H, mScale);
        if(mThumbnail == null) {
            //Assert.assertNotNull(mThumbnail);
            return;
        }

        setImageBitmap(mThumbnail);
        setScaleType(ImageView.ScaleType.CENTER);

        // Setup the paint to draw the window rect (for later use).
        //canvas = new Canvas(mThumbnail);
        mRectPaint = new Paint();
        mRectPaint.setAntiAlias(true);
        mRectPaint.setStyle(Paint.Style.STROKE);
        mRectPaint.setStrokeWidth(WIN_RECT_STROKE);
        mRectPaint.setColor(0xFFFF0000);//RED

        // We preserve a backup for later use (to erase the rect).
        mBackupThumbnail = mThumbnail.copy(Bitmap.Config.RGB_565, false);
        Assert.assertNotNull(mBackupThumbnail);

        // Useful if we want the overview bitmap has alpha.
        //setAlpha(DEFAULT_ALPHA);
        invalidate();

        // Draw the rect.
        int x = Math.round(mWebView.getScrollX()*mScale);
        int y = Math.round(mWebView.getScrollY()*mScale);
        mWinRect = new Rect(x, y, 
                x + Math.round(mWebView.getWidth()*mScale), 
                y + Math.round(mWebView.getHeight()*mScale));
        mPageRect = new Rect(0, 0, 
                Math.round(mWebView.getContentWidth()*mScale), 
                Math.round(mWebView.getContentHeight()*mScale));
        if(mWinRect.bottom > mPageRect.bottom)
            mWinRect.bottom = mPageRect.bottom;
        if(mWinRect.right > mPageRect.right)
            mWinRect.right = mPageRect.right;
        drawSimulateRect();

        // Setup the stride we use to move on arrow keys (for later use).
        RECT_MOVE_STRIDE_H = mWinRect.width() / 4;
        RECT_MOVE_STRIDE_V = mWinRect.height() / 4;

        if(Config.LOGV) {
            Log.v(LOGTAG, "* OverviewPage() created: " + mWinRect.right + 
                    "/" + mWinRect.bottom + " page: " +
                     mPageRect.right + "/" + mPageRect.bottom);
        }
    }

    // Listener to be notified by behavior of OverviewPage.
    public interface OverviewListener {
        //Called when user clicks to view the selected rect.
        public void onClick(int x, int y);
    }

    private OverviewListener mListener = null;

    public void setListener(OverviewListener l) {
        mListener = l;
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        //Log.e(LOGTAG, "OverviewPage: onKeyUp()");
        return false;
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        //Log.e(LOGTAG, "OverviewPage: onKeyDown()");

        if(mWinRect == null || mPageRect == null || 
                mThumbnail == null) {
            return false;
        }

        switch( keyCode ) {
            case KeyEvent.KEYCODE_DPAD_UP:
                moveRectBy(0, -RECT_MOVE_STRIDE_V);
                return true;

            case KeyEvent.KEYCODE_DPAD_DOWN:
                moveRectBy(0, RECT_MOVE_STRIDE_V);
                return true;

            case KeyEvent.KEYCODE_DPAD_LEFT:
                moveRectBy(-RECT_MOVE_STRIDE_H, 0);
                return true;

            case KeyEvent.KEYCODE_DPAD_RIGHT:
                moveRectBy(RECT_MOVE_STRIDE_H, 0);
                return true;

            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if(mListener != null) {
                    mScale = (mScale == 0) ? 1 : mScale;
                    mListener.onClick(Math.round((float)mWinRect.left/mScale), 
                            Math.round((float)mWinRect.top/mScale));
                }
                return true;
            default:
                break;
        }

        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if(mWinRect == null || mPageRect == null || 
                mThumbnail == null) {
            return false;
        }

        //translate the coors from screen to view. (Somewhat ugly...)
        float x = ev.getX() - (this.getWidth() - mThumbnail.getWidth())/2;
        float y = ev.getY() - (this.getHeight() - mThumbnail.getHeight())/2;

        //Log.v(LOGTAG, "OverviewPage: onTouchEvent() " + ev.getX() + 
        //        "/" + ev.getY() + " -> " + x + "/" + y);

        if(mWinRect.width()<=0 || mWinRect.height()<=0) {
            Assert.assertTrue(mWinRect.width()>0);
            Assert.assertTrue(mWinRect.height()>0);
            return true;
        }

        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN: 
                int dx = (int)x - mWinRect.width()/2 - mWinRect.left;
                int dy = (int)y - mWinRect.height()/2 - mWinRect.top;
                moveRectBy(dx, dy);
                break;

            case MotionEvent.ACTION_MOVE:
                dx = (int)x - mWinRect.width()/2 - mWinRect.left;
                dy = (int)y - mWinRect.height()/2 - mWinRect.top;
                moveRectBy(dx, dy);
                break;

            case MotionEvent.ACTION_UP:
                // Move to destination right after motion up.
                if(mListener != null) {
                    mScale = (mScale == 0) ? 1 : mScale;
                    mListener.onClick(
                            Math.round((float)mWinRect.left/mScale), 
                            Math.round((float)mWinRect.top/mScale));
                }
                break;

            default:
                break;
        }
        return true;
    }

    // Deprecated. This will lead to stack overflow.
    private void update() {
        mThumbnail = mBackupThumbnail.copy(Bitmap.Config.RGB_565, true);

        setImageBitmap(mThumbnail);
        drawSimulateRect();
        // For debug only
        //report();
    }

    // Move the rect by a delta coors.
    private boolean moveRectBy(int x, int y) {
        int dx = x; 
        int dy = y;

        if(Config.LOGV) {
            Log.v(LOGTAG, "*** moveRectBy(" + x + "," + y + 
                    ") origin coor: " + mWinRect.left + "/" + mWinRect.top + 
                    " page: " + mPageRect.left + "/" + mPageRect.top);
        }

        //make sure we won't move the mWinRect out of the bounds.
        if(mWinRect.left + x < 0)
            dx = - mWinRect.left;
        else if(mWinRect.right + x >= mPageRect.right)
            dx = mPageRect.right - mWinRect.right;

        if(mWinRect.top + y < 0)
            dy = - mWinRect.top;
        else if(mWinRect.bottom + y >= mPageRect.bottom)
            dy = mPageRect.bottom - mWinRect.bottom;

        if(Config.LOGV) {
            Log.v(LOGTAG, "*** moveRectBy() win size: " + mWinRect.width() + 
                    "/" + mWinRect.height() + "  delta: " + dx + "/" + dy + 
                    " page: " + mPageRect.right + "/" + mPageRect.bottom);
        }

        if(dx == 0 && dy == 0) {
            return false;
        }

        // Make sure the old rect is erased clearly.
        int H = mWinRect.height() + 2;
        int W = mThumbnail.getWidth();
        int oldPixels[] = new int[H * W];

        int startX = mWinRect.left - 1;
        int startY = mWinRect.top - 1;
        int height = mWinRect.height() + 2;
        int width = mWinRect.width() + 2;
        if(mWinRect.left == 0) {
            startX = 0;
            width -= 1;
        }
        if(mWinRect.right == mBackupThumbnail.getWidth()) {
            width -= 1;
        }
        if(mWinRect.top == 0) {
            startY = 0;
            height -= 1;
        }
        if(mWinRect.bottom == mBackupThumbnail.getHeight()) {
            height -= 1;
        }

        // Make sure we won't do anything wrong...
        if(startX < 0 || startY < 0 ||
                startX + width > mBackupThumbnail.getWidth() || 
                startY + height > mBackupThumbnail.getHeight()) {
            return false;
        }

        try{
            mBackupThumbnail.getPixels(oldPixels, 0, mBackupThumbnail.getWidth(), 
                        startX, startY, width, height);

            mThumbnail.setPixels(oldPixels, 0, mBackupThumbnail.getWidth(), 
                        startX, startY, width, height);
        }catch(Exception e) {
            e.printStackTrace();
            return false;
        }

        // Useful if we want the bitmap has alpha.
        //setAlpha(DEFAULT_ALPHA);
        invalidate();

        mWinRect.offset(dx, dy);
        drawSimulateRect();

        //debug only!
        //report();

        return true;
    }

    private void drawSimulateRect() {
        if(mWinRect == null) {
            return;
        }

        Canvas canvas = new Canvas(mThumbnail);
        canvas.drawRect(mWinRect, mRectPaint);
     }

    //TODO: for debug only. remove this before ship.
    public void report() {
        Log.e(LOGTAG, "*** OverviewPage report ***");
        Log.e(LOGTAG, "My view focus: " + this.isFocused());
        Log.e(LOGTAG, "Overview: (" + mThumbnail.getWidth() + ", " + 
                mThumbnail.getHeight() + ")");
        Log.e(LOGTAG, "Rect: (" + mWinRect.left + ", " + mWinRect.top + 
                ", " + mWinRect.right + ", " + mWinRect.bottom + ")");
        Log.e(LOGTAG, "PageRect: (" + mPageRect.left + ", " + 
                mPageRect.top + ", " + mPageRect.right + ", " + 
                mPageRect.bottom + ")");
    }

}
