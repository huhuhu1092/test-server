package com.android.browser;

import android.widget.AdapterView;
import android.widget.Adapter;
import android.view.View;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.FrameLayout;

public interface BrowserTabView {
    public static final int CANCEL  = -99;
    public static final int NEW_TAB = -1;
    public static final int TAB_GALLERY_MODE = 1;
    public static final int TAB_GIRD_MODE = 2;
    public static final int TAB_GALLERY_LAND_MODE = 3;
    public static final int TAB_GIRD_LAND_MODE = 4;
    public static final String TAB_PREFERENCE_STR_KEY = "pre_tab_mod";
    public void add(TabControl.Tab t);
 
    public void remove(int index);

    public void setCurrentIndex(int startingIndex);
    public int getCurrentIndex();
    
    public BrowserTabViewListener getListener();

    public void setListener(BrowserTabViewListener l);

    /**
     * Return true if the ImageGrid is live. This means that tabs can be chosen
     * and the menu can be invoked.
     */
    public boolean isLive();

    /**
     * Do some internal cleanup of the ImageGrid's adapter.
     */
    public void clear();
    public void onItemClick(AdapterView parent, View v, int position, long id);

    // convert a context menu position to an actual tab position. Since context
    // menus are not created for the "New Tab" cell, this will always return a
    // valid tab position.
    public int getContextMenuPosition(MenuItem menu);

    public Adapter getAdapter();

    public View getChildAt(int index);
    public void startAnimation(Animation animation);
    public int getFirstVisiblePosition();
    public boolean requestFocus();
    public FrameLayout.LayoutParams getLayoutParams();
    public void updateNewTabBtn();
    public void setPageTextView(int pos);
    public void removeChildViews();
    public void onConfigrationChanged();
    public void initButtons();
    public boolean isInMoving();
}



