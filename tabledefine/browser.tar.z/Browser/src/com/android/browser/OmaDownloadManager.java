/*
 * Copyright (C) 2006-2008 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.ContentValues;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Downloads;
import android.util.Log;
import android.util.Config;
import android.view.View;
import android.view.LayoutInflater;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.widget.TextView;
import android.media.MediaFile;
import android.text.format.Formatter;
import android.drm.mobile1.DrmRawContent;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.FileInputStream;
import java.util.HashMap;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

/**
 * Download-manager implementation according to the:
 * "Generic Content Download Over The Air Specification", version 1.0.
 */
public class OmaDownloadManager extends Activity {
    static final String FILE_BASE = "file://";

    // activity state attribute keys
    static final String KEY_DESCRIPTOR_URI = "descriptor-uri";
    static final String KEY_MEDIA_OBJECT_URI = "media-object-uri";

    // descriptor attributes
    static final String ATTRIBUTE_TYPE = "type";
    static final String ATTRIBUTE_SIZE = "size";
    static final String ATTRIBUTE_OBJECT_URI = "objectURI";
    static final String ATTRIBUTE_INSTALL_NOTIFY_URI = "installNotifyURI";
    static final String ATTRIBUTE_NEXT_URL = "nextURL";
    static final String ATTRIBUTE_DD_VERSION = "DDVersion";
    static final String ATTRIBUTE_NAME = "name";
    static final String ATTRIBUTE_DESCRIPTION = "description";
    static final String ATTRIBUTE_VENDOR = "vendor";
    static final String ATTRIBUTE_INFO_URL = "infoURL";
    static final String ATTRIBUTE_ICON_URI = "iconURI";
    static final String ATTRIBUTE_INSTALL_PARAM = "installParam";

    // status/error message codes
    static final int STATUS_SUCCESS = 900;
    static final int STATUS_INSUFFICIENT_MEMORY = 901;
    static final int STATUS_USER_CANCELLED = 902;
    static final int STATUS_LOSS_OF_SERVICE = 903;
    static final int STATUS_ATTRIBUTE_MISMATCH = 905;
    static final int STATUS_INVALID_DECRIPTOR = 906;
    static final int STATUS_INVALID_DDVERSION = 951;
    static final int STATUS_DEVICE_ABORTED = 952;
    static final int STATUS_NONACCEPTABLE_CONTENT = 953;
    static final int STATUS_LOADER_ERROR = 954;

    // notification status, success by default, but can be changed to an error:
    private int mStatus = STATUS_SUCCESS;

    // download-descriptor URI (once it has been downloaded):
    private String mDescriptorUri;

    // the list of MIME media types of the media object:
    private String[] mTypeList;

    // the highest-priority supported MIME media type:
    private String mType;

    // the number of bytes to be downloaded from the media-object URI:
    private long mSize;

    // the URI (usually URL) from which the media object can be downloaded:
    private String mObjectUri;

    // the URI of the media object on the device once it has been downloaded:
    private Uri mContentUri;

    // the URI (usually URL) to which an installation report is to be sent:
    private String mInstallNotifyUri;

    // the URL to which the client should navigate later if the user chooses so:
    private String mNextUrl;

    // the version of the download descriptor technology (1.0 is the default):
    private String mVersion;

    // a user-readable name of the media object that identifies the object:
    private String mName;

    // a short textual description of the media object:
    private String mDescription;

    // the organization that provides the media object:
    private String mVendor;

    // A URL for further describing the media object:
    private String mInfoUrl;

    // The URI of an icon:
    private String mIconUri;

    // An installation parameter associated with the downloaded media object:
    private String mInstallParam;

    // OMS: Network params.
    static String mUserAgent;
    static String mProxy;
    static int mPort = 0;

    // OMS: Hash map from Cid to String array of Filename and Mimetype
    public static HashMap<String, String[]> mDrmCidMap = new HashMap<String, String[]>();


    /**
     * Helper class to assist with logging
     */
    static private class OmaLog {
        private static final String LOGTAG = "oma";

        private static final boolean DEBUG = true;
        public static final boolean LOGV = DEBUG ? Config.LOGD : Config.LOGV;

        public static void v(String logMe) {
            Log.v(LOGTAG, logMe);
        }

        public static void e(String logMe) {
            Log.e(LOGTAG, logMe);
        }
    }

    /**
     * Called when this activity is created
     *
     * @param icicle - The bundle of data with the saved activity state (if any)
     */
    @Override public void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        mDescriptorUri =
            icicle != null ? icicle.getString(KEY_DESCRIPTOR_URI) : null;
        if (mDescriptorUri == null) {
            final Intent intent = getIntent();
            if (intent.getAction() != null) {
                if (intent.getAction().equals(intent.ACTION_VIEW)) {
                    mDescriptorUri = intent.getData().toString();
                }
            }
        }

        mContentUri = (Uri)(getIntent().getExtra("contenturi"));

        if (!parseDescriptor()) {
            error(STATUS_INVALID_DECRIPTOR);
        } else {
            if (checkValidVersion() && checkEnoughMemory() && checkContentTypes()) {
                displayInfoToUser();
            }
        }
    }

    /**
     * Called before this activity is suspended
     *
     * @param outState - The bundle of data used to save the activity state (if any)
     */
    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString(KEY_DESCRIPTOR_URI, mDescriptorUri);
    }

    /**
     * Parses the download descriptor.
     *
     * @return True iff succeeds to parse the descriptor.
     */
    private boolean parseDescriptor() {
        if (mDescriptorUri == null || !URLUtil.isFileUrl(mDescriptorUri)) {
            return false;
        }

        String path = URLUtil.stripAnchor(
            mDescriptorUri.substring(FILE_BASE.length()));
        if (path == null || path.length() == 0) {
            return false;
        }

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder docBuilder = factory.newDocumentBuilder();
            Document doc = docBuilder.parse(new File(path));
            if (doc == null) {
                return false;
            }

            mTypeList = getStringListAttribute(doc, ATTRIBUTE_TYPE);
            mSize = getLongAttribute(doc, ATTRIBUTE_SIZE);
            mObjectUri = getStringAttribute(doc, ATTRIBUTE_OBJECT_URI);

            if (mTypeList == null || mSize <= 0 || mObjectUri.length() == 0) {
                // type, size, and object-uri are required attributes!
                return false;
            }

            mInstallNotifyUri = getStringAttribute(doc, ATTRIBUTE_INSTALL_NOTIFY_URI);
            mNextUrl = getStringAttribute(doc, ATTRIBUTE_NEXT_URL);

            mVersion = getStringAttribute(doc, ATTRIBUTE_DD_VERSION);
            if (mVersion.length() == 0) {
                mVersion = "1.0";
            }

            mName = getStringAttribute(doc, ATTRIBUTE_NAME);
            if (mName.length() == 0) {
                //mName = mObjectUri;
                mName = "Unknow";
            }

            mDescription = getStringAttribute(doc, ATTRIBUTE_DESCRIPTION);
            mVendor = getStringAttribute(doc, ATTRIBUTE_VENDOR);
            mInfoUrl = getStringAttribute(doc, ATTRIBUTE_INFO_URL);
            mIconUri = getStringAttribute(doc, ATTRIBUTE_ICON_URI);
            mInstallParam = getStringAttribute(doc, ATTRIBUTE_INSTALL_PARAM);
        } catch (ParserConfigurationException e) {
            OmaLog.v("parseDescriptor(): exception: " + e.toString());
            return false;
        } catch (IOException e) {
            OmaLog.v("parseDescriptor(): exception: " + e.toString());
            return false;
        } catch (SAXException e) {
            OmaLog.v("parseDescriptor(): exception: " + e.toString());
            return false;
        }

        return true;
    }

    /**
     * @param doc The XML document object
     * @param attribute The attribute to search for
     *
     * @return The list of string attribute values in the document
     * or null if no values can be found
     */
    private static String[] getStringListAttribute(Document doc, String attribute) {
        if (doc == null || attribute == null || attribute.length() == 0) {
            return null;
        }

        NodeList nodes = doc.getElementsByTagName(attribute);
        int nodesNum = nodes.getLength();
        if (nodesNum <= 0) {
            return null;
        }

        ArrayList<String> attributeList = new ArrayList<String>();

        for (int i = 0; i < nodesNum; ++i) {
            // text content could be split over multiple child nodes!
            StringBuilder sb = new StringBuilder();

            NodeList children = nodes.item(i).getChildNodes();
            int childNum = children.getLength();
            for (int j = 0; j < childNum; j++) {
                Node n = children.item(j);
                if (n.getNodeType() == Node.TEXT_NODE) {
                    sb.append(n.getNodeValue());
                }
            }

            String stringAttribute = sb.toString().trim();
            if (attribute.length() != 0) {
                attributeList.add(stringAttribute);
            }
        }

        String[] rval = null;

        int attributeNum = attributeList.size();
        if (0 < attributeNum) {
            rval = new String [attributeNum];
            for (int i = 0; i < attributeNum; ++i) {
                rval[i] = attributeList.get(i);
            }
        }

        return rval;
    }

    /**
     * @param doc The XML document object
     * @param attribute The attribute to search for
     *
     * @return The first occurance of the long attribute value in the
     * document or 0 if no values can be found
     */
    private static long getLongAttribute(Document doc, String attribute) {
        long rval = 0;

        String toParse = getStringAttribute(doc, attribute);
        if (toParse != null) {
            try {
                rval = Long.parseLong(toParse);
            } catch (NumberFormatException e) {
                // do nothing, just return 0.
            }
        }

        return rval;
    }

    /**
     * @param doc The XML document object
     * @param attribute The attribute to search for
     *
     * @return The first occurance of the string attribute value in the
     * document or an empry string if no values can be found
     */
    private static String getStringAttribute(Document doc, String attribute) {
        String rval = "";

        if (doc == null || attribute == null || attribute.length() == 0) {
            return rval;
        }

        NodeList nodes = doc.getElementsByTagName(attribute);
        if (nodes.getLength() > 0) {
            // text content could be split over multiple child nodes!
            StringBuilder sb = new StringBuilder();

            NodeList children = nodes.item(0).getChildNodes();
            int childNum = children.getLength();
            for (int j = 0; j < childNum; j++) {
                Node n = children.item(j);
                if (n.getNodeType() == Node.TEXT_NODE) {
                    sb.append(n.getNodeValue());
                }
            }

            rval = sb.toString().trim();
        }

        return rval;
    }

    /**
     * Checks if the download descriptor file version is supported. The
     * present implementation supports versions 1.X
     *
     * @return True iff the descriptor version is valid and supported
     */
    private boolean checkValidVersion() {
        // if no version number is specified, it is assumed to be 1.0
        boolean rval = (mVersion == null || mVersion.startsWith("1."));
        if (!rval) {
            error(STATUS_INVALID_DDVERSION);
        }

        return rval;
    }

    /**
     * Checks if there is enough memory on the SD card to download the
     * media object
     *
     * @return True iff there is enough memory to download the object
     */
    private boolean checkEnoughMemory() {
        boolean rval = false;

        String status = Environment.getExternalStorageState();
        if (status.equals(Environment.MEDIA_MOUNTED)) {
            try {
                File path = Environment.getExternalStorageDirectory();
                StatFs stat = new StatFs(path.getPath());

                long blockSize = stat.getBlockSize();
                long availableBlocks = stat.getAvailableBlocks();

                rval = (mSize <= availableBlocks * blockSize);

            } catch (IllegalArgumentException e) {}
        }

        if (!rval) {
            error(STATUS_INSUFFICIENT_MEMORY);
        }

        return rval;
    }

    /**
     * Checks if the media object mimetype is supported. If at least one
     * mimetype in the type list is not supported, displays a warning to
     * the user and let the user to cancel the download later
     *
     * @return True iff all types in the descriptor are supported
     */
    private boolean checkContentTypes() {
        boolean rval = true;

        mType = null;

        //Intent intent = new Intent(Intent.ACTION_VIEW);

        PackageManager pm = OmaDownloadManager.this.getPackageManager();
        for(int i = 0; i < mTypeList.length; ++i) {
            String mimeType = mTypeList[i];

            // retrieve a list of apps that support the mimetype
            /* Don't use pm.queryIntentActivities as Music requires a schema 
                filter.
            intent.setType(mimeType);
            List<ResolveInfo> list = pm.queryIntentActivities
                (intent, PackageManager.MATCH_DEFAULT_ONLY);
            if (list.size() == 0) {
                rval = false;
            */
            if(MediaFile.getFileTypeForMimeType(mimeType) == 0) {
                rval = false;
            } else {
                // first supported mimetype is the most important!
                if (mType == null) {
                    mType = mimeType;
                }
            }
        }

        if (mType == null) {
            // if none of the content types is supported, display an error
            error(STATUS_NONACCEPTABLE_CONTENT);
        } else {
            if (!rval) {
                // if at least one type is supported but not all, display a warning
                warning(
                    getText(R.string.oma_warning_one_or_more_types_not_supported),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            displayInfoToUser();
                        }
                    });
            }
        }

        return rval;
    }

    /**
     * Displays an error message to the user and exits this activity
     *
     * @param statusCode The oma-download status code (here, and error)
     */
    private void error(int statusCode) {
        // safeguard against error calling error (infinite recursion)!
        if (mStatus == STATUS_SUCCESS && statusCode != STATUS_SUCCESS) {
            mStatus = statusCode;
            error(this, statusCode, mInstallNotifyUri);
        }
    }

    /**
     * Displays a warning message to the user
     *
     * @param warningMessageText The text of the warning message
     * @param onAction The click listener to be notified should
     * the user choose to ignore the warning and proceed
     */
    private void warning(CharSequence warningMessageText,
                         DialogInterface.OnClickListener onAction) {
        if (warningMessageText != null && warningMessageText.length() != 0) {
            new AlertDialog.Builder(OmaDownloadManager.this)
                .setTitle(R.string.oma_label_download_error)
                .setIcon(com.android.internal.R.drawable.cmcc_dialog_question)
                .setMessage(warningMessageText)
                .setPositiveButton(R.string.oma_label_proceed, onAction)
                .setNegativeButton(
                    R.string.oma_label_exit,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            cancelOnUserRequest();
                        }
                    })
                .setCancelable(false)
                .show();
        }
    }

    /**
     * Cancels the download on user request.
     */
    public void cancelOnUserRequest() {
        String[] projection = { Downloads.COLUMN_STATUS, Downloads._DATA, 
                    Downloads.COLUMN_MIME_TYPE, Downloads.COLUMN_NOTIFICATION_EXTRAS,  
                    Downloads.COLUMN_USER_AGENT, Downloads.COLUMN_PROXY_HOST, Downloads.COLUMN_PROXY_PORT,
                    Downloads._ID };
        Cursor objectDownloadCursor;
        try {
            objectDownloadCursor = getContentResolver().query(
                mContentUri, projection, null, null, null);
        } catch (Exception e) {
            OmaLog.v("Exception during query");
            return;
        }

        if (null != objectDownloadCursor) {
            objectDownloadCursor.moveToFirst();
		}
		String filename = objectDownloadCursor.getString(objectDownloadCursor.getColumnIndexOrThrow(Downloads._DATA));
		try{
			if(mContentUri != null) {
                getContentResolver().delete(mContentUri, null, null);
            }
            File f = new File(filename);
            if (f.exists()) {
                OmaLog.v("mCancelOnMidletResponse onClick, will remove:"+filename);
                f.delete();        
            }
        }finally{}
        sendNotificationOnFailure(mStatus = STATUS_USER_CANCELLED);
    }

    /**
     * Displays basic information about the media object to be downloaded:
     * name, vendor, size, type, description
     */
    private void displayInfoToUser() {
        if (mStatus != STATUS_SUCCESS) {
            return;
        }

        final View view = LayoutInflater.from(OmaDownloadManager.this).inflate(
            R.layout.oma_download, null);

        TextView nameView = (TextView)view.findViewById(R.id.value_name_view);
        nameView.setText(mName);

        TextView vendorView =
            (TextView)view.findViewById(R.id.value_vendor_view);
        vendorView.setText(mVendor);

        TextView sizeView = (TextView)view.findViewById(R.id.value_size_view);
        sizeView.setText(Formatter.formatFileSize(this, mSize));

        TextView typeView = (TextView)view.findViewById(R.id.value_type_view);
        typeView.setText(mType);

        TextView descriptionView =
            (TextView)view.findViewById(R.id.value_description_view);
        descriptionView.setText(mDescription);

        new AlertDialog.Builder(OmaDownloadManager.this)
            .setTitle(R.string.oma_label_want_to_download)
            .setIcon(com.android.internal.R.drawable.cmcc_dialog_question)
            .setView(view)
            .setPositiveButton(R.string.oma_label_action,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            downloadMediaObject();
                        }
                    })
            .setNegativeButton(R.string.oma_label_cancel,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            cancelOnUserRequest();
                        }
                    })
             .setCancelable(false)
             .show();
    }

    /**
     * Requests the download manager to download the media object and
     * saves the oma-download state to a database to retrieve it once
     * the download is complete.
     * Calls finish() to exit the activity
     */
    private void downloadMediaObject() {
        String cookies = CookieManager.getInstance().getCookie(mObjectUri);

        String filename = URLUtil.guessFileName(mObjectUri,
                null, mType);

        // Try to get the file name from DD file.
        String hintFileName = null;
        if(mName != null && filename.indexOf(".") >= 0 && mName.indexOf(".") < 0) {
            hintFileName = mName + filename.substring(filename.indexOf("."));
        }else {
            hintFileName = filename;
        }

        ContentValues values = new ContentValues();
        values.put(Downloads.COLUMN_URI, mObjectUri);
        values.put(Downloads.COLUMN_COOKIE_DATA, cookies);
        values.put(Downloads.COLUMN_NOTIFICATION_PACKAGE, "com.android.browser");
        values.put(Downloads.COLUMN_NOTIFICATION_CLASS,
                   OmaDownloadManagerBroadcastReceiver.class.getName());
        values.put(Downloads.COLUMN_MIME_TYPE, mType);
        //values.put(Downloads.COLUMN_DESCRIPTION, mDescription);
        values.put(Downloads.COLUMN_TOTAL_BYTES, mSize);
        //values.put(Downloads.COLUMN_TITLE, mName);
        values.put(Downloads.COLUMN_FILE_NAME_HINT, hintFileName);
        values.put(Downloads.COLUMN_STOREPATH, BrowserSettings.getInstance().getStorePath());

        // OMS hack: put notifyUri here.
        if(mInstallNotifyUri != null) {
            values.put(Downloads.COLUMN_NOTIFICATION_EXTRAS, mInstallNotifyUri);
        }
//values.put(Downloads.COLUMN_NOTIFICATION_EXTRAS, "http://www.baidu.com");
        Log.d("oma", "mInstallNotifyUri=" + mInstallNotifyUri);

        // Don't forget to copy the network params to download the JAR file.
        final String[] projection = { Downloads._ID, 
                Downloads.COLUMN_NETWORK_INTERFACE, 
                Downloads.COLUMN_PROXY_HOST, Downloads.COLUMN_PROXY_PORT,
                Downloads.COLUMN_USER_AGENT };
        if(mContentUri != null) {
            Cursor c = getContentResolver().query(mContentUri, projection, null, null, null);
            if(c != null && c.moveToFirst()) {
                values.put(Downloads.COLUMN_NETWORK_INTERFACE, c.getString(1));
                values.put(Downloads.COLUMN_PROXY_HOST, c.getString(2));
                values.put(Downloads.COLUMN_PROXY_PORT, c.getString(3));
                values.put(Downloads.COLUMN_USER_AGENT, c.getString(4));
            }else {
                // Something wrong!
                Log.w("Oma", "No cursor found in db for jad file.");
            }
        }

        final Uri contentUri =
            getContentResolver().insert(Downloads.CONTENT_URI, values);
        if (contentUri != null) {
            //WebViewDatabase.getInstance(this).setOmaObjectDownloadState(
            //    contentUri.toString(), mInstallNotifyUri);
        }

        // OMS: Remove the DD file from DB and disk.
        removeDescription();

        finish();
    }

    private void removeDescription() {
        // OMS: Remove the mContentUri of the DD file.
        if(mContentUri != null) {
            try {
                getContentResolver().delete(mContentUri, null, null);
            }catch(Exception ee) {
            }
            mContentUri = null;
        }

        if(mDescriptorUri != null) {
            // TODO: Remove the file on SD card for now.
            try {
                String filePath = mDescriptorUri.replace("file://", "");
                File f = new File(filePath);
                if (f.exists()) {
                    f.delete();        
                }
            }catch(Exception ee) {
                Log.w("oms", "Failed to remove DD file:" + ee);
            }
            mDescriptorUri = null;
        }
    }

    /**
     * Sends an installation notification if installation was a failure.
     * Calls finish() to exit the activity
     *
     * @param statusCode The oma-download status code (here, an error)
     */
    void sendNotificationOnFailure(int statusCode) {
        OmaDownloadManager.sendNotificationOnFailure(
            this, mInstallNotifyUri, statusCode);

        finish();
    }

    static void viewDrmFileByCid(final Context context, final String cid) {
            new AlertDialog.Builder(context)
                    .setTitle("TODO: this is title")
                    .setMessage("TODO: this is msg")
                    .setPositiveButton(R.string.ok, 
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    String file = mDrmCidMap.get(cid)[0]; 
                                    String mime = mDrmCidMap.get(cid)[1];  
                                    Uri contentUri = Uri.parse(file);
                                    Intent i = new Intent();
                                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    i.setAction(Intent.ACTION_VIEW);
                                    i.setDataAndType(contentUri, mime);
                                    Log.d("Browser", "file="+file+", mime="+mime);
                                    context.startActivity(i); 
                                }
                           })
                    .setNegativeButton(R.string.cancel, null)
                    .show();

    }


    /**
     * Broadcast receiver notified when the download manager has finished the work
     */
    public static class OmaDownloadManagerBroadcastReceiver
        extends BroadcastReceiver {

        /**
         * Called when the download manager has finished the work
         *
         * @param context The application context
         * @param intent The intent used to notify this broadcast receiver
         */
        @Override
        public void onReceive(Context context, Intent intent) {
            if (OmaLog.LOGV) {
                OmaLog.v("OmaDownloadManagerBroadcastReceiver.onReceive()");
            }

            if (!intent.getAction().equals(Downloads.ACTION_DOWNLOAD_COMPLETED)) {
                return;
            }
            final Uri contentUri = intent.getData();
/*
            Bundle omaState = new Bundle();
                //WebViewDatabase.getInstance(context).getOmaDownloadState(contentUri.toString());
            if (omaState == null) {
                return;
            }

            String notifyUri = omaState.getString("notify-uri");
            String objectUri = omaState.getString("object-uri");
*/
            //WebViewDatabase.getInstance(context).deleteOmaDownloadState(objectUri);

            String[] projection = { Downloads.COLUMN_STATUS, Downloads._DATA, 
                    Downloads.COLUMN_MIME_TYPE, Downloads.COLUMN_NOTIFICATION_EXTRAS,  
                    Downloads.COLUMN_USER_AGENT, Downloads.COLUMN_PROXY_HOST, Downloads.COLUMN_PROXY_PORT,
                    Downloads._ID };

            // if it is the media object that has been downloaded
            Cursor objectDownloadCursor = context.getContentResolver().query(
                contentUri, projection, null, null, null);
            if (objectDownloadCursor != null && objectDownloadCursor.getCount() > 0) {
                objectDownloadCursor.moveToFirst();
                int status = objectDownloadCursor.getInt(objectDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_STATUS));
                String notifyUri = objectDownloadCursor.getString(objectDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_NOTIFICATION_EXTRAS));
                // Network params
                mUserAgent = objectDownloadCursor.getString(objectDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_USER_AGENT));
                mProxy = objectDownloadCursor.getString(objectDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_PROXY_HOST));
                mPort = objectDownloadCursor.getInt(objectDownloadCursor.getColumnIndexOrThrow(Downloads.COLUMN_PROXY_PORT));

Log.e("oma", "mProxy= " + mProxy + "/" + notifyUri);
                if (Downloads.isStatusSuccess(status)) {

                    if (notifyUri != null && 0 < notifyUri.length()) {
                        // make download hidden if notification requested
                        /*
                        // TODO: enable once we have updateBoolean (or a substitute)
                        objectDownloadCursor.updateInt(
                            objectDownloadCursor.getColumnIndexOrThrow(Downloads.VISIBILITY),
                            Downloads.VISIBILITY_HIDDEN);
                        */
                        
                        OmaDownloadManager.sendNotificationOnSuccess(
                            context, notifyUri);
     
                        // OMS: If it's DRM, will do some special handle
                        specialHandleForDrm(context, objectDownloadCursor, contentUri);
                        
                    }
                } else {
                    // on error, remove the download
                    //objectDownloadCursor.deleteRow();
                    if (notifyUri != null && 0 < notifyUri.length()) {
                        onDownloadManagerError(context, status, notifyUri);
                    }
                }
                objectDownloadCursor.close();
            }
        }

        private void specialHandleForDrm(Context context, Cursor cursor, Uri uri) {
            String mimeType = cursor.getString(cursor.getColumnIndexOrThrow(Downloads.COLUMN_MIME_TYPE));
            String fileName = cursor.getString(cursor.getColumnIndexOrThrow(Downloads._DATA));
            //int id = cursor.getColumnIndexOrThrow(Downloads._ID);
            //Uri uri = ContentUris.withAppendedId(Downloads.CONTENT_URI, id);

            Log.d("OmaDownloadPage", "specialHandleForDrm, mime="+mimeType+", fileName="+fileName);
            if(mimeType == null || mimeType.length() == 0) {
                Log.e("OmaDownloadPage", "why mime is null?");
                return;
            }

            if (mimeType.equalsIgnoreCase(DrmRawContent.DRM_MIMETYPE_CONTENT_STRING)) {
                try {
                File dcfHandle = new File(fileName);
                FileInputStream fis = new FileInputStream(dcfHandle);
                DrmRawContent rawContent = new DrmRawContent(fis, (int)dcfHandle.length(),
                                                   DrmRawContent.DRM_MIMETYPE_CONTENT_STRING);
                //merge-todo: wait for DRM inplementation...
                //String cid = rawContent.getContentID();
String cid = "111";
                String newMime = rawContent.getContentType();

                
                //Log.d("OmaDownloadPage", "cid="+rawContent.getContentID() +", file="+fileName+", mime="+rawContent.getContentType());

                String [] arr = new String[2];
                arr[0] = fileName;
                arr[1] = newMime;

                if (arr[0] == null || arr[1] == null) {
                    Log.e("OmaDownloadPage", "why it's null? arr[0]="+arr[0]+", arr[1]="+arr[1]);
                    return;
                }
                //merge-todo: wait for DRM inplementation...
                //mDrmCidMap.put(rawContent.getContentID(), arr);
                updateDatabaseForDrm(context, uri, newMime, cid);
                } catch (Exception e) {
                    Log.e("BrowserDownloadPage", "exception", e);
                }

                return;
            }

        }

        // OMS: ** IMPORTANT ** 
        // Do remember to update the DownloadProvider.java update() if 
        // we want to update other fields to the database someday.
        void updateDatabaseForDrm(Context context, Uri uri, String mime , String cid) {
            ContentValues values = new ContentValues();
            //OMS: Mar12, 2010:
            // Not update the mimetype, fix ticket 49680, MediaScanner will scan this file later.
            // values.put(Downloads.COLUMN_MIME_TYPE, mime);
            values.put(Downloads.COLUMN_NOTIFICATION_EXTRAS, cid);
            // values.put(Downloads.MEDIA_SCANNED, 1); 
            context.getContentResolver().update(uri, values, null, null);
        }

        /**
         * Called if the download manager has failed, in which case we report an
         * error to the user and send an installation notification if requested
         *
         * @param context The application context
         * @param status The download-manager error status code
         * @param notifyUri The installation notification uri
         */
        private static void onDownloadManagerError(
            Context context, int status, String notifyUri) {

            if (OmaLog.LOGV) {
                OmaLog.v("onDownloadManagerError(): status: " + status);
            }

            if (context == null) {
                return;
            }

            switch(status) {
                case Downloads.STATUS_FILE_ERROR:
                    error(context, STATUS_INSUFFICIENT_MEMORY, notifyUri);
                    break;

                case Downloads.STATUS_CANCELED:
                    error(context, STATUS_USER_CANCELLED, notifyUri);
                    break;

                case Downloads.STATUS_NOT_ACCEPTABLE:
                    error(context, STATUS_NONACCEPTABLE_CONTENT, notifyUri);
                    break;

                default:
                    error(context, STATUS_DEVICE_ABORTED, notifyUri);
            }
        }

         /**
          * Displays an error message to the user. Because we cannot create
          * an error dialog from a broadcast receiver directly, create a
          * small activity that would display the error message and send an
          * installation notification if requested.
          *
          * @param context The application context
          * @param statusCode The oma-download status code (here, an error)
          * @param notifyUri The installation notification uri
          */
        private static void error(Context context, int statusCode, String notifyUri) {
            if (context == null || statusCode == STATUS_SUCCESS) {
                return;
            }

            Intent intent = new Intent(context, OmaDownloadManagerAlert.class);

            intent.putExtra("status-code", statusCode);
            intent.putExtra("notify-uri", notifyUri);

            intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                            Intent.FLAG_ACTIVITY_SINGLE_TOP |
                            Intent.FLAG_ACTIVITY_NEW_TASK);

            context.startActivity(intent);
        }
    }

    /**
     * Simple activity used to display an error message from the oma-download
     * broadcast receiver
     */
    public static class OmaDownloadManagerAlert extends Activity {

        /**
         * Called when this activity is created
         *
         * @param icicle - The bundle of data with the saved activity state (if any)
         */
        @Override
        protected void onCreate(Bundle icicle) {
            super.onCreate(icicle);
            setTitle("");

           final Intent intent = getIntent();
           if (intent != null) {
               int statusCode = intent.getIntExtra("status-code", 0);
               String notifyUri = intent.getStringExtra("notify-uri");

               OmaDownloadManager.error(this, statusCode, notifyUri);
           }
        }
    }

    /**
     * Sends an installation notification if installation was a failure
     *
     * @param context The application context
     * @param notifyUri The installation notification uri
     * @param statusCode The oma-download status code (here, an error)
     */
    public static void sendNotificationOnFailure(
        Context context, String notifyUri, int statusCode) {
        if (context != null && notifyUri != null && notifyUri.length() != 0) {
            OmaDownloadManager.sendNotification(
                context, notifyUri, statusCode);
        }
    }

    /**
     * Sends an installation notification if installation was a success
     *
     * @param context The application context
     * @param notifyUri The installation notification uri
     * @param objectUri The media object uri
     */
    static void sendNotificationOnSuccess(
        Context context, String notifyUri) {
        if (context != null && notifyUri != null && notifyUri.length() != 0) {
            OmaDownloadManager.sendNotification(
                context, notifyUri, STATUS_SUCCESS);
        }
    }

    /**
     * Sends an installation notification
     *
     * @param context The application context
     * @param notifyUri The installation notification uri
     * @param statusCode The oma-download status code
     * @param objectUri The media object uri
     */
    public static void sendNotification(
        Context context, String notifyUri, int statusCode) {
        Log.d("OmaDownloadManager", "sendNotification():" +
                     " notify-uri: " + notifyUri + " status: " + statusCode);

        if (context == null || notifyUri == null || notifyUri.length() == 0) {
            return;
        }
        String notification = Integer.toString(statusCode) + " " +
            OmaDownloadManager.statusMessage(context, statusCode).toString() + "\n\r";
        BrowserHelper.sendData(notifyUri, "POST", notification, 
                CookieManager.getInstance().getCookie(notifyUri), mUserAgent, mProxy, mPort);
    }

    /**
     * Displays an error message to the user
     *
     * @param activity The application context
     * @param statusCode The oma-download status code (here, an error)
     * @param notifyUri The installation notification uri
     */
    public static void error(final Activity context, final int statusCode, final String notifyUri) {
        CharSequence errorMessageText =
            OmaDownloadManager.errorMessage(context, statusCode);
        if (OmaLog.LOGV) {
            OmaLog.v("error(): status: " + statusCode + " message: " + errorMessageText);
        }

        if (statusCode != STATUS_SUCCESS) {
            new AlertDialog.Builder(context)
                .setTitle(R.string.oma_label_download_error)
                .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                .setMessage(errorMessageText)
                .setPositiveButton(
                    R.string.oma_label_exit,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            OmaDownloadManager.sendNotificationOnFailure(context, notifyUri, statusCode);
                            context.finish();
                        }
                    })
                .setCancelable(false)
                .show();
        }
    }

    /**
     * Given an oma-download status code, returns an error message to
     * be displayed to the user
     *
     * @param context The application context
     * @param statusCode The oma-download status code (here, an error)
     * @return The error message to be displayed to the user
     */
    static CharSequence errorMessage(Context context, int statusCode) {
        int errorResource = R.string.oma_error_failed_to_download;

        switch(statusCode) {
            case STATUS_INSUFFICIENT_MEMORY:
                errorResource = R.string.oma_error_insufficient_memory;
                break;
            case STATUS_INVALID_DECRIPTOR:
            case STATUS_INVALID_DDVERSION:
                errorResource = R.string.oma_error_invalid_descriptor;
                break;
            case STATUS_NONACCEPTABLE_CONTENT:
                errorResource = R.string.oma_error_non_acceptable_content;
                break;
        }

        return context.getText(errorResource);
     }

    /**
     * Given an oma-download status code, returns a status message to
     * be sent back to the server, along with the status code
     *
     * @param context The application context
     * @param statusCode The oma-download status code
     * @return The status message to be sent back to the server
     */
    static CharSequence statusMessage(Context context, int statusCode) {
        int statusResource = -1;

        switch(statusCode) {
            case STATUS_SUCCESS:
                statusResource = R.string.oma_status_success;
                break;
            case STATUS_INSUFFICIENT_MEMORY:
                statusResource = R.string.oma_status_insufficient_memory;
                break;
            case STATUS_LOSS_OF_SERVICE:
                statusResource = R.string.oma_status_loss_of_service;
                break;
            case STATUS_ATTRIBUTE_MISMATCH:
                statusResource = R.string.oma_status_attribute_mismatch;
                break;
            case STATUS_INVALID_DECRIPTOR:
                statusResource = R.string.oma_status_invalid_descriptor;
                break;
            case STATUS_INVALID_DDVERSION:
                statusResource = R.string.oma_status_invalid_version;
                break;
            case STATUS_DEVICE_ABORTED:
                statusResource = R.string.oma_status_device_aborted;
                break;
            case STATUS_NONACCEPTABLE_CONTENT:
                statusResource = R.string.oma_status_non_acceptable_content;
                break;
            case STATUS_LOADER_ERROR:
                statusResource = R.string.oma_status_loader_error;
                break;
        }

        return statusResource >= 0 ? context.getText(statusResource) : "";
    }
}
