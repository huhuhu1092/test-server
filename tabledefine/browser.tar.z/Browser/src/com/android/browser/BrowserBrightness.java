/* 
 * This is only a wrapper to set browser brightness. The code is moved from
 * BrowserActivity.java
 */
 
package com.android.browser;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface;
import android.os.SystemProperties;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.SeekBar;

import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;

public class BrowserBrightness {
    static public final String LOGTAG = "browserbrightness";
    private AlertDialog mBrightnessDialog;
    private int mOldBrightness;
    private SeekBar mSeekBar;
    private Context mContext;
    private boolean mSystemPowerSaveModeOn;
    
    public BrowserBrightness(Context c) {
        mContext = c;
    }

    public void turnOnPowerSaveMode() {
        if (!mSystemPowerSaveModeOn) return;
        
        File aclFile = new File("sys/class/leds/lcd-backlight/acl_state");
    	try{
             BufferedWriter bw = new BufferedWriter( new FileWriter(aclFile) );
  	         bw.write("1");
    		 bw.close();
    	}catch(IOException e){
    	    Log.e(LOGTAG, "IOException", e);
        }
    }

    public void turnOffPowerSaveMode() {
        mSystemPowerSaveModeOn = getSystemPowerSaveMode();
        if (!mSystemPowerSaveModeOn) return;
        
        File aclFile = new File("sys/class/leds/lcd-backlight/acl_state");
    	try{
             BufferedWriter bw = new BufferedWriter( new FileWriter(aclFile) );
  	         bw.write("0");
    		 bw.close();
    	}catch(IOException e){
    	    Log.e(LOGTAG, "IOException", e);
        }
    }

    private boolean getSystemPowerSaveMode() {
        boolean ret = true; // true means power save mode is on.
        try{
            File file = new File("sys/class/leds/lcd-backlight/acl_state");
            BufferedReader br = new BufferedReader(new FileReader(file));
            int tempint = br.read();
            if ((tempint-48) == 1){
                ret = true;
            }else {
                ret = false;
            }               
        }catch(IOException e){
        }
        return ret;
    }

    public void enterBrowserBrightness() {
        // if brower has its own brightness, and keyguard is not shown
        BrowserSettings bs = BrowserSettings.getInstance();
        if ((-1 != bs.getBrightness()) && 
            (SystemProperties.getBoolean("sys.keyguard.disable", true))) {
            setBrightness(bs.getBrightness());
        }
    }

    public void exitBrowserBrightness() {   
        BrowserSettings bs = BrowserSettings.getInstance();

        int systemBrightness;
        try {
            systemBrightness = Settings.System.getInt(mContext.getContentResolver(), 
                Settings.System.SCREEN_BRIGHTNESS);
        } catch (SettingNotFoundException snfe) {
            systemBrightness = BrowserSettings.MAXIMUM_BACKLIGHT;
        }

        if (null != mBrightnessDialog && mBrightnessDialog.isShowing()) { 
            mBrightnessDialog.dismiss();
            setBrightness(systemBrightness);
            return;
        }
/*
        // if user have set browser brightness, retore to system brightness setting
        if (-1 != bs.getBrightness()) {
            setBrightness(systemBrightness);
        }        
*/        
    }
    
    private void setBrightness(int value) {
       WindowManager.LayoutParams lp = ((BrowserActivity)mContext).getWindow().getAttributes(); 
       float val = value/255.f;
       if (val < .12f) val += .12f;
       lp.screenBrightness = val;
       ((BrowserActivity)mContext).getWindow().setAttributes(lp);
    }
    
    public void showBrightnessDialog () {
        LayoutInflater factory = LayoutInflater.from(mContext);
        View v = factory.inflate(R.layout.preference_dialog_brightness, null);
        
        mSeekBar = (SeekBar) v.findViewById(R.id.seekbar);
        mSeekBar.setMax(BrowserSettings.BRIGHTNESS_STEP);
        mOldBrightness = BrowserSettings.getInstance().getBrightness();
        if (-1 == mOldBrightness) {
            try {
                mOldBrightness = Settings.System.getInt(mContext.getContentResolver(), 
                    Settings.System.SCREEN_BRIGHTNESS);                
            } catch (SettingNotFoundException snfe) {
                mOldBrightness = BrowserSettings.MAXIMUM_BACKLIGHT;
            }
        }
        mSeekBar.setProgress((mOldBrightness - BrowserSettings.MINIMUM_BACKLIGHT)/20);
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            
            public void onProgressChanged(SeekBar seekBar, int progress,
                boolean fromTouch) {
                setBrightness(progress*20 + BrowserSettings.MINIMUM_BACKLIGHT);
            }
            
            public void onStartTrackingTouch(SeekBar seekBar) {
                // NA
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                // NA
            }
        });

        mBrightnessDialog = new AlertDialog.Builder(mContext)
            .setView(v)
            .setTitle(R.string.brightness)
            .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                
                public void onClick(DialogInterface dialog,
                                    int whichButton) {
                    int value = (mSeekBar.getProgress())*20 + BrowserSettings.MINIMUM_BACKLIGHT;
                    setBrightness(value);
                    BrowserSettings.getInstance()
                        .setBrightness(mContext, value);
                }
                
            })
            .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                
                public void onClick(DialogInterface dialog,
                                    int whichButton) {
                    setBrightness(mOldBrightness);
                }
            })
            .create();
        mBrightnessDialog.show();
    }
}

