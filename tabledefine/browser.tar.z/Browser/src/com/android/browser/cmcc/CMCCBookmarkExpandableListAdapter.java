package com.android.browser.cmcc;


import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Iterator;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Browser;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebIconDatabase;
import android.webkit.WebIconDatabase.IconListener;
import android.widget.BaseExpandableListAdapter;
import android.database.CursorIndexOutOfBoundsException;

public class CMCCBookmarkExpandableListAdapter  extends BaseExpandableListAdapter{
    private static final boolean mDebug = false;
    private static final int MAX_CATEGORIES = 10;

    private Context mContext; 
    private static final String TAG = "BookmarkExpandableListAdapter";
    private Cursor[] cursors = new Cursor[MAX_CATEGORIES + 1];
    private int mGroupCount;

    private ArrayList<String> mCheckedIDlist;
    private int mExpandedGroupPosition = -1;
    
    private final                   String LOGTAG = "Bookmarks";
    private Cursor                  mCursor;

    private int                     mTitleIndex;
    private int                     mUrlIndex;
    private int                     mIdIndex;
    private int                     mFaviconIndex;
    private int                     mCATIdIndex;
    private int                     mCount;
    private String                  mLastWhereClause;
    private String[]                mLastSelectionArgs;
    private String                  mLastOrderBy;
    private CMCCBrowserBookmarksPage    mBookmarksPage;
    private ContentResolver         mContentResolver;
    private ChangeObserver          mChangeObserver;
    private static final String[]   mColumnStrings = 
            { Browser.BookmarkColumns._ID, 
              Browser.BookmarkColumns.TITLE, 
              Browser.BookmarkColumns.URL, 
              Browser.BookmarkColumns.BOOKMARK, 
              Browser.BookmarkColumns.VISITS,
              Browser.BookmarkColumns.FAVICON,
              Browser.BookmarkColumns.CATID};
        
        private static final String[]   mCagegoryColumnStrings = 
        { Browser.CategoryColumns._ID, 
          Browser.CategoryColumns.NAME };

        // When true, this adapter is used to pick a bookmark to create a shortcut
        //private boolean mCreateShortcut;
        private int mExtraOffset;

        // Implementation of WebIconDatabase.IconListener
        private class IconReceiver implements IconListener {
            public void onReceivedIcon(String url, Bitmap icon) {
                updateBookmarkFavicon(mContentResolver, url, icon);
            }
        }

        // Instance of IconReceiver
        private final IconReceiver mIconReceiver = new IconReceiver();

    public CMCCBookmarkExpandableListAdapter(CMCCBrowserBookmarksPage b, String curPage, boolean createShortcut, Context context){
        mDestroyed = false;
        mContext = context;
        mCheckedIDlist = new ArrayList<String>();

        //mCreateShortcut = createShortcut;
        mExtraOffset = createShortcut ? 0 : 1;
        mBookmarksPage = b;
        mContentResolver = b.getContentResolver();
        mLastOrderBy = Browser.BookmarkColumns.CREATED + " DESC";
        mChangeObserver = new ChangeObserver();
        
        intiatedata();

        // Update the preloaded categories.
        CategoryManager.instance(context).loadPreloadedCategories(context);

        // FIXME: Should have a default sort order that the user selects.
        search(null);
        // FIXME: This requires another query of the database after the
        // initial search(null). Can we optimize this?
        Browser.requestAllIcons(mContentResolver,
                Browser.BookmarkColumns.FAVICON + " is NULL AND " +
                Browser.BookmarkColumns.BOOKMARK + " == 1", mIconReceiver);
    }

    private void intiatedata(){
        if(mDebug) Log.i(TAG, "in intiatedata, begin");
        mGroupCount = 0;
        // 1. Category cursor.
        if (cursors[0] != null) {
            cursors[0].unregisterContentObserver(mChangeObserver);
            mBookmarksPage.stopManagingCursor(cursors[0]);
            cursors[0].deactivate();
        }
        cursors[0] = CategoryManager.instance(mContext).query( Browser.CATEGORY_URI,mCagegoryColumnStrings, null, null, null);
        //Log.i(TAG, "in intiatedata, begin,count:" + cursors[0].getCount());
        cursors[0].registerContentObserver(mChangeObserver);
        mBookmarksPage.startManagingCursor(cursors[0]);

        // 2. Bookmark cursors
        while(cursors[0].moveToNext()){
            //Something wrong in DB that we have over max categories.
            if(++mGroupCount > MAX_CATEGORIES) {
                break;
            }

            if (cursors[mGroupCount] != null) {
                cursors[mGroupCount].unregisterContentObserver(mChangeObserver);
                mBookmarksPage.stopManagingCursor(cursors[mGroupCount]);
                cursors[mGroupCount].deactivate();
            }
            cursors[mGroupCount] = mContentResolver.query( Browser.BOOKMARKS_URI,mColumnStrings,
            		Browser.BookmarkColumns.BOOKMARK + " == 1 and " + 
            		Browser.BookmarkColumns.CATID + " = ?", 
            		new String[]{ cursors[0].getString(0) }, null);
            cursors[mGroupCount].registerContentObserver(mChangeObserver);
            mBookmarksPage.startManagingCursor(cursors[mGroupCount]);
        }

    }

    boolean mDestroyed = false;
    // Called by BookmarksPage to clear local variables.
    void onDestroy() {
        mDestroyed = true;
        try {
            for(int i=0; i<MAX_CATEGORIES; i++) {
                if (cursors[i] != null) {
                    cursors[i].unregisterContentObserver(mChangeObserver);
                    cursors[i].close();
                }
            }
            if(mCursor != null) {
                mCursor.close();
            }
        }catch(Exception ee) {
            Log.e(TAG, "Bookmark onDestroy failed! ", ee);
        }
    }

    public View getChildView(int groupPosition, int childPosition,boolean isLastChild, View convertView, ViewGroup parent) 
    {
        if(mDebug) Log.i(TAG, "getChildView, child name=" + cursors[groupPosition+1].getString(mTitleIndex) + "," +  groupPosition + ":" + childPosition);
        cursors[groupPosition+1].moveToPosition(childPosition);

        boolean inDeleteView = mBookmarksPage.isInDeleteView();
        CMCCBookmarkItem  bookmarkitem = new CMCCBookmarkItem(this, mContext, inDeleteView);
        bookmarkitem.setName(cursors[groupPosition+1].getString(mTitleIndex));
        bookmarkitem.setUrl(cursors[groupPosition+1].getString(mUrlIndex));
        String bookmarkId = cursors[groupPosition+1].getString(mIdIndex);
        bookmarkitem.setBookmarkId(bookmarkId);

        byte[] data = cursors[groupPosition+1].getBlob(mFaviconIndex);
        if (data != null) {
            bookmarkitem.setFavicon(BitmapFactory.decodeByteArray(data, 0, data.length));
        } else {
            bookmarkitem.setFavicon(null);
        }

        bookmarkitem.setPadding(26, 0, 0, 0);

        // Set the item checked if it's in the checked list.
        if(inDeleteView) {
            if(mCheckedIDlist.contains(bookmarkId)) {
                bookmarkitem.setChecked(true);
            }else {
                bookmarkitem.setChecked(false);
            }
        }
        return bookmarkitem;
    }

    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) 
    {
    	//if(groupPosition < mGroupCount) {
	        cursors[0].moveToPosition(groupPosition);

	        CMCCCategoryItem categoryitem = new CMCCCategoryItem(mContext);

            boolean preloaded = groupPosition < CategoryManager.mPreloadedCategorySize ? true : false;
            categoryitem.setPreloaded(preloaded);
            if(preloaded) {
                categoryitem.setName(CategoryManager.mPreLoadedCategories[groupPosition].toString());
            }else {
    	        categoryitem.setName(cursors[0].getString(1));
            }
	        int count = cursors[groupPosition + 1] == null ? 0 : 
	            cursors[groupPosition + 1].getCount();
	        categoryitem.setCount(count);
	        return categoryitem;
    	//} else {
    	//	return null;
    	//}
    }

    public Object getChild(int groupPosition, int childPosition) {
        cursors[groupPosition+1].moveToPosition(childPosition);
        return  mCursor.getString(mTitleIndex);
    }

    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    public int getChildrenCount(int groupPosition) {
        return cursors[groupPosition+1].getCount();
    }

    public Object getGroup(int groupPosition) {
        cursors[0].moveToPosition(groupPosition);
        return  mCursor.getString(1);
    }

    public int getGroupCount() {
        return mGroupCount;
    }

    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    public boolean hasStableIds() {
        // TODO Auto-generated method stub
        return true;
    }

    public boolean isChildSelectable(int groupPosition, int childPosition) {
        // TODO Auto-generated method stub
        return true;
    }
    
    public int getCategoryCount(){
        return getGroupCount(); 
    }
    
    public void onGroupExpanded(int groupPosition){
        if(mDebug) Log.i(TAG, "in onGroupExpanded:" + groupPosition);
        mExpandedGroupPosition = groupPosition;
        for(int i=0; i<mGroupCount; i++){
            if(groupPosition != i){
                mBookmarksPage.getExpandableListView().collapseGroup(i);
            }
        }
    }
    
    public void onGroupCollapsed(int groupPosition){
        if(mExpandedGroupPosition == groupPosition) {
            mExpandedGroupPosition = -1;
        }
    }

    public int getExpandedGroupPosition() {
        return mExpandedGroupPosition;
    }

    /**
     *  Return a hashmap with one row's Title, Url, and favicon.
     *  @param position  Position in the list.
     *  @return Bundle  Stores title, url of row position, favicon, and id
     *                   for the url.  Return a blank map if position is out of 
     *                   range.
     */
    public Bundle getRow(int groupPosition, long childPosition) {
        Bundle map = new Bundle();
        cursors[groupPosition+1].moveToPosition((int) childPosition);
        String url = cursors[groupPosition+1].getString(mUrlIndex);
        map.putString(Browser.BookmarkColumns.TITLE, 
                cursors[groupPosition+1].getString(mTitleIndex));
        map.putString(Browser.BookmarkColumns.URL, url);
        byte[] data = cursors[groupPosition+1].getBlob(mFaviconIndex);
        if (data != null) {
            map.putParcelable(Browser.BookmarkColumns.FAVICON,
                    BitmapFactory.decodeByteArray(data, 0, data.length));
        }
        map.putInt("id", cursors[groupPosition+1].getInt(mIdIndex));
        map.putString(Browser.BookmarkColumns.CATID, cursors[groupPosition+1].getString(mCATIdIndex));
        return map;
    }
    
    public Bundle getCategoryRow(int groupPosition, long childPosition) {
        Bundle map = new Bundle();
        cursors[0].moveToPosition((int) groupPosition);
        String id = cursors[0].getString(0);
        String title = cursors[0].getString(1);
        map.putString(Browser.CategoryColumns._ID, id);
        map.putString(Browser.CategoryColumns.NAME, title);
        return map;
    }

    public Cursor getCategoryCursor() {
        return cursors[0];
    }

    public String getBookmarkId(int groupPosition, int childPosition) {
        if(cursors[groupPosition+1].moveToPosition(childPosition)) {
            return  mCursor.getString(mIdIndex);
        }else {
            return null;
        }
    }

    /**
     *  Update a row in the database with new information. 
     *  Requeries the database if the information has changed.
     *  @param map  Bundle storing id, title and url of new information
     */
    public void updateRow(Bundle map) {

        // Find the record
        int id = map.getInt("id");
        int position = -1;
        for (mCursor.moveToFirst(); !mCursor.isAfterLast(); mCursor.moveToNext()) {
            if (mCursor.getInt(mIdIndex) == id) {
                position = mCursor.getPosition();
                break;
            }
        }
        if (position < 0) {
            return;
        }
        mCursor.moveToPosition(position);
        String title = map.getString(Browser.BookmarkColumns.TITLE);
        if (!title.equals(mCursor.getString(mTitleIndex))) {
            mCursor.updateString(mTitleIndex, title);
        }
        String url = map.getString(Browser.BookmarkColumns.URL);
        if (!url.equals(mCursor.getString(mUrlIndex))) {
            mCursor.updateString(mUrlIndex, url);
        }
        
        String catid = map.getString(Browser.BookmarkColumns.CATID);
        if (!catid.equals(mCursor.getString(mCATIdIndex))) {
            mCursor.updateString(mCATIdIndex, catid);
        }
        if (mCursor.commitUpdates()) {
            refreshList();
        }
    }

    /**
     *  Delete a row from the database.  Requeries the database.  
     *  Does nothing if the provided position is out of range.
     *  @param position Position in the list.
     */
    public void deleteRow(int groupPosition,long childPosition) {
        /*if (position < mExtraOffset || position >= getChildrenCount(position)) {
            return;
        }
        mCursor.moveToPosition(position- mExtraOffset);*/
        try {
            cursors[groupPosition+1].moveToPosition((int) childPosition);
            int visitsIndex = cursors[groupPosition+1].getColumnIndexOrThrow(Browser.BookmarkColumns.VISITS);
            int numVisits = cursors[groupPosition+1].getInt(visitsIndex);
            String url = cursors[groupPosition+1].getString(mUrlIndex);
            WebIconDatabase.getInstance().releaseIconForPageUrl(url);
            if (0 == numVisits) {
                cursors[groupPosition+1].deleteRow();
            } else {
                int bookmarkIndex = 
                    cursors[groupPosition+1].getColumnIndexOrThrow(Browser.BookmarkColumns.BOOKMARK);
                cursors[groupPosition+1].updateInt(bookmarkIndex, 0); 
                cursors[groupPosition+1].commitUpdates();
            }   
        } catch (CursorIndexOutOfBoundsException e) {
            Log.e(LOGTAG, "Index out of bound happened !");
            return;
        }   
        
        refreshList();
    }
    
    /**
     *  Delete all rows from the database.
     */
    public void deleteAll() {
        mCursor = mContentResolver.query(Browser.BOOKMARKS_URI, mColumnStrings,
                Browser.BookmarkColumns.BOOKMARK + " == 1", null, null);
        mCursor.registerContentObserver(mChangeObserver);
        mBookmarksPage.startManagingCursor(mCursor);
        mTitleIndex = mCursor.getColumnIndexOrThrow(Browser.BookmarkColumns.TITLE);
        mUrlIndex = mCursor.getColumnIndexOrThrow(Browser.BookmarkColumns.URL);
        int visitsIndex = mCursor.getColumnIndexOrThrow(Browser.BookmarkColumns.VISITS);
        int bookmarkIndex = 
                mCursor.getColumnIndexOrThrow(Browser.BookmarkColumns.BOOKMARK);
        int count = mCursor.getCount();
        String url;
        for (int i = 0; i < count; i++) {
            mCursor.moveToPosition(i);
            url = mCursor.getString(mUrlIndex);
            WebIconDatabase.getInstance().releaseIconForPageUrl(url);
            if (mCursor.getInt(visitsIndex) == 0) {
                mCursor.updateInt(visitsIndex, -1);
            } else {
                mCursor.updateInt(visitsIndex, 0);
                mCursor.updateString(mTitleIndex, "");
                mCursor.updateInt(bookmarkIndex, 0);
            }
        }
        mCursor.commitUpdates();
        mContentResolver.delete(Browser.BOOKMARKS_URI, 
                Browser.BookmarkColumns.VISITS + " == -1", null);
        refreshList();
    }
    
    public void deleteBookmarks(){
        Iterator iterator = mCheckedIDlist.iterator();
        while(iterator.hasNext()){
            mContentResolver.delete(Browser.BOOKMARKS_URI, Browser.CategoryColumns._ID+" = ?", new String[]{ (String) iterator.next() });
        }
        mCheckedIDlist.clear();
    }

    // See how many items have been checked.
    public int getCheckedItemCount() {
        return mCheckedIDlist.size();
    }

    //OMS 90347:get checked item count for the specific group
    public int getCheckedItemCountForGroup(int groupPosition){
         Cursor selectedCursor = cursors[groupPosition + 1];
         int count = 0;
         if(selectedCursor == null || selectedCursor.getCount() <= 0) {
             return count;
         }
         selectedCursor.moveToFirst();
         do {
             String id = selectedCursor.getString(mIdIndex);
             if(mCheckedIDlist.contains(id)) {
                 count ++;
             }
         }while(selectedCursor.moveToNext());
         return count;
    }

    /**
     *  Refresh list to recognize a change in the database.
     */
    public void refreshList() {
        // FIXME: consider using requery().
        // Need to do more work to get it to function though.
        int expandedGroup = -1;
    	for(int i=0; i<mGroupCount; i++){
            if(mBookmarksPage.getExpandableListView().isGroupExpanded(i)) {
                expandedGroup = i;
                mBookmarksPage.getExpandableListView().collapseGroup(i);
                //Don't have to go ahead as we only have one group expanded at a time.
                break;
            }
        }
        searchInternal(mLastWhereClause, mLastSelectionArgs, mLastOrderBy);

        // Expand the group now.
        if(expandedGroup >= 0) {
        	mBookmarksPage.getExpandableListView().expandGroup(expandedGroup);
        }
    }

    /**
     *  Search the database for bookmarks that match the input string.
     *  @param like String to use to search the database.  Strings with spaces 
     *              are treated as having multiple search terms using the
     *              OR operator.  Search both the title and url.
     */
    public void search(String like) {
        String whereClause = Browser.BookmarkColumns.BOOKMARK + " == 1";
        String[] selectionArgs = null;
        if (like != null) {
            String[] likes = like.split(" ");
            int count = 0;
            boolean firstTerm = true;
            StringBuilder andClause = new StringBuilder(256);
            for (int j = 0; j < likes.length; j++) {
                if (likes[j].length() > 0) {
                    if (firstTerm) {
                        firstTerm = false;
                    } else {
                        andClause.append(" OR ");
                    }
                    andClause.append(Browser.BookmarkColumns.TITLE
                            + " LIKE ? OR " + Browser.BookmarkColumns.URL
                            + " LIKE ? ");
                    count += 2;
                }
            }
            if (count > 0) {
                selectionArgs = new String[count];
                count = 0;
                for (int j = 0; j < likes.length; j++) {
                    if (likes[j].length() > 0) {
                        like = "%" + likes[j] + "%";
                        selectionArgs[count++] = like;
                        selectionArgs[count++] = like;
                    }
                }
                whereClause += " AND (" + andClause + ")";
            }
        }
        searchInternal(whereClause, selectionArgs, mLastOrderBy);
    }

    /**
     * Update the bookmark's favicon.
     * @param cr The ContentResolver to use.
     * @param url The url of the bookmark to update.
     * @param favicon The favicon bitmap to write to the db.
     */
    /* package */ static void updateBookmarkFavicon(ContentResolver cr,
            String url, Bitmap favicon) {
        if (url == null || favicon == null) {
            return;
        }
        final String[] selArgs = new String[] { url };
        final String where = Browser.BookmarkColumns.URL + " == ? AND "
                + Browser.BookmarkColumns.BOOKMARK + " == 1";
        final Cursor c = cr.query(Browser.BOOKMARKS_URI,
                Browser.HISTORY_PROJECTION, where, selArgs, null);
        if (c.moveToFirst()) {
            final int faviconIndex =
                    c.getColumnIndexOrThrow(Browser.BookmarkColumns.FAVICON);
            final ByteArrayOutputStream os = new ByteArrayOutputStream();
            favicon.compress(Bitmap.CompressFormat.JPEG, 100, os);
            c.updateBlob(faviconIndex, os.toByteArray());
            c.commitUpdates();
        }
        c.close();
    }

    /**
     *  This sorts alphabetically, with non-capitalized titles before 
     *  capitalized.
     */
    public void sortAlphabetical() {
        searchInternal(mLastWhereClause, mLastSelectionArgs,
                Browser.BookmarkColumns.TITLE + " COLLATE UNICODE ASC");
    }

    /**
     *  Internal function used in search, sort, and refreshList.
     */
    private void searchInternal(String whereClause, String[] selectionArgs,
            String orderBy) {
        if (mCursor != null) {
            mCursor.unregisterContentObserver(mChangeObserver);
            mBookmarksPage.stopManagingCursor(mCursor);
            mCursor.deactivate();
        }
        
        mLastWhereClause = whereClause;
        mLastSelectionArgs = selectionArgs;
        mLastOrderBy = orderBy;
        
        mCursor = mContentResolver.query(
            Browser.BOOKMARKS_URI,
            mColumnStrings,
            whereClause,
            selectionArgs, 
            orderBy);
        mCursor.registerContentObserver(mChangeObserver);
        mBookmarksPage.startManagingCursor(mCursor);
        
        intiatedata();
        notifyDataSetChanged();

        mCount = mCursor.getCount() + mExtraOffset;
        
        mTitleIndex = mCursor.getColumnIndexOrThrow(Browser.BookmarkColumns.TITLE);
        mUrlIndex = mCursor.getColumnIndexOrThrow(Browser.BookmarkColumns.URL);
        mIdIndex = mCursor.getColumnIndexOrThrow(Browser.BookmarkColumns._ID);
        mFaviconIndex = mCursor.getColumnIndexOrThrow(Browser.BookmarkColumns.FAVICON);
        mCATIdIndex = mCursor.getColumnIndexOrThrow(Browser.BookmarkColumns.CATID) ;
    }
    

    /**
     * @see android.widget.Adapter#getNewSelectionForKey
     *//*
    public int getNewSelectionForKey(int currentSelection, int key,
            KeyEvent event) {
        // FIXME: seems like a good idea, but we steal keys for searching
        if (key >= KeyEvent.KEYCODE_0 && key <= KeyEvent.KEYCODE_9) {
            return key - KeyEvent.KEYCODE_0;
            
        }
        return NO_SELECTION;
    }*/

    /**
     *  Return the title for this item in the list.
     */
    public String getTitle(int groupPosition, long childPosition) {
        return getString(mTitleIndex, groupPosition, childPosition);
    }

    /**
     *  Return the Url for this item in the list.
     */
    public String getUrl(int groupPosition, long childPosition) {
        return getString(mUrlIndex, groupPosition, childPosition);
    }
    
    /**
     * Private helper function to return the title or url.
     */
    private String getString(int cursorIndex, int groupPosition, long childPosition) {
         /* if (position < mExtraOffset || position > mCount) {
            return "";
        }
      mCursor.moveToPosition(position- mExtraOffset);
        return mCursor.getString(cursorIndex);*/
        cursors[groupPosition+1].moveToPosition((int) childPosition);
        return cursors[groupPosition+1].getString(cursorIndex);
    }
    /*
    private void bind(CMCCBookmarkItem b, int position) {
        mCursor.moveToPosition(position- mExtraOffset);

        String title = mCursor.getString(mTitleIndex);
        if (title.length() > Constants.MAX_TEXTVIEW_LEN) {
            title = title.substring(0, Constants.MAX_TEXTVIEW_LEN);
        }
        b.setName(title);
        String url = mCursor.getString(mUrlIndex);
        if (url.length() > Constants.MAX_TEXTVIEW_LEN) {
            url = url.substring(0, Constants.MAX_TEXTVIEW_LEN);
        }
        b.setUrl(url);
        byte[] data = mCursor.getBlob(mFaviconIndex);
        if (data != null) {
            b.setFavicon(BitmapFactory.decodeByteArray(data, 0, data.length));
        } else {
            b.setFavicon(null);
        }
    }*/
    
     private class ChangeObserver extends ContentObserver {
        public ChangeObserver() {
            super(new Handler());
        }

       
        public boolean deliverSelfNotifications() {
            return true;
        }

        
        public void onChange(boolean selfChange) {
            if(mDestroyed) return;
            try {
            // In case the content is changed by Sync...
            //if(selfChange) {
                refreshList();
            //}
            }catch(Exception ee) {
                Log.w("Failed to refresh list in bookmark adapter!", ee);
            }
        }
     }

     public void clearCheckedList() {
         mCheckedIDlist.clear();
     }
     
     // The following methods are used to the intermediate cursor of 
     // what user chooses when deleting bookmarks.
     //private int mLastSelectedGroup = -1;
     public void selectAll() {
         if(mExpandedGroupPosition < 0 || mExpandedGroupPosition > mGroupCount) {
             return;
         }
         //mLastSelectedGroup = mExpandedGroupPosition;

         //mCheckedIDlist.clear();

         Cursor selectedCursor = cursors[mExpandedGroupPosition + 1];
         if(selectedCursor == null || selectedCursor.getCount() <= 0) {
             return;
         }
         selectedCursor.moveToFirst();
         do {
             String id = selectedCursor.getString(mIdIndex);
             if(!mCheckedIDlist.contains(id)) {
                 mCheckedIDlist.add(id);
             }
         }while(selectedCursor.moveToNext());
     }

     public void cancelSelectAll() {
         if(mExpandedGroupPosition < 0 || mExpandedGroupPosition > mGroupCount) {
             return;
         }
         //mLastSelectedGroup = mExpandedGroupPosition;

         //mCheckedIDlist.clear();
         Cursor selectedCursor = cursors[mExpandedGroupPosition + 1];
         if(selectedCursor == null || selectedCursor.getCount() <= 0) {
             return;
         }
         selectedCursor.moveToFirst();
         do {
             String id = selectedCursor.getString(mIdIndex);
             mCheckedIDlist.remove(id);
         }while(selectedCursor.moveToNext());
     }

     public void toggleBookmark(String id, boolean checked) {
         if(checked) {
             if(!mCheckedIDlist.contains(id)) {
                 mCheckedIDlist.add(id);
             }
         }else {
             mCheckedIDlist.remove(id);
         }
     }

     public void toggleBookmark(int groupPosition, int childPosition, 
             boolean checked) {
         if(groupPosition > mGroupCount) return;

         //mLastSelectedGroup = groupPosition;
         String id = getBookmarkId(groupPosition, childPosition);
         if(id == null) {
             return;
         }
         if(checked) {
             if(!mCheckedIDlist.contains(id)) {
                 mCheckedIDlist.add(id);
             }
         }else {
             mCheckedIDlist.remove(id);
         }
     }
}
