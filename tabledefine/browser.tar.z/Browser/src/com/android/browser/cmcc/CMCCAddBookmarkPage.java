/*
 * Copyright (C) 2006-2007 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser.cmcc;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.net.ParseException;
import android.net.WebAddress;
import android.os.Bundle;
import android.provider.Browser;
import android.view.View;
import android.webkit.WebIconDatabase;
import android.widget.AdapterView;
import java.util.ArrayList;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;
import android.view.WindowManager;
import android.text.InputType;

import java.util.Date;
import com.android.browser.R;
//import android.util.Log;

public class CMCCAddBookmarkPage extends Activity {

    private final String LOGTAG = "AddBookmarkPage";

    private static final String[]   mCagegoryColumnStrings = 
    { Browser.CategoryColumns._ID, 
      Browser.CategoryColumns.NAME };
    
    private EditText    mTitle;
    private EditText    mAddress;
    private TextView    mButton;
    private View        mCancelButton;
    private boolean     mEditingExisting;
    private Bundle      mMap;
    
    CMCCAddBookmarkAdapter mAdapter;
    private Spinner mSpinner;
    private int iSpinnerSelectPosition;
    private static final String[]   mProjection = 
        { "_id", "url", "bookmark", "created", "title", "catid"};
    private static final String     WHERE_CLAUSE = "url = ? AND bookmark = 0";
    private static final String     CHECK_WHERE_CLAUSE = 
            "url = ? AND bookmark = 1";
    private final String[]          SELECTION_ARGS = new String[1];

    private final static int COLUMN_ID = 0;
    private final static int COLUMN_URL = 1;
    private final static int COLUMN_BOOKMARK = 2;
    private final static int COLUMN_CREATED = 3;
    private final static int COLUMN_TITLE = 4;
    private final static int COLUMN_CATID = 5;

    private View.OnClickListener mOverrideBookmark = new View.OnClickListener() {
        public void onClick(View v) {
            setResult(RESULT_OK);
            finish();
            Toast.makeText(CMCCAddBookmarkPage.this, R.string.bookmark_saved,
                    Toast.LENGTH_LONG).show();
        }
    };

    private View.OnClickListener mSaveBookmark = new View.OnClickListener() {
        public void onClick(View v) {
            if (save()) {
                finish();
                Toast.makeText(CMCCAddBookmarkPage.this, R.string.bookmark_saved,
                        Toast.LENGTH_LONG).show();
            }
        }
    };

    private View.OnClickListener mCancel = new View.OnClickListener() {
        public void onClick(View v) {
            finish();
        }
    };

    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.cmcc_add_bookmark);
        setTitle(R.string.save_to_bookmarks);
        
        iSpinnerSelectPosition = 0;
        
        String title = null;
        String url = null;
        String catid = null;
        String category = null;
        mMap = getIntent().getExtras();
        if (mMap != null) {
            Bundle b = mMap.getBundle("bookmark");
            if (b != null) {
                mMap = b;
                mEditingExisting = true;
                setTitle(R.string.edit_bookmark);
            }
            title = mMap.getString("title");
            url = mMap.getString("url");
            catid = mMap.getString("catid");
            
            if(catid !=null){
                Cursor cursor = CategoryManager.instance(this).query( Browser.CATEGORY_URI,
                    mCagegoryColumnStrings, Browser.CategoryColumns._ID+" = ?", new String[]{ catid }, null);
                if(cursor.moveToNext()){
                    category = cursor.getString(1);
                }
                //OMS 0097878:We should close it when finished use.
                cursor.close();
            }
        }

//getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

        mTitle = (EditText) findViewById(R.id.title);
        mTitle.setText(title);
        mAddress = (EditText) findViewById(R.id.address);
        mAddress.setInputType(InputType.TYPE_TEXT_VARIATION_URI | InputType.TYPE_CLASS_TEXT);
        mAddress.setText(url);

        int index = 0;
        Cursor cursor = CategoryManager.instance(this).query( Browser.CATEGORY_URI,mCagegoryColumnStrings, null, null, null);
        int resource = android.R.layout.simple_spinner_item; 
        ArrayList<String> categoryArray = new ArrayList<String>(0);
        CategoryManager.loadPreloadedCategories(this);
        while(cursor.moveToNext()){
            if(index < CategoryManager.mPreloadedCategorySize) {
                categoryArray.add(CategoryManager.mPreLoadedCategories[index].toString());
            }else {
                categoryArray.add(cursor.getString(1));
            }
            index++;
        }
        //OMS 0097878:We should close it when finished use.
        cursor.close();
        mAdapter = new CMCCAddBookmarkAdapter(this, catid, category, resource, categoryArray);
        mSpinner = (Spinner) findViewById(R.id.categoryList);
        mAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpinner.setAdapter(mAdapter);
        if (catid != null) {
            int i = mAdapter.getSelectedIndex();
            if (i != -1) {
                mSpinner.setSelection(i);
            }
        }

        mSpinner.setOnItemSelectedListener(new OnItemSelectedListener(){

            public void onItemSelected(AdapterView<?> arg0, View arg1,
                    int arg2, long arg3) {
                iSpinnerSelectPosition = arg2;
                
            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
                
            }
            
        });

        View.OnClickListener accept = mSaveBookmark;
        mButton = (TextView) findViewById(R.id.OK);
        mButton.setOnClickListener(accept);

        mCancelButton = findViewById(R.id.cancel);
        mCancelButton.setOnClickListener(mCancel);
    }
    
    /**
     * Set the focus appropriately on opening the dialog.  
     * If this is an old bookmark we are editing, or a new bookmark with a
     * default name, set it to the Save button.  Else set it to the name
     * textfield.
     */
    protected void onStart() {
        super.onStart();
        if (mTitle.getText().length() == 0) {
            mTitle.requestFocus();
        } else {
            mButton.requestFocus();
        }
    }
    
    private void showOverrideDialog(final String title, final String url, 
            final int catid, final Cursor c) {
        /*
        final LayoutInflater factory = LayoutInflater.from(AddBookmarkPage.this);
        final View v = null;
        factory.inflate(R.layout.override, null);
        ((TextView)v.findViewById(R.id.old_title)).setText(title);
        String oldUrl = c.getString(c.getColumnIndex("url"));
        ((TextView)v.findViewById(R.id.old_url)).setText(oldUrl);
        ((TextView)v.findViewById(R.id.new_url)).setText(url);*/

        new AlertDialog.Builder(CMCCAddBookmarkPage.this)
            .setTitle(R.string.override_title)
            .setIcon(com.android.internal.R.drawable.cmcc_dialog_question2)
            .setMessage(R.string.override_message)// setView(v)
            .setPositiveButton(R.string.override, 
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            Uri record = ContentUris.withAppendedId(
                                    Browser.BOOKMARKS_URI, c.getInt(COLUMN_ID));
                            ContentValues map = new ContentValues();
                            map.put(Browser.BookmarkColumns.URL, url);
                            map.put(Browser.BookmarkColumns.TITLE, title);
                            map.put(Browser.BookmarkColumns.CREATED, new Date().getTime());
                            map.put(Browser.BookmarkColumns.CATID, catid);
                            getContentResolver().update(record, map, null, null);
                            c.deactivate();
                            mOverrideBookmark.onClick(null);
                        }
                    })
             .setNegativeButton(R.string.cancel, 
                     new DialogInterface.OnClickListener() {
                         public void onClick(DialogInterface dialog, int which) {
                             c.deactivate();
                         }
                     })
             .setOnCancelListener(
                     new DialogInterface.OnCancelListener() {
                         public void onCancel(DialogInterface dialog) {
                             c.deactivate();
                         }
                     })
             .show();

    }
    
    /**
     *  Save the data to the database. 
     *  Also, change the view to dialog stating 
     *  that the webpage has been saved.
     */
    boolean save() {
        String title = mTitle.getText().toString().trim();
        String unfilteredUrl = mAddress.getText().toString();
        int catID = (int)mAdapter.getItemId(iSpinnerSelectPosition);
        boolean emptyTitle = title.length() == 0;
        boolean emptyUrl = unfilteredUrl.trim().length() == 0;
        if (emptyTitle) {
            if (emptyUrl) {
                Toast.makeText(this, R.string.empty_bookmark, 
                    Toast.LENGTH_SHORT).show();
                return false;
            }    
            Toast.makeText(this, R.string.bookmark_needs_title, 
                Toast.LENGTH_SHORT).show();
            return false;
        }
        if (emptyUrl) {
            Toast.makeText(this, R.string.bookmark_needs_url, 
                Toast.LENGTH_SHORT).show();
            return false;
        }
        String url = unfilteredUrl;
        if (!(url.startsWith("about:") || url.startsWith("data:") || url
                .startsWith("file:") || url.startsWith("rtsp:"))) {
            WebAddress address;
            try {
                address = new WebAddress(unfilteredUrl);
            } catch (ParseException e) {
                Toast.makeText(this, R.string.bookmark_url_not_valid, 
                    Toast.LENGTH_SHORT).show();
                return false;
            }
            if (address.mHost.length() == 0) {
                Toast.makeText(this, R.string.bookmark_url_not_valid, 
                    Toast.LENGTH_SHORT).show();
                return false;
            }
            url = address.toString();
        }

        // 1. Check to see if we already have a bookmark with this url.
        SELECTION_ARGS[0] = url;
        ContentResolver cr = getContentResolver();
        try {
            Cursor c = cr.query(Browser.BOOKMARKS_URI,
                                mProjection,
                                CHECK_WHERE_CLAUSE,
                                SELECTION_ARGS,
                                null);
            // Will only have one bookmark per url.
            if (c.moveToFirst()) {
                if (mEditingExisting) {
                    // If we are editing a bookmark, it is okay to keep the name but
                    // change the url.
                    int otherId = c.getInt(COLUMN_ID);
                    int editingId = mMap.getInt("id");
                    if (otherId != editingId) {
                        // We are attempting to overwrite an existing bookmark.
                        // Do not delete the bookmark being edited, but give the
                        // user an opportunity to override the other one.
                        showOverrideDialog(title, url, catID, c);
                        return false;
                    }
                } else {
                    // We are attempting to overwrite an existing bookmark.
                    // Ask the user if they want to override the existing one.
                    showOverrideDialog(title, url, catID, c);
                    return false;
                }
            }

            // 2. Go ahead if thers's no existing bookmark.
            if (mEditingExisting) {
                mMap.putString("title", title);
                mMap.putString("url", url);
                mMap.putString(Browser.BookmarkColumns.CATID, Integer.toString(catID) );
                setResult(RESULT_OK, (new Intent()).setAction(
                        getIntent().toString()).putExtras(mMap));
            } else {
                // Want to append to the beginning of the list
                long creationTime = new Date().getTime();
                SELECTION_ARGS[0] = url;
                /*sContentResolver cr = getContentResolver();
                Cursor c = cr.query(Browser.BOOKMARKS_URI,
                        mProjection,
                        WHERE_CLAUSE,
                        SELECTION_ARGS,
                        null);*/
                if (c.moveToFirst()) {
                    // This means we have been to this site, so convert the 
                    // history item to a bookmark.
                    Uri record = ContentUris.withAppendedId(
                            Browser.BOOKMARKS_URI, c.getInt(COLUMN_ID));
                    ContentValues map = new ContentValues();
                    map.put(Browser.BookmarkColumns.CREATED, creationTime);
                    map.put(Browser.BookmarkColumns.TITLE, title);
                    map.put(Browser.BookmarkColumns.BOOKMARK, 1);
                    map.put(Browser.BookmarkColumns.CATID, (int) catID);
                    getContentResolver().update(record, map, null, null);
                } else {
                    // Adding a bookmark for a site the user has not been to.
                    ContentValues map = new ContentValues();
                    map.put(Browser.BookmarkColumns.TITLE, title);
                    map.put(Browser.BookmarkColumns.URL, url);
                    map.put(Browser.BookmarkColumns.CREATED, creationTime);
                    map.put(Browser.BookmarkColumns.BOOKMARK, 1);
                    map.put(Browser.BookmarkColumns.DATE, 0);
                    map.put(Browser.BookmarkColumns.VISITS, 0);
                    if (mAdapter.getCount() <= 0) {
                        Toast.makeText(this, R.string.no_category_exist, 
                            Toast.LENGTH_SHORT).show();
                        return false;
                    }

                    map.put(Browser.BookmarkColumns.CATID, catID);
                    cr.insert(Browser.BOOKMARKS_URI, map);
                }
                WebIconDatabase.getInstance().retainIconForPageUrl(url);
                c.deactivate();
                setResult(RESULT_OK);
            }
        } catch (IllegalStateException e) {
            Toast.makeText(this, R.string.no_database, 
                Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
        
