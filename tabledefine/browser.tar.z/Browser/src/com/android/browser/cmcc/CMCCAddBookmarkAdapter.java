package com.android.browser.cmcc;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.provider.Browser;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.TextView;

//import android.util.Log;

public class CMCCAddBookmarkAdapter  extends ArrayAdapter<String> {
    private static String LOGTAG = "AddBookmarkAdapter";
    private String mSelectedCatId = null;
    private Context mContext;
    
    public CMCCAddBookmarkAdapter(Context context, String catid, String category, int res, ArrayList<String> catList){
        super(context, res, catList);

        mContext = context;

        if (catid != null) {
            mSelectedCatId = catid;
        }
    }
   
    //return -1 : not found
    public int getSelectedIndex() {
        if (mSelectedCatId == null) {
            return -1;
        }
 
        for (int i=0; i<getCount(); i++) {
            if (Long.parseLong(mSelectedCatId) == getItemId(i)) {
                return i;
            }
        }
        return -1; 
    }

    public Filter getFilter() {
        return null;
    }

    public int getCount() {
        return CategoryManager.instance(mContext).getCount();
    }

    public String getItem(int position) {
        //load the string for preloaded categories to do the translation.
        if(position < CategoryManager.mPreloadedCategorySize) {
            return CategoryManager.mPreLoadedCategories[position].toString();
        }
        ArrayList<String > nameList = CategoryManager.instance(mContext).getNameList();
        if(nameList != null) {
            return nameList.get(position);
        }
        return "";
    }

    public long getItemId(int position) {
        ArrayList<String > idList = CategoryManager.instance(mContext).getIdList();
        // User default ID.
        if(idList.size() < 1) {
            android.util.Log.w("bookmark", "Category list is empty.");
            return 1;
        }
        return Long.parseLong((String)idList.get(position));
    }
    /* Use android.R.layout.simple_spinner_item instead.
    public View getView(int position, View convertView, ViewGroup parent) {
        //CategoryManager.instance(mContext).updateLocal();
        TextView text = new TextView(mContext);
        text.setText(getItem(position));

        return text;
    }*/

}
