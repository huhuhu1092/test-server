
package com.android.browser.cmcc;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.Gravity;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.text.TextUtils;
import android.util.Log;
/**
 *  Custom layout for an item representing a bookmark in the browser.
 */
public class CMCCCategoryItem extends RelativeLayout {

    private TextView    mTextView;
    private TextView    mCountText;
    private LayoutInflater mFactory;
    private ImageView mImageView;
    private boolean mPreloaded = false;

    /**
     *  Instantiate a bookmark item, including a default favicon.
     *
     *  @param context  The application context for the item.
     */
    CMCCCategoryItem(Context context) {
        super(context);

        mFactory = LayoutInflater.from(context);
        /*
        mFactory.inflate(R.layout.bookmark_item, this);
        mTextView = (TextView) findViewById(R.id.title);
        mUrlText = (TextView) findViewById(R.id.url);
        mImageView = (ImageView) findViewById(R.id.favicon);
        */
        mFactory.inflate(android.R.layout.cmcc_list_4, this);
        mTextView = (TextView) findViewById(android.R.id.text1);
        mTextView.setEllipsize(TextUtils.TruncateAt.END);
        mCountText = (TextView) findViewById(android.R.id.text2);
        mImageView = (ImageView) findViewById(android.R.id.listicon1);
        mCountText.setGravity(Gravity.RIGHT);
    }

    /**
     *  Copy this BookmarkItem to item.
     *  @param item BookmarkItem to receive the info from this BookmarkItem.
     */
    /* package */ void copyTo(CMCCCategoryItem item) {
        item.mTextView.setText(mTextView.getText());
        item.mCountText.setText(mCountText.getText());
    }

    /**
     * Return the name assigned to this bookmark item.
     */
    /* package */ CharSequence getName() {
        return mTextView.getText();
    }

    /**
     * Return the TextView which holds the name of this bookmark item.
     */
    /* package */ TextView getNameTextView() {
        return mTextView;
    }

    /**
     *  Set the new name for the bookmark item.
     *
     *  @param name The new name for the bookmark item.
     */
    /* package */ void setName(String name) {
        mTextView.setText(name);
    }
    
    /**
     *  Set the item count for the bookmark item.
     *  @param url  The new url for the bookmark item.
     */
    /* package */ void setCount(int count) {
        mCountText.setText("(" + count + ")");
    }

    /**
     *  Whether this item is preloaded.
     *  @param url  The new url for the bookmark item.
     */
    /* package */ void setPreloaded(boolean preloaded) {
        /*
        if(mPreloaded) {
            mImageView.setImageResource(android.R.drawable.star_big_on);
        }*/
        mPreloaded = preloaded;
    }

    /* package */ boolean getPreloaded() {
        return mPreloaded;
    }
}
