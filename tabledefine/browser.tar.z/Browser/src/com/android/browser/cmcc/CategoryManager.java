/*
 * Copyright (C) 2006-2007 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser.cmcc;

import java.util.ArrayList;
import android.database.Cursor;
import android.content.ContentResolver;
import android.net.Uri;
import android.content.ContentValues;
import android.provider.Browser;
import android.content.Context;

import com.android.browser.R;

import android.util.Log;

public class CategoryManager {
    private boolean mNeedUpdateLocal;
    private ArrayList<String> al_id;
    private ArrayList<String> al_name;
    
    private static CategoryManager mInstance;    
    private ContentResolver mContentResolver;
    private static final String[] mCagegoryColumnStrings = { Browser.CategoryColumns._ID, 
                                                             Browser.CategoryColumns.NAME };

    private final static String LOGTAG = "CategoryManager";

    // This is used to do translation for the preloaded categories.
    /* package */ static CharSequence[] mPreLoadedCategories;
    /* package */ static int mPreloadedCategorySize;

    public static synchronized CategoryManager instance(Context context) {
        if (mInstance == null) {
            mInstance = new CategoryManager(context);
        }
        return mInstance;
    }

    public static synchronized void onDestroy() {
        mInstance = null;
    }

    public CategoryManager(Context context) {
        mContentResolver = context.getContentResolver(); 
        //always update in the first time
        mNeedUpdateLocal = true; 
    }
    
    // TODO: We can remove all the url/uri because they are all Browser.CATEGORY_URI
    //

    public final Uri insert(Uri url, ContentValues values) {
        mNeedUpdateLocal = true;
        return mContentResolver.insert(url, values);
    }

    public final Cursor query(Uri uri, String[] projection, String selection, 
                            String[] selectionArgs, String sortOrder) {
        return mContentResolver.query(uri, projection, selection, selectionArgs, sortOrder); 
    }

    public final int update(Uri uri, ContentValues values, String where, String[] selectionArgs) {
        mNeedUpdateLocal = true;
        return mContentResolver.update(uri, values, where, selectionArgs);
    }

    public final int delete(Uri url, String where, String[] selectionArgs) {
        mNeedUpdateLocal = true;
        return mContentResolver.delete(url, where, selectionArgs); 
    }

    private void updateLocal() {
        al_id = new ArrayList();
        al_name = new ArrayList();
        Cursor cursor = mContentResolver.query(Browser.CATEGORY_URI, mCagegoryColumnStrings, null, null, null);

        while(cursor.moveToNext()){
            al_id.add(cursor.getString(0));
            al_name.add(cursor.getString(1));
        }
        cursor.close();
    }

    public ArrayList<String> getIdList() {
        if (mNeedUpdateLocal) {
            updateLocal();
            mNeedUpdateLocal = false;
        }
        return al_id;
    }
    
    public ArrayList<String> getNameList() {
        if (mNeedUpdateLocal) {
            updateLocal();
            mNeedUpdateLocal = false;
        }
        return al_name;
    }
 
    public int getCount() {
        if (mNeedUpdateLocal) {
            updateLocal();
            mNeedUpdateLocal = false;
        }
        return al_name.size();
    }

    // We call this every time CMCCAddBookmarkAdapter & CMCCBookmarkExpandableListAdapter
    // are created - it seems enough for all cases, including Changing the global languages.
    /* package */static void loadPreloadedCategories(Context context) {
        mPreLoadedCategories = context.getResources().getTextArray(R.array.categories);
        mPreloadedCategorySize = mPreLoadedCategories.length;
    }       
}


