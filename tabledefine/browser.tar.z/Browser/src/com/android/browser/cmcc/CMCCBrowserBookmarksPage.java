/*
 * Copyright (C) 2006-2007 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.browser.cmcc;

import android.app.AlertDialog;
import android.app.ExpandableListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.ServiceManager;
import android.provider.Browser;
import android.text.IClipboard;
import android.util.Log;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnCreateContextMenuListener;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.ExpandableListView.ExpandableListContextMenuInfo;
import android.widget.ExpandableListView.OnChildClickListener;

import java.util.ArrayList;
import com.android.browser.R;
import oms.app.FrameExpListActivity;
import oms.app.AbsFrameView;


/**
 *  View showing the user's bookmarks in the browser.
 */
public class CMCCBrowserBookmarksPage extends FrameExpListActivity implements OnCreateContextMenuListener{

    private CMCCBookmarkExpandableListAdapter mBookmarksAdapter;            //modify by caobin
    private static final int        SAVE_NEED_UPDATE = 1;
    private static final int        SAVE_NOT_NEED_UPDATE = 2;
    private boolean                 mMaxTabsOpen;
    private CMCCBookmarkItem            mContextHeader;
    private CMCCCategoryItem            mContextHeader_category;
    private boolean                 mCanceled = false;
    private boolean                 mCreateShortcut;
    private boolean mInDeleteView = false;
    
    private final static String LOGTAG = "browser";
    static final private boolean mDebug = false;


    /**
     *  Create a new BrowserBookmarksPage.
     */  
    
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        if (Intent.ACTION_CREATE_SHORTCUT.equals(getIntent().getAction())) {
            mCreateShortcut = true;
        }
        if(mCreateShortcut) {
            setTitle(R.string.bookmarks_create_shortcut);
        }else {
            setTitle(R.string.browser_bookmarks_page_bookmarks_text);
        }

        // OMS: Request for orientation sensor
        //super.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);

        mBookmarksAdapter = new CMCCBookmarkExpandableListAdapter(this, getIntent().getStringExtra("title"), mCreateShortcut, this);
        setListAdapter(mBookmarksAdapter);
        
        mMaxTabsOpen = getIntent().getBooleanExtra("maxTabsOpen", false);
       
        getExpandableListView().setOnChildClickListener(new OnChildClickListener(){
            public boolean onChildClick(ExpandableListView arg0, View arg1,
                    int arg2, int arg3, long arg4) {
                if(mDebug) Log.i(LOGTAG, "in setOnChildClickListener,mCreateShortcut=" + mCreateShortcut);
                if(mDebug) Log.i(LOGTAG, arg2 + ":" + arg3 + ":" +arg4 );
                if (mCanceled) {
                    Log.w("browser", "item clicked when dismising");
                    return true;
                }
                if(!mCreateShortcut) {
                    if(mInDeleteView) {
                        toggleBookmark(arg1, arg2, (int)arg3);
                        return true;
                    }else {
                        loadUrl(arg2, arg3);
                    }
                }else {
                    String url = getUrl(arg2, arg3);
                    if(url.startsWith("file://") || url.startsWith("data:") || 
                            url.startsWith("about:")) {
                        new AlertDialog.Builder(CMCCBrowserBookmarksPage.this)
                                .setTitle(R.string.delete_bookmark)
                                .setIcon(com.android.internal.R.drawable.cmcc_dialog_information)
                                .setMessage(R.string.bookmarks_invalid_shortcut)
                                .setPositiveButton(R.string.ok, null)
                                .show();
                            return true;
                    }

                    final Intent intent = new Intent();
                    intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, new Intent(Intent.ACTION_VIEW,
                            Uri.parse(url)));
                    intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, getBookmarkTitle(arg2, arg3));
                    intent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
                            Intent.ShortcutIconResource.fromContext(CMCCBrowserBookmarksPage.this,
                                    R.drawable.ic_launcher_browser));
                    setResult(RESULT_OK, intent);
                    finish();
                }
                return true;
            }
        });
        
        getExpandableListView().setOnCreateContextMenuListener(this);
        initButtons();
        if(mBookmarksAdapter.getCategoryCount() == 1)
            getExpandableListView().expandGroup(0);
        else
            setButtons();
    }
    //button for adding new bookmark
    private AbsFrameView mNew = null;
    //button for adding new category and delete bookmark
    private AbsFrameView mOne = null;
    //button for selecting all and canceling all selected
    private AbsFrameView mTwo = null;
    private int mTwoBtnState = 0;//0:shows select all , 1:shows diselect all

    private View.OnClickListener mNewBtnListener = new View.OnClickListener(){
    public void onClick(View v){
            saveCurrentPage(true);
        }
    };

    private View.OnClickListener mOneBtnListener = new View.OnClickListener(){
    public void onClick(View v){
            if(isInDeleteView())	   
            	   displayRemoveBookmarksDialog();
            else{
                if(mBookmarksAdapter.getCategoryCount() >= 10){
                    String message = getString(R.string.category_overflow);
                    Toast.makeText(CMCCBrowserBookmarksPage.this, message, Toast.LENGTH_SHORT).show();
                } else {
                    newCagetory();
                }
            }
        }
    };

    private View.OnClickListener mTwoBtnListener = new View.OnClickListener(){
    public void onClick(View v){
            if(!isInDeleteView()){
                showDeleteView();
            }
            else{
            	   if(mTwoBtnState == 0){
                    selectAllBookmark();
                    mTwoBtnState = 1;
                    mTwo.setText(R.string.bookmark_delete_cancel_selectall);
            	   }else{
                    cancelSelectAllBookmark();
                    mTwoBtnState = 0;
                    mTwo.setText(R.string.bookmark_delete_selectall);
            	   }
            }
        }
    };

    private void initButtons(){
        if(mCreateShortcut){
            return;
        }
        mNew = findWinViewById(FRAMENEW);
        mOne = findWinViewById(FRAMEONE);
        mTwo = findWinViewById(FRAMETWO);
        
        mNew.setOnClickListener(mNewBtnListener);
        mNew.setVisibility(View.VISIBLE);
        mNew.setText(R.string.bookmark_new);

        mOne.setOnClickListener(mOneBtnListener);
        mOne.setVisibility(View.VISIBLE);

        mTwo.setOnClickListener(mTwoBtnListener);
        mTwo.setVisibility(View.VISIBLE);

        setBottomVisibility(true);
    }

    private void setButtons(){
        if(mCreateShortcut){
            return;
        }
        int i = mBookmarksAdapter.getExpandedGroupPosition();
        boolean expanded = i < 0 ? false : true; 
        boolean hasChild = false;
        if (expanded) {
            hasChild = mBookmarksAdapter.getChildrenCount(i) > 0;
        }
              
        if(isInDeleteView()){
            mOne.setText(R.string.delete_bookmark);
            //OMS 0098363
            if(mBookmarksAdapter.getCheckedItemCount() >0){
                mOne.setEnabled(true);
            }else{
                mOne.setEnabled(false);
            }
            
            if(expanded){
                //OMS 90347:if the selected group's children are all checked, we will change the button to cacel_selectall
                if(hasChild && mBookmarksAdapter.getCheckedItemCountForGroup(i) == mBookmarksAdapter.getChildrenCount(i)){
                    mTwo.setText(R.string.bookmark_delete_cancel_selectall);
                    mTwoBtnState = 1;
                }else{
                    mTwo.setText(R.string.bookmark_delete_selectall);
                    mTwoBtnState = 0;
                }
                mTwo.setEnabled(hasChild);
            }else{
                mTwo.setText(R.string.bookmark_delete_selectall);
                mTwoBtnState = 0;
                mTwo.setEnabled(false);
            }
        }else{
            mOne.setEnabled(true);
            mOne.setText(R.string.category_page);
            mTwo.setText(R.string.remove_bookmark);
            if(expanded){
                mTwo.setEnabled(hasChild);
            }else{
                mTwo.setEnabled(false);
            }
        }

    }

    @Override
    public void onGroupExpand(int groupPosition) {
        setButtons();
    }
    
    @Override
    public void onGroupCollapse(int groupPosition) {
        setButtons();
    }

    
    @Override
    protected void onDestroy() {
        try {
            CategoryManager.onDestroy();
            if(mBookmarksAdapter != null) {
                mBookmarksAdapter.onDestroy();
            }
        } catch(Exception ee) {
            Log.w("bookmark", "Failure occurred when destroying bookmark cursors. ", ee);
        }
        super.onDestroy();
    }

    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        if(mInDeleteView || mCreateShortcut) {
            return;
        }
        ExpandableListContextMenuInfo i =  (ExpandableListContextMenuInfo) menuInfo;

        if((i.targetView.toString()).indexOf("CMCCCategoryItem") == -1){
            if(mDebug) Log.i(LOGTAG, "child long click");
            
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.cmcc_bookmarkscontext, menu);

            CMCCBookmarkItem b = (CMCCBookmarkItem) i.targetView;
            menu.setHeaderTitle(b.getName()); 

            if (mMaxTabsOpen) {
                menu.findItem(R.id.new_window_context_menu_id).setVisible(
                        false);
            }
        } else {
            if(mDebug) Log.i(LOGTAG, "group long click");
            
            CMCCCategoryItem c = (CMCCCategoryItem) i.targetView;
            if(c.getPreloaded()) {
                // Not allow to remove or rename preloaded categories.
                return;
            }
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.cmcc_categoriescontext, menu);
            menu.setHeaderTitle(c.getName());
        }
    }
    
    public boolean onContextItemSelected(MenuItem item) {
        // It is possible that the view has been canceled when we get to
        // this point as back has a higher priority 

       if (mCanceled) {
            return true;
        }
        
        ExpandableListContextMenuInfo info = (ExpandableListContextMenuInfo)item.getMenuInfo();
        int position = ExpandableListView.getPackedPositionGroup(info.packedPosition);
        if(mDebug) Log.i(LOGTAG, position + ":" + info.id);
        
        if (info == null) {
            return true;
        }
        
        switch (item.getItemId()) {
        case R.id.new_context_menu_id:
            saveCurrentPage(false);
            break;
        case R.id.edit_context_menu_id:
            editBookmark(position,  info.id);
            break;
        case R.id.delete_context_menu_id:
            displayRemoveBookmarkDialog(position,  info.id);
            break;
        case R.id.new_window_context_menu_id:
            openInNewWindow(position,  info.id);
            break;
        case R.id.send_context_menu_id:
            Browser.sendString(CMCCBrowserBookmarksPage.this, getUrl(position,  info.id));
            break;
        case R.id.copy_url_context_menu_id:
            copy(getUrl(position,  info.id));
            break;
        case R.id.move_context_menu_id:
            moveBookmark(position,  info.id);
            break;
        case R.id.rename_category_id:
            renameCategories(position,  info.id);
            break;
        case R.id.delete_category_id:
            displayRemoveCategoryDialog(position,  info.id);
            break;
        default:
            return super.onContextItemSelected(item);
        }
        return true;
    }

    private void saveCurrentPage(boolean blankPage) {
        Intent i = new Intent(CMCCBrowserBookmarksPage.this,
                CMCCAddBookmarkPage.class);
        if (blankPage == false) {
            i.putExtras(getIntent());
        }

        startActivityForResult(i, SAVE_NEED_UPDATE);
    }
    
    private void loadUrl(int groupPosition, long hchildPositionildPosition) {
        setResult(RESULT_OK, (new Intent()).setAction(getUrl(groupPosition, hchildPositionildPosition)));
        finish();
    }

    
    public boolean onCreateOptionsMenu(Menu menu) {
     //we use the btn from FrameListActivity,so the option menu is unnecessary
     return true;
    	/*
        boolean result = super.onCreateOptionsMenu(menu);
        if (!mCreateShortcut) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.cmcc_bookmarks, menu);
            return true;
        }
        return result;
     */
    }
    public boolean onPrepareOptionsMenu(Menu menu){
    	   //we use the btn from FrameListActivity,so the option menu is unnecessary
        return true;
/*
        // Disable options menu in shortcut mode.
        if(mCreateShortcut) {
            return false;
        }

        int i = mBookmarksAdapter.getExpandedGroupPosition();
        boolean expanded = i < 0 ? false : true; 
        boolean hasChild = false;
        if (expanded) {
            hasChild = mBookmarksAdapter.getChildrenCount(i) > 0;
        }

        if(mInDeleteView){
            menu.setGroupVisible(R.id.BOOKMARK_MAIN, false);
            menu.setGroupVisible(R.id.BOOKMARK_DELETE, true);

            menu.findItem(R.id.selectall_menu_id).setVisible(expanded && hasChild);
            menu.findItem(R.id.cancel_selectall_menu_id).setVisible(expanded && hasChild);
            return true;
        } else {
            menu.setGroupVisible(R.id.BOOKMARK_MAIN, true);
            menu.findItem(R.id.delete_menu_id).setVisible(expanded && hasChild);
            menu.setGroupVisible(R.id.BOOKMARK_DELETE, false);
            return true;
        }
*/
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_context_menu_id:
                saveCurrentPage(false);
                break;
            case R.id.new_bookmark_menu_id:
                saveCurrentPage(true);
                break;
            case R.id.new_category_menu_id:
                if(mBookmarksAdapter.getCategoryCount() >= 10){
                    String message = this.getString(R.string.category_overflow);
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                } else {
                    newCagetory();
                }
                break;
            case R.id.delete_menu_id:
                showDeleteView();
                break;
            case R.id.delete_bookmarks_menu_id:
                displayRemoveBookmarksDialog();
                break;
            case R.id.selectall_menu_id:
                selectAllBookmark();
                break;
            case R.id.cancel_selectall_menu_id:
                cancelSelectAllBookmark();
                break;
            /*case R.id.reverse_select_menu_id:
                reverseSelectallBookmark();
                break;*/
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }

    private void openInNewWindow(int groupPosition, long childPosition) {
        Bundle b = new Bundle();
        b.putBoolean("new_window", true);
        setResult(RESULT_OK,
                (new Intent()).setAction(getUrl(groupPosition, childPosition)).putExtras(b));

        finish();
    }
    
    // Called when we are going into delete view.
    private void showDeleteView() {
        mInDeleteView = true;
        setTitle(R.string.remove_bookmark);

        // Remember which group is expanded now and expand it in the delete view.
        int expandedGrp = mBookmarksAdapter.getExpandedGroupPosition();

        ExpandableListView list = getExpandableListView();
        mBookmarksAdapter.clearCheckedList();
        //list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        if(expandedGrp >= 0) {
            // Collapsing the group will do it a simple refresh.
            list.collapseGroup(expandedGrp);
            list.expandGroup(expandedGrp);
        }
        setButtons();
    }

    // Called when we are resumed from delete view.
    private void showMainView() {
        mCanceled = false;
        mInDeleteView = false;
        setTitle(R.string.browser_bookmarks_page_bookmarks_text);
        // Remember which group is expanded now and expand it in the bookmark view.
        int expandedGrp = mBookmarksAdapter.getExpandedGroupPosition();

        ExpandableListView list = getExpandableListView();
        //list.unSelectAll();

        if(expandedGrp >= 0) {
            // Collapsing the group will do it a simple refresh.
            list.collapseGroup(expandedGrp);
            list.expandGroup(expandedGrp);
        }
        setButtons();
    }

    public boolean isInDeleteView() {
        return mInDeleteView;
    }

    private void deleteBookmarks() {
        // Remember which group is expanded now and expand it in the delete view.
        //int expandedGrp = mBookmarksAdapter.getExpandedGroupPosition();

        mBookmarksAdapter.deleteBookmarks();
        refreshList();
        /*
        if(expandedGrp >= 0) {
            // Collapsing the group will do it a simple refresh.
            getExpandableListView().collapseGroup(expandedGrp);
            getExpandableListView().expandGroup(expandedGrp);
        }*/
    }
    
    private void selectAllBookmark() {
        // Remember which group is expanded now and expand it later  
        // to do the refresh.
        int expandedGrp = mBookmarksAdapter.getExpandedGroupPosition();

        //getExpandableListView().selectAll();
        mBookmarksAdapter.selectAll();
        
        if(expandedGrp >= 0) {
            // Collapsing the group will do it a simple refresh.
            getExpandableListView().collapseGroup(expandedGrp);
            getExpandableListView().expandGroup(expandedGrp);
        }
    }
    
    private void cancelSelectAllBookmark() {
        // Remember which group is expanded now and expand it later  
        // to do the refresh.
        int expandedGrp = mBookmarksAdapter.getExpandedGroupPosition();

        //getExpandableListView().unSelectAll();
        mBookmarksAdapter.cancelSelectAll();

        if(expandedGrp >= 0) {
            // Collapsing the group will do it a simple refresh.
            getExpandableListView().collapseGroup(expandedGrp);
            getExpandableListView().expandGroup(expandedGrp);
        }
    }

    private void toggleBookmark(View view, int groupPosition, int childPosition) {
        if(!(view instanceof CMCCBookmarkItem)) {
            return;
        }

        CMCCBookmarkItem item = (CMCCBookmarkItem)view;
        item.toggle();
        //mBookmarksAdapter.toggleBookmark(groupPosition, childPosition, item.isChecked());
        mBookmarksAdapter.toggleBookmark(item.getBookmarkId(), item.isChecked());
        //OMS 90347:check if we should change the select_button
        setButtons();
    }

    private void editBookmark(int groupPosition, long childPosition) {
        Intent intent = new Intent(CMCCBrowserBookmarksPage.this, 
                CMCCAddBookmarkPage.class);
        intent.putExtra("bookmark", getRow(groupPosition, childPosition));
        startActivityForResult(intent, SAVE_NEED_UPDATE);
    }
    
    private void moveBookmark(int groupPosition, long childPosition) {
        final Bundle bookmarkMap = getRow(groupPosition, childPosition);

        // Build the category item CharSequence for the single select, 
        // as we have some preloaded categories need to be translated.
        ArrayList<String> categoryList = CategoryManager.instance(this).getNameList();
        int itemCount = categoryList.size();
        CharSequence[] categoryItems = new CharSequence[itemCount];
        for(int i=0; i<itemCount; i++) {
            if(i < CategoryManager.mPreloadedCategorySize) {
                categoryItems[i] = CategoryManager.mPreLoadedCategories[i];
            }else {
                categoryItems[i] = categoryList.get(i);
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setSingleChoiceItems(categoryItems, groupPosition, new DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialog, int which) {
                    moveBookmark(bookmarkMap, which);
                    dialog.dismiss();
                }})
        .show();
    }

    private void moveBookmark(Bundle map, int index) {
        int oldId = Integer.parseInt(map.getString(Browser.BookmarkColumns.CATID));
        Bundle catMap = mBookmarksAdapter.getCategoryRow(index, 0);
        int newId = catMap == null ? -1 : Integer.parseInt(catMap.getString(Browser.CategoryColumns._ID));
        if(oldId == newId) return;
        
        map.putString(Browser.BookmarkColumns.CATID, Integer.toString(newId));
        mBookmarksAdapter.updateRow(map);
        Toast.makeText(this, R.string.bookmark_saved, Toast.LENGTH_SHORT).show();
    }

    private void newCagetory() {
        Intent i = new Intent(CMCCBrowserBookmarksPage.this,
                CMCCAddCategoryPage.class);
        startActivityForResult(i, SAVE_NOT_NEED_UPDATE);
    }

    private void  renameCategories(int groupPosition, long childPosition) {
        Intent intent = new Intent(CMCCBrowserBookmarksPage.this, 
                CMCCAddCategoryPage.class);
        //intent.putExtra("bookmark", getCategoryRow(groupPosition, childPosition));
        intent.putExtra("bookmark", getCategoryRow(groupPosition, childPosition));
        startActivityForResult(intent, SAVE_NOT_NEED_UPDATE);
    }

    private void displayRemoveCategoryDialog(final int groupPosition, final long childPosition) {
        String title = getCategoryRow(groupPosition, childPosition).getString(Browser.CategoryColumns.NAME);
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_category)
                .setIcon(com.android.internal.R.drawable.cmcc_dialog_question2)
                .setMessage(getText(R.string.delete_category_warning).toString().replace(
                        "%s", title))
                .setPositiveButton(R.string.ok, 
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                deleteCategory(groupPosition, childPosition);
                            }
                        })
                .setNegativeButton(R.string.cancel, null) 
                .show();
    }
      
    private void deleteCategory(final int groupPosition, final long childPosition) {
        String id = getCategoryRow(groupPosition, childPosition).getString(Browser.CategoryColumns._ID);;
        mBookmarksAdapter.onGroupExpanded(-1);//collapse all groups
        this.getContentResolver().delete(Browser.BOOKMARKS_URI,  Browser.BookmarkColumns.CATID+" = ?", new String[]{ id     });
        CategoryManager.instance(this).delete(Browser.CATEGORY_URI,  Browser.CategoryColumns._ID+" = ?", new String[]{ id });
        refreshList();
    }
  
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        switch(requestCode) {
            case SAVE_NEED_UPDATE:
                if (resultCode == RESULT_OK) {
                    Bundle extras;
                    if (data != null && (extras = data.getExtras()) != null) {
                        // If there are extras, then we need to save
                        // the edited bookmark. This is done in updateRow()
                        String title = extras.getString("title");
                        String url = extras.getString("url");
                        String catid = extras.getString("catid");
                        if (title != null && url != null  && catid != null) {
                            mBookmarksAdapter.updateRow(extras);
                        }
                        refreshList();
                    } else {
                        // extras == null then a new bookmark was added to
                        // the database.
                        refreshList();
                    }
                }
                break;
            case SAVE_NOT_NEED_UPDATE:
                refreshList();
                 break;
            default:
                break;
        }
    }
    
    private void displayRemoveBookmarkDialog(final int groupPosition, final long childPosition) {
        // Put up a dialog asking if the user really wants to
        // delete the bookmark
        //final int deletePos = position;
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_bookmark)
                .setIcon(com.android.internal.R.drawable.cmcc_dialog_question2)
                .setMessage(getText(R.string.delete_bookmark_warning).toString().replace(
                        "%s", getBookmarkTitle(groupPosition, childPosition)))
                .setPositiveButton(R.string.ok, 
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                deleteBookmark(groupPosition, childPosition);
                            }
                        })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void displayRemoveBookmarksDialog() {
        // Prompt if nothing checked.
        if(mBookmarksAdapter.getCheckedItemCount() <= 0) {
            Toast.makeText(this, R.string.bookmak_no_checked, Toast.LENGTH_SHORT).show();
            mInDeleteView = true;
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_bookmark)
                .setIcon(com.android.internal.R.drawable.cmcc_dialog_question2)
                .setMessage(R.string.delete_bookmarks_warning)
                .setPositiveButton(R.string.ok, 
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                deleteBookmarks();
                                mInDeleteView = false;
                                //OMS 0096374:go to main view
                                showMainView();
                            }
                        })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    /**
     *  Refresh the shown list after the database has changed.
     */
    public void refreshList() {
        mBookmarksAdapter.refreshList();
    }
    
    /**
     *  Return a hashmap representing the currently highlighted row.
     */
    public Bundle getRow(int groupPosition, long childPosition) {
        return mBookmarksAdapter.getRow(groupPosition, childPosition);
    }
    
    public Bundle getCategoryRow(int groupPosition, long childPosition) {
        return mBookmarksAdapter.getCategoryRow(groupPosition, childPosition);
    }
    
    
    /**
     *  Return the url of the currently highlighted row.
     */
    public String getUrl(int groupPosition, long childPosition) {
        return mBookmarksAdapter.getUrl(groupPosition, childPosition);
    }

    private void copy(CharSequence text) {
        try {
            IClipboard clip = IClipboard.Stub.asInterface(ServiceManager.getService("clipboard"));
            if (clip != null) {
                clip.setClipboardText(text);
            }
        } catch (android.os.RemoteException e) {
            Log.e(LOGTAG, "Copy failed", e);
        }
    }
    
    public String getBookmarkTitle(int groupPosition, long childPosition) {
        return mBookmarksAdapter.getTitle(groupPosition, childPosition);
    }

    /**
     *  Delete the currently highlighted row.
     */
    public void deleteBookmark(int groupPosition, long childPosition) {
        mBookmarksAdapter.deleteRow(groupPosition, childPosition);
    }
    
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() ==  KeyEvent.KEYCODE_BACK && 
                event.getAction() == KeyEvent.ACTION_DOWN) {
            // Return back to bookmark view if we are now in delete view.
            if(mInDeleteView) {
                showMainView();
                return true;
            }else {
                setResult(RESULT_CANCELED);
                mCanceled = true;
            }
        }
        return super.dispatchKeyEvent(event);
    }
}
