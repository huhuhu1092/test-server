package com.android.browser.cmcc;

import android.app.Activity;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Browser;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.res.Resources;

import com.android.browser.R;
//import android.util.Log;

public class CMCCAddCategoryPage extends Activity {
    
    private EditText    mTitle;
    private EditText    mAddress;
    private TextView    mButton;
    private View        mCancelButton;
    //private Bundle      mMap;
    private boolean     mRename = false;//false indicate 'add new category', true indiate 'rename a category'
    private String      mCategoryId = "-1";
    private String      mOldCategoryName;
    
    private static final String     WHERE_CLAUSE = "name = ?";
    private final String[]          SELECTION_ARGS = new String[1];
    
    private static final String[]   mCagegoryColumnStrings = 
    { Browser.CategoryColumns._ID, 
      Browser.CategoryColumns.NAME };
    
    //private final String LOGTAG = "AddCategoryPage";
    
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.cmcc_add_category);
        setTitle(R.string.category_page);
        
        mTitle = (EditText) findViewById(R.id.title);
        Bundle mMap = getIntent().getExtras();
        if (mMap != null) {
            Bundle b = mMap.getBundle("bookmark");
            if (b != null) {
                mMap = b;
                mCategoryId = mMap.getString(Browser.CategoryColumns._ID);
                mOldCategoryName = mMap.getString(Browser.CategoryColumns.NAME);
                mTitle.setText(mOldCategoryName);
            }
            setTitle(R.string.rename_category);
            mRename = true;
        }

        View.OnClickListener accept = mSaveBookmark;
        mButton = (TextView) findViewById(R.id.OK);
        mButton.setOnClickListener(accept);

        mCancelButton = findViewById(R.id.cancel);
        mCancelButton.setOnClickListener(mCancel);
    }
    
    private View.OnClickListener mSaveBookmark = new View.OnClickListener() {
        public void onClick(View v) {
            if (save()) {
                finish();
            }
        }
    };

    private View.OnClickListener mCancel = new View.OnClickListener() {
        public void onClick(View v) {
            finish();
        }
    };
    
    boolean save() {
        String title = mTitle.getText().toString().trim();
        boolean emptyTitle = title.length() == 0;
        Resources r = getResources();
        if (emptyTitle) {
            Toast.makeText(this, R.string.category_needs_title, 
                Toast.LENGTH_SHORT).show();
            return false;
        }
        if(mRename && mOldCategoryName != null && mOldCategoryName.equals(title)) {
            return true;
        }

        SELECTION_ARGS[0] = title;  
        ContentResolver cr = getContentResolver();

        // See if it's existed in the preloaded ones.
        if(CategoryManager.mPreLoadedCategories != null) {
            for(int i=0; i<CategoryManager.mPreloadedCategorySize; i++) {
                if(CategoryManager.mPreLoadedCategories[i] != null && 
                        title.equals(CategoryManager.mPreLoadedCategories[i])) {
                    Toast.makeText(this, R.string.category_already_existed, 
                        Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        }

        try {
            Cursor c = CategoryManager.instance(this).query(Browser.CATEGORY_URI,
                new String[]{ "name" }, WHERE_CLAUSE, SELECTION_ARGS,null);
	 
            if (c.moveToFirst()) {//if already existed, will not add it
                Toast.makeText(this, R.string.category_already_existed, 
                    Toast.LENGTH_SHORT).show();
                return false;
            }
            //OMS 0097878:We should close it when finished use.
            c.close();
            ContentValues map = new ContentValues();
            map.put(Browser.CategoryColumns.NAME, mTitle.getText().toString().trim());
            if(mRename) {
                map.put(Browser.CategoryColumns._ID, mCategoryId);
                CategoryManager.instance(this).update(Browser.CATEGORY_URI, map, 
                    Browser.CategoryColumns._ID + " = " + mCategoryId, null);
            }else { 
                CategoryManager.instance(this).insert(Browser.CATEGORY_URI, map);
            }
            return true;
        } catch (IllegalStateException e) {
            Toast.makeText(this, R.string.no_database, 
                Toast.LENGTH_SHORT).show();
             return false;
        }
    }
        
}
