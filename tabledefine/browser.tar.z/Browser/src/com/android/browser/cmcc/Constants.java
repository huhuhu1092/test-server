
package com.android.browser.cmcc;

class Constants {

    // Value to truncate strings when adding them to a TextView within
    // a ListView. Keep it in sync with what's in Browser.Settings.
    public final static int MAX_TEXTVIEW_LEN = 80;

    Constants() {
    }
}