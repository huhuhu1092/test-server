
package com.android.browser.cmcc;

class CMCCConstants {

    public final static int MAX_TEXTVIEW_LEN = 80;

    CMCCConstants() {
    }
}