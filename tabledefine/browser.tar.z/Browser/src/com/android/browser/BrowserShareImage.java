package com.android.browser;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.app.AlertDialog;
import android.webkit.CacheManager;
import android.webkit.URLUtil;
import android.content.DialogInterface;

import android.util.Log;

public class BrowserShareImage{

    private BrowserActivity mActivity;
    //image's url
    private String mUrl;
    //the file path we save the image
    private String mTempFilePath = "/sdcard/tmp/";
    //the image's name(guess from url)
    private String mFileName = null;
    //the image's mime type(from cache or from http header)
    private String mMimeType = null;
    //the inputstream from http or cache
    private InputStream mInStream = null;
    //the dload obj which is used to download the image
    private DownloadImage mDload = null;
    //the notice dialog when downloading the image
    private AlertDialog mDlg = null;
    
    public BrowserShareImage(BrowserActivity act, String url){
        mActivity = act;
        mUrl = url;
    }

    public void share(){
        mFileName = URLUtil.guessFileName(mUrl,null,null);
        // Check to see if we have an SDCard
        String status = Environment.getExternalStorageState();
        if (!status.equals(Environment.MEDIA_MOUNTED)) {
            int title;
            String msg;

            // Check to see if the SDCard is busy
            if (status.equals(Environment.MEDIA_SHARED)) {
                msg = mActivity.getString(R.string.download_sdcard_busy_dlg_msg);
                title = R.string.download_sdcard_busy_dlg_title;
            } else {
                msg = mActivity.getString(R.string.download_no_sdcard_dlg_msg, mFileName);
                title = R.string.download_no_sdcard_dlg_title;
            }

            new AlertDialog.Builder(mActivity)
                .setTitle(title)
                .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                .setMessage(msg)
                .setPositiveButton(R.string.ok, null)
                .show();
            return;
        }

        CacheManager.CacheResult res = CacheManager.getCacheFile(mUrl,null);
        //if we can not find the image in the cache, then download it.
        if(null == res){
            mDload = new DownloadImage();
            mDload.execute();
            showLoadingDlg();
            return;
        }else{
            mInStream = res.getInputStream();
            mMimeType = res.getMimeType();
        }
        writeAndSend();
    }

    //write the image file, and send it to the 3rd app.
    private void writeAndSend(){
        //if we have not get the input stream yet, return.
        if(mInStream == null){
            new AlertDialog.Builder(mActivity)
                .setTitle(R.string.failed_share_image)
                .setIcon(com.android.internal.R.drawable.cmcc_dialog_notice)
                .setMessage(R.string.failed_info_share_image)
                .setPositiveButton(R.string.ok, null)
                .show();
            return;
        }
        try{
            //write file.
            FileOutputStream fos = new FileOutputStream(mTempFilePath+mFileName);
            byte buf[] = new byte[128];
            int readnum;
            do{
                readnum = mInStream.read(buf);
                if(readnum<=0){
                    break;
                }
                fos.write(buf,0,readnum);
            }while(true);
            fos.close();
            mInStream.close();
            mInStream = null;
        }catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        File f = null;
        f = new File(mTempFilePath+mFileName);
        //send it
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setDataAndType(Uri.fromFile(f),mMimeType);
        send.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(f));

        try {
            mActivity.startActivity(Intent.createChooser(send, mUrl));
        } catch(android.content.ActivityNotFoundException ex) {
            // if no app handles it, do nothing
        }
    }
    //the download task
    private class DownloadImage extends AsyncTask<Void,Void,InputStream>{
        @Override
        protected InputStream doInBackground(Void... urls) {
            try{
                URL url = new URL(mUrl);
                URLConnection conn = url.openConnection();
                mMimeType = conn.getContentType();
                conn.connect();
                return conn.getInputStream();
            }catch(Exception e){
                e.printStackTrace();
                return null;
            }
        }
        @Override
        protected void onPostExecute(InputStream result) {
            mInStream = result;
            //dismiss the notice dialog
            if(null != mDlg){
                mDlg.dismiss();
                mDlg = null;
            }
            writeAndSend();
        }

    }
    //show the notice dialog when in downloading.
    private void showLoadingDlg(){
        mDlg = new AlertDialog.Builder(mActivity)
            .setIcon(com.android.internal.R.drawable.cmcc_dialog_information)
            .setTitle(R.string.download_running)
            .setMessage(R.string.waiting_share_image)
            .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialog, int which) {
                    if(mDload != null){
                        mDload.cancel(true);
                        mDload = null;
                    }
                }
            })
            .show();
    }

}
