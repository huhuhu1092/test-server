
package com.android.browser;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

public class BrowserReceiver extends BroadcastReceiver {
     @Override
     public void onReceive(Context context, Intent intent) {
         String action = intent.getAction();
         if("oms.action.MASTERRESET".equals(action) ){
             BrowserSettings.getInstance().resetDefaultPreferences(context);
         } else if ("android.permission.MASTER_CLEAR".equals(action) ) {
             BrowserProvider.resetBrowserTables(context);
            // TODO: clear cookies, cache...
         }
     }
}


