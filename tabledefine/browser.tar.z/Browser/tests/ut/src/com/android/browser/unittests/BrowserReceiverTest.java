package com.android.browser.unittests;

import android.content.Context;
import android.content.Intent;
import android.test.AndroidTestCase;
import android.test.mock.MockContext;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.MediumTest;
import android.test.suitebuilder.annotation.Suppress;

import com.android.browser.BrowserReceiver;

/**
 * Test BrowserReceiver.java.
 * @author b391(LuoXiaofei)
 *
 */
@Suppress
public class BrowserReceiverTest extends AndroidTestCase {

	private Context mContext;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mContext = getContext();
	}

	@Override
	protected void tearDown() throws Exception {
		mContext = null;
		super.tearDown();
	}

	/**
	 * there tests method onReceive and intent.action="oms.action.MASTERRESET"
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonReceive() throws Exception {
		Intent intent = new Intent("oms.action.MASTERRESET");
		BrowserReceiver browserReceiver = new BrowserReceiver();
		browserReceiver.onReceive(mContext, intent);
	}

	/**
	 * there tests method onRceive and
	 * intent.action="android.permission.MASTER_CLEAR"
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testonReceiveaction() throws Exception {
		MockContext mc = new MockContext();
		Intent intent = new Intent("android.permission.MASTER_CLEAR");
		BrowserReceiver browserReceiver = new BrowserReceiver();
		browserReceiver.onReceive(mc, intent);
	}
}
