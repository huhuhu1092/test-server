package com.android.browser.unittests;

import com.android.browser.BrowserHelper;
import com.android.browser.unittests.testutil.Helper;

import android.os.SystemClock;
import android.test.AndroidTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.MediumTest;

/**
 * Test class of BrowserHelper
 * @author I087(Cao Lina)
 *
 */
public class BrowserHelperTest extends AndroidTestCase {

	public BrowserHelperTest() {
		super();
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	/**
	 * test the BrowserHelper's constructor
	 * @throws Exception
	 */
	@MediumTest
	public void testConstructor()throws Exception{
	    assertNotNull(new BrowserHelper());
	}
	/**
	 * test method of sendData()with five parameter and method=POST
	 * @throws Exception
	 */
	@LargeTest
	public void testSendDataWithFiveParameter() throws Exception{
		try{
		BrowserHelper.sendData("file:///sdcard/Download","POST","t","test","test");
		SystemClock.sleep(5000);
		}catch(IllegalStateException ex){
			assertNotNull(ex);
		}
	}
	/**
	 * test method of sendData() with method !=POST
	 * @throws Exception
	 */
	@LargeTest
	public void testSendDataWithMethodIsNotPost() throws Exception{
		try{
		BrowserHelper.sendData("/sdcard/Download","GET","&&&","test","test");
		SystemClock.sleep(5000);
		}catch(IllegalStateException ex){
			assertNotNull(ex);
		}
	}
	 /**
	  * test method of sendData() with seven parameter
	  * @throws Exception
	  */
	@LargeTest
	public void testSendDataWithSevenParamter() throws Exception{
		BrowserHelper.sendData("http://www.baidu.com", "GET", "test",null,"Firefox","2.89.3.8", 80);
		SystemClock.sleep(5000);
	}

}
