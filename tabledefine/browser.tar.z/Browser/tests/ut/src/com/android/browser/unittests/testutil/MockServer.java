package com.android.browser.unittests.testutil;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.StringTokenizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.util.Config;
import android.util.Log;

public class MockServer {
	protected String docroot;
	protected int port;
	protected ServerSocket ss;
	private static final String TAG = "MockServer";

	/*public MockServer(String[] args) throws Exception {
		Log.d(TAG, "Checking for paramaters");
		parseParams(args);
		Log.d(TAG, "Starting web server......");
		this.ss = new ServerSocket(this.port);
		Log.d(TAG, "OK");
		while(true){
			Socket accept = ss.accept();
			Log.d(TAG, "Socket create OK");
			new Handler(accept, docroot).start();
			Log.d(TAG, "Handler");
		}

	}*/


	public static class Handler extends Thread {
		protected Socket socket;
		protected PrintWriter pw;
		protected BufferedOutputStream bos;
		protected BufferedReader br;
		protected File docroot;

		public Handler(Socket _socket, String _docroot) throws IOException {
			socket = _socket;
			docroot = new File(_docroot).getCanonicalFile();
		}

		public void run() {
			try {
				br = new BufferedReader(new InputStreamReader(socket
						.getInputStream()));
				bos = new BufferedOutputStream(socket.getOutputStream());
				pw = new PrintWriter(new OutputStreamWriter(bos));
				String line = br.readLine();
				socket.shutdownInput();
				if (line == null) {
					socket.close();
					return;
				}
				if (line.toUpperCase().startsWith("GET")) {
					StringTokenizer tokens = new StringTokenizer(line, " ?");
					tokens.nextToken();
					String req = tokens.nextToken();
					String name;
					if (req.startsWith("/") || req.startsWith("\\"))
						name = this.docroot + req;
					else
						name = this.docroot + File.separator + req;
					File file = new File(name).getCanonicalFile();
					if (!file.getAbsolutePath().startsWith(
							this.docroot.getAbsolutePath())) {
						pw.println("HTTP/1.0 403 Forbidden");
						pw.println();
					} else if (!file.exists()) {
						pw.println("HTTP/1.0 404 File Not Found");
						pw.println();
					} else if (!file.canRead()) {
						pw.println("HTTP/1.0 403 Forbidden");
						pw.println();
					} else if (file.isDirectory()) {
						sendDir(bos, pw, file, req);
					} else {
						sendFile(bos, pw, file.getAbsolutePath());
					}
				} else {
					pw.println("HTTP/1.0 501 Not Implemented");
					pw.println();
				}
				pw.flush();
				bos.flush();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			try {
				socket.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}

		protected void sendFile(BufferedOutputStream bos, PrintWriter pw,
				String filename) throws IOException {
			try {
				BufferedInputStream bis = new BufferedInputStream(
						new FileInputStream(filename));
				byte[] data = new byte[10 * 1024];
				int read = bis.read(data);
				pw.println("HTTP/1.0 200 Okay");
				pw.println();
				pw.flush();
				bos.flush();
				while (read != -1) {
					bos.write(data, 0, read);
					read = bis.read(data);
				}
				bos.flush();
			} catch (Exception ex) {
				pw.flush();
				bos.flush();
			}
		}

		protected void sendDir(BufferedOutputStream bos, PrintWriter pw,
				File dir, String req) throws IOException {
			try {
				pw.println("HTTP/1.0 200 Okay");
				pw.println();
				pw.flush();
				pw.print("<html><head><titleDirectory of ");
				pw.print(req);
				pw.print("</title></head><body><h1>Directory of ");
				pw.print(req);
				pw.println("</h1><table border=0>");
				File[] contents = dir.listFiles();
				for (int i = 0; i < contents.length; i++) {
					pw.print("<tr>");
					pw.print("<td><a href=\"");
					pw.print(req);
					pw.print(contents[i].getName());
					if (contents[i].isDirectory())
						pw.print("/");
					pw.print("\">");
					if (contents[i].isDirectory())
						pw.print("Dir -> ");
					pw.print(contents[i].getName());
					pw.print("</a></td>");
					pw.println("</tr>");
				}
				pw.println("</table></body></html>");
				pw.flush();
			} catch (Exception ex) {
				pw.flush();
				bos.flush();
			}
		}
	}

	/*protected void parseParams(String[] args) {
		switch (args.length) {
		case 1:
		case 0:
			System.err.println("Syntax: <jvm> " + this.getClass().getName()
					+ " docroot port");
			System.exit(0);
		default:
			this.docroot = args[0];
			this.port = Integer.parseInt(args[1]);
			break;
		}
	}*/
	
	private static boolean sServerEstablished = false;
	private static boolean sServerListen = false;
	private static ServerSocket sServer = null;
	private static final int SO_TIMEOUT = 3000;
	private static int sConnectionFailure = 0;
	
	private static Object sStartSync = new Object();
	private static Object sStopSync = new Object();
	
	/**
	 * Start MockServer to listen.
	 * @param port
	 * @param docRoot
	 * @return true if start successfully, otherwise false.
	 */
	synchronized public static boolean start(int port, String docRoot) {
		
		if (!sServerEstablished) {
			//Start ServerSocket to listen
			synchronized (sStartSync) {
				new ServerListenThread(port, docRoot).start();
				log("ServerSocket Listen Thread start.");
				
				//Wait for Server to establish
				try {
					sStartSync.wait();
					log("ServerSocket start Listening.");
				} catch (InterruptedException ie) {
					ie.printStackTrace();
				}
			}
		}	
		
		return sServerEstablished;		
	}
	
	/**
	 * Stop SocketServer listening and close it.
	 */
	synchronized public static void stop() {
		if (sServerEstablished) {
			synchronized (sStopSync) {
				//Stop Listening
				sServerListen = false;
				try {
					sStopSync.wait();
					log("ServerSocket Listen Thread stop.");
				} catch (InterruptedException ie) {
					ie.printStackTrace();
				} 
			}
		}
	}
	
	private static class ServerListenThread extends Thread {
		
		private int _Port;
		private String _DocRoot;
		
		private ServerListenThread(int port, String docRoot) {
			_Port = port;
			_DocRoot = docRoot;
		}
		
		public void run() {
			try {
				sServer = new ServerSocket(_Port);
				sServer.setSoTimeout(SO_TIMEOUT);
				sServerEstablished = true;
			} catch (IOException ioe) {
				sServerEstablished = false;
				log("SocketServer fail to establish.");
				ioe.printStackTrace();
				return;
			} finally {
				synchronized (sStartSync) {
					sStartSync.notify();
				}
			}

			sServerListen = true;
			sConnectionFailure = 0;
			final ExecutorService pool = Executors.newCachedThreadPool();
			
			while (sServerListen) {
				try {
					pool.execute(new Handler(sServer.accept(), _DocRoot));
				} catch (SocketTimeoutException soe) {
					continue;
				} catch (IOException ioe) {
					sConnectionFailure++;
					ioe.printStackTrace();
					continue;
				}				
			}
			
			//Listen stop and close ServerSocket.
			pool.shutdownNow();
			
			try {
				sServer.close();
			} catch (IOException ie) {
				ie.printStackTrace();
			} finally {
				sServer = null;
				sServerEstablished = false;
			}
			
			synchronized (sStopSync) {
				sStopSync.notify();
			}
			
		}		
	}
	
	/**
	 * Test if MockHttpServer is established.
	 * @return
	 */
	public static boolean isServerEstablished() {
		return sServerEstablished;
	}
	
	/**
	 * Get connection failure count.
	 * @return
	 */
	public static int getConnectionFailCount() {
		return sConnectionFailure;
	}
	
	private static void log(String msg) {
		if (Config.DEBUG)
			Log.d(TAG, msg);
	}

}