package com.android.browser;

import android.app.Instrumentation;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.SystemClock;
import android.telephony.TelephonyManager;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.webkit.MotWebView;

import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;
/**
 * test FlashBrowserActivity.
 * @author wsj
 *
 */
@Suppress
public class FlashBrowserActivityUTTest extends InstrumentationTestCase {
	private Instrumentation mInst;
	private static BrowserActivity mActivity = null;
	private static boolean flag = true;
	private static int mCount = 0;
	private static FlashBrowserActivity mFlashBrowser;

	public FlashBrowserActivityUTTest() {
		super();
		mCount++;
	}

	 
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		if (flag) {
			mActivity = getBrowserActivity();
			mFlashBrowser = getFlashBrowserActivity();
			mFlashBrowser.onDestroy();
			flag = false;
		}
	}

	 
	protected void tearDown() throws Exception {
//		Log.e("*******************", " " + mCount);
		mCount--;
		if (mCount == 0 && mActivity != null) {
			// mActivity.finish();
			mActivity.goQuit();
			SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
			mActivity = null;
			Helper.deleteFileAndFolder("/sdcard");
			mFlashBrowser = null;
		}
		mInst = null;
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
		super.tearDown();
	}

/**
 * test onKeyDown
 * @throws Exception
 */
	@LargeTest
	public void testonKeyDown() throws Exception {
//		assertNotNull(mFlashBrowser = getFlashBrowserActivity());
		KeyEvent ev = new KeyEvent(KeyEvent.KEYCODE_2, 0);
		mFlashBrowser.onKeyDown(KeyEvent.KEYCODE_BACK, ev);

		ReflectHelper.setPrivateField(mFlashBrowser, "isFlashFullScreenMode",
				true);
		mFlashBrowser.onKeyDown(KeyEvent.KEYCODE_BACK, ev);

	}
/**
 * test flashFullScreenMode 
 * @throws Exception
 */
	@LargeTest
	public void testflashFullScreenMode() throws Exception {
//		assertNotNull(mFlashBrowser = getFlashBrowserActivity());
		mFlashBrowser.flashFullScreenMode();

	}
/**
 * test onReceive
 * @throws Exception
 */
	@LargeTest
	public void testonReceive() throws Exception {
//		assertNotNull(mFlashBrowser = getFlashBrowserActivity());
		BroadcastReceiver flashTelIntentReceiver = (BroadcastReceiver) ReflectHelper
				.getPrivateField(mFlashBrowser, "mFlashTelIntentReceiver");
		Intent intent = new Intent(TelephonyManager.ACTION_PHONE_STATE_CHANGED);
		intent.putExtra(TelephonyManager.EXTRA_STATE, "IDLE");
		flashTelIntentReceiver.onReceive(mActivity, intent);
		intent.putExtra(TelephonyManager.EXTRA_STATE, "RINGING");
		flashTelIntentReceiver.onReceive(mActivity, intent);
		intent.putExtra(TelephonyManager.EXTRA_STATE, "OFFHOOK");
	}
/**
 * test onConfigurationChanged
 * 
 * @throws Exception
 */
	@LargeTest
	public void testonConfigurationChanged() throws Exception {
//		assertNotNull(mFlashBrowser = getFlashBrowserActivity());
		ReflectHelper.setPrivateField(mFlashBrowser, "isFlashFullScreenMode",
				true);
		mFlashBrowser.onConfigurationChanged(new Configuration());
	}
	
	/**
	 * test onOptionsItemSelected
	 * @throws Exception
	 */
	@LargeTest
	public void testonOptionsItemSelected()throws Exception{
//		assertNotNull(mFlashBrowser = getFlashBrowserActivity());
		MockTabControl tabControl = new MockTabControl(mActivity);
		ReflectHelper.setPrivateField(mFlashBrowser, "mTabControl", tabControl);
		MockMenuItem item = new MockMenuItem(R.id.flash_quality);
		mFlashBrowser.onOptionsItemSelected(item);
		
		MockMenuItem item1 = new MockMenuItem(R.id.flash_quality);
		mFlashBrowser.onOptionsItemSelected(item1);
	}
	//helper method 
	/**
	 * launch BrowserActivity
	 * @return
	 * @throws Exception
	 */
		private BrowserActivity getBrowserActivity() throws Exception {
//			Helper.createFileToSdcard(mInst.getContext(), "test.txt", "/sdcard");
			Helper.createFileToSdcard(mInst.getContext(), "test.html", "/sdcard");
			Intent intent = new Intent(Intent.ACTION_VIEW);
			intent.setClassName("com.android.browser", BrowserActivity.class
					.getName());
//			intent.setData(Uri.parse("file:///sdcard/test.txt"));
			intent.setData(Uri.parse("file:///sdcard/test.html"));
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			BrowserActivity browserActivity = (BrowserActivity) mInst.startActivitySync(intent);
			SystemClock.sleep(60000);
			return browserActivity;
		}
	/**
	 * get FlashBrowserActivity object
	 * @return
	 * @throws Exception
	 */
		private FlashBrowserActivity getFlashBrowserActivity() throws Exception {
			TabControl tabControl;
			TitleBar titleBar;
			assertNotNull(mActivity);
			tabControl = new TabControl(mActivity);
			titleBar = new TitleBar(mActivity);
			return new FlashBrowserActivity(mActivity, tabControl, titleBar);
		}
		/**
		 * Mock a class about TabControl
		 * @author wsj
		 *
		 */
	public static class MockTabControl extends TabControl{
       private MotWebView view;
		MockTabControl(BrowserActivity activity) {
			super(activity);
		}
		public  MotWebView getCurrentWebView(){
			Log.e("nihao ***************************", " ");
			return view;
		}
		
	}
    public static class MockMenuItem implements MenuItem{
        private int mId;
        public MockMenuItem(int id){
        	mId = id;
        }
		 
		public char getAlphabeticShortcut() {
			return 0;
		}

		 
		public int getGroupId() {
			return 0;
		}

		 
		public Drawable getIcon() {
			return null;
		}

		 
		public Intent getIntent() {
			return null;
		}

		 
		public int getItemId() {
			return mId;
		}

		 
		public ContextMenuInfo getMenuInfo() {
			return null;
		}

		 
		public char getNumericShortcut() {
			return 0;
		}

		 
		public int getOrder() {
			return 0;
		}

		 
		public SubMenu getSubMenu() {
			return null;
		}

		 
		public CharSequence getTitle() {
			return null;
		}

		 
		public CharSequence getTitleCondensed() {
			return null;
		}

		 
		public boolean hasSubMenu() {
			return false;
		}

		 
		public boolean isCheckable() {
			return false;
		}

		 
		public boolean isChecked() {
			return false;
		}

		 
		public boolean isEnabled() {
			return false;
		}

		 
		public boolean isVisible() {
			return false;
		}

		 
		public MenuItem setAlphabeticShortcut(char arg0) {
			return null;
		}

		 
		public MenuItem setCheckable(boolean arg0) {
			return null;
		}

		 
		public MenuItem setChecked(boolean arg0) {
			return null;
		}

		 
		public MenuItem setEnabled(boolean arg0) {
			return null;
		}

		 
		public MenuItem setIcon(Drawable arg0) {
			return null;
		}

		 
		public MenuItem setIcon(int arg0) {
			return null;
		}

		 
		public MenuItem setIntent(Intent arg0) {
			return null;
		}

		 
		public MenuItem setNumericShortcut(char arg0) {
			return null;
		}

		 
		public MenuItem setOnMenuItemClickListener(OnMenuItemClickListener arg0) {
			return null;
		}

		 
		public MenuItem setShortcut(char arg0, char arg1) {
			return null;
		}

		 
		public MenuItem setTitle(CharSequence arg0) {
			return null;
		}

		 
		public MenuItem setTitle(int arg0) {
			return null;
		}

		 
		public MenuItem setTitleCondensed(CharSequence arg0) {
			return null;
		}

		 
		public MenuItem setVisible(boolean arg0) {
			return null;
		}
    	
    }
}
