package com.android.browser;

import com.android.browser.unittests.testutil.Helper;

import android.app.Instrumentation;
import android.content.Intent;
import android.os.SystemClock;
import android.test.InstrumentationTestCase;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ListView;

public class BrowserPreferencesPagesTest_New extends InstrumentationTestCase{
	
	private static BrowserPreferencesPage sActivity;
	private Instrumentation mInst;
	private static ListView slistView;
	private static int sCount = 0;
	private final static int WAIT_TIME = 1000;
	private final static int WAIT_PRESS = 500;
	
	public BrowserPreferencesPagesTest_New() {
		super();
		sCount ++;
	}
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mInst.setInTouchMode(false);
		if (sActivity == null) {
			sActivity = launchActivity();
			slistView = sActivity.getListView();
		}
	}
	
	@Override
	protected void tearDown() throws Exception {
		if(-- sCount == 0 && sActivity != null) {
			sActivity.finish();
			SystemClock.sleep(WAIT_TIME);
			slistView = null;
		}
		mInst = null;
		super.tearDown();
	}
	
	public void testopenInBackground() {
		/*openInBackground default value is false*/
		BrowserSettings browserSettings = BrowserSettings.getInstance();
		boolean flag = browserSettings.openInBackground();
		assertFalse(flag);
		
		/*click the checkbox about openInBackground
		 * the value change to true*/
//		{
//			for(int i = 0; i < 7; i++) {
//				Helper.HardKey.down(mInst);
//				SystemClock.sleep(WAIT_PRESS);
//			}
//			Helper.HardKey.center(mInst);
//		}
		clickSettingItem(mInst, slistView, BrowserSetting.OPEN_IN_BACKGROUND);
		SystemClock.sleep(WAIT_TIME);
		browserSettings.loadFromDb(sActivity);
		SystemClock.sleep(WAIT_TIME);
		flag = browserSettings.openInBackground();
		assertTrue(flag);
		
		/*change the value back to false*/
//		Helper.HardKey.center(mInst);
		clickSettingItem(mInst, slistView, BrowserSetting.OPEN_IN_BACKGROUND);
		SystemClock.sleep(WAIT_PRESS);
		browserSettings.loadFromDb(sActivity);
		SystemClock.sleep(WAIT_TIME);
		flag = browserSettings.openInBackground();
		assertFalse(flag);
	}
	
	private BrowserPreferencesPage launchActivity() {
		BrowserPreferencesPage browserPreferencesPage;
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setClassName("com.android.browser", BrowserPreferencesPage.class
				.getName());
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		browserPreferencesPage = (BrowserPreferencesPage) mInst
				.startActivitySync(intent);
		SystemClock.sleep(WAIT_TIME);
		return browserPreferencesPage;
	}
	
	private static void clickSettingItem(Instrumentation inst, ListView lv,
			BrowserSetting settingItem) {
		int position = 0;
		for (BrowserSetting item : BrowserSetting.values()) {
			if (settingItem.equals(item))
				break;
			position++;
		}
		inst.runOnMainSync(new SelectListItem(lv, position));
		inst.waitForIdleSync();
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
		View listItem = lv.getChildAt(position - lv.getFirstVisiblePosition());
		int[] location = { 0, 0 };
		listItem.getLocationOnScreen(location);

		location[0] += (listItem.getWidth() / 2);
		location[1] += (listItem.getHeight() / 2);

		long downTime = SystemClock.uptimeMillis();
		MotionEvent mv = MotionEvent.obtain(downTime, SystemClock
				.uptimeMillis(), KeyEvent.ACTION_DOWN, location[0],
				location[1], 0);
		inst.sendPointerSync(mv);
		inst.waitForIdleSync();
		SystemClock.sleep(ViewConfiguration.getPressedStateDuration());
		mv = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(),
				KeyEvent.ACTION_UP, location[0], location[1], 0);
		inst.sendPointerSync(mv);
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
	}

	private static class SelectListItem implements Runnable {
		ListView mListView;
		int mPosition;

		public SelectListItem(ListView lv, int pos) {
			mListView = lv;
			mPosition = pos;
		}

		public void run() {
			mListView.setSelection(mPosition);
		}
	}

	private enum BrowserSetting {
		// Order must be consistent with the Setting List order
		PAGE_CONTENT_SETTINGS("Page content settings"), SET_DEFAULT_ZOOM(
				"Set default zoom"), SET_TEXT_ENCODING("Set text encoding"), BLOCK_POPUP_WINDOWS(
				"Block pop-up windows"), LOAD_IMAGES("Load images"),
		// FIT_SCREEN_WIDTH("fit_screen_width"),//no
		ENABLE_JAVASCRIPT("Enable JavaScript"),
		PREVIEW_MODE("Preview mode"), // yes
		OPEN_IN_BACKGROUND("open_in_background"),
		SET_HOME_PAGE("Set home page"), RESET_HOME_PAGE("Reset home page"),
		// SELECT_PRELOAD_HOME_PAGE("homepage"),
		SEARCH_PORTAL("Search portal"), NETWORK("Network"), DATA_CONNECTION(
				"Data connection"), PRIVACY_SETTINGS("Privacy settings"), CLEAR_CACHE(
				"Clear cache"), CLEAR_HISTORY("Clear history"), ACCEPT_COOKIES(
				"Accept cookies"), CLEAR_ALL_COOKIES_DATA(
				"Clear all cookie data"), REMEMBER_FORM_DATA(
				"Remember form data"), CLEAR_FORM_DATA("Clear form data"), SECURITY_SETTINGS(
				"Security settings"), REMEMBER_PASSWORDS("Remember passwords"), CLEAR_PASSWORDS(
				"Clear passwords"), SHOW_SECURITY_WARNINGS(
				"Show security warnings"), ADVANCED_SETTINGS(
				"Advanced settings"),
		// EXTRAS("Extras"),
		// ENABLE_GEARS("enable_gears"),
		// GEARS_SETTINGS("gear settings"),
		RESET_TO_DEFAULT("Reset to default"), SET_DOWNLOAD_DIRCETORY(
				"set download directory"), DOWNLOAD_MEDIA_FILES(
				"Download media files");
		// Constructor
		BrowserSetting(String prefKey) {
			mKey = prefKey;
		}

		final String mKey;
		//b392 5.21
//		public final String prefKey() {
//			return mKey;
//		}
//
//		public static int settingItemCount() {
//			return BrowserSetting.values().length;
//		}
//end
	}

}
