package com.android.browser.unittests;

import junit.framework.TestSuite;
import oms.test.SuppressInstRunner;

import com.android.browser.BrowserDownloadpageTest;
import com.android.browser.BrowserDownloadpageTest2;
import com.android.browser.FlashBrowserActivityUTTest;
import com.android.browser.ImageGridTest;
import com.android.browser.OverviewPageTest;
import com.android.browser.TabControlTest;
import com.android.browser.cmcc.CMCCBrowserBookmarksPageTest;
import com.android.browser.midlet.MidletDownloadManagerTest;

public class BrowserInstrumentationTestRunner extends
SuppressInstRunner {
	
	public BrowserInstrumentationTestRunner(){
		super(true);
	}
	
	/**
	 * Override this to define all of the tests to run in your package.
	 */
	public TestSuite getAllTests() {
		TestSuite suite = new TestSuite();
		suite.addTestSuite(FlashBrowserActivityUTTest.class);
		suite.addTestSuite(ImageGridTest.class);
		suite.addTestSuite(BrowserDownloadpageTest.class);
		suite.addTestSuite(BrowserDownloadpageTest2.class);
		suite.addTestSuite(OverviewPageTest.class);
		suite.addTestSuite(TabControlTest.class);
		suite.addTestSuite(CMCCBrowserBookmarksPageTest.class);
		suite.addTestSuite(MidletDownloadManagerTest.class);
		return suite;
	}
}
