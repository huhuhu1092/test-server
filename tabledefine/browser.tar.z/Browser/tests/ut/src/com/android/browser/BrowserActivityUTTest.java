package com.android.browser;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Browser;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;
import android.view.KeyEvent;
import android.view.Window;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

@Suppress
public class BrowserActivityUTTest extends
		ActivityUnitTestCase<BrowserActivity> {

	private static BrowserActivity mBrowserActivity;
	private Instrumentation mInst;
	private Context mCtx;
	private static int count = 0;
	private static boolean flag = true;

	public BrowserActivityUTTest() {
		super(BrowserActivity.class);
		count ++;
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = this.getInstrumentation();
		mCtx = mInst.getContext();
		if(flag){
			mBrowserActivity = launchActivity();
			flag = false;
		}
	}

	@Override
	protected void tearDown() throws Exception {
		if(--count == 0){
			Helper.deleteFileAndFolder("/sdcard");
			finishActivity();
		}
		mCtx = null;
		mInst = null;
		super.tearDown();
	}

	// test method
//	/**
//	 * This method test onOptionsItemSelected and menu id is R.id.goto_menu_id.
//	 */
//	@LargeTest
//	public void testOnOptionsItemSelectedgoto_menu_id() throws Exception {
////		mBrowserActivity = launchActivity();
//		assertNotNull(mBrowserActivity);
//		mInst.invokeMenuActionSync(mBrowserActivity, R.id.goto_menu_id, 0);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}
//
//	/**mAlertDialog
//	 * This method test onOptionsItemSelected and menu id is
//	 * R.id.stop_reload_menu_id.
//	 */
//	@LargeTest
//	public void testOnOptionsItemSelectedstop_reload_menu_id() throws Exception {
////		mBrowserActivity = launchActivity();
//		assertNotNull(mBrowserActivity);
//		mInst.invokeMenuActionSync(mBrowserActivity, R.id.stop_reload_menu_id,
//				0);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}

//	/**
//	 * This method test onOptionsItemSelected and menu id is R.id.back_menu_id.
//	 */
//	@LargeTest
//	public void testOnOptionsItemSelectedback_menu_id() throws Exception {
////		mBrowserActivity = launchActivity();
//		assertNotNull(mBrowserActivity);
//		mInst.invokeMenuActionSync(mBrowserActivity, R.id.back_menu_id, 0);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}

//	/**
//	 * This method test onOptionsItemSelected and menu id is
//	 * R.id.forward_menu_id.
//	 */
//	@LargeTest
//	public void testOnOptionsItemSelectedforward_menu_id() throws Exception {
////		mBrowserActivity = launchActivity();
//		assertNotNull(mBrowserActivity);
//		mInst.invokeMenuActionSync(mBrowserActivity, R.id.forward_menu_id, 0);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}

	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.homepage_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedhomepage_menu_id() throws Exception {
//		mBrowserActivity = launchActivity();
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.homepage_menu_id, 0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.preferences_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedpreferences_menu_id() throws Exception {
//		mBrowserActivity = launchActivity();
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.preferences_menu_id,
				0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

//	/**
//	 * This method test onOptionsItemSelected and menu id is
//	 * R.id.advanced_menu_id.
//	 */
//	@LargeTest
//	public void testOnOptionsItemSelectedadvanced_menu_id() throws Exception {
////		mBrowserActivity = launchActivity();
//		Instrumentation.ActivityMonitor monitor = new Instrumentation.ActivityMonitor(BrowserExtraMenuPage.class.getName(), null, true);
//		mInst.addMonitor(monitor);
//		try {
//			assertNotNull(mBrowserActivity);
//			mInst.invokeMenuActionSync(mBrowserActivity, R.id.advanced_menu_id, 0);
//			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		} finally {
//			mInst.removeMonitor(monitor);
//		}
//		
//	}

	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.classic_history_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedclassic_history_menu_id()
			throws Exception {
//		mBrowserActivity = launchActivity();
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity,
				R.id.classic_history_menu_id, 0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	/**
	 * This method test shouldOverrideUrlLoading.
	 */
	@LargeTest
	public void testOnOptionsItemSelected() throws Exception {
//		mBrowserActivity = launchActivity();
		assertNotNull(mBrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mCanChord", false);
		assertFalse(mBrowserActivity.onOptionsItemSelected(null));
	}

	/**
	 * This method test onOptionsItemSelected and mCanChord is false.
	 */
	@LargeTest
	public void testShouldOverrideUrlLoading() throws Exception {
//		mBrowserActivity = launchActivity();
		assertNotNull(mBrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mNetworkManager", NetworkManager.createInstance(mBrowserActivity));
		WebViewClient webViewClient = (WebViewClient) ReflectHelper
				.getPrivateField(mBrowserActivity, "mWebViewClient");
		assertNotNull(webViewClient);
		webViewClient.shouldOverrideUrlLoading(null, Helper.URL);
	}
//	/**
//	 * This method test onOptionsItemSelected and mCanChord is false.
//	 */
//	@LargeTest
//	public void testShouldOverrideUrlLoadingmNetworkConnectingFalse() throws Exception {
////		mBrowserActivity = launchActivity();
//		assertNotNull(mBrowserActivity);
////		WebViewClient webViewClient = (WebViewClient) ReflectHelper
////				.getPrivateField(mBrowserActivity, "mWebViewClient");
////		assertNotNull(webViewClient);
////		ReflectHelper.setPrivateField(mBrowserActivity, "mNetworkConnecting", false);
////		ReflectHelper.setPrivateField(mBrowserActivity, "mMenuIsDown", true);
//		mInst.runOnMainSync(new Runnable() {
//			public void run() {
//				try {
//					WebViewClient webViewClient = (WebViewClient) ReflectHelper
//							.getPrivateField(mBrowserActivity, "mWebViewClient");
//					assertNotNull(webViewClient);
//					ReflectHelper.setPrivateField(mBrowserActivity,
//							"mNetworkConnecting", false);
//					ReflectHelper.setPrivateField(mBrowserActivity,
//							"mMenuIsDown", true);
//					webViewClient.shouldOverrideUrlLoading(null, Helper.URL);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
////		webViewClient.shouldOverrideUrlLoading(null, Helper.URL);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}
	
	/**
	 * This method test setMenuState.
	 */
	@LargeTest
	public void testSetMenuState() throws Exception {
//		mBrowserActivity = launchActivity();
		assertNotNull(mBrowserActivity);
		mBrowserActivity.setMenuState(0);
		assertEquals(0, ReflectHelper.getPrivateField(mBrowserActivity, "mCurrentMenuState"));
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}
	
	/**
	 * This method test setHttpAuthUsernamePassword.
	 */
	@LargeTest
	public void testSetHttpAuthUsernamePassword() throws Exception {
//		mBrowserActivity = launchActivity();
		assertNotNull(mBrowserActivity);
		mBrowserActivity.setHttpAuthUsernamePassword(String.valueOf(Helper.SERVERPORT),"realm","test","111111");
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}
	
	/**
	 * This method test postMessage.
	 */
	@LargeTest
	public void testPostMessage() throws Exception {
//		mBrowserActivity = launchActivity();
		assertNotNull(mBrowserActivity);
		mBrowserActivity.postMessage(0, 0, 0, null);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}
	
	/**
	 * This method test removeTabAndShow.
	 */
	@LargeTest
	public void testRemoveTabAndShow() throws Exception {
//		mBrowserActivity = launchActivity();
		assertNotNull(mBrowserActivity);
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				try{
					ReflectHelper.runPrivateMethod(mBrowserActivity, "removeTabAndShow", new Class[]{int.class,int.class}, new Object[]{0,1});
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
//		ReflectHelper.runPrivateMethod(mBrowserActivity, "removeTabAndShow", new Class[]{int.class,int.class}, new Object[]{0,1});
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}
	
	/**
	 * This method tests onDownloadStart and minetype is audio.
	 * @throws Exception
	 */
	@LargeTest
	public void testOnDownloadStart() throws Exception{
//		mBrowserActivity = launchActivity();
		assertNotNull(mBrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mNetworkManager", NetworkManager.createInstance(mBrowserActivity));
		mBrowserActivity.onDownloadStart(Helper.URL, "userAgent", "http://www.w3.org/Protocols/rfc2616/rfc2616-sec19.html", "audio", 1234l);
	}
	/**
	 * This method tests onDownloadStart and minetype is not audio.
	 * @throws Exception
	 */
	@LargeTest
	public void testOnDownloadStartNoAudio() throws Exception{
//		mBrowserActivity = launchActivity();
		assertNotNull(mBrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mNetworkManager", NetworkManager.createInstance(mBrowserActivity));
		mBrowserActivity.onDownloadStart(Helper.URL, "userAgent", null, "text/html", 1234l);
	}
	
	
	//b392 add 5.31 (from BrowserActivitylUTTest.java)
//	/**
//	 * this case tests onOptionsItemSelected() for bookmarks_tab_menu
//	 */
//	@LargeTest
//	public void testOnOptionsItemSelected_bookmarks_tab_menu() throws Exception {
////		mBrowserActivity = launchActivity();
//		Instrumentation.ActivityMonitor monitor = new Instrumentation.ActivityMonitor(CMCCBrowserBookmarksPage.class.getName(), null, true);
//	    mInst.addMonitor(monitor);
//		try {
//		assertTrue(mBrowserActivity instanceof BrowserActivity);
//		ReflectHelper.setPrivateField(mBrowserActivity, "mMenuState", R.id.TAB_MENU);
//		assertTrue(mInst.invokeMenuActionSync(mBrowserActivity,
//				R.id.bookmarks_tab_menu_id, 0));
//		}finally {
//			mInst.removeMonitor(monitor);
//		}
//	}
	
//	/**
//	 * this case tests onOptionsItemSelected() for book marks
//	 */
//	@LargeTest
//	public void testOnoptionsItemSelected_bookmarks_menu_id() {
//		Instrumentation.ActivityMonitor monitor = new Instrumentation.ActivityMonitor(CMCCBrowserBookmarksPage.class.getName(), null, true);
//	    mInst.addMonitor(monitor);
//		try {
//			assertTrue(mBrowserActivity instanceof BrowserActivity);
//			mInst.invokeMenuActionSync(mBrowserActivity, R.id.bookmarks_menu_id, 0);
//		} finally {
//			mInst.removeMonitor(monitor);
//		}
//	}
//
//	/**
//	 * this case tests onOptionsItemSelected() for copy and paste
//	 */
//	@LargeTest
//	public void testOnOptionsItemSelected_copy_and_paste() {
//		assertTrue(mBrowserActivity instanceof BrowserActivity);
//		mInst.invokeMenuActionSync(mBrowserActivity, R.id.copy_and_paste_id, 0);
//	}
	//end
	
	//from browser UITest
//	/**
//	 * This method tests loadURL.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testLoadURL() throws Exception {
//		assertNotNull(mBrowserActivity);
//
//		WebView view = new WebView(mCtx);
//		String url = "wtai://wp/sd;10086";// need a String start with
//		// "wtai://wp/sd;"+
//		ReflectHelper.runPrivateMethod(mBrowserActivity, "loadURL",
//				new Class[] { WebView.class, String.class }, new Object[] {
//						view, url });
//	}
	
//	/**
//	 * This method tests OnContextItemSelected and the menu is
//	 * open_newtab_context_menu_id.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testOnContextItemSelectedopen_newtab_context_menu_id()
//			throws Exception {
//		assertNotNull(mBrowserActivity);
//		mBrowserActivity.runOnUiThread(new Runnable() {
//			public void run() {
//				mInst.invokeContextMenuAction(mBrowserActivity,
//						R.id.open_newtab_context_menu_id, 0);
//			}
//		});
//	}
	
	/**
	 * This method tests onActivityResult and requestcode is
	 * CLASSIC_HISTORY_PAGE and new_window is false.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnActivityResultCLASSIC_HISTORY_PAGENewWindowFalse() throws Exception {
		assertNotNull(mBrowserActivity);
		Intent data = new Intent("file:///sdcard/test.txt");
		mBrowserActivity.onActivityResult(2, Activity.RESULT_OK, data);
	}
	
	/**
	 * This method tests showTab().
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testShowDrmDlg() throws Exception {
		assertNotNull(mBrowserActivity);

		String cid = "1";
		mBrowserActivity.showDrmDlg(cid);
	}
	
	/**
	 * This method tests onDownloadStartNoStream.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnDownloadStartNoStream() throws Exception {
		assertNotNull(mBrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mNetworkManager", NetworkManager.createInstance(mBrowserActivity));
		mBrowserActivity.onDownloadStartNoStream("file:///sdcard/test.txt", "userAgent",
				"http://www.w3.org/Protocols/rfc2616/rfc2616-sec19.html",
				"text/plain", 312l); 
	}
	
	/**
	 * This method tests onActivityResult and requestcode is
	 * CLASSIC_HISTORY_PAGE and new_window is true.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnActivityResultCLASSIC_HISTORY_PAGE() throws Exception {
		assertNotNull(mBrowserActivity);
		TabControl tabControl = (TabControl) ReflectHelper.getPrivateField(
				mBrowserActivity, "mTabControl");
		Intent i = new Intent(mBrowserActivity, BrowserHistoryPage.class);

		i.putExtra("maxTabsOpen",
				tabControl.getTabCount() >= TabControl.MAX_TABS);

		Intent data = new Intent("file:///sdcard/test.txt");
		Bundle bundle = new Bundle();
		bundle.putBoolean("new_window", true);
		data.putExtras(bundle);
		mBrowserActivity.startActivityForResult(i, 2);
	}
	
	/**
	 * This method tests onActivityResult and requestcode is
	 * CLASSIC_HISTORY_PAGE and result is RESULT_OK.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void test0OnActivityResultFILE_PICK_UIRESULT_OK() throws Exception {
		assertNotNull(mBrowserActivity);
		Intent data = new Intent();
		data.setData(Uri.parse("file:///sdcard/test.txt"));
		mBrowserActivity.onActivityResult(21, -1, data);
		//end
	}
	//end
	
	//from UIITest
	/**
	 * This method tests onActivityResult and requestcode is PREFERENCES_PAGE.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnActivityResultPREFERENCES_PAGE() throws Exception {
		assertNotNull(mBrowserActivity);
		Intent intent = new Intent(mBrowserActivity,
				BrowserPreferencesPage.class);
		Bundle bundle = new Bundle();
		bundle.putBoolean("new_window", false);
		mBrowserActivity.startActivityForResult(intent, 4);
	}
	
	/**
	 * This method tests OnKeyDown and request code is KEYCODE_MENU.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnKeyDownKEYCODE_MENU() throws Exception {
		assertNotNull(mBrowserActivity);
		mBrowserActivity.runOnUiThread(new Runnable() {
			public void run() {
				mBrowserActivity.onKeyDown(KeyEvent.KEYCODE_MENU, new KeyEvent(
						KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MENU));
			}
		});
	}
	
//	/**
//	 * This method tests OnKeyDown and request code is KEYCODE_SPACE.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testOnKeyDownKEYCODE_SPACE() throws Exception {
//		assertNotNull(mBrowserActivity);
//		mBrowserActivity.runOnUiThread(new Runnable() {
//			public void run() {
//				assertTrue(mBrowserActivity.onKeyDown(KeyEvent.KEYCODE_SPACE,
//						new KeyEvent(KeyEvent.ACTION_DOWN,
//								KeyEvent.KEYCODE_SPACE)));
//			}
//		});
//	}
	
	/**
	 * This method tests onMenuOpened().
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnMenuOpened() throws Exception {
		assertNotNull(mBrowserActivity);
		assertTrue(mBrowserActivity.onMenuOpened(Window.FEATURE_OPTIONS_PANEL, null));
	}
	
	/**
	 * This method tests onMenuOpened().
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnMenuOpenedmOptionsMenuOpenmConfigChangedIsTrue()
			throws Exception {
		assertNotNull(mBrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mOptionsMenuOpen",
				true);
		ReflectHelper.setPrivateField(mBrowserActivity, "mConfigChanged", true);
		assertTrue(mBrowserActivity.onMenuOpened(Window.FEATURE_OPTIONS_PANEL, null));
	}
	
	/**
	 * This method tests onMenuOpened().
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnMenuOpenedmOptionsMenuOpenTruemConfigChangedFalse()
			throws Exception {
		assertNotNull(mBrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mOptionsMenuOpen",
				true);
		assertTrue(mBrowserActivity.onMenuOpened(Window.FEATURE_OPTIONS_PANEL, null));
	}
	
	/**
	 * This method tests onMenuOpened().
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnMenuOpenedmOptionsMenuOpenTruemConfigChangedFalsemIconViewTrue()
			throws Exception {
		assertNotNull(mBrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mOptionsMenuOpen",
				true);
		ReflectHelper.setPrivateField(mBrowserActivity, "mIconView", true);
		assertTrue(mBrowserActivity.onMenuOpened(Window.FEATURE_OPTIONS_PANEL, null));
	}
//	
//	/**
//	 * This method tests OnNetworkToggle.
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testOnNetworkToggle() throws Exception{
//		assertNotNull(mBrowserActivity);
//		mBrowserActivity.onNetworkToggle(true);
//		ReflectHelper.setPrivateField(mBrowserActivity, "mInLoad", true);
//		mBrowserActivity.runOnUiThread(new Runnable() {
//			public void run() {
//				mBrowserActivity.onNetworkToggle(false);
//			}
//		});
////		mBrowserActivity.onNetworkToggle(false);
//		mBrowserActivity.onNetworkToggle(true);
//	}
	
	/**
	 * This method tests reload().
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testReload() throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		assertNotNull(mBrowserActivity);
		mBrowserActivity.reload();
	}
	
	/**
	 * This method tests shouldOverrideUrlLoading().
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testShouldOverrideUrlLoading1() throws Exception {
		String url = "mms:10086?subject=MMS+Testing&body=MMS";
		String webViewClientS = "mWebViewClient";
//		mBrowserActivity = launchActivity(FILEPATH);
		assertNotNull(mBrowserActivity);
		WebViewClient webViewClient = (WebViewClient) ReflectHelper
				.getPrivateField(mBrowserActivity, webViewClientS);
		assertNotNull(webViewClient);
		assertTrue(webViewClient.shouldOverrideUrlLoading(null, url));
	}
	
//	/**
//	 * This method tests shouldOverrideUrlLoading().
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testShouldOverrideUrlLoadingfile() throws Exception {
////		mBrowserActivity = launchActivity(FILEPATH);
//		String webViewClientS = "mWebViewClient";
//		assertNotNull(mBrowserActivity);
//		ReflectHelper.setPrivateField(mBrowserActivity, "mNetworkManager", NetworkManager.createInstance(mBrowserActivity));
//		WebViewClient webViewClient = (WebViewClient) ReflectHelper
//				.getPrivateField(mBrowserActivity, webViewClientS);
//		assertNotNull(webViewClient);
//		webViewClient.shouldOverrideUrlLoading(null, "content://contacts/people/1");
//	}
	
	/**
	 * This method tests shouldOverrideUrlLoading().
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testShouldOverrideUrlLoadingSCHEME_WTAI_AP() throws Exception {
		String url = "wtai://wp/ap;" + "10086;abc";
		String webViewClientS = "mWebViewClient";
//		mBrowserActivity = launchActivity(FILEPATH);
		assertNotNull(mBrowserActivity);
		WebViewClient webViewClient = (WebViewClient) ReflectHelper
				.getPrivateField(mBrowserActivity, webViewClientS);
		assertNotNull(webViewClient);
		assertTrue(webViewClient.shouldOverrideUrlLoading(null, url));
	}
	
	/**
	 * This method tests shouldOverrideUrlLoading().
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testShouldOverrideUrlLoadingSCHEME_WTAI_MC() throws Exception {
		String url = "wtai://wp/mc;" + "10086";
		String webViewClientS = "mWebViewClient";
//		mBrowserActivity = launchActivity(FILEPATH);

		assertNotNull(mBrowserActivity);
		WebViewClient webViewClient = (WebViewClient) ReflectHelper
				.getPrivateField(mBrowserActivity, webViewClientS);
		assertNotNull(webViewClient);
		assertTrue(webViewClient.shouldOverrideUrlLoading(null, url));
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	/**
	 * This method tests shouldOverrideUrlLoading().
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testShouldOverrideUrlLoadingSCHEME_WTAI_SD() throws Exception {
		String url = "wtai://wp/sd;" + "10086";
		String webViewClientS = "mWebViewClient";
//		mBrowserActivity = launchActivity(FILEPATH);

		assertNotNull(mBrowserActivity);
		WebViewClient webViewClient = (WebViewClient) ReflectHelper
				.getPrivateField(mBrowserActivity, webViewClientS);

		assertNotNull(webViewClient);
		assertTrue(webViewClient.shouldOverrideUrlLoading(null, url));
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}
	//end
	
	// help method
	private BrowserActivity launchActivity() {
		Helper.createFileToSdcard(mCtx, "test.txt", "/sdcard");
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse("file:///sdcard/test.txt"));
		Bundle bundle = new Bundle();
		bundle.putInt(Browser.INITIAL_ZOOM_LEVEL, 1);
		bundle.putBoolean("testing", false);
		intent.putExtras(bundle);
		return startActivity(intent, null, null);
	}

	private void finishActivity() {
		if (mBrowserActivity != null) {
			mBrowserActivity.finish();
//			mBrowserActivity.goQuit();
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
			getInstrumentation().runOnMainSync(new Runnable(){
				public void run() {
					try {
						FrameLayout contentView =  (FrameLayout) ReflectHelper.getPrivateField(mBrowserActivity, "mContentView");
						if(contentView != null){
							contentView.removeAllViews();
						}
					}catch(Exception e){
						e.printStackTrace();
					}
				}
			});
			mBrowserActivity = null;
		}
	}

}
