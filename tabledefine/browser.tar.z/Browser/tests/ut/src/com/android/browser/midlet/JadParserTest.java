package com.android.browser.midlet;

import java.io.File;

import com.android.browser.midlet.JadParser;

import com.android.browser.unittests.testutil.Helper;

import android.content.Context;

import android.test.AndroidTestCase;
import android.test.suitebuilder.annotation.MediumTest;
import android.test.suitebuilder.annotation.SmallTest;
import android.util.Log;

/**
 * Test JadParser.java.
 * 
 * @author b391(LuoXiaofei)
 * 
 */
public class JadParserTest extends AndroidTestCase {

	private Context mContext;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mContext = getTestContext();
	}

	@Override
	protected void tearDown() throws Exception {
		mContext = null;
		super.tearDown();
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=false
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadFlagIsFalse() throws Exception {
		File jadfile = null;
		boolean flag = false;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=true
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadJadFlagIsTrue() throws Exception {
		File jadfile = null;
		boolean flag = true;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=false and
	 * JadParser.jadMidlet.name!=null; JadParser.jadMidlet.vendor=null;
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadjadMidletNameNotNull() throws Exception {
		File jadfile = null;
		boolean flag = false;
		JadParser.jadMidlet.name = "name";
		JadParser.jadMidlet.vendor = null;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=flase and
	 * JadParser.jadMidlet.name!=null; and JadParser.jadMidlet.vendor="vendor";
	 * and JadParser.jadMidlet.version=null;
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadjadMidletNameAndvendorNotNull() throws Exception {
		File jadfile = null;
		boolean flag = false;
		JadParser.jadMidlet.name = "name";
		JadParser.jadMidlet.vendor = "vendor";
		JadParser.jadMidlet.version = null;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=flase and
	 * JadParser.jadMidlet.name!=null; and JadParser.jadMidlet.vendor="vendor";
	 * and JadParser.jadMidlet.version="version"; and
	 * version.length()<=0||version.length()>3
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadjadMidletNameAndvendorAndVersionNotNull()
			throws Exception {
		File jadfile = null;
		boolean flag = false;
		JadParser.jadMidlet.name = "name";
		JadParser.jadMidlet.vendor = "vendor";
		JadParser.jadMidlet.version = "version";
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=flase and
	 * JadParser.jadMidlet.name!=null; and JadParser.jadMidlet.vendor="vendor";
	 * and JadParser.jadMidlet.version="version"; and
	 * version.length()>0||version.length()<3 and version is String
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadjadMidletlengthlessThanThree() throws Exception {
		File jadfile = null;
		boolean flag = false;
		JadParser.jadMidlet.name = "name";
		JadParser.jadMidlet.vendor = "vendor";
		JadParser.jadMidlet.version = "ve";
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=flase and
	 * JadParser.jadMidlet.name!=null; and JadParser.jadMidlet.vendor="vendor";
	 * and JadParser.jadMidlet.version="version"; and
	 * version.length()>0||version.length()<3 and version is int and
	 * JadParser.jadMidlet.profile=null; and JadParser.jadMidlet.jarurl= null;
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadjadMidletlengthlessThanThreeInt()
			throws Exception {
		File jadfile = null;
		boolean flag = false;
		JadParser.jadMidlet.name = "name";
		JadParser.jadMidlet.vendor = "vendor";
		JadParser.jadMidlet.version = "3";
		JadParser.jadMidlet.profile = null;
		JadParser.jadMidlet.configuration = null;
		JadParser.jadMidlet.jarurl = null;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=flase and
	 * JadParser.jadMidlet.name!=null; and JadParser.jadMidlet.vendor="vendor";
	 * and JadParser.jadMidlet.version="version"; and
	 * version.length()>0||version.length()<3 and version is int and
	 * JadParser.jadMidlet.profile="profile";
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadjadMidletprofileIsNotNull() throws Exception {
		File jadfile = null;
		boolean flag = false;
		JadParser.jadMidlet.name = "name";
		JadParser.jadMidlet.vendor = "vendor";
		JadParser.jadMidlet.version = "3";
		JadParser.jadMidlet.profile = "profile";
		assertEquals(JadParser.STATUS_INCOMPATIBLE_PROFILE, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=flase and
	 * JadParser.jadMidlet.name!=null; and JadParser.jadMidlet.vendor="vendor";
	 * and JadParser.jadMidlet.version="version"; and
	 * version.length()>0||version.length()<3 and version is int and
	 * JadParser.jadMidlet.configuration="configuration";
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadjadMidletconfigurationIsNotNull()
			throws Exception {
		File jadfile = null;
		boolean flag = false;
		JadParser.jadMidlet.name = "name";
		JadParser.jadMidlet.vendor = "vendor";
		JadParser.jadMidlet.version = "3";
		JadParser.jadMidlet.configuration = "configuration";
		assertEquals(JadParser.STATUS_INCOMPATIBLE_CONFIGURATION, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=flase and
	 * JadParser.jadMidlet.name!=null; and JadParser.jadMidlet.vendor="vendor";
	 * and JadParser.jadMidlet.version="version"; and
	 * version.length()>0||version.length()<3 and version is int and
	 * JadParser.jadMidlet.profile=null; and JadParser.jadMidlet.jarurl= null;
	 * and JadParser.jadMidlet.jarurl= "uri"; and JadParser.jadMidlet.size<=0;
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadjadMidletSizelessThanZero() throws Exception {
		File jadfile = null;
		boolean flag = false;
		JadParser.jadMidlet.name = "name";
		JadParser.jadMidlet.vendor = "vendor";
		JadParser.jadMidlet.version = "3";
		JadParser.jadMidlet.profile = null;
		JadParser.jadMidlet.configuration = null;
		JadParser.jadMidlet.jarurl = "uri";
		JadParser.jadMidlet.size = 0;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=flase and
	 * JadParser.jadMidlet.name!=null; and JadParser.jadMidlet.vendor="vendor";
	 * and JadParser.jadMidlet.version="version"; and
	 * version.length()>0||version.length()<3 and version is int and
	 * JadParser.jadMidlet.profile=null; and JadParser.jadMidlet.jarurl= null;
	 * and JadParser.jadMidlet.jarurl= "uri"; and
	 * JadParser.jadMidlet.size>JAR_MAX_SIZE;
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadjadMidletSizelessThanZeroElse() throws Exception {
		File jadfile = null;
		boolean flag = false;
		JadParser.jadMidlet.name = "name";
		JadParser.jadMidlet.vendor = "vendor";
		JadParser.jadMidlet.version = "3";
		JadParser.jadMidlet.profile = null;
		JadParser.jadMidlet.configuration = null;
		JadParser.jadMidlet.jarurl = "uri";
		int JAR_MAX_SIZE = 1024 * 1024 * 3;
		JadParser.jadMidlet.size = JAR_MAX_SIZE + 1;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method validateJad and jadfile=null and flag=flase and
	 * JadParser.jadMidlet.name!=null; and JadParser.jadMidlet.vendor="vendor";
	 * and JadParser.jadMidlet.version="version"; and
	 * version.length()>0||version.length()<3 and version is int and
	 * JadParser.jadMidlet.profile=null; and JadParser.jadMidlet.jarurl= null;
	 * and JadParser.jadMidlet.jarurl= "uri"; and JadParser.jadMidlet.size=1;
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJadadMidletmidletnum() throws Exception {
		File jadfile = null;
		boolean flag = false;
		JadParser.jadMidlet.name = "name";
		JadParser.jadMidlet.vendor = "vendor";
		JadParser.jadMidlet.version = "3";
		JadParser.jadMidlet.profile = null;
		JadParser.jadMidlet.configuration = null;
		JadParser.jadMidlet.jarurl = "uri";
		JadParser.jadMidlet.size = 1;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJad(jadfile, flag));
	}

	/**
	 * there tests method checkOldVersion jadfile=null flag=true
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testcheckOldVersion() throws Exception {
		File jadfile = null;
		boolean flag = true;
		assertEquals(-5, JadParser.checkOldVersion(jadfile, flag));
	}

	/**
	 * there tests method checkOldVersion and File in not null
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testcheckOldVersionFileIsNotNull() throws Exception {
		String path = "///sdcard/";
		String name = "test.txt";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		boolean flag = true;
		assertEquals(-1,JadParser.checkOldVersion(jadfile, flag) );
		assertTrue(jadfile.delete());
	}

	/**
	 * there tests method Iftrust and jadfile is null
	 */
	@MediumTest
	public void testcheckIftrust() throws Exception {
		File jadfile = null;
		boolean flag = true;
//		assertTrue(JadParser.checkIftrust(jadfile, flag));
		JadParser.checkIftrust(jadfile, flag);
	}

	/**
	 * there tests method Iftrusu and jadfile is not null
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testcheckIftrustFileIsNotNull() throws Exception {
		String path = "///sdcard/";
		String name = "test.txt";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		boolean flag = true;
		assertFalse(JadParser.checkIftrust(jadfile, flag));
		assertTrue(jadfile.delete());
	}

	/**
	 * there tests method getJarUrl and jadfiel is null
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testgetJarUrl() throws Exception {
		File jadfile = null;
		boolean flag = true;
		assertNull(JadParser.getJarUrl(jadfile, flag));
	}

	/**
	 * there tests methohd getJarUrl and jadfile is not null and File is exists
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testgetJarUrlFileNotNull() throws Exception {
		String path = "///sdcard/";
		String name = "test.txt";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		boolean flag = true;
		JadParser.getJarUrl(jadfile, flag);
		
		assertTrue(jadfile.delete());
		
	}

	/**
	 * there tests method getFile
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testgetFile() throws Exception {
		String path = "///sdcard/";
		String name = "test.txt";
		Helper.createFileToSdcard(mContext, name, path);
		JadParser.getFile(path + name);
		JadParser.getFile(path + name).delete();
	}

	/**
	 * there tests method parseJar
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testparseJar() throws Exception {
		String path = "///sdcard/";
		String name = "oms.jar";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		assertTrue(JadParser.parseJar(jadfile));
		assertTrue(jadfile.delete());
	}

	/**
	 * there tests method parseJar throws Exception
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testparseJarException() throws Exception {
		String path = "///sdcard/";
		String name = "test.txt";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		assertFalse(JadParser.parseJar(jadfile));
		assertTrue(jadfile.delete());
	}

	/**
	 * there tests method comparversion and newversion is null
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testcomparversion() throws Exception {
		assertEquals(0, JadParser.comparversion(null, null));
	}

	/**
	 * there tests method comparversion and newversion.length
	 * >=oldversion.length
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testcomparversionNewversionLengthThanOldversion()
			throws Exception {
		String newversion = "1.5";
		String oldversion = "1";
		int back = JadParser.comparversion(newversion, oldversion);
		assertEquals(2, back);
	}

	/**
	 * there tests method comparversion and newversion.length<oldversion.length
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testcomparversionNewversionLengthsmallThanOldversion()
			throws Exception {
		String newversion = "2";
		String oldversion = "1.5";
		int back = JadParser.comparversion(newversion, oldversion);
		assertEquals(2, back);
	}

	/**
	 * there tests method comparversion and newversion=oldversion
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testcomparversionNewversionEqualOldversion() throws Exception {
		String newversion = "2";
		String oldversion = "2";
		int back = JadParser.comparversion(newversion, oldversion);
		assertEquals(1, back);
	}

	/**
	 * there tests method dealEncode and src=null
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testdealEncode() throws Exception {
		String back = JadParser.dealEncode(null);
		assertEquals("", back);
	}

	/**
	 * there tests method dealEncode and src not null
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testdelEncodeSrcNotNull() throws Exception {
		String src = "luo";
		String back = JadParser.dealEncode(src);
		assertEquals(src, back);
	}

	/**
	 * there tests method getOnlyMidletName and src=null
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testgetOnlyMidletNameSrcIsNull() throws Exception {
		assertEquals("", JadParser.getOnlyMidletName(null, true));
	}

	/**
	 * there tests method getOnlymidletname and src has "," and ifencode is true
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testgetOnlyMidletnameSrcNotNull() throws Exception {
		String src = "luo,xiao";
		String back = JadParser.getOnlyMidletName(src, true);
		assertEquals("luo", back);
	}

	/**
	 * there tests method getOnlymidletname and src has "," and ifencode is
	 * false
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testgetOnlyMidletnameIfencodeIsFalse() throws Exception {
		String src = "luo,xiao";
		String back = JadParser.getOnlyMidletName(src, false);
		assertEquals("luo", back);
	}

	/**
	 * there tests method getOnlymidletname and src has no "," and ifencode is
	 * true
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testgetOnlymidletanmeSrcIsLuo() throws Exception {
		String src = "luo";
		String back = JadParser.getOnlyMidletName(src, true);
		assertEquals("luo", back);
	}

	/**
	 * there tests method getOnlymidletname and src has no "," and ifencode is
	 * false
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testgetOnlymidletanmeSrcIsLuoIfencodeFalse() throws Exception {
		String src = "luo";
		String back = JadParser.getOnlyMidletName(src, false);
		assertEquals("luo", back);
	}

	// /**
	// * there tests method Read
	// * @throws Exception
	// */
	// public void testRead()throws Exception
	// {
	// String path="///sdcard/";
	// String name="test.data";
	// Helper.createFileToSdcard(mContext, name,path);
	// JadParser.Read(path+name);
	// SystemClock.sleep(long_time);
	// }
	/**
	 * there tests method validateJar and jadFile is null
	 */
	@SmallTest
	public void testvalidateJarFileIsNull() throws Exception {
		File jadfile = null;
		boolean flag = true;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJar(jadfile, flag));
	}

	/**
	 * there tests method validateJar and jadFile is oms.jar and
	 * JadParser.jarMidlet.name = null;
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testvalidateJarFileIsNotNullName() throws Exception {
		String path = "///sdcard/";
		String name = "oms.jar";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		boolean flag = false;
		JadParser.jarMidlet.name = null;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJar(jadfile, flag));
		jadfile.delete();
	}

	/**
	 * there tests method validatejar and jadFile is test.txt
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testsvalidateJarFileIsNotNull() throws Exception {
		String path = "///sdcard/";
		String name = "test.txt";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		boolean flag = true;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJar(jadfile, flag));
		jadfile.delete();
	}

	/**
	 * there tests method validateJar and jadFile is oms.jar and
	 * JadParser.jarMidlet.name = "name"; JadParser.jarMidlet.vendor=null;
	 * 
	 * @throws Exceptioni
	 */
	@SmallTest
	public void testvalidateJarFilejarIsNotnullVendor() throws Exception {
		String path = "///sdcard/";
		String name = "oms.jar";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		boolean flag = false;
		JadParser.jarMidlet.name = "name";
		JadParser.jarMidlet.vendor = null;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJar(jadfile, flag));
		jadfile.delete();
	}

	/**
	 * there test method validatejar and jadFile is oms.jar and
	 * jadParser.jarMidlet.name = "name"; JadParser.jarMidlet.vendor="vendor";
	 * JadParser.jarMidlet.version=null;
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidateJarFileisNotnullVersion() throws Exception {
		String path = "///sdcard/";
		String name = "oms.jar";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		boolean flag = false;
		JadParser.jarMidlet.name = "name";
		JadParser.jarMidlet.vendor = "vendor";
		JadParser.jarMidlet.version = null;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJar(jadfile, flag));
		jadfile.delete();
	}

	/**
	 * there tests method validatejar and jdFile is oms.jar and
	 * JadParser.jarMidlet.name = "name"; JadParser.jarMidlet.vendor = "vendor";
	 * JadParser.jarMidlet.version = "luo";
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidatejarFileVersionIsNotNull() throws Exception {
		String path = "///sdcard/";
		String name = "oms.jar";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		boolean flag = false;
		JadParser.jarMidlet.name = "name";
		JadParser.jarMidlet.vendor = "vendor";
		JadParser.jarMidlet.version = "version";
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJar(jadfile, flag));
		jadfile.delete();
	}

	/**
	 * there tests method validatejar and jadFile is oms.jar and
	 * JadParser.jarMidlet.name = "name"; JadParser.jarMidlet.vendor = "vendor";
	 * JadParser.jarMidlet.version = "luo,xiao"; JadParser.jarMidlet.profile
	 * =null;
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidatejarFileprofile() throws Exception {
		String path = "///sdcard/";
		String name = "oms.jar";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		boolean flag = false;
		JadParser.jarMidlet.name = "name";
		JadParser.jarMidlet.vendor = "vendor";
		JadParser.jarMidlet.version = "1.5";
		JadParser.jarMidlet.profile = null;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJar(jadfile, flag));
		jadfile.delete();
	}

	/**
	 * there tests method validatejarFile and jadFile is oms.jar and
	 * JadParser.jarMidlet.name = "name"; JadParser.jarMidlet.vendor = "vendor";
	 * JadParser.jarMidlet.version = "luo,xiao"; JadParser.jarMidlet.profile =
	 * "profile"; JadParser.jarMidlet.configuration = null;
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidatejarFileconfiguration() throws Exception {
		String path = "///sdcard/";
		String name = "oms.jar";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		boolean flag = false;
		JadParser.jarMidlet.name = "name";
		JadParser.jarMidlet.vendor = "vendor";
		JadParser.jarMidlet.version = "1.5";
		JadParser.jarMidlet.profile = "profile";
		JadParser.jarMidlet.configuration = null;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJar(jadfile, flag));
		jadfile.delete();
	}

	/**
	 * there tests method validatejar and ajrFile is oms.jar and
	 * JadParser.jarMidlet.name = "name"; JadParser.jarMidlet.vendor = "vendor";
	 * JadParser.jarMidlet.version = "1.5"; JadParser.jarMidlet.profile =
	 * "profile"; JadParser.jarMidlet.configuration = "configuration";
	 * JadParser.jarMidlet.midletnum=0;
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testvalidatejarFilemidletnum() throws Exception {
		String path = "///sdcard/";
		String name = "oms.jar";
		Helper.createFileToSdcard(mContext, name, path);
		File jadfile = new File(path + name);
		boolean flag = false;
		JadParser.jarMidlet.name = "name";
		JadParser.jarMidlet.vendor = "vendor";
		JadParser.jarMidlet.version = "1.5";
		JadParser.jarMidlet.profile = "profile";
		JadParser.jarMidlet.configuration = "configuration";
		JadParser.jarMidlet.midletnum = 0;
		assertEquals(JadParser.STATUS_INVALID_DESCRIPTOR, JadParser
				.validateJar(jadfile, flag));
		jadfile.delete();
	}

	/**
	 * there tests method parsejadSec and path=""
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testparseJadSecpathIsNull() throws Exception {
		assertNull(JadParser.parseJadSec("", null));
	}

	/**
	 * there tests method parsejadSec and the File is Exist
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testparseJadSecFileExist() throws Exception {
		String path = "///sdcard/";
		String name = "oms.jar";
		Helper.createFileToSdcard(mContext, name, path);
		JadParser.parseJadSec(path + name, null);
	}
}
