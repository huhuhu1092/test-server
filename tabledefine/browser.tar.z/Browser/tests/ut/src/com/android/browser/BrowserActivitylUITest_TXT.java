package com.android.browser;

import java.util.concurrent.TimeUnit;

import android.app.AlertDialog;
import android.app.Instrumentation;
import android.app.Instrumentation.ActivityMonitor;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.SystemClock;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import com.android.browser.cmcc.CMCCAddBookmarkPage;
import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

/**
 * this class tests BrowserActivity in Browser application by UI
 * 
 * @author b357-DengLinling
 * 
 */
public class BrowserActivitylUITest_TXT extends InstrumentationTestCase {

	private Instrumentation mInst;
	private Context mCtx;
	private static BrowserActivity mActivity;
	private final static String BASEPATH = "/sdcard";
	public final static String TXT = "test.html";
	public final static String EMAIL = "email.html";
	public final static String PHONE = "phone.html";
	public final static String GEO = "geo.html";
	public final static String IMAGE = "image.html";
	public final static String JAVASCRIPT = "javascript.html";
	public final static String TXT_PATH = "file://" + BASEPATH + "/" + TXT;
	public final static String EMAIL_PATH = "file://" + BASEPATH + "/" + EMAIL;
	public final static String PHONE_PATH = "file://" + BASEPATH + "/" + PHONE;
	public final static String GEO_PATH = "file://" + BASEPATH + "/" + GEO;
	public final static String JAVASCRIPT_PATH = "file://" + BASEPATH + "/"
			+ JAVASCRIPT;
	public final static String IMAGE_PATH = "file://" + BASEPATH + "/" + IMAGE;
	public final static int MINITIME = 500;
	
	private static int sCount = 0;
	private static boolean sFlag = true;
	
	public BrowserActivitylUITest_TXT() {
		super();
		sCount ++;
	}

	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mInst.setInTouchMode(false);
		mCtx = mInst.getTargetContext();
		if(sFlag) {
			mActivity = launchActivity(TXT);
			sFlag = false;
		}
	}

	protected void tearDown() throws Exception {
		if (--sCount == 0 && mActivity != null) {
			mActivity.goQuit();
			SystemClock.sleep(15000);//wait for real finish
			mActivity = null;
		}
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.deleteFileAndFolder(BASEPATH);
		mCtx = null;
		mInst = null;
		super.tearDown();
	}

	// test method
	/**
	 * this case tests onOptionsItemSelected() method for dump_nav_menu_id
	 */
	@LargeTest
	public void testOnOptionsItemSelected_dump_nav() throws Exception {
		boolean navDump = BrowserSettings.getInstance().isNavDump();
		ReflectHelper.setPrivateField(BrowserSettings.getInstance(), "navDump",
				true);
		assertTrue(mActivity instanceof BrowserActivity);
		mInst.invokeMenuActionSync(mActivity, R.id.dump_nav_menu_id, 0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		ReflectHelper.setPrivateField(BrowserSettings.getInstance(), "navDump",
				navDump);
	}

	/**
	 * this case tests onOptionsItemSelected() for new_tab_menu
	 */
	@LargeTest
	// need to improve
	public void testOnOptionsItemSelected_new_tab_menu() throws Exception {
		assertTrue(mActivity instanceof BrowserActivity);
		//6.28
		Integer state = (Integer) ReflectHelper.getPrivateField(mActivity, "mMenuState");
		Log.e("###################testOnOptionsItemSelected_new_tab_menu############state1", state+"");
		ReflectHelper.setPrivateField(mActivity, "mMenuState", R.id.TAB_MENU);
		mInst.invokeMenuActionSync(mActivity, R.id.new_tab_menu_id, 0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		//6.28
		ReflectHelper.setPrivateField(mActivity, "mMenuState", state);
	}
//the following methods move to BrowserActivityTest
//	/**
//	 * this case tests onContextItemSelected() method for
//	 * copy_mail_context_menu_id
//	 * 
//	 * @throws MalformedMimeTypeException
//	 */
//	@LargeTest
//	public void testOnContextItemSelected_copy_email_context_menu()
//			throws MalformedMimeTypeException {
//
//		mActivity = launchActivity(EMAIL);
//		assertTrue(mActivity instanceof BrowserActivity);
//		showContextMenu();
////		assertNotNull(mActivity.findViewById(R.id.send_context_menu_id));
//		
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		Helper.HardKey.back(mInst);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}

//	/**
//	 * this case tests onContextItemSelected() method for
//	 * copy_phone_context_menu_id
//	 */
//	@LargeTest
//	public void testOnContextItemSelected_copy_phone_context_menu()
//			throws MalformedMimeTypeException {
//
//		mActivity = launchActivity(PHONE);
//		assertTrue(mActivity instanceof BrowserActivity);
//		showContextMenu();
////		assertNotNull(mActivity.findViewById(R.id.add_contact_context_menu_id));
//		// to click item "Copy"
//		Helper.HardKey.down(mInst);
//		SystemClock.sleep(MINITIME);
//		Helper.HardKey.down(mInst);
//		SystemClock.sleep(MINITIME);
//		Helper.HardKey.center(mInst);
//	}

//	/**
//	 * this case tests onContextItemSelected() method for
//	 * copy_geo_context_menu_id
//	 */
//	@LargeTest
//	public void testOnContextItemSelected_copy_geo_context_menu()
//			throws MalformedMimeTypeException {
//
//		mActivity = launchActivity(GEO);
//		assertTrue(mActivity instanceof BrowserActivity);
//		showContextMenu();
////		assertNotNull(mActivity.findViewById(R.id.copy_geo_context_menu_id));
//		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
//		Helper.HardKey.back(mInst);
//		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
//	}

//	/**
//	 * this case tests show image context menu
//	 */
//	@LargeTest
//	public void testShowImageContextMenu() {
//		mActivity = launchActivity(IMAGE);
//		assertTrue(mActivity instanceof BrowserActivity);
//		showContextMenu();
////		assertNotNull(mActivity
////				.findViewById(R.id.unknown_type_copy_text_menu_id));
//		// click context item "Copy Text"
//		Helper.HardKey.center(mInst);
//	}

	/**
	 * this case tests do flick on the blank place
	 */
	@LargeTest
	public void testClickOnControlPanel0() {
		assertNotNull(mActivity);
		sendMoveEvent();
		View button0 = mActivity.findViewById(R.id.button0);
		Helper.clickOn(mInst, button0);
	}

	/**
	 * this case tests do flick on the blank place
	 */
	@LargeTest
	public void testClickOnControlPanel1() {
		assertNotNull(mActivity);
		sendMoveEvent();
		View button1 = mActivity.findViewById(R.id.button1);
		Helper.clickOn(mInst, button1);
	}

	/**
	 * this case tests do flick on the blank place
	 */
	@LargeTest
	public void testClickOnControlPanel2() {
		assertNotNull(mActivity);
		sendMoveEvent();
		View button2 = mActivity.findViewById(R.id.button2);
		Helper.clickOn(mInst, button2);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.back(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	/**
	 * this case tests do flick on the blank place
	 */
	@LargeTest
	public void testClickOnControlPanel3() {
		ActivityMonitor monitor = new ActivityMonitor(CMCCAddBookmarkPage.class
				.getName(), null, true);
		mInst.addMonitor(monitor);
		try {
			assertNotNull(mActivity);
			sendMoveEvent();
			View button3 = mActivity.findViewById(R.id.button3);
			Helper.clickOn(mInst, button3);
			assertEquals(1, monitor.getHits());
		} finally {
			mInst.removeMonitor(monitor);
		}
	}

	/**
	 * this case tests do flick on the blank place
	 */
	@LargeTest
	public void testClickOnControlPanel4() {
		assertNotNull(mActivity);
		sendMoveEvent();
		View button4 = mActivity.findViewById(R.id.button4);
		Helper.clickOn(mInst, button4);
	}

	/**
	 * this case tests do flick on the blank place
	 */
	@LargeTest
	public void testClickOnControlPanel5() {
		assertNotNull(mActivity);
		sendMoveEvent();
		View button5 = mActivity.findViewById(R.id.button5);
		Helper.clickOn(mInst, button5);
	}

	/**
	 * this case tests do flick on the blank place
	 */
	@LargeTest
	public void testClickOnControlPanel6() {
		assertNotNull(mActivity);
		sendMoveEvent();
		View button6 = mActivity.findViewById(R.id.button6);
		Helper.clickOn(mInst, button6);
		SystemClock.sleep(MINITIME);

		mActivity.runOnUiThread(new Runnable() {
			public void run() {
				mActivity.hideControlPanel();
			}
		});
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

//	/**
//	 * this case tests the methods of WebChromeClient
//	 */
//	@LargeTest
//	public void testWebChromeClient() {
//		Helper.createFileToSdcard(mInst.getContext(), "test.png", BASEPATH);
//		Helper.createFileToSdcard(mInst.getContext(), TXT, BASEPATH);
//		mActivity = launchActivity(JAVASCRIPT);
//		assertTrue(mActivity instanceof BrowserActivity);
//		// open window by click link "open window"
//		Helper.HardKey.down(mInst);
//		Helper.HardKey.center(mInst);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}

	/**
	 * this case tests onOptionsMenuClosed() method by click back
	 */
	@LargeTest
	public void test03OnOptionsMenuClosedClickMenu() throws Exception {
		assertNotNull(mActivity);
		showAndHideOptionsMenuClickMenu();
	}

	/**
	 * this case tests onOptionsMenuClosed() method by click more actions
	 */
	@LargeTest
	public void test02OnOptionsMenuClosedClickBackClickMoreActions()
			throws Exception {
		assertNotNull(mActivity);
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
		clickMoreActions();
		
		//exit cancel
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
		Helper.HardKey.right(mInst);
		TimeUnit.SECONDS.sleep(1);
		Helper.HardKey.right(mInst);
		Helper.HardKey.right(mInst);
		Helper.HardKey.center(mInst);
		TimeUnit.SECONDS.sleep(1);
	}

	/**
	 * this case tests onOptionsMenuClosed() method by click back
	 */
	@LargeTest
	public void test01OnOptionsMenuClosedClickBack() throws Exception {
		assertNotNull(mActivity);
		showAndHideOptionsMenuClickBack();
	}

//	/**
//	 * this case tests onNewIntent() with action view and extra application id
//	 */
//	@LargeTest
//	public void testOnNewIntent_Action_View_Application_ID() throws Exception {
//		mActivity = launchActivity(EMAIL);
//		assertTrue(mActivity instanceof BrowserActivity);
//		final Intent intent = new Intent(Intent.ACTION_VIEW);
//		intent.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
//		intent.setData(Uri.parse(EMAIL_PATH));
//		intent.putExtra(Browser.EXTRA_APPLICATION_ID, "0"); // "0" is a random
//															// appId of Tab
//		mInst.runOnMainSync(new Runnable() {
//			public void run() {
//				mInst.callActivityOnNewIntent(mActivity, intent);
//				mInst.callActivityOnNewIntent(mActivity, intent);
//			}
//		});
//	}

	/**
	 * this case tests onAirplaneModeChanged() method
	 */
	@LargeTest
	public void testOnAirplaneModeChanged() throws Exception {
//		mActivity = launchActivity(TXT);
		assertTrue(mActivity instanceof BrowserActivity);
		BroadcastReceiver receiver = (BroadcastReceiver) ReflectHelper
				.getPrivateField(mActivity, "mBrowserIntentReceiver");
		Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
		intent.putExtra("state", true);
		receiver.onReceive(mCtx, intent);
		intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
		intent.putExtra("state", false);
		receiver.onReceive(mCtx, intent);
		
		AlertDialog airplaneOnDialog = (AlertDialog) ReflectHelper.getPrivateField(mActivity, "mAirplaneOnDialog");
	    AlertDialog airplaneOffDialog = (AlertDialog) ReflectHelper.getPrivateField(mActivity, "mAirplaneOffDialog");
	    if(airplaneOnDialog != null){
	    	airplaneOnDialog.dismiss();
	    }
	    if(airplaneOffDialog != null){
	    	airplaneOffDialog.dismiss();
	    }
	}

	/**
	 * this case tests onConfigurationChanged() method
	 */
	@LargeTest
	public void testOnConfigurationChanged() throws Exception {
		assertNotNull(mActivity);
		//show find menu
		mInst.invokeMenuActionSync(mActivity, R.id.find_menu_id, 0);
		SystemClock.sleep(MINITIME);
		Configuration newConfig = new Configuration();
		mActivity.onConfigurationChanged(newConfig);
		
		//close find menu
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		mInst.sendCharacterSync(KeyEvent.KEYCODE_BACK);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.right(mInst);
		SystemClock.sleep(MINITIME);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(5000);
	}

	//this test method will show search and can't close
//	/**
//	 * this case tests onSearchRequested() method
//	 */
//	@LargeTest
//	public void testOnSearchRequested() {
////		mActivity = launchActivity(TXT);
//		assertTrue(mActivity instanceof BrowserActivity);
//		mActivity.onSearchRequested();
//	}

	/**
	 * this case tests onKeyTraker() method
	 */
	@LargeTest
	public void testOnKeyTraker() {
		assertNotNull(mActivity);
		mActivity.onKeyTracker(KeyEvent.KEYCODE_BACK, null,
				KeyTracker.Stage.UP, 0);
	}
	
	public void testWifiNetwork() throws Exception {
		assertNotNull(mActivity);
		BroadcastReceiver receiver = (BroadcastReceiver) ReflectHelper
				.getPrivateField(mActivity, "mBrowserIntentReceiver");
		assertNotNull(receiver);
		Intent intent = new Intent(WifiManager.NETWORK_STATE_CHANGED_ACTION);
		NetworkInfo info = new NetworkInfo(0);
		intent.putExtra(WifiManager.EXTRA_NETWORK_INFO, info);
		receiver.onReceive(mCtx, intent);
	}
	
	/**
	 * From BrowserActivityUITest
	 */
	/**
	 * test: showTab()
	 * args: TabControl.Tab
	 * return: null
	 * @throws Exception
	 */
	@LargeTest
	public void testShowTab() throws Exception {
		assertNotNull(mActivity);
		TabControl tabControl = (TabControl) ReflectHelper.getPrivateField(
				mActivity, "mTabControl");
		assertNotNull(tabControl);
		final TabControl.Tab t = tabControl.getCurrentTab();
		assertNotNull(t);
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				assertNotNull(t);
				mActivity.showTab(t);
			}
		});
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
	}
	
	/**
	 * This method tests OnKeyDown and request code is KEYCODE_SPACE.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnKeyDownKEYCODE_SPACE() throws Exception {
		assertNotNull(mActivity);
		mActivity.runOnUiThread(new Runnable() {
			public void run() {
				assertTrue(mActivity.onKeyDown(KeyEvent.KEYCODE_SPACE,
						new KeyEvent(KeyEvent.ACTION_DOWN,
								KeyEvent.KEYCODE_SPACE)));
			}
		});
	}

	// help method
	/**
	 * launch activity with action view and file path
	 * 
	 * @param path
	 * @return
	 */
	private BrowserActivity launchActivity(String path) {
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setClass(mCtx, BrowserActivity.class);
		if (path == EMAIL) {
			Helper.createFileToSdcard(mInst.getContext(), EMAIL, BASEPATH);
			intent.setData(Uri.parse(EMAIL_PATH));
		} else if (path == PHONE) {
			Helper.createFileToSdcard(mInst.getContext(), PHONE, BASEPATH);
			intent.setData(Uri.parse(PHONE_PATH));
		} else if (path == TXT) {
			Helper.createFileToSdcard(mInst.getContext(), TXT, BASEPATH);
			intent.setData(Uri.parse(TXT_PATH));
		} else if (path == GEO) {
			Helper.createFileToSdcard(mInst.getContext(), GEO, BASEPATH);
			intent.setData(Uri.parse(GEO_PATH));
		} else if (path == JAVASCRIPT) {
			Helper.createFileToSdcard(mInst.getContext(), JAVASCRIPT, BASEPATH);
			intent.setData(Uri.parse(JAVASCRIPT_PATH));
		} else {
			Helper.createFileToSdcard(mInst.getContext(), IMAGE, BASEPATH);
			intent.setData(Uri.parse(IMAGE_PATH));
		}
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		BrowserActivity activity = (BrowserActivity) mInst
				.startActivitySync(intent);
		final int WAIT_FOR_LAUNCH = 60000;
		SystemClock.sleep(WAIT_FOR_LAUNCH);
		return activity;
	}

	/**
	 * send a pointer event: move from (100,100) to (0,100)
	 */
	private void sendMoveEvent() {
		MotionEvent event = MotionEvent.obtain(0, MINITIME,
				MotionEvent.ACTION_DOWN, 100, 100, 0);
		mInst.sendPointerSync(event);
		event = MotionEvent.obtain(0, MINITIME, MotionEvent.ACTION_MOVE, 0,
				100, 0);
		mInst.sendPointerSync(event);
		event = MotionEvent.obtain(0, MINITIME, MotionEvent.ACTION_UP, 0, 100,
				0);
		mInst.sendPointerSync(event);
		SystemClock.sleep(MINITIME);
	}

	/**
	 * send keycode_menu and keycode_back events to show and hide options menu
	 */
	private void showAndHideOptionsMenuClickMenu() throws Exception {
		mInst.sendKeyDownUpSync(KeyEvent.KEYCODE_MENU);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		mInst.sendKeyDownUpSync(KeyEvent.KEYCODE_MENU);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	/**
	 * send keycode_menu and keycode_back events to show and hide options menu
	 * call  showFakeTitleBar() which in onOptionsMenuClosed(Menu menu)
	 */
	private void showAndHideOptionsMenuClickBack() throws Exception {
		mInst.sendKeyDownUpSync(KeyEvent.KEYCODE_MENU);
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
		//6.28 
		Boolean inload = (Boolean) ReflectHelper.getPrivateField(mActivity, "mInLoad");
		Boolean iconView = (Boolean) ReflectHelper.getPrivateField(mActivity, "mIconView");
		ReflectHelper.setPrivateField(mActivity, "mInLoad", true);
		ReflectHelper.setPrivateField(mActivity, "mIconView", false);
		mInst.sendKeyDownUpSync(KeyEvent.KEYCODE_MENU);
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
		ReflectHelper.setPrivateField(mActivity, "mInLoad", inload);
		ReflectHelper.setPrivateField(mActivity, "mIconView", iconView);
	}

	/**
	 * send keycode_menu and keycode_back events to show and hide options menu
	 */
	private void clickMoreActions() throws Exception {
		mInst.sendKeyDownUpSync(KeyEvent.KEYCODE_MENU);
		TimeUnit.SECONDS.sleep(2);
		mInst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_DOWN);
		mInst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_RIGHT);
		mInst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_RIGHT);
		TimeUnit.SECONDS.sleep(1);
		mInst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_RIGHT);
		mInst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_DOWN);
		mInst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_CENTER);
		TimeUnit.SECONDS.sleep(1);
	}
}
