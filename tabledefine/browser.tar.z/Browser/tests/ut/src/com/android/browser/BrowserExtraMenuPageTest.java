package com.android.browser;

import com.android.browser.unittests.testutil.Helper;
import android.app.Instrumentation;
import android.content.Intent;
import android.os.SystemClock;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;

/**
 * test BrowserExtraMenuPage.java.
 * 
 * @author Tang Ting
 * 
 */
public class BrowserExtraMenuPageTest extends InstrumentationTestCase {
	private static final int SHORT_TIME = 500;
	private BrowserExtraMenuPage mBrowserExtraMenuPage;
	private Instrumentation mInst;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
	}

	@Override
	protected void tearDown() throws Exception {
		if (mBrowserExtraMenuPage != null) {
			mBrowserExtraMenuPage.finish();
			SystemClock.sleep(SHORT_TIME);
			mBrowserExtraMenuPage = null;
		}
		mInst = null;
		super.tearDown();
	}

	// method
	// launch BrowserHistoryPage Activity
	private BrowserExtraMenuPage launchActvitiy() {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName(mInst.getTargetContext(),
				BrowserExtraMenuPage.class.getName());
		return (BrowserExtraMenuPage) mInst.startActivitySync(intent);
	}

	/**
	 * test onListItemClick()
	 */
	@LargeTest
	public void testonListItemClick() {
		mBrowserExtraMenuPage = launchActvitiy();
		SystemClock.sleep(SHORT_TIME);
		assertNotNull(mBrowserExtraMenuPage);

		Helper.HardKey.down(mInst);
		SystemClock.sleep(SHORT_TIME);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(SHORT_TIME);
	}
}
