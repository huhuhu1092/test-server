package com.android.browser;

import android.app.Instrumentation;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.MediumTest;
import android.test.suitebuilder.annotation.Suppress;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;

import com.android.browser.TabControl.Tab;
/**the class is used to test ImageGrid.
 * @author b364-Pang Hongwei
 * */
@Suppress
public class ImageGridTest extends InstrumentationTestCase {
     public ImageGridTest(){
    	 super();
    	 caseCount++;
     }
     private static int caseCount = 0;
     private static boolean activityLive = true;
     private static BrowserActivity mActivity;
     private static Instrumentation mInst = null;
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		if(activityLive){
			mActivity = launchActivity();
			activityLive = false;
		}
	}
 
	@Override
	protected void tearDown() throws Exception {
		if(--caseCount == 0 && mActivity != null){
			finishActivity();
		}
		
		super.tearDown();
	}
	/**launching BrowserActivity.
	 * @throws Exception
	 * */
	private static BrowserActivity launchActivity() throws Exception{
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.setClassName("com.android.browser", BrowserActivity.class.getName());
			BrowserActivity activity =(BrowserActivity)mInst.startActivitySync(intent);
			SystemClock.sleep(60000);
			assertNotNull(activity);
		return activity;
	}
	/**test the constructor of ImageGrid.
	 * @throws Exception
	 * */
	@LargeTest
	public void testT001ImageGridConstructorAndDispatchKeyDown()throws Exception{
//		class Listener implements BrowserTabViewListener{
//			public void onClick(int position) {
//				Log.i("ImageGridTest", "###########click cancle");
//			}
//			public void remove(int position) {
//			}	
//		}	
		final ImageGrid imageGrid = new ImageGrid(mActivity, true, new Listener());
		//call KEYCODE_BACK down.
		final KeyEvent  backDown = new KeyEvent(100,100,KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_BACK,0);	
		mInst.runOnMainSync(new Runnable(){
			public void run(){
				imageGrid.dispatchKeyEvent(backDown);
			}
		});
		//call other KeyEvent.
		final KeyEvent  event = new KeyEvent(100,100,KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_DPAD_CENTER,0);	
		mInst.runOnMainSync(new Runnable(){
			public void run(){
				imageGrid.dispatchKeyEvent(event);
			}
		});
	}
	/**test setting and getting listener.
	 * @throws Exception
	 * */
	@LargeTest
	public void testT002SetListener()throws Exception{
//		ImageGrid.Listener listener=(ImageGrid.Listener)ReflectHelper.getPrivateInnerClass(mActivity, "com.android.browser.BrowserActivity$TabListener", new Class[]{mActivity.getClass()}, new Object[]{mActivity});
//		ImageGrid imageGrid = new ImageGrid(mActivity,true,listener);
//		assertEquals(listener,imageGrid.getListener());
		ImageGrid imageGrid = new ImageGrid(mActivity, true, new Listener());
		imageGrid.setListener(null);
//		assertNull(imageGrid.getListener());
	}
	/**test add tab and set current tab.
	 * @throws Exception
	 * */
	@MediumTest
	public void testT003AddTabAndSetCurrent()throws Exception{
//		ImageGrid.Listener listener=(ImageGrid.Listener)ReflectHelper.getPrivateInnerClass(mActivity, "com.android.browser.BrowserActivity$TabListener", new Class[]{mActivity.getClass()}, new Object[]{mActivity});
//		ImageGrid imageGrid = new ImageGrid(mActivity,true,listener);
		ImageGrid imageGrid = new ImageGrid(mActivity, true, new Listener());
		//construct tab.
		TabControl control = new TabControl(mActivity);
		Tab tab =control.createNewTab(false, "ID-1", "http://www.baidu.com/");
		control.setCurrentTab(tab);
		//set current tab.
		imageGrid.add(control.getCurrentTab());
		imageGrid.setCurrentIndex(2);
		assertTrue(imageGrid.isLive());
	}
	/**test adapter.
	 * @throws Exception
	 * */	
	@MediumTest
	public void testT004Adpater()throws Exception{
//		class Listener implements BrowserTabViewListener{
//			public void onClick(int position) {
//			}
//			public void remove(int position) {
//				Log.i("ImageGridTest#testOnItemClick", "###########click item!");
//			}	
//		}	
		ImageGrid imageGrid = new ImageGrid(mActivity,true,new Listener());
		imageGrid.remove(2);
		imageGrid.clear();
		assertNull(imageGrid.getItemAtPosition(0));
	}
	/**test onItemClick();
	 *@throws Exception
	 * */
	@MediumTest
	public void testT005OnItemClick()throws Exception{
//		class Listener implements BrowserTabViewListener{
//			public void onClick(int position) {
//				Log.i("ImageGridTest#testOnItemClick", "###########click item!");
//			}
//			public void remove(int position) {
//			}	
//		}	
		final ImageGrid imageGrid = new ImageGrid(mActivity,true,new Listener());
		mInst.runOnMainSync(new Runnable(){
			public void run(){
				imageGrid.onItemClick(null, null, 1, 0);
			}
		});
	
	}
	/**test onCreateContextMenu()
	 * @throws Exception*/
	@MediumTest
	public void testT006OnCreateContextMenu()throws Exception{
//		class Listener implements BrowserTabViewListener{
//			public void onClick(int position) {
//				Log.i("ImageGridTest#testOnItemClick", "###########onCreateContextMenu!");
//			}
//			public void remove(int position) {
//			}	
//		}	
		//listener is null 
		ImageGrid imageGrid01 = new ImageGrid(mActivity, true, null);
		imageGrid01.onCreateContextMenu(null, null, null);
		
		//the position of menu info  is 0 
		ImageGrid imageGrid02 = new ImageGrid(mActivity, true, new Listener());
		AdapterView.AdapterContextMenuInfo info01 = new AdapterContextMenuInfo(imageGrid01,0,0);
		imageGrid02.onCreateContextMenu(new MockMenu(), imageGrid02, info01);
		//the position of menu info not 0 and  parameter maxed false.
		AdapterView.AdapterContextMenuInfo info02 = new AdapterContextMenuInfo(imageGrid01,1,0);
		TabControl control = new TabControl(mActivity);
		imageGrid02.add(control.createNewTab(false,"ID-0","http://www.hao123.com/"));
		imageGrid02.onCreateContextMenu(new MockMenu(), imageGrid02, info02);
	}
	/**test getContextMenuPosition().
	 * @throws Exception.
	 * */
	@MediumTest
	public void testT007GetContextMenuPosition()throws Exception{
//		ImageGrid.Listener listener=(ImageGrid.Listener)ReflectHelper.getPrivateInnerClass(mActivity, "com.android.browser.BrowserActivity$TabListener", new Class[]{mActivity.getClass()}, new Object[]{mActivity});
//		ImageGrid imageGrid = new ImageGrid(mActivity,true,listener);
		ImageGrid imageGrid = new ImageGrid(mActivity, true, new Listener());
		assertEquals(0,imageGrid.getContextMenuPosition(new MockMenuItem()));
	}
	/**test onSizeChanged().
	 * @throws Exception
	 * */
	@MediumTest
	public void testT008OnSizeChanged()throws Exception{
//		ImageGrid.Listener listener=(ImageGrid.Listener)ReflectHelper.getPrivateInnerClass(mActivity, "com.android.browser.BrowserActivity$TabListener", new Class[]{mActivity.getClass()}, new Object[]{mActivity});
//		ImageGrid imageGrid = new ImageGrid(mActivity,true,listener);
		ImageGrid imageGrid = new ImageGrid(mActivity, true, new Listener());
		imageGrid.onSizeChanged(10, 10, imageGrid.getHeight(),imageGrid.getWidth());
	}
	
	//b392 5.24
	private void finishActivity() {
		if (mActivity != null) {
			mActivity.goQuit();
			SystemClock.sleep(15000);
			mActivity = null;
		}
	}
	
	
	/**mock ContextMenu.
	 * */
	private class MockMenu implements ContextMenu{
		public void clearHeader() {	
		}

		public ContextMenu setHeaderIcon(int arg0) {
			return null;
		}

		public ContextMenu setHeaderIcon(Drawable arg0) {
			return null;
		}

		public ContextMenu setHeaderTitle(int arg0) {
			return null;
		}
		public ContextMenu setHeaderTitle(CharSequence arg0) {
			return null;
		}

		public ContextMenu setHeaderView(View arg0) {
			return null;
		}

		public MenuItem add(CharSequence arg0) {
			return null;
		}

		public MenuItem add(int arg0) {
			return null;
		}

		public MenuItem add(int arg0, int arg1, int arg2, CharSequence arg3) {
			return new MockMenuItem();
		}

		public MenuItem add(int arg0, int arg1, int arg2, int arg3) {
			return new MockMenuItem();
		}

		public int addIntentOptions(int arg0, int arg1, int arg2,
				ComponentName arg3, Intent[] arg4, Intent arg5, int arg6,
				MenuItem[] arg7) {
			return 0;
		}

		public SubMenu addSubMenu(CharSequence arg0) {
			return null;
		}

		public SubMenu addSubMenu(int arg0) {
			return null;
		}

		public SubMenu addSubMenu(int arg0, int arg1, int arg2,
				CharSequence arg3) {
			return null;
		}

		public SubMenu addSubMenu(int arg0, int arg1, int arg2, int arg3) {
			return null;
		}

		public void clear() {
		}

		public void close() {		
		}

		public MenuItem findItem(int arg0) { 
			return null;
		}

		public MenuItem getItem(int arg0) {	 
			return null;
		}

		public boolean hasVisibleItems() {	 
			return false;
		}

		public boolean isShortcutKey(int arg0, KeyEvent arg1) { 
			return false;
		}

		public boolean performIdentifierAction(int arg0, int arg1) {
			return false;
		}

		public boolean performShortcut(int arg0, KeyEvent arg1, int arg2) {	 
			return false;
		}

		public void removeGroup(int arg0) {
		}

		public void removeItem(int arg0) {
		}

		public void setGroupCheckable(int arg0, boolean arg1, boolean arg2) {
		}

		public void setGroupEnabled(int arg0, boolean arg1) {	
		}

		public void setGroupVisible(int arg0, boolean arg1) {	
		}

		public void setQwertyMode(boolean arg0) {	
		}

		public int size() {
			return 0;
		}
		
	}
	/**mock MenuItem.
	 * */
	private class MockMenuItem implements MenuItem{
		
		public char getAlphabeticShortcut() {
		 
			return 0;
		}

		public int getGroupId() {
		 
			return 0;
		}

		public Drawable getIcon() {
		 
			return null;
		}

		public Intent getIntent() {
		 
			return null;
		}

		public int getItemId() {
		 
			return 0;
		}

		public ContextMenuInfo getMenuInfo() {
		 
			return new AdapterContextMenuInfo(null,1,0);
		}

		public char getNumericShortcut() {
		 
			return 0;
		}

		public int getOrder() {
		 
			return 0;
		}

		public SubMenu getSubMenu() {
		 
			return null;
		}

		public CharSequence getTitle() {
		 
			return null;
		}

		public CharSequence getTitleCondensed() {
		 
			return null;
		}

		public boolean hasSubMenu() {
		 
			return false;
		}

		public boolean isCheckable() {
		 
			return false;
		}

		public boolean isChecked() {
		 
			return false;
		}

		public boolean isEnabled() {
		 
			return false;
		}

		public boolean isVisible() {
		 
			return false;
		}

		public MenuItem setAlphabeticShortcut(char arg0) {
		 
			return  new MockMenuItem();
		}

		public MenuItem setCheckable(boolean arg0) {
		 
			return new MockMenuItem();
		}

		public MenuItem setChecked(boolean arg0) {
		 
			return new MockMenuItem();
		}

		public MenuItem setEnabled(boolean arg0) {
		 
			return new MockMenuItem();
		}

		public MenuItem setIcon(Drawable arg0) {
		 
			return new MockMenuItem();
		}

		public MenuItem setIcon(int arg0) {
		 
			return new MockMenuItem();
		}

		public MenuItem setIntent(Intent arg0) {
		 
			return new MockMenuItem();
		}

		public MenuItem setNumericShortcut(char arg0) {
		 
			return new MockMenuItem();
		}

		public MenuItem setOnMenuItemClickListener(OnMenuItemClickListener arg0) {
		 
			return new MockMenuItem();
		}

		public MenuItem setShortcut(char arg0, char arg1) {
		 
			return new MockMenuItem();
		}

		public MenuItem setTitle(CharSequence arg0) {
		 
			return new MockMenuItem();
		}

		public MenuItem setTitle(int arg0) {
		 
			return new MockMenuItem();
		}

		public MenuItem setTitleCondensed(CharSequence arg0) {
		 
			return new MockMenuItem();
		}

		public MenuItem setVisible(boolean arg0) {
		 
			return new MockMenuItem();
		}
		
	}
	
	private class Listener implements BrowserTabViewListener{
		public void onClick(int position) {
		}
		public void remove(int position) {
		}	
	}

}
