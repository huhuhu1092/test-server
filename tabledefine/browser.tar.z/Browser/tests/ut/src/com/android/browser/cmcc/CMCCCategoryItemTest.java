package com.android.browser.cmcc;

import android.test.AndroidTestCase;
import android.test.suitebuilder.annotation.MediumTest;
import android.test.suitebuilder.annotation.SmallTest;

/**
 * test CMCCCategoryItem.java.
 * 
 * @author Tang Ting
 * 
 */
public class CMCCCategoryItemTest extends AndroidTestCase {
	private CMCCCategoryItem mCMCCCategoryItem;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mCMCCCategoryItem = new CMCCCategoryItem(getContext());
	}

	@Override
	protected void tearDown() throws Exception {
		mCMCCCategoryItem = null;
		super.tearDown();
	}

	/**
	 * test copyTo
	 */
	@SmallTest
	public void testcopyTo() {
		mCMCCCategoryItem.copyTo(mCMCCCategoryItem);
	}

	/**
	 * test setName and getName
	 */
	@MediumTest
	public void testSetAndGetName() {
		String name = "borqs";
		mCMCCCategoryItem.setName(name);
		assertEquals(name, mCMCCCategoryItem.getName());
	}

	/**
	 * test getNameTextView
	 */
	@SmallTest
	public void testgetNameTextView() {
		assertNotNull(mCMCCCategoryItem.getNameTextView());
	}

	/**
	 * test setCount
	 */
	@SmallTest
	public void testsetCount() {
		int count = 10;
		mCMCCCategoryItem.setCount(count);
	}

	/**
	 * test setPreloaded and getPreloaded
	 */
	@SmallTest
	public void testSetAndGetPreloaded() {
		boolean preloaded = true;
		mCMCCCategoryItem.setPreloaded(preloaded);
		assertTrue(mCMCCCategoryItem.getPreloaded());
	}

}
