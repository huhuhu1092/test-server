package com.android.browser.midlet;

import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.Downloads;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.MediumTest;
import android.test.suitebuilder.annotation.Suppress;

import com.android.browser.BrowserActivity;
import com.android.browser.unittests.testutil.Helper;

/**
 * test MidletDownloadManager.java
 * 
 * @author Tang Ting
 * 
 */
@Suppress
public class MidletDownloadManagerTest extends InstrumentationTestCase {
	private static final String JAD_DOWNLOAD_URL = "http://borqstom.8800.org/"
			+ "JavaDownload/AppsDownloadTesting/PlayTone.jad";
	private static final String JAR_DOWNLOAD_URL = "http://borqstom.8800.org/"
			+ "JavaDownload/AppsDownloadTesting/PlayTone.jar";

	private static final int UNNORMAL_STATUS = 899;
	private static final int SHORT_TIME = 500;
	private static final int LONG_TIME = 5000;

	private final static int INSTALL_MIDLET = 5;
	private MidletDownloadManager mMidletDownloadManager;
	private Instrumentation mInst;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mInst.setInTouchMode(false);
	}

	@Override
	protected void tearDown() throws Exception {
		clearAllDownloads();
		if (mMidletDownloadManager != null) {
			mMidletDownloadManager.finish();
			SystemClock.sleep(SHORT_TIME);
			mMidletDownloadManager = null;
		}
		mInst = null;
		super.tearDown();
	}

	/**
	 * test onCreate when Uri is null
	 */
	@LargeTest
	public void testonCreate_UriIsNull() {
		mMidletDownloadManager = launchActivity(null, 0);
		assertNotNull(mMidletDownloadManager);
	}

	/**
	 * test onCreate when DB is null
	 */
	@LargeTest
	public void testonCreate_DBIsNull() {
		Uri data = Downloads.CONTENT_URI;
		mMidletDownloadManager = launchActivity(data, 0);
		assertNotNull(mMidletDownloadManager);
	}

	/**
	 * test onCreate when STATUS_USER_CANCELLED (getIntExtra("postIndicate",
	 * -1)=902)
	 */
	@LargeTest
	public void testonCreate_StatusUserCancelled() {
		InsertDataInDownloads();
		Uri data = Downloads.CONTENT_URI;
		mMidletDownloadManager = launchActivity(data,
				MidletDownloadManager.STATUS_USER_CANCELLED);
		assertNotNull(mMidletDownloadManager);
	}

	/**
	 * test onCreate when file doesn't download successfully(status != 200) and
	 * the type of file is jar
	 */
	@LargeTest
	public void testonCreate_JarTypeFileDownloadNoSuccess() {
		InsertDataInDownloads();
		Uri data = Downloads.CONTENT_URI;
		mMidletDownloadManager = launchActivity(data,
				MidletDownloadManager.STATUS_LOSS_OF_SERVICE);
		assertNotNull(mMidletDownloadManager);
	}

	/**
	 * test onCreate when file downloads successfully(status = 200) and the type
	 * of file is jar
	 */
	@LargeTest
	public void testonCreate_JarTypeFileDownloadSuccess() throws Exception {

		IntentFilter filter = new IntentFilter(
				"android.intent.action.BORQS_MIDLETBOX_OTA");
		filter.addCategory("android.intent.category.DEFAULT");
		filter.addDataType("text/vnd.sun.j2me.app-descriptor");
		filter.addDataType("application/java-archive");
		Instrumentation.ActivityMonitor monitor = new Instrumentation.ActivityMonitor(
				filter, null, true);
		mInst.addMonitor(monitor);
		SystemClock.sleep(SHORT_TIME);

		completedDownload(JAR_DOWNLOAD_URL,
				MidletDownloadManager.MIDLET_JAR_TYPE);
		SystemClock.sleep(LONG_TIME);

		completedDownload(JAD_DOWNLOAD_URL,
				MidletDownloadManager.MIDLET_JAD_TYPE);
		SystemClock.sleep(LONG_TIME);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(LONG_TIME);

		Uri data = Downloads.CONTENT_URI;
		mMidletDownloadManager = launchActivity(data,
				MidletDownloadManager.STATUS_SUCCESS);
		assertNotNull(mMidletDownloadManager);
		mInst.removeMonitor(monitor);
	}

	/**
	 * test onCreate when file downloads successfully(status = 200) and the type
	 * of file is jad
	 */
	@LargeTest
	public void testonCreate_JadTypeFileDownloadNoSuccess() {
		completedDownload(JAD_DOWNLOAD_URL,
				MidletDownloadManager.MIDLET_JAD_TYPE);

		Uri data = Downloads.CONTENT_URI;
		mMidletDownloadManager = launchActivity(data,
				MidletDownloadManager.STATUS_SUCCESS);
		assertNotNull(mMidletDownloadManager);
		SystemClock.sleep(LONG_TIME);

		Helper.HardKey.right(mInst);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(SHORT_TIME);
	}

	/**
	 * test onActivityResult
	 */
	@LargeTest
	public void testonActivityResult() {
		int requestCode = INSTALL_MIDLET;
		int resultCode = 910;
		String[] deleteNotifyArr = new String[] { "test", "test1" };
		Intent intent = new Intent();
		intent.putExtra("serverUrl", JAD_DOWNLOAD_URL);
		intent.putExtra("deleteFlag", true);
		intent.putExtra("deleteNotifyArr", deleteNotifyArr);

		Uri data = Downloads.CONTENT_URI;
		mMidletDownloadManager = launchActivity(data,
				MidletDownloadManager.STATUS_SUCCESS);
		assertNotNull(mMidletDownloadManager);
		mMidletDownloadManager
				.onActivityResult(requestCode, resultCode, intent);
	}

	/**
	 * test guessFileName
	 */
	@MediumTest
	public void testguessFileName() {
		String url = JAD_DOWNLOAD_URL;
		assertEquals("PlayTone.jad", MidletDownloadManager.guessFileName(url,
				null));
	}

	/**
	 * test getStatuseString
	 */
	@LargeTest
	public void testgetStatuseString() {
		Uri data = Downloads.CONTENT_URI;
		mMidletDownloadManager = launchActivity(data,
				MidletDownloadManager.STATUS_SUCCESS);
		assertEquals("", mMidletDownloadManager
				.getStatuseString(UNNORMAL_STATUS));
		assertEquals("900 Success", mMidletDownloadManager
				.getStatuseString(MidletDownloadManager.STATUS_SUCCESS));
	}

	/**
	 * test isMidletType
	 */
	@MediumTest
	public void testisMidletType() {
		assertTrue(MidletDownloadManager
				.isMidletType(MidletDownloadManager.MIDLET_JAD_TYPE));
	}

	// ***********************************Method*************************************
	// launchActivity
	private MidletDownloadManager launchActivity(Uri data, int extra) {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName(mInst.getTargetContext(),
				MidletDownloadManager.class.getName());
		intent.setData(data);
		intent.putExtra("postIndicate", extra);
		return (MidletDownloadManager) mInst.startActivitySync(intent);
	}

	// insert Data in downloads
	// private void InsertDataInDownloads(String column_uri, String title,
	// String data, String mimetype, String notification, Integer status,
	// String network, String host, Integer port, String useragent) {
	// ContentResolver mContentResolver = mInst.getContext()
	// .getContentResolver();
	// ContentValues values = new ContentValues();
	// values.put(Downloads.COLUMN_URI, column_uri);
	// values.put(Downloads.COLUMN_TITLE, title);
	// values.put(Downloads._DATA, data);
	// values.put(Downloads.COLUMN_MIME_TYPE, mimetype);
	// values.put(Downloads.COLUMN_NOTIFICATION_EXTRAS, notification);
	// values.put(Downloads.COLUMN_STATUS, status);
	// values.put(Downloads.COLUMN_NETWORK_INTERFACE, network);
	// values.put(Downloads.COLUMN_PROXY_HOST, host);
	// values.put(Downloads.COLUMN_PROXY_PORT, port);
	// values.put(Downloads.COLUMN_USER_AGENT, useragent);
	// Uri uri = mContentResolver.insert(Downloads.CONTENT_URI, values);
	// assertNotNull("Insert history to DB failed! ", uri);
	// SystemClock.sleep(SHORT_TIME);
	// }

	// insert Data in downloads DB
	private void InsertDataInDownloads() {
		String wrongDownloadUrl = "http://www.baidu.com";
		String downloadFileName = "PlayTone";
		String downloadStoredPath = "/sdcard/";
		String wrongProxyHost = "192.168.1.1";
		int wrongProxtPort = 8080;
		ContentResolver resolver = mInst.getContext().getContentResolver();
		ContentValues values = new ContentValues();
		values.put(Downloads.COLUMN_URI, wrongDownloadUrl);
		values.put(Downloads.COLUMN_TITLE, downloadFileName);
		values.put(Downloads._DATA, downloadStoredPath);
		values.put(Downloads.COLUMN_MIME_TYPE,
				MidletDownloadManager.MIDLET_JAR_TYPE);
		values.put(Downloads.COLUMN_STATUS, Downloads.STATUS_HTTP_DATA_ERROR);
		values.put(Downloads.COLUMN_PROXY_HOST, wrongProxyHost);
		values.put(Downloads.COLUMN_PROXY_PORT, wrongProxtPort);
		Uri uri = resolver.insert(Downloads.CONTENT_URI, values);
		assertNotNull("Insert history to DB failed! ", uri);
		SystemClock.sleep(SHORT_TIME);
	}

	// completed download once
	private void completedDownload(String url, String type) {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName(mInst.getTargetContext(), BrowserActivity.class
				.getName());
		BrowserActivity browserActivity = (BrowserActivity) mInst
				.startActivitySync(intent);
		browserActivity.onDownloadStart(url, null, null, type, 0);
		SystemClock.sleep(LONG_TIME);
		browserActivity.finish();
		SystemClock.sleep(LONG_TIME);
		browserActivity = null;
	}

	// delete all data in downloads both completed and uncompleted
	private void clearAllDownloads() {
		Cursor downloadCursor;
		ContentResolver resolver = mInst.getContext().getContentResolver();
		downloadCursor = resolver.query(Downloads.CONTENT_URI, null, null,
				null, null);
		int columnId = downloadCursor.getColumnIndexOrThrow(Downloads._ID);
		if (downloadCursor.moveToFirst()) {
			StringBuilder where = new StringBuilder();
			boolean firstTime = true;
			while (!downloadCursor.isAfterLast()) {
				if (firstTime) {
					firstTime = false;
				} else {
					where.append(" OR ");
				}
				where.append("( ");
				where.append(Downloads._ID);
				where.append(" = '");
				where.append(downloadCursor.getLong(columnId));
				where.append("' )");
				downloadCursor.moveToNext();
			}
			if (!firstTime) {
				resolver.delete(Downloads.CONTENT_URI, where.toString(), null);
			}
		}
		downloadCursor.close();
		downloadCursor = null;
	}
}
