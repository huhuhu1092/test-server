package com.android.browser;



import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;

import com.android.browser.unittests.testutil.Helper;

/**
 * Test FindDialog.java.
 * @author b391(LuoXiaofei)
 *
 */
@Suppress
public class FindDialogTest extends ActivityUnitTestCase<BrowserActivity>{

	private Instrumentation mInst;
	private Context mContext;
	private static BrowserActivity mBrowserActivity;
	private FindDialog mFindDialog;
//	private final static String name="test.txt";
	private final static String name="test.html";
	private final static String path="/sdcard";
//	private final static String filepath="file:///sdcard/test.txt";
	private final static String filepath="file:///sdcard/test.html";
	
	private static int count = 0;

	public FindDialogTest() {
		super(BrowserActivity.class);
		count ++;
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst=getInstrumentation();
		mInst.setInTouchMode(false);
		mContext=mInst.getTargetContext();
		if(mBrowserActivity == null){
			mBrowserActivity = launchBrowserActivity();
		}
	}

	@Override
	protected void tearDown() throws Exception {
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		if (--count == 0 && mBrowserActivity != null) {
			finishActivity();
		}
		if (mFindDialog != null) {
			mFindDialog = null;
		}
		mInst=null;
		mContext=null;
		super.tearDown();
	}
//	/**
//	 * there tests new FindDialog and the method show
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testsNewFindDialog()throws Exception
//	{
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		assertNotNull(mBrowserActivity);
//		mFindDialog=new FindDialog(mBrowserActivity);
//		mFindDialog.setWebView(getWebView());
//		mFindDialog.show();
//		SystemClock.sleep(1000);
//		Helper.HardKey.right(mInst);
//		SystemClock.sleep(500);
//		Helper.HardKey.center(mInst);
//		SystemClock.sleep(500);
//	}
	/**
	 * there tests method dispatchKeyEvent
	 * @throws Exception
	 */
	@LargeTest
	public void testdispatchKeyEvent()throws Exception
	{
		KeyEvent event=new KeyEvent(KeyEvent.ACTION_UP,KeyEvent.KEYCODE_ENTER);
		
		assertNotNull(mBrowserActivity);
		mFindDialog = new FindDialog(mBrowserActivity);
		mFindDialog.show();
		mFindDialog.setWebView(getWebView());
		assertTrue(mFindDialog.dispatchKeyEvent(event));
	}
	/**
	 *there tests click view R.id.next 
	 * @throws Exception
	 */
	@LargeTest
	public void testnextView()throws Exception
	{
		assertNotNull(mBrowserActivity);
		mFindDialog=new FindDialog(mBrowserActivity);
		mFindDialog.show();
		mFindDialog.setWebView(getWebView());
		View button = mFindDialog.findViewById(R.id.next);
		button.performClick();
	}
	/**
	 *there tests click view R.id.next and webView is null
	 * @throws Exception
	 */
	@LargeTest
	public void testnextViewWebViewIsNull()throws Exception
	{
		assertNotNull(mBrowserActivity);
		mFindDialog=new FindDialog(mBrowserActivity);
		mFindDialog.show();
//		mFindDialog.setWebView(getWebView());
		try {
			View button = mFindDialog.findViewById(R.id.next);
			button.performClick();
		} catch (AssertionError e) {
		}
	}
	/**
	 *there tests click view R.id.previous 
	 * @throws Exception
	 */
	@LargeTest
	public void testnextprevious()throws Exception
	{
		assertNotNull(mBrowserActivity);
		mFindDialog = new FindDialog(mBrowserActivity);
		mFindDialog.show();
		mFindDialog.setWebView(getWebView());
		View button = mFindDialog.findViewById(R.id.previous);
		button.performClick();
	}
	/**
	 *there tests click view R.id.previous webview is null
	 * @throws Exception
	 */
	@LargeTest
	public void testnextpreviousWebviewIsNull()throws Exception
	{
		assertNotNull(mBrowserActivity);
		mFindDialog = new FindDialog(mBrowserActivity);
//		mFindDialog.setWebView(getWebView());
		mFindDialog.show();
		try {
			View button = mFindDialog.findViewById(R.id.previous);
			button.performClick();
		} catch (AssertionError e) {
		}
	}
	/**
	 *there tests click view R.id.done
	 * @throws Exception
	 */
	@LargeTest
	public void testViewDone() throws Exception {
//		mBrowserActivity = launchBrowserActivity();
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.find_menu_id, 0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.right(mInst);
		SystemClock.sleep(500);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}
	/**
	 *there tests onTextChanged
	 * @throws Exception
	 */
	@LargeTest
	public void testonTextChanged() throws Exception {
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.find_menu_id, 0);
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
		mInst.sendStringSync("luo");
		Helper.HardKey.enter(mInst);
		SystemClock.sleep(500);
		Helper.HardKey.back(mInst);
		SystemClock.sleep(500);
		Helper.HardKey.right(mInst);
		SystemClock.sleep(500);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(500);
	}
	
	
	// help method
	/**
	 * there launchUIBrowserActivity
	 */
	private BrowserActivity launchBrowserActivity() {
		Helper.createFileToSdcard(mInst.getContext(), name, path);
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse(filepath));
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClass(mContext, BrowserActivity.class);
		mBrowserActivity = (BrowserActivity) mInst.startActivitySync(intent);
		SystemClock.sleep(60000);
		return mBrowserActivity;
	}
	
	//b392 5.20
	private void finishActivity() throws Exception {
		if (mBrowserActivity != null) {
			mBrowserActivity.goQuit();
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
			mBrowserActivity = null;
			Helper.deleteFileAndFolder("/sdcard");
		}
	}
	
	private WebView getWebView() {
		return mBrowserActivity.getCurrentWebView();
	}
	//end

}
