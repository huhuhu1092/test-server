package com.android.browser;

import com.android.browser.KeyTracker.OnKeyTracker;
import com.android.browser.KeyTracker.Stage;
import com.android.browser.KeyTracker.State;
import com.android.browser.unittests.testutil.ReflectHelper;

import android.test.AndroidTestCase;
import android.test.suitebuilder.annotation.MediumTest;
import android.test.suitebuilder.annotation.SmallTest;
import android.view.KeyEvent;

/**
 * Test KeyTracker.java
 * 
 * @author b391(LuoXiaofei)
 * 
 */
public class KyeTrackerTest extends AndroidTestCase {

	private KeyTracker mKeyTracker;
	private static final int NOT_A_KEYCODE = -123456;

	@Override
	protected void setUp() throws Exception {
		// TODO Auto-generated method stub
		super.setUp();
	}

	@Override
	protected void tearDown() throws Exception {
		// TODO Auto-generated method stub
		mKeyTracker = null;
		super.tearDown();
	}

	/**
	 * there tests new KeyTracker
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testnewKeyTracker() throws Exception {
		OnKeyTracker onkeytracker = new MockOnKeyTracker();
		mKeyTracker = new KeyTracker(onkeytracker);
		assertNotNull(mKeyTracker);
	}

	/**
	 * there tests method doKeyDown
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testdoKeyDown() throws Exception {
		OnKeyTracker onkeytracker = new MockOnKeyTracker();
		mKeyTracker = new KeyTracker(onkeytracker);
		assertNotNull(mKeyTracker);
		KeyEvent event = new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP);
		int keyCode = 1;
		mKeyTracker.doKeyDown(keyCode, event);
	}

	/**
	 * there tests method
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testsdoKeyUp() throws Exception {
		OnKeyTracker onkeytracker = new MockOnKeyTracker();
		mKeyTracker = new KeyTracker(onkeytracker);
		assertNotNull(mKeyTracker);
		KeyEvent event = new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP);
		int keyCode = NOT_A_KEYCODE;
		ReflectHelper.setPrivateField(mKeyTracker, "mState",
				State.KEEP_TRACKING);
		mKeyTracker.doKeyUp(keyCode, event);
	}

	// help class
	class MockOnKeyTracker implements OnKeyTracker {

		public State onKeyTracker(int keyCode, KeyEvent event, Stage stage,
				int duration) {
			// TODO Auto-generated method stub
			return State.KEEP_TRACKING;
		}

	}

}
