package com.android.browser;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.Downloads;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.SmallTest;
import android.test.suitebuilder.annotation.Suppress;

import com.android.browser.unittests.testutil.Helper;
/**
 * Test class of BrowserDownloadAdapter() 
 * @author I087(Cao Lina)
 *
 */
@Suppress
public class BrowserDownloadAdapterTest extends ActivityUnitTestCase<BrowserDownloadPage> {
	private BrowserDownloadAdapter mBrowserDownloadAdapter;
	private Context mContext;
    private BrowserDownloadPage mBrowserDownloadPage;
    private static final long middle_time = 4000;
    
	public BrowserDownloadAdapterTest() {
		super(BrowserDownloadPage.class);
	}

	protected void setUp() throws Exception {
		super.setUp();
		mContext=this.getInstrumentation().getTargetContext();
	}

	protected void tearDown() throws Exception {
		clearAllDownloads();
		if (mBrowserDownloadPage != null) {
			mBrowserDownloadPage.finish();
			mBrowserDownloadPage = null;
		}
		mBrowserDownloadAdapter=null;
		super.tearDown();
	}
	/**
	 * Test BrowserDownloadAdapter's Constructor
	 * @throws Exception
	 */
	@LargeTest
	public void testConstructor() throws Exception{
		insertdownload(405,"test");
		mBrowserDownloadPage=launchBrowserDownloadPage();
		Cursor downloadCursor = mContext.getContentResolver().query(Downloads.CONTENT_URI, 
                new String [] {"_id", Downloads.COLUMN_TITLE, Downloads.COLUMN_STATUS,
                Downloads.COLUMN_TOTAL_BYTES, Downloads.COLUMN_CURRENT_BYTES, 
                Downloads._DATA, Downloads.COLUMN_DESCRIPTION, 
                Downloads.COLUMN_MIME_TYPE, Downloads.COLUMN_LAST_MODIFICATION,
                Downloads.COLUMN_VISIBILITY, Downloads.COLUMN_NOTIFICATION_EXTRAS }, 
                null, null, null);
		mBrowserDownloadAdapter = new BrowserDownloadAdapter(mBrowserDownloadPage, 
	            R.layout.browser_download_item, downloadCursor);
		assertNotNull(mBrowserDownloadAdapter);
		SystemClock.sleep(middle_time);
		//b392 close the dialog
		Helper.HardKey.down(getInstrumentation());
		SystemClock.sleep(500);
		Helper.HardKey.right(getInstrumentation());
		SystemClock.sleep(500);
		Helper.HardKey.center(getInstrumentation());
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		//end
	}
	/**
	 * test method of BindView() when Title is Null
	 * @throws Exception
	 */
	@LargeTest
	public void testBindViewWithTitleIsNull() throws Exception{
		insertdownload(194,null);
		mBrowserDownloadPage=launchBrowserDownloadPage();
		Cursor downloadCursor = mContext.getContentResolver().query(Downloads.CONTENT_URI, 
                new String [] {"_id", Downloads.COLUMN_TITLE, Downloads.COLUMN_STATUS,
                Downloads.COLUMN_TOTAL_BYTES, Downloads.COLUMN_CURRENT_BYTES, 
                Downloads._DATA, Downloads.COLUMN_DESCRIPTION, 
                Downloads.COLUMN_MIME_TYPE, Downloads.COLUMN_LAST_MODIFICATION,
                Downloads.COLUMN_VISIBILITY, Downloads.COLUMN_NOTIFICATION_EXTRAS }, 
                null, null, null);
		mBrowserDownloadAdapter=new BrowserDownloadAdapter(mBrowserDownloadPage, 
	            R.layout.browser_download_item, downloadCursor);
		assertNotNull(mBrowserDownloadAdapter);
		SystemClock.sleep(middle_time);
		

		//b392 close the dialog
		Helper.HardKey.down(getInstrumentation());
		SystemClock.sleep(500);
		Helper.HardKey.right(getInstrumentation());
		SystemClock.sleep(500);
		Helper.HardKey.center(getInstrumentation());
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		//end
	}
	/**
	 * test method of getErrorText() when status=STATUS_NOT_ACCEPTABLE
	 * @throws Exception
	 */
	@SmallTest
	public void testgetErrorTextWithStatusISNOT_ACCEPTABLE() throws Exception{
	  assertEquals(R.string.download_not_acceptable, BrowserDownloadAdapter.getErrorText(Downloads.STATUS_NOT_ACCEPTABLE));
	}
	/**
	 * test method of getErrorText() when status=STATUS_LENGTH_REQUIRED
	 * @throws Exception
	 */
	@SmallTest
	public void testgetErrorTextWithStatusISLENGTH_REQUIRED() throws Exception{
		assertEquals(R.string.download_length_required, BrowserDownloadAdapter.getErrorText(Downloads.STATUS_LENGTH_REQUIRED));
	}
	/**
	 * test method of getErrorText() when status=STATUS_PRECONDITION_FAILED
	 * @throws Exception
	 */
	@SmallTest
	public void testgetErrorTextWithStatusISPRECONDITION_FAILED() throws Exception{
		assertEquals(R.string.download_precondition_failed, BrowserDownloadAdapter.getErrorText(Downloads.STATUS_PRECONDITION_FAILED));
	}
	/**
	 * test method of getErrorText() when status=STATUS_CANCELED
	 * @throws Exception
	 */
	@SmallTest
	public void testgetErrorTextWithStatusISCANCELED() throws Exception {
		assertEquals(R.string.download_canceled, BrowserDownloadAdapter.getErrorText(Downloads.STATUS_CANCELED));
	}
	/**
	 * test method of getErrorText() when status=STATUS_FILE_ERROR
	 * @throws Exception
	 */
	@SmallTest
	public void testgetErrorTextWithStatusISFILE_ERROR() throws Exception{
		assertEquals(R.string.download_file_error, BrowserDownloadAdapter.getErrorText(Downloads.STATUS_FILE_ERROR));
	}
	/**
	 * test method of getErrorText() when status=STATUS_NTITY_TOO_LARGE
	 * @throws Exception
	 */
	@SmallTest
	public void testgetErrorTextWithStatusISENTITY_TOO_LARGE() throws Exception{
		assertEquals(R.string.download_entity_too_large, BrowserDownloadAdapter.getErrorText(413));
	}
	/**
	 * test method of getErrorText() when status=Default
	 * @throws Exception
	 */
	@SmallTest
	public void testgetErrorTextWithStatusISDefault() throws Exception {
		assertEquals(R.string.download_error, BrowserDownloadAdapter.getErrorText(1));
	}
	
	
	/**
	 *there is launch the activity BrowserDownloadPage
	 * 
	 * @return mBrowserDownloadPage
	 */
	private BrowserDownloadPage launchBrowserDownloadPage() {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClass(mContext, BrowserDownloadPage.class);
		Uri uri = Uri.parse(Downloads.CONTENT_URI.toString() + "/1");
		intent.setData(uri);
		intent.putExtra("drm_cid", "drm_cid");
		String[] value = new String[] { "1", "2" };
		String key = "drm_cid";
		OmaDownloadManager.mDrmCidMap.put(key, value);
		BrowserDownloadPage browserDownloadPage = (BrowserDownloadPage) this.getInstrumentation()
				.startActivitySync(intent);
		return browserDownloadPage;
	}
    /**
     * help method insert data 
     * @param status
     * @param title
     */
	private void insertdownload(int status,String title) {
		ContentValues cv = new ContentValues();
		cv.put(Downloads.COLUMN_URI, "http://www.baidu.com");
		cv.put(Downloads._DATA, "http://www.baidu.com");
		cv.put(Downloads.COLUMN_TITLE, title);
		cv.put(Downloads.COLUMN_STATUS, status);
		cv.put(Downloads.COLUMN_MIME_TYPE, "123type");
		ContentResolver contentResolver=mContext.getContentResolver();
		contentResolver.insert(Downloads.CONTENT_URI, cv);
	}
	/**
	 * there is delete alldownloads
	 */
	private void clearAllDownloads() {
		Cursor downloadCursor;
		ContentResolver contentResolver=mContext.getContentResolver();
		downloadCursor = contentResolver.query(Downloads.CONTENT_URI, null,
				null, null, null);
		try {
			int mStatusColumnId = downloadCursor
					.getColumnIndexOrThrow(Downloads.COLUMN_STATUS);
			int mIdColumnId = downloadCursor
					.getColumnIndexOrThrow(Downloads._ID);
			if (downloadCursor.moveToFirst()) {
				StringBuilder where = new StringBuilder();
				boolean firstTime = true;
				while (!downloadCursor.isAfterLast()) {
					int status = downloadCursor.getInt(mStatusColumnId);
					if (Downloads.isStatusCompleted(status)) {
						if (firstTime) {
							firstTime = false;
						} else {
							where.append(" OR ");
						}
						where.append("( ");
						where.append(Downloads._ID);
						where.append(" = '");
						where.append(downloadCursor.getLong(mIdColumnId));
						where.append("' )");
					}
					downloadCursor.moveToNext();
				}
				if (!firstTime) {
					contentResolver.delete(Downloads.CONTENT_URI, where
							.toString(), null);
				}
			}
		} finally {
			downloadCursor.close();
			downloadCursor = null;
		}
	}
}
