package com.android.browser.cmcc;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Browser;
import android.provider.Browser.BookmarkColumns;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;
import android.view.KeyEvent;
import android.widget.EditText;

import com.android.browser.R;
import com.android.browser.unittests.testutil.Helper;

/**
 * test CMCCBrowserBookmarksPage.class.
 * 
 * @author Tang Ting
 */
@Suppress
public class CMCCBrowserBookmarksPageTest extends InstrumentationTestCase {
	private static final String BOOKMARK_TITLE = "byr";
	private static final String BOOKMARK_URL = "http://forum.byr.edu.cn";
	private static final int VISITED_TIMES = 1;
	private static final String CATEGORY_TITLE = "Tang";
	private static final int SHORT_TIME = 1000;

	private static final int SAVE_NEED_UPDATE = 1;
	private static final int SAVE_NOT_NEED_UPDATE = 2;
	
	private static Uri sUri;
	private static int sCount = 0;

	private Instrumentation mInst;
	private CMCCBrowserBookmarksPage mCMCCBrowserBookmarksPage;
	
	public CMCCBrowserBookmarksPageTest(){
		super();
		sCount ++;
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		
		mInst = getInstrumentation();
		mInst.setInTouchMode(false);
		if(haveOneMoreCategories()) {
			clearCategories();
		}
		if (!haveBookMark()) {
			sUri = addOneBookmark(BOOKMARK_TITLE, BOOKMARK_URL, VISITED_TIMES);
		}
	}

	@Override
	protected void tearDown() throws Exception {
		if (mCMCCBrowserBookmarksPage != null) {
			mCMCCBrowserBookmarksPage.finish();
			SystemClock.sleep(SHORT_TIME);
			mCMCCBrowserBookmarksPage = null;
		}
		mInst = null;
		if(-- sCount == 0 && sUri != null) {
			clearBookmarks();
		}
		
		super.tearDown();
	}

	/**
	 * test onContextItemSelected with choosed the Item of open in new window
	 */
	@LargeTest
	public void testonContextItemOpenInNewWindowSelected() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
		assertNotNull(mCMCCBrowserBookmarksPage);
		int location = 2;
		focusInBookmark(location);

		IntentFilter intentFilter = new IntentFilter(BOOKMARK_URL);
		Instrumentation.ActivityMonitor Monitor = new Instrumentation.ActivityMonitor(
				intentFilter, null, true);
		mInst.addMonitor(Monitor);
		SystemClock.sleep(SHORT_TIME);
		try {
			boolean returnValue = mInst.invokeContextMenuAction(
					mCMCCBrowserBookmarksPage, R.id.new_window_context_menu_id,
					0);
			SystemClock.sleep(SHORT_TIME);
			assertTrue(returnValue);
		} finally {
			mInst.removeMonitor(Monitor);
		}
	}

	/**
	 * test onContextItemSelected with choosed the Item of Edit bookmark
	 */
	@LargeTest
	public void testonContextItemEditBookmarkSelected() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
		int location = 2;
		focusInBookmark(location);

		IntentFilter intentFilter = new IntentFilter(Intent.ACTION_MAIN);
		intentFilter.addCategory("bookmark");
		Instrumentation.ActivityMonitor Monitor = new Instrumentation.ActivityMonitor(
				intentFilter, null, true);
		mInst.addMonitor(Monitor);
		SystemClock.sleep(SHORT_TIME);

//		boolean returnValue = mInst.invokeContextMenuAction(
//				mCMCCBrowserBookmarksPage, R.id.edit_context_menu_id, 0);
//		SystemClock.sleep(SHORT_TIME);
//		assertTrue(returnValue);
		try {
			mInst.invokeContextMenuAction(mCMCCBrowserBookmarksPage,
					R.id.edit_context_menu_id, 0);
		} finally {
			mInst.removeMonitor(Monitor);
		}
	}

	/**
	 * test onContextItemSelected with choosed the Item of delete
	 */
	@LargeTest
	public void testonContextItemDeleteSelected() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
		int location = 2;
		focusInBookmark(location);

//		boolean returnValue = mInst.invokeContextMenuAction(
//				mCMCCBrowserBookmarksPage, R.id.delete_context_menu_id, 0);
//		SystemClock.sleep(SHORT_TIME);
//		assertTrue(returnValue);
		mInst.invokeContextMenuAction(mCMCCBrowserBookmarksPage, R.id.delete_context_menu_id, 0);
		selectOK();
	}

	/**
	 * test onContextItemSelected with choosed the Item of move bookmark
	 */
	@LargeTest
	public void testonContextItemMoveBookmarkSelected() {
		addOneCategorie("Tang");
		mCMCCBrowserBookmarksPage = launchActvitiy();

		int location = 1;
		focusInBookmark(location);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(500);
		Helper.HardKey.down(mInst);
		SystemClock.sleep(500);
		// boolean returnValue = mInst.invokeContextMenuAction(
		// mCMCCBrowserBookmarksPage, R.id.move_context_menu_id, 0);
		// SystemClock.sleep(SHORT_TIME);
		// assertTrue(returnValue);
		mInst.invokeContextMenuAction(mCMCCBrowserBookmarksPage,
				R.id.move_context_menu_id, 0);
		// SystemClock.sleep(SHORT_TIME);
		Helper.HardKey.down(mInst);
		selectOK();
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	/**
	 * test onContextItemSelected with choosed the Item of share link
	 */
	@LargeTest
	public void testonContextItemShareLinkSelected() {
		String setType = "text/plain";

		mCMCCBrowserBookmarksPage = launchActvitiy();
		int location = 2;
		focusInBookmark(location);

		Intent intent = new Intent(Intent.ACTION_SEND);
		intent.setType(setType);
		Intent chooserIntent = Intent.createChooser(intent, null);
		IntentFilter filter = new IntentFilter(chooserIntent.getAction());
		Instrumentation.ActivityMonitor Monitor = new Instrumentation.ActivityMonitor(
				filter, null, true);
		mInst.addMonitor(Monitor);
		try {
			boolean returnValue = mInst.invokeContextMenuAction(
					mCMCCBrowserBookmarksPage, R.id.send_context_menu_id, 0);
			SystemClock.sleep(SHORT_TIME);
			assertTrue(returnValue);
		} finally {
			mInst.removeMonitor(Monitor);
		}
	}

	/**
	 * test onContextItemSelected with choosed the Item of copy link
	 */
	@LargeTest
	public void testonContextItemCopyLinkSelected() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
		int location = 2;
		focusInBookmark(location);

//		boolean returnValue = mInst.invokeContextMenuAction(
//				mCMCCBrowserBookmarksPage, R.id.copy_url_context_menu_id, 0);
//		SystemClock.sleep(SHORT_TIME);
//		assertTrue(returnValue);
		mInst.invokeContextMenuAction(mCMCCBrowserBookmarksPage, R.id.copy_url_context_menu_id, 0);
	}

	/**
	 * test onContextItemSelected with choosed the Item of rename category
	 */
	@LargeTest
	public void testonContextItemRenameAndDeleteCategorySelected() {
		addOneCategorie("Tang");
		mCMCCBrowserBookmarksPage = launchActvitiy();
		// choose category(Tang)
		// Helper.HardKey.down(mInst);b392
		int location = 2;
		focusInBookmark(location);
		// end

		mInst.invokeContextMenuAction(mCMCCBrowserBookmarksPage,
				R.id.rename_category_id, 0);
		SystemClock.sleep(SHORT_TIME);

		// cancel input the new name of category(Tang)
		Helper.HardKey.down(mInst);
		Helper.HardKey.right(mInst);
		selectOK();

		// press down twice and ensure choose category(Tang)
		// Helper.HardKey.down(mInst);
		// Helper.HardKey.down(mInst);
		// SystemClock.sleep(SHORT_TIME);

		mInst.invokeContextMenuAction(mCMCCBrowserBookmarksPage,
				R.id.delete_category_id, 0);

		selectOK();
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	/**
	 * tests onOptionsItemSelected with choosed the Item of add current
	 */
	@LargeTest
	public void testonOptionsItemAddCurrentSelected() {
		mCMCCBrowserBookmarksPage = launchActvitiy();

		IntentFilter intentFilter = new IntentFilter(Intent.ACTION_MAIN);
		Instrumentation.ActivityMonitor Monitor = new Instrumentation.ActivityMonitor(
				intentFilter, null, true);
		mInst.addMonitor(Monitor);
		try {
			mInst.invokeMenuActionSync(mCMCCBrowserBookmarksPage,
					R.id.new_context_menu_id, 0);
			// assertTrue(returnValue);
		} finally {
			mInst.removeMonitor(Monitor);
		}
	}

	/**
	 * tests onOptionsItemSelected with choosed the Item of add new
	 */
	@LargeTest
	public void testonOptionsItemAddNewSelected() {
		mCMCCBrowserBookmarksPage = launchActvitiy();

		IntentFilter intentFilter = new IntentFilter(Intent.ACTION_MAIN);
		Instrumentation.ActivityMonitor Monitor = new Instrumentation.ActivityMonitor(
				intentFilter, null, true);
		mInst.addMonitor(Monitor);
		try {
			mInst.invokeMenuActionSync(mCMCCBrowserBookmarksPage,
					R.id.new_bookmark_menu_id, 0);
			// assertTrue(returnValue);
		} finally {
			mInst.removeMonitor(Monitor);
		}
	}

	/**
	 * tests onOptionsItemSelected with choosed the Item of add new Category
	 */
	@LargeTest
	public void testonOptionsItemAddCategorieSelected() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
		//b392 5.25
//		boolean returnValue = mInst.invokeMenuActionSync(
//				mCMCCBrowserBookmarksPage, R.id.new_category_menu_id, 0);
//		assertTrue(returnValue);
		Instrumentation.ActivityMonitor monitor = new Instrumentation.ActivityMonitor(CMCCAddCategoryPage.class.getName(), null, false);
		mInst.addMonitor(monitor);
		try {
			mInst.invokeMenuActionSync(mCMCCBrowserBookmarksPage,
					R.id.new_category_menu_id, 0);
			int location = 3;
			focusInBookmark(location);
			Helper.HardKey.center(mInst);
			SystemClock.sleep(SHORT_TIME);
			CMCCAddCategoryPage cmccAddCategoryPage = (CMCCAddCategoryPage) monitor
					.getLastActivity();
			final EditText title = (EditText) cmccAddCategoryPage
					.findViewById(R.id.title);
			cmccAddCategoryPage.runOnUiThread(new Runnable() {
				public void run() {
					title.setText(CATEGORY_TITLE);
				}
			});
			// //end
			// // ensure on the first 7.5
			// // Helper.HardKey.up(mInst);
			// //end
			//		
			// // Helper.HardKey.down(mInst);
			// SystemClock.sleep(SHORT_TIME);
			// Helper.HardKey.center(mInst);
			// SystemClock.sleep(SHORT_TIME);
			// mInst.sendStringSync(CATEGORY_TITLE);
			SystemClock.sleep(SHORT_TIME);

			// choose OK and end input the name of new Category
			// Helper.HardKey.enter(mInst);
			Helper.HardKey.down(mInst);
			SystemClock.sleep(SHORT_TIME);
			Helper.HardKey.down(mInst);
			SystemClock.sleep(SHORT_TIME);
			Helper.HardKey.down(mInst);
			SystemClock.sleep(SHORT_TIME);
			Helper.HardKey.center(mInst);
			SystemClock.sleep(SHORT_TIME);
		} finally {
			mInst.removeMonitor(monitor);
		}
	}

	/**
	 * tests onOptionsItemSelected with choosed the Item of Delete then press
	 * Select all->Deselect all->Select all->Delete in the final,delete the all
	 * bookmarks
	 */
	@LargeTest
	public void testonOptionsItemSelected() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
		int location = 2;
		focusInBookmark(location);

		mInst.invokeMenuActionSync(mCMCCBrowserBookmarksPage,
				R.id.delete_menu_id, 0);
		mInst.invokeMenuActionSync(mCMCCBrowserBookmarksPage,
				R.id.selectall_menu_id, 0);
		mInst.invokeMenuActionSync(mCMCCBrowserBookmarksPage,
				R.id.cancel_selectall_menu_id, 0);
		mInst.invokeMenuActionSync(mCMCCBrowserBookmarksPage,
				R.id.selectall_menu_id, 0);
		mInst.invokeMenuActionSync(mCMCCBrowserBookmarksPage,
				R.id.delete_bookmarks_menu_id, 0);

		selectOK();
	}

	/**
	 * tests dispatchKeyEvent when press back in delete view
	 */
	@LargeTest
	public void testdispatchKeyEventIndeleteView() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
//		assertTrue(mInst.invokeMenuActionSync(mCMCCBrowserBookmarksPage,
//				R.id.delete_menu_id, 0));
		mInst.invokeMenuActionSync(mCMCCBrowserBookmarksPage,R.id.delete_menu_id, 0);
		int location = 4;
		focusInBookmark(location);
		/*go into delete menu*/
		Helper.HardKey.right(mInst);
		SystemClock.sleep(500);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(500);
		location = 3;
		focusInBookmark(location);
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				KeyEvent event = new KeyEvent(KeyEvent.ACTION_DOWN,
						KeyEvent.KEYCODE_BACK);
				assertTrue(mCMCCBrowserBookmarksPage.dispatchKeyEvent(event));
			}
		});
	}

	/**
	 * tests dispatchKeyEvent when press back in bookmark view
	 */
	@LargeTest
	public void testdispatchKeyEventInBookmarkView() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
		KeyEvent event = new KeyEvent(KeyEvent.ACTION_DOWN,
				KeyEvent.KEYCODE_BACK);
		assertTrue(mCMCCBrowserBookmarksPage.dispatchKeyEvent(event));
	}

	/**
	 * test loadUrl , in bookmark view click a url in the bookmarklist
	 */
	@LargeTest
	public void testloadUrl() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
//		int location = 1;
		int location = 2;//b392
		focusInBookmark(location);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(SHORT_TIME);
	}

	/**
	 * test onCreate , when mCreateShortcut = true and in bookmark view click a
	 * url in the bookmarklist and url is not started with "file://","data:" and
	 * "about:"
	 */
	@LargeTest
	public void testonCreateUrlStartedWithHttp() {
		mCMCCBrowserBookmarksPage = launchCreateShortcutActvitiy();
		assertNotNull(mCMCCBrowserBookmarksPage);
		int location = 2;
		focusInBookmark(location);
		Helper.HardKey.enter(mInst);
		SystemClock.sleep(SHORT_TIME);
	}

	/**
	 * test onCreate , when mCreateShortcut = true and in bookmark view click a
	 * url in the bookmarklist and url is started with "about:"
	 */
	@LargeTest
	public void testonCreateUrlStartedWithAbout() {
		String BOOKMARK_TITLE_SECOND = "About";
		String BOOKMARK_URL_SECOND = "about:blank";

		mCMCCBrowserBookmarksPage = launchCreateShortcutActvitiy();
		addOneBookmark(BOOKMARK_TITLE_SECOND, BOOKMARK_URL_SECOND,
				VISITED_TIMES);

		// let focus in the second bookmark and press
		int location = 3;
		focusInBookmark(location);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(SHORT_TIME);

		selectOK();
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	/**
	 * test toggleBookmark
	 */
	@LargeTest
	public void testtoggleBookmark() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
//		boolean returnValue = mInst.invokeMenuActionSync(
//				mCMCCBrowserBookmarksPage, R.id.delete_menu_id, 0);
//		assertTrue(returnValue);
		mInst.invokeMenuActionSync(mCMCCBrowserBookmarksPage, R.id.delete_menu_id, 0);
		// let focus in the second bookmark and press
		//b392
		int location = 3;
		focusInBookmark(location);
		Helper.HardKey.right(mInst);
		SystemClock.sleep(SHORT_TIME);
		location = 3;
		focusInBookmark(location);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(SHORT_TIME);

		// mCMCCBrowserBookmarksPage.onCreate(null);
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				mInst.callActivityOnCreate(mCMCCBrowserBookmarksPage, null);
			}
		});

	}

	/**
	 * test onActivityResult with save need update
	 */
	@LargeTest
	public void testonActivityResultWithSaveNeedUpdate() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				Intent intent = createIntent();
				mCMCCBrowserBookmarksPage.onActivityResult(SAVE_NEED_UPDATE,
						Activity.RESULT_OK, intent);
			}
		});
		SystemClock.sleep(SHORT_TIME);
	}

	/**
	 * test onActivityResult with save not need update
	 */
	@LargeTest
	public void testonActivityResultWithSaveNotNeedUpdate() {
		mCMCCBrowserBookmarksPage = launchActvitiy();
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				Intent intent = createIntent();
				mCMCCBrowserBookmarksPage.onActivityResult(
						SAVE_NOT_NEED_UPDATE, Activity.RESULT_OK, intent);
			}
		});
		SystemClock.sleep(SHORT_TIME);
	}

	// ***********************Helper method*********************************
	// Create a new Intent that testonActivityResult need
	private Intent createIntent() {
		Bundle extras = new Bundle();
		extras.putString("title", BOOKMARK_TITLE);
		extras.putString("url", BOOKMARK_URL);
		extras.putString("catid", BOOKMARK_TITLE);
		Intent intent = new Intent();
		intent.putExtras(extras);
		return (intent);
	}

	// Insert Bookmark to DB.
	private Uri addOneBookmark(String title, String url, int time) {
		final Uri BOOKMARKS_URI = Uri.parse("content://browser/bookmarks");
		ContentResolver resolver = mInst.getContext().getContentResolver();
		ContentValues value = new ContentValues();
		value.put(BookmarkColumns.TITLE, title);
		value.put(BookmarkColumns.URL, url);
		value.put(BookmarkColumns.VISITS, time);
		value.put(BookmarkColumns.BOOKMARK, "1");
		Uri uri = resolver.insert(BOOKMARKS_URI, value);
		assertNotNull("Insert history to DB failed! ", uri);
		SystemClock.sleep(SHORT_TIME);
		return uri;
	}

	// clear all Bookmarks in DB
	private void clearBookmarks() {
		final Uri BOOKMARKS_URI = Uri.parse("content://browser/bookmarks");
		ContentResolver resolver = getInstrumentation().getContext()
				.getContentResolver();
		resolver.delete(BOOKMARKS_URI, null, null);
		SystemClock.sleep(SHORT_TIME);
		Cursor c = resolver.query(BOOKMARKS_URI, null, null, null, null);
		assertEquals(0, c.getCount());

		c.close();
		c = null;
	}
	
//	private void clearBookmarks(Uri uri) {
//		ContentResolver resolver = getInstrumentation().getContext()
//				.getContentResolver();
//		resolver.delete(uri, null, null);
//		SystemClock.sleep(SHORT_TIME);
//		Cursor c = resolver.query(uri, null, null, null, null);
//		assertEquals(0, c.getCount());
//
//		c.close();
//		c = null;
//	}

	// launch CMCCBrowserBookmarksPage Activity
	private CMCCBrowserBookmarksPage launchActvitiy() {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName(mInst.getTargetContext(),
				CMCCBrowserBookmarksPage.class.getName());
		return (CMCCBrowserBookmarksPage) mInst.startActivitySync(intent);
	}

	// launch CMCCBrowserBookmarksPage CreateShortcut Activity
	private CMCCBrowserBookmarksPage launchCreateShortcutActvitiy() {
		Intent intent = new Intent(Intent.ACTION_CREATE_SHORTCUT);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName(mInst.getTargetContext(),
				CMCCBrowserBookmarksPage.class.getName());
		return (CMCCBrowserBookmarksPage) mInst.startActivitySync(intent);
	}

	// select OK
	private void selectOK() {
		Helper.HardKey.center(mInst);
		SystemClock.sleep(SHORT_TIME);
	}

	// let the focus in the bookmark
	private void focusInBookmark(int location) {
//		Helper.HardKey.center(mInst);
		for (int i = 0; i < location; i++) {
			Helper.HardKey.down(mInst);
			SystemClock.sleep(500);
		}
	}

	// delete Categorie in DB except the "My Favorite" which is created by
	// system
	private void clearCategories() {
		final Uri CATEGORIES_URI = Uri.parse("content://browser/categories");
		ContentResolver resolver = getInstrumentation().getContext()
				.getContentResolver();
		resolver.delete(CATEGORIES_URI, "_id <> 1", null);
//		resolver.delete(uri, null, null);
		SystemClock.sleep(SHORT_TIME);
		Cursor c = resolver.query(CATEGORIES_URI, null, null, null, null);
		assertEquals(1, c.getCount());
		c.close();
		c = null;
	}

	// Insert Categorie to DB.
	private Uri addOneCategorie(String name) {
		final Uri CATEGORIES_URI = Uri.parse("content://browser/categories");
		final String CATEGORIES_URI_NAME = "name";
		ContentResolver resolver = mInst.getContext().getContentResolver();
		ContentValues value = new ContentValues();
		value.put(CATEGORIES_URI_NAME, name);
		Uri uri = resolver.insert(CATEGORIES_URI, value);
		assertNotNull("Insert history to DB failed! ", uri);
		SystemClock.sleep(SHORT_TIME);
		return uri;
	}
	
	private boolean haveBookMark() {
		Cursor c = mInst.getTargetContext().getContentResolver().query(Browser.BOOKMARKS_URI, null, null, null, null);
		if(c.getCount() > 0) {
			clearBookmarks();
		}
		return false;
	}
	
	private boolean haveOneMoreCategories() {
		Cursor c = mInst.getTargetContext().getContentResolver().query(Browser.CATEGORY_URI, null, null, null, null);
		if(c.getCount() > 1) {
			return true;
		}
		return false;
	}
}
