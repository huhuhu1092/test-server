package com.android.browser.unittests;

import java.util.concurrent.TimeUnit;

import android.app.Instrumentation;
import android.app.Instrumentation.ActivityMonitor;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.SystemClock;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.MotionEvent;
import android.widget.ZoomButton;

import com.android.browser.BrowserActivity;
import com.android.browser.ControlPanel;
import com.android.browser.cmcc.CMCCAddBookmarkPage;
import com.android.browser.unittests.testutil.Helper;

/**
 * Test ControlPanel.java.
 * @author b391(LuoXiaofei)
 *
 */
public class ControlPanelTest extends ActivityUnitTestCase<BrowserActivity>{

	private Instrumentation mInst;
	private Context mContext;
	private static BrowserActivity mBrowserActivity;
	private ControlPanel mControlPanel;
	private static Handler handler;
	private static int sCount = 0;
	private static boolean sFlag = true;
	
	private static final int WAIT_TIME = 1000;
	
	public ControlPanelTest() {
		super(BrowserActivity.class);
		sCount ++;
	}

	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst=getInstrumentation();
		mContext=mInst.getTargetContext();
		mInst.setInTouchMode(false);
		handler = new Handler();
		if(sFlag){
			mBrowserActivity = launchBrowserActivity();
			sFlag = false;
		}
		mControlPanel = new ControlPanel(mBrowserActivity, handler);
	}

	@Override
	protected void tearDown() throws Exception {
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		mContext=null;
		mInst=null;
		if (--sCount == 0 && mBrowserActivity != null) {
			finishActivity();
			Helper.deleteFileAndFolder("/sdcard");
		}
		if(mControlPanel!=null)
		{
			mControlPanel=null;
		}
			
		super.tearDown();
	}
	/**
	 * there tests getinstance
	 * @throws Exception
	 */
	@LargeTest
	public void testnewControlPanel()throws Exception
	{
//		mBrowserActivity=launchBrowserActivity();
		assertNotNull(mBrowserActivity);
//		mControlPanel= ControlPanel.getInstance(mBrowserActivity);
		mControlPanel = new ControlPanel(mBrowserActivity, handler);
		assertNotNull(mControlPanel);
	}
	
	/**
	 * there tests button0 click
	 * @throws Exception
	 */
	@LargeTest
	public void testbutton0()throws Exception
	{
//		mBrowserActivity=launchBrowserActivity();
		assertNotNull(mBrowserActivity);
		final ZoomButton button = (ZoomButton) mControlPanel.findViewById(com.android.browser.R.id.button0);
		assertNotNull(button);
		mBrowserActivity.runOnUiThread(new Runnable() {
			public void run() {
				button.performClick();
			}
		});
		
	}
	
	/**
	 * there tests button1 click
	 * @throws Exception
	 */
	@LargeTest
	public void testbutton1()throws Exception
	{
//		mBrowserActivity=launchBrowserActivity();
		assertNotNull(mBrowserActivity);
		final ZoomButton button = (ZoomButton) mControlPanel.findViewById(com.android.browser.R.id.button1);
		assertNotNull(button);
		mBrowserActivity.runOnUiThread(new Runnable() {
			public void run() {
				button.performClick();
			}
		});
	}
	/**
	 * there tests button2 click
	 * @throws Exception
	 */
	@LargeTest
	public void testbutton2()throws Exception
	{
//		mBrowserActivity=launchBrowserActivity();
		assertNotNull(mBrowserActivity);
		final ZoomButton button = (ZoomButton) mControlPanel.findViewById(com.android.browser.R.id.button2);
		assertNotNull(button);
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				button.performClick();
			}
		});
//		TimeUnit.SECONDS.sleep(WAIT_TIME);
//		Helper.HardKey.back(mInst);
//		TimeUnit.SECONDS.sleep(WAIT_TIME);
//		TimeUnit.SECONDS.sleep(WAIT_TIME);
	}
	/**
	 * there tests button3 click
	 * @throws Exception
	 */
	@LargeTest
	public void testbutton3()throws Exception
	{
//		mBrowserActivity=launchBrowserActivity();
		assertNotNull(mBrowserActivity);
		ActivityMonitor monitor = new ActivityMonitor(CMCCAddBookmarkPage.class
				.getName(), null, true);
		mInst.addMonitor(monitor);
		try {
			final ZoomButton button3 = (ZoomButton) mControlPanel
					.findViewById(com.android.browser.R.id.button3);
			assertNotNull(button3);
			mBrowserActivity.runOnUiThread(new Runnable() {
				public void run() {
					button3.performClick();
				}
			});
			Thread.sleep(WAIT_TIME);
		} finally {
			mInst.removeMonitor(monitor);
		}
	}
	/**
	 * there tests button4 click
	 * @throws Exception
	 */
	@LargeTest
	public void testbutton4()throws Exception
	{
//		mBrowserActivity=launchBrowserActivity();
		assertNotNull(mBrowserActivity);
		final ZoomButton button = (ZoomButton) mControlPanel.findViewById(com.android.browser.R.id.button4);
		assertNotNull(button);
		mBrowserActivity.runOnUiThread(new Runnable() {
			public void run() {
				button.performClick();
			}
		});
	}
	
	/**
	 * there tests button5 click
	 * @throws Exception
	 */
	@LargeTest
	public void testbutton5()throws Exception
	{
//		mBrowserActivity=launchBrowserActivity();
		assertNotNull(mBrowserActivity);
		final ZoomButton button = (ZoomButton) mControlPanel.findViewById(com.android.browser.R.id.button5);
		assertNotNull(button);
		mBrowserActivity.runOnUiThread(new Runnable() {
			public void run() {
				button.performClick();
			}
		});
	}
	/**
	 * there tests button6 click
	 * @throws Exception
	 */
	@LargeTest
	public void testbutton6()throws Exception
	{
//		mBrowserActivity=launchBrowserActivity();
		assertNotNull(mBrowserActivity);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		final ZoomButton button = (ZoomButton) mControlPanel.findViewById(com.android.browser.R.id.button6);
		assertNotNull(button);
		mBrowserActivity.runOnUiThread(new Runnable() {
			public void run() {
				button.performClick();
			}
		});
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		mBrowserActivity.runOnUiThread(new Runnable() {
			public void run() {
				button.performClick();
			}
		});
	}
	
	/**
	 * there tests method showIfNeeded and event.action=MotionEvent.ACTION_DOWN
	 * @throws Exception
	 */
	@LargeTest
	public void testshowIfNeededACTION_DOWN()throws Exception
	{
//		mBrowserActivity=launchBrowserActivity();
		assertNotNull(mBrowserActivity);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		mControlPanel= ControlPanel.getInstance(mBrowserActivity);
		mControlPanel = new ControlPanel(mBrowserActivity, handler);
		long downTime=0;
		long eventTime=0;
		int action=MotionEvent.ACTION_DOWN;
        float x=0;
		float y=0;
		int metaState=0;
		MotionEvent event = MotionEvent.obtain(downTime,eventTime,action,x,y,metaState);
		mControlPanel.showIfNeeded(event);
	}
	/**
	 * there tests method showIfNeeded and event.action=MotionEvent.ACTION_DOWN
	 * @throws Exception
	 */
	@LargeTest
	public void testshowIfNeededACTION_MOVE()throws Exception
	{
//		mBrowserActivity=launchBrowserActivity();
		assertNotNull(mBrowserActivity);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		mControlPanel= ControlPanel.getInstance(mBrowserActivity);
		mControlPanel = new ControlPanel(mBrowserActivity, handler);
		long downTime=0;
		long eventTime=0;
		int action=MotionEvent.ACTION_MOVE;
        float x=0;
		float y=0;
		int metaState=0;
		MotionEvent event = MotionEvent.obtain(downTime,eventTime,action,x,y,metaState);
		mControlPanel.showIfNeeded(event);
	}
	
	/**
	 * there tests method show
	 * @throws Exception
	 */
	@LargeTest
	public void testshow()throws Exception
	{
//		mBrowserActivity=launchBrowserActivity();
		assertNotNull(mBrowserActivity);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		mControlPanel= ControlPanel.getInstance(mBrowserActivity);
		mControlPanel = new ControlPanel(mBrowserActivity, handler);
		assertNotNull(mControlPanel);
		mBrowserActivity.runOnUiThread(new Runnable() {
			public void run() {
				mControlPanel.show();
			}
		});
	}
	
	//help method
	/**
	 * there launchUIBrowserActivity
	 */
	private BrowserActivity launchBrowserActivity()
	{
//		String name="test.txt";
		String name="test.html";
		String path="/sdcard";
//		String filepath="file:///sdcard/test.txt";
		String filepath="file:///sdcard/test.html";
		Helper.createFileToSdcard(mInst.getContext(), name, path);
		Intent intent=new Intent(Intent.ACTION_VIEW);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setData(Uri.parse(filepath));
		intent.setClass(mContext, BrowserActivity.class);
		mBrowserActivity=(BrowserActivity) mInst.startActivitySync(intent);
		SystemClock.sleep(60000);
		return mBrowserActivity;
	}
	
	//b392 5.20
	private void finishActivity() {
		if (mBrowserActivity != null) {
			mBrowserActivity.goQuit();
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
			mBrowserActivity = null;
		}
	}
	//end
}
