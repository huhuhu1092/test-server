package com.android.browser;

import java.util.concurrent.TimeUnit;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.ImageView;

import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

public class TitleBarUITest extends ActivityUnitTestCase<BrowserActivity> {
	
	private Instrumentation mInst;
	private Context mContext;
	private static BrowserActivity mBrowserActivity;
	private static TitleBar mTitleBar;
	private final static String NAME="test.html";
	private final static String PATH="/sdcard";
	private final static String FILEPATH="file:///sdcard/test.html";
	
	private static int count = 0;
	private static boolean flag = true;
	
	public TitleBarUITest() {
		super(BrowserActivity.class);
		count ++;
	}
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mContext = mInst.getTargetContext();
		if(flag) {
			mBrowserActivity = launchBrowserActivity();
			mTitleBar = new TitleBar(mBrowserActivity);
			flag = false;
		}
	}

	@Override
	protected void tearDown() throws Exception {
		TimeUnit.SECONDS.sleep(2);
		if(--count == 0 && mBrowserActivity != null) {
			finishActivity();
			Helper.deleteFileAndFolder(PATH);
			mTitleBar = null;
		}
		mInst = null;
		mContext = null;
		
		super.tearDown();
	}

	/**
	 * there tests new TitleBar
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void test001NewTitleBar() throws Exception {
		assertNotNull(mBrowserActivity);
		mTitleBar = new TitleBar(mBrowserActivity);
	}

	/**
	 * there tests method onTouchEvent and event.avtion=MotionEvent.ACTION_UP
	 * and mRtButton.clickOn
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonTouchEventACTION_UPmRtButton() throws Exception {
		long downTime = 0;
		long eventTime = 0;
		int action = MotionEvent.ACTION_UP;
		float x = 0;
		float y = 100;
		int metaState = 0;
		MotionEvent event = MotionEvent.obtain(downTime, eventTime, action, x,
				y, metaState);
		assertNotNull(mBrowserActivity);
		ImageView mRtButton = (ImageView) mBrowserActivity
				.findViewById(R.id.rt_btn);
		Helper.clickOn(mInst, mRtButton);
		assertTrue(mTitleBar.onTouchEvent(event));
		flag = true;
	}

	/**
	 * there tests method onTouchEvent and event.action=MotionEvent.ACTION_MOVE
	 * and mTitleBg.clickOk
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonTouchEventACTION_MOVEmRtButton() throws Exception {
		long downTime = 0;
		long eventTime = 0;
		int action = MotionEvent.ACTION_MOVE;
		float x = 100;
		float y = 0;
		int metaState = 0;
		MotionEvent event = MotionEvent.obtain(downTime, eventTime, action, x,
				y, metaState);
		assertNotNull(mBrowserActivity);
		ImageView mRtButton = (ImageView) mBrowserActivity
				.findViewById(R.id.rt_btn);
		Helper.clickOn(mInst, mRtButton);
		assertTrue(mTitleBar.onTouchEvent(event));
		mBrowserActivity.goQuit();
		TimeUnit.SECONDS.sleep(5);
		flag = true;
	}

	/**
	 * there tests handler message
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testhandlermessage() throws Exception {
		assertNotNull(mBrowserActivity);
		Handler handler = (Handler) ReflectHelper.getPrivateField(mTitleBar,
				"mHandler");
		Message msg = new Message();
		int LONG_PRESS = 1;
		msg.what = LONG_PRESS;
		handler.handleMessage(msg);
	}

	// help method
	/**
	 * there launchUIBrowserActivity
	 */
	private BrowserActivity launchBrowserActivity() {
		Helper.createFileToSdcard(mInst.getContext(), NAME, PATH);
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse(FILEPATH));
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClass(mContext, BrowserActivity.class);
		mBrowserActivity = (BrowserActivity) mInst.startActivitySync(intent);
		SystemClock.sleep(30000);
		return mBrowserActivity;
	}

	 //b392 5.20
    private void finishActivity() {
		if (mBrowserActivity != null) {
			mBrowserActivity.goQuit();
			SystemClock.sleep(15000);
			mBrowserActivity = null;
		}
	}
	//end

}
