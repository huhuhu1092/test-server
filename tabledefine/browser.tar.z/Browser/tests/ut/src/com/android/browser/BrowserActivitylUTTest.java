package com.android.browser;

import android.app.Instrumentation;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.Browser;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.widget.FrameLayout;

import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

/**
 * this class tests BrowserActivity in Browser application by UT
 * 
 * @author b357-DengLinling
 * 
 */
public class BrowserActivitylUTTest extends
		ActivityUnitTestCase<BrowserActivity> {

	private Instrumentation mInst;
	private Context mCtx;
	private BrowserActivity mActivity;

	public BrowserActivitylUTTest() {
		super(BrowserActivity.class);
	}

	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mCtx = mInst.getTargetContext();
	}

	protected void tearDown() throws Exception {
		finishActivity();
		mCtx = null;
		mInst = null;
		super.tearDown();
	}

	// test method
//	/**
//	 * this case tests onOptionsItemSelected() for book marks
//	 */
//	@LargeTest
//	public void testOnoptionsItemSelected_bookmarks_menu_id() {
//		mActivity = launchActivity();
//		assertTrue(mActivity instanceof BrowserActivity);
//		assertTrue(mInst.invokeMenuActionSync(mActivity,
//				R.id.bookmarks_menu_id, 0));
//	}

//	/**
//	 * this case tests onOptionsItemSelected() for copy and paste
//	 */
//	@LargeTest
//	public void testOnOptionsItemSelected_copy_and_paste() {
//		mActivity = launchActivity();
//		assertTrue(mActivity instanceof BrowserActivity);
//		assertTrue(mInst.invokeMenuActionSync(mActivity,
//				R.id.copy_and_paste_id, 0));
//	}

	/**
	 * this case tests onOptionsItemSelected() for view_download
	 */
	@LargeTest
	public void testOnOptionsItemSelected_view_download() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		assertTrue(mInst.invokeMenuActionSync(mActivity,
				R.id.view_downloads_menu_id, 0));
	}

//	/**
//	 * this case tests onOptionsItemSelected() for bookmarks_tab_menu
//	 */
//	@LargeTest
//	public void testOnOptionsItemSelected_bookmarks_tab_menu() throws Exception {
//		mActivity = launchActivity();
//		assertTrue(mActivity instanceof BrowserActivity);
//		ReflectHelper.setPrivateField(mActivity, "mMenuState", R.id.TAB_MENU);
//		assertTrue(mInst.invokeMenuActionSync(mActivity,
//				R.id.bookmarks_tab_menu_id, 0));
//	}

	/**
	 * this case tests onOptionsItemSelected() for history_tab_menu
	 */
	@LargeTest
	public void testOnOptionsItemSelected_history_tab_menu() throws Exception {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		ReflectHelper.setPrivateField(mActivity, "mMenuState", R.id.TAB_MENU);
		assertTrue(mInst.invokeMenuActionSync(mActivity,
				R.id.history_tab_menu_id, 0));
	}

	/**
	 * this case tests onNewIntent() with action main
	 */
	@LargeTest
	public void testOnNewIntent_Action_Main() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		Intent intent = new Intent(Intent.ACTION_MAIN);
		mInst.callActivityOnNewIntent(mActivity, intent);
	}

	/**
	 * this case tests onNewIntent() with action view and content type data
	 */
	@LargeTest
	public void testOnNewIntent_Action_View_Content_Type_Data() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse("content://browser/bookmarks"));
		intent.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
		mInst.callActivityOnNewIntent(mActivity, intent);
	}

	/**
	 * this case tests onNewIntent() with action web search
	 */
	@LargeTest
	public void testOnNewIntent_Action_Web_Search() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
		intent.putExtra(SearchManager.QUERY, "http://wap.139.com");
		mInst.callActivityOnNewIntent(mActivity, intent);
	}

	/**
	 * this case tests onNewIntent() with action web search and connection "net"
	 */
	@LargeTest
	public void testzOnNewIntent_Action_Web_Search_Connection_Net() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
		intent.putExtra("data_connection", "net");
		intent.putExtra(SearchManager.QUERY, "g ");
//		mInst.callActivityOnNewIntent(mActivity, intent);
		mActivity.onNewIntent(intent);
	}

	/**
	 * this case tests smartUrlFilter() with url "g abc"
	 */
	@LargeTest
	public void testSmartUrlFilter_G() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
		intent.putExtra("data_connection", "net");
		intent.putExtra(SearchManager.QUERY, "g abc");
		mInst.callActivityOnNewIntent(mActivity, intent);
	}

	/**
	 * this case tests smartUrlFilter() with url "g abc"
	 */
	@LargeTest
	public void testSmartUrlFilter_D() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
		intent.putExtra("data_connection", "net");
		intent.putExtra(SearchManager.QUERY, "d abc");
		mInst.callActivityOnNewIntent(mActivity, intent);
	}

	/**
	 * this case tests smartUrlFilter() with url "g abc"
	 */
	@LargeTest
	public void testSmartUrlFilter_W() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
		intent.putExtra("data_connection", "net");
		intent.putExtra(SearchManager.QUERY, "w abc");
		mInst.callActivityOnNewIntent(mActivity, intent);
	}

	/**
	 * this case tests smartUrlFilter() with url "g abc"
	 */
	@LargeTest
	public void testSmartUrlFilter_L() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
		intent.putExtra("data_connection", "net");
		intent.putExtra(SearchManager.QUERY, "l abc");
		mInst.callActivityOnNewIntent(mActivity, intent);
	}

	/**
	 * this case tests onNewIntent() with action view and uri = "about:debug"
	 */
	@LargeTest
	public void testOnNewIntent_Action_View_Url_Debug() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse("about:debug"));
		intent.putExtra("data_connection", "net");
		mInst.callActivityOnNewIntent(mActivity, intent);
	}

	/**
	 * this case tests getHandler() method
	 */
	@LargeTest
	public void testGetHandler() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		assertNotNull(mActivity.getHandler());
	}

	/**
	 * this case tests getProgress()
	 */
	@LargeTest
	public void testGetProgress() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		assertNotNull(mActivity.getProgress());
	}

	/**
	 * this case tests getWindowCount() method
	 */
	@LargeTest
	public void testGetWindowCount() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		assertNotNull(mActivity.getWindowCount());
	}

/*	move to BrowserActivitylUITest_TXT *//**
	 * this case tests Wifi network
	 *//*
	@SuppressWarnings("deprecation")
	@LargeTest
	public void testWifiNetwork() throws Exception {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		BroadcastReceiver receiver = (BroadcastReceiver) ReflectHelper
				.getPrivateField(mActivity, "mBrowserIntentReceiver");
		assertNotNull(receiver);
		Intent intent = new Intent(WifiManager.NETWORK_STATE_CHANGED_ACTION);
		NetworkInfo info = new NetworkInfo(0);
		intent.putExtra(WifiManager.EXTRA_NETWORK_INFO, info);
		receiver.onReceive(mCtx, intent);
	}*/

	/**
	 * this case tests onLowMemory() method
	 */
	@LargeTest
	public void testOnLowMemory() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		mActivity.onLowMemory();
	}

	/**
	 * this case tests onNetworkChanged() method
	 */
	@LargeTest
	public void testOnNetworkChanged() {
		mActivity = launchActivity();
		assertNotNull(mActivity);
		mActivity.onNetworkChanged(true);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	// help method
	private BrowserActivity launchActivity() {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setClass(mCtx, BrowserActivity.class);
		intent.putExtra(Browser.EXTRA_APPLICATION_ID, "com.android.mms");
		BrowserActivity activity = startActivity(intent, null, null);
		return activity;
	}
	
	private void finishActivity() throws Exception {
		if (mActivity != null) {
			mActivity.finish();
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
			mInst.runOnMainSync(new Runnable() {
				public void run() {
					try {
						FrameLayout contentView = (FrameLayout) ReflectHelper
								.getPrivateField(mActivity, "mContentView");
						if (contentView != null) {
							contentView.removeAllViews();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
			mActivity = null;
		}
	}

}
