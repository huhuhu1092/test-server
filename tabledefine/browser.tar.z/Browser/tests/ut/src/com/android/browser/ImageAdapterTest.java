package com.android.browser;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;

import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;
/**
 * Test class of ImageAdapter()
 * @author I087(Cao Lina)
 *
 */

public class ImageAdapterTest extends InstrumentationTestCase {
	private ImageAdapter mImageAdapter;
	private Context mContext;
    private static BrowserActivity mActivity;
    
  //b392 5.20 only launch once
	private static int count = 0;
	private static boolean flag = true;
    
	public ImageAdapterTest() {
		super();
		count ++;
	}

	protected void setUp() throws Exception {
		super.setUp();
		
		mContext=this.getInstrumentation().getTargetContext();
		if(flag){
			mActivity =lanuchActivity();
			flag = false;
		}
		mImageAdapter = getInstance();
	}

	protected void tearDown() throws Exception {
		//b392 5.20
		if(--count == 0){
			finishActivity();
			Helper.deleteFileAndFolder("/sdcard");
		}
		mImageAdapter=null;
		mContext=null;
		
		super.tearDown();
	}
	/**
	 * test ImageAdapter's constructor
	 * @throws Exception
	 */
	@LargeTest
	public void testConstrunctor() throws Exception{
	     assertNotNull(mImageAdapter);
	}
	/**
	 * test method of heightChanged()
	 * @throws Exception
	 */
	@LargeTest
	public void testHeightChanged() throws Exception{
		mImageAdapter.heightChanged(4);
	}
	/**
	 * test method of maxedOut()
	 * @throws Exception
	 */
	@LargeTest
	public void testMaxedOut() throws Exception{
		 assertFalse(mImageAdapter.maxedOut());
	}
	/**
	 * test method of clear()
	 * @throws Exception
	 */
	@LargeTest
	public void testClear() throws Exception{
		TabControl tab=new TabControl(mActivity);
		TabControl.Tab t=tab.createNewTab(true, "1", "file:///sdcard/download");
		mImageAdapter.add(t);
		mImageAdapter.clear();
	}
	/**
	 * test method of areAllItemsEnabled()
	 * @throws Exception
	 */
	@LargeTest
	public void testAreAllItemsEnabled() throws Exception{
		assertTrue(mImageAdapter.areAllItemsEnabled());
	}
	/**
	 * test method of isEnabled() when position <Items.size()
	 * @throws Exception
	 */
	@LargeTest
	public void testisEnabledReturnFalse() throws Exception{
		assertFalse(mImageAdapter.isEnabled(4));
	}
	/**
	 * test method of isEnabled() when position >Items.size()
	 * @throws Exception
	 */
	@LargeTest
	public void testisEnabledReturnTure() throws Exception{
		TabControl tab=new TabControl(mActivity);
		TabControl.Tab t=tab.createNewTab(true, "1", "file:///sdcard/download");
		mImageAdapter.add(t);
		assertTrue(mImageAdapter.isEnabled(0));
	}
	/**
	 * test method of getItemViewType()
	 * @throws Exception
	 */
	@LargeTest
	public void testGetItemViewType() throws Exception{
	   assertEquals(0, (mImageAdapter.getItemViewType(3)));
	}
	/**
	 * test method of hasStableIds()
	 * @throws Exception
	 */
	@LargeTest
	public void testHasStableIds() throws Exception{
	    assertTrue(mImageAdapter.hasStableIds());
	}
	/**
	 * test method of remove()
	 * @throws Exception
	 */
	@LargeTest
	public void testRemove() throws Exception{
		TabControl tab=new TabControl(mActivity);
		TabControl.Tab t=tab.createNewTab(true, "1", "file:///sdcard/download");
		mImageAdapter.add(t);
		mImageAdapter.remove(0);
	}
	/**
	 * test method of isEmpty
	 * @throws Exception
	 */
	@LargeTest
	public void testIsEmpty() throws Exception{
		if(mImageAdapter.getCount() == 0) {
			assertTrue(mImageAdapter.isEmpty());
		}else {
			assertFalse(mImageAdapter.isEmpty());
		}
	}
	/**
	 * test method of getItem()
	 * @throws Exception
	 */
	@LargeTest
	public void testGetItem() throws Exception{
		  assertNull(mImageAdapter.getItem(0));
	}
	/**
	 * test method of getItemId()
	 * @throws Exception
	 */
	@LargeTest
	public void testGetItemId() throws Exception{
		 assertEquals(1,mImageAdapter.getItemId(1));
	}
	/**
	 * test method of add()
	 * @throws Exception
	 */
	@LargeTest
	public void testAdd() throws Exception{
		TabControl tab=new TabControl(mActivity);
		TabControl.Tab t=tab.getCurrentTab();
		mImageAdapter.add(t);
	}
	/**
	 * test method of getView() when position = ImageGrid.NEW_TAB
	 * @throws Exception
	 */
	@LargeTest
	public void testGetView() throws Exception{
//		TabControl tab=new TabControl(mActivity);
//		TabControl.Tab t=tab.getCurrentTab();
		TabControl tabControl = (TabControl)ReflectHelper.getPrivateField(mActivity, "mTabControl");
		TabControl.Tab t = tabControl.getCurrentTab();
		mImageAdapter.add(t);
		int position= 0;
		View convertView = null;
		ViewGroup parent = null;
		assertNotNull(mImageAdapter.getView(position, convertView, parent));
	}
	/**
	 * test method of getView when position != ImageGrid.NEW_TAB
	 * @throws Exception
	 */
	@LargeTest
	public void testGetViewWithPositionNot() throws Exception{
//		TabControl tabControl = (TabControl)ReflectHelper.getPrivateField(mActivity, "mTabControl");
//		int position = tabControl.getCurrentIndex();
		TabControl tab=new TabControl(mActivity);
		TabControl.Tab t=tab.getCurrentTab();
		mImageAdapter.add(t);
		int position= 1;
		View convertView=null;
		ViewGroup parent=null;
		TabControl tabControl=new TabControl(mActivity);
		TabControl.Tab t2 = tabControl.createNewTab(true, "1", "file:///sdcard/download");
		mImageAdapter.add(t2);
		assertNotNull(mImageAdapter.getView(position, convertView, parent));
	}
	/**
	 * test method of confirmClose()
	 * @throws Exception
	 */
	@LargeTest
	public void testConfirmClose() throws Exception{
		ReflectHelper.runPrivateMethod(mImageAdapter, "confirmClose", new Class[]{int.class}, new Object[]{0});
	}
	//launch Activity 
	private BrowserActivity lanuchActivity() throws Exception {
		// b392 5.20
//		Helper.createFileToSdcard(getInstrumentation().getContext(), "test.txt", "/sdcard");
		Helper.createFileToSdcard(getInstrumentation().getContext(), "test.html", "/sdcard");
		Intent intent = new Intent(Intent.ACTION_VIEW);
//		intent.setData(Uri.parse("file:///sdcard/test.txt"));
		intent.setData(Uri.parse("file:///sdcard/test.html"));
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName("com.android.browser", BrowserActivity.class.getName());

		BrowserActivity activity = (BrowserActivity) this.getInstrumentation().startActivitySync(intent);
		SystemClock.sleep(60000);
		assertNotNull(activity);
		return activity;
	}
	
	private ImageAdapter getInstance() {
		BrowserTabViewListener listener = new MockBrowserTabViewListener();
		ImageGrid imageGrid = new ImageGrid(mActivity, true, listener);
		ImageAdapter imageAdapter = new ImageAdapter(mContext, imageGrid, true);
		return imageAdapter;
	}
	
	private void finishActivity() {
		if (mActivity != null) {
			mActivity.goQuit();
			SystemClock.sleep(15000);
			mActivity = null;
		}
	}
	
	private static class MockBrowserTabViewListener implements BrowserTabViewListener {

		public MockBrowserTabViewListener() {
			
		}
		public void onClick(int arg0) {
			
		}

		public void remove(int arg0) {
			
		}
		
	}
	//end

}
