package com.android.browser;

import android.app.Instrumentation;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.Downloads;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.Suppress;

import com.android.browser.OmaDownloadManager.OmaDownloadManagerBroadcastReceiver;
import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

/**
 * Test OmaDownloadManager.java.
 * 
 * @author b391(LuoXiaofei) and (Tang Ting)
 * 
 */
@Suppress
public class OMaDownloadManagerTest extends
		ActivityUnitTestCase<OmaDownloadManager> {

	private Instrumentation mInst;
	private Context mContext;
	private OmaDownloadManager mOmaDownloadManager;
	private final static String NAME = "test.xml";
	private final static String NAME1 = "test1.xml";
	private final static String PATH = "/sdcard";
	private final static String FILEPATH = "file:///sdcard/test.xml";
	private final static String FILEPATH1 = "file:///sdcard/test1.xml";
	private static final int STATUS_INSUFFICIENT_MEMORY = 901;
	private static final int STATUS_LOSS_OF_SERVICE = 903;
	private static final int STATUS_ATTRIBUTE_MISMATCH = 905;
	private static final int STATUS_INVALID_DECRIPTOR = 906;
	private static final int STATUS_INVALID_DDVERSION = 951;
	private static final int STATUS_DEVICE_ABORTED = 952;
	private static final int STATUS_NONACCEPTABLE_CONTENT = 953;
	private static final int STATUS_LOADER_ERROR = 954;
	private static int CASE_COUNT = 0;

	public OMaDownloadManagerTest() {
		super(OmaDownloadManager.class);
		CASE_COUNT++;
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mContext = mInst.getTargetContext();
		mInst.setInTouchMode(false);
	}

	@Override
	protected void tearDown() throws Exception {
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		if (--CASE_COUNT == 0) {
			clearAllDownloads();
		}
		if (mOmaDownloadManager != null) {
			mOmaDownloadManager.finish();
			mOmaDownloadManager = null;
		}
		mInst = null;
		mContext = null;
		super.tearDown();
	}

	/**
	 * there tests launchOmaDownloadManagerURLIsFileURL and xml objectURI is a
	 * error file and click download and then click exit.
	 * 
	 * @throws Exception
	 */
	//TODO
	public void testlaunchOmaDownloadManagerURLIsFileURLDownloadingError() {
		assertNotNull(launchOmaDownloadManagerURLIsFileURL(NAME1, FILEPATH1));
		// click button download
		Helper.HardKey.down(mInst);
		Helper.HardKey.left(mInst);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(10000);
		// click button exit b392 5.26
//		Helper.HardKey.down(mInst);
//		Helper.HardKey.center(mInst);
	}

	/**
	 * there tests launchOmaDownloadManagerURLIsFileURL and the xml type is
	 * image/jpg and then click prossed and then click download.
	 * 
	 * @throws Exception
	 */
	public void testlaunchOmaDownloadManagerURLIsFileURLclickDownload()
			throws Exception {
		assertNotNull(launchOmaDownloadManagerURLIsFileURL(NAME, FILEPATH));
		// click button prossed
		Helper.HardKey.down(mInst);
		Helper.HardKey.left(mInst);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		// click button download
		Helper.HardKey.down(mInst);
		Helper.HardKey.left(mInst);
		Helper.HardKey.center(mInst);
	}

//	/**
//	 * there launchOmaDownloadManagerURLIsFileURL and the xml type is image/jpg
//	 * and then click exit.
//	 * 
//	 * @throws Exception
//	 */
//	public void test001launchOmaDownloadManagerURLIsFileURLclickexit()
//			throws Exception {
//		Uri uri = insertdownload(205, "type");
////		 String[] projection = { Downloads.COLUMN_STATUS, Downloads._DATA, 
////                 Downloads.COLUMN_MIME_TYPE, Downloads.COLUMN_NOTIFICATION_EXTRAS,  
////                 Downloads.COLUMN_USER_AGENT, Downloads.COLUMN_PROXY_HOST, Downloads.COLUMN_PROXY_PORT,
////                 Downloads._ID };
////		Cursor objectDownloadCursor = mContext.getContentResolver().query(uri, projection, null, null, null);
////		if (null != objectDownloadCursor) {
////            objectDownloadCursor.moveToFirst();
////		}
////		String filename = objectDownloadCursor.getString(objectDownloadCursor.getColumnIndexOrThrow(Downloads._DATA));
////		Log.d("############", "123::"+filename);
//		assertNotNull(launchOmaDownloadManager(uri, NAME, FILEPATH));
//		Helper.HardKey.right(mInst);
//		Helper.HardKey.center(mInst);
//
//	}

	/**
	 * there tests launchOmaDownloadManagerURLIsNotFileURL and click error.
	 */
	public void testlaunchOmaDownloadManagerURLIsNotFileURL() {
		assertNotNull(launchOmaDownloadManagerURLIsNotFileURL());
		Helper.HardKey.center(mInst);
	}

	/**
	 * there tests method statusMessage and statusMessage is
	 * STATUS_INSUFFICIENT_MEMORY.
	 * 
	 * @throws Exception
	 */
	public void teststatusMessageSTATUS_INSUFFICIENT_MEMORY() throws Exception {
		assertEquals(mInst.getTargetContext().getText(
				R.string.oma_status_insufficient_memory), OmaDownloadManager
				.statusMessage(mContext, STATUS_INSUFFICIENT_MEMORY));
	}

	/**
	 * there tests method statusMessage and statusMessage is
	 * STATUS_LOSS_OF_SERVICE.
	 * 
	 * @throws Exception
	 */
	public void teststatusMessageSTATUS_LOSS_OF_SERVICE() throws Exception {
		assertEquals(mInst.getTargetContext().getText(
				R.string.oma_status_loss_of_service), OmaDownloadManager
				.statusMessage(mContext, STATUS_LOSS_OF_SERVICE));
	}

	/**
	 * there tests method statusMessage and statusMessage is
	 * STATUS_ATTRIBUTE_MISMATCH.
	 * 
	 * @throws Exception
	 */
	public void teststatusMessageSTATUS_ATTRIBUTE_MISMATCH() throws Exception {
		assertEquals(mInst.getTargetContext().getText(
				R.string.oma_status_attribute_mismatch), OmaDownloadManager
				.statusMessage(mContext, STATUS_ATTRIBUTE_MISMATCH));
	}

	/**
	 * there tests method statusMessage and statusMessage is
	 * STATUS_INVALID_DECRIPTOR.
	 * 
	 * @throws Exception
	 */
	public void teststatusMessageSTATUS_INVALID_DECRIPTOR() throws Exception {
		assertEquals(mInst.getTargetContext().getText(
				R.string.oma_status_invalid_descriptor), OmaDownloadManager
				.statusMessage(mContext, STATUS_INVALID_DECRIPTOR));

	}

	/**
	 * there tests method statusMessage and statusMessage is
	 * STATUS_INVALID_DDVERSION.
	 * 
	 * @throws Exception
	 */
	public void teststatusMessageSTATUS_INVALID_DDVERSION() throws Exception {
		assertEquals(mInst.getTargetContext().getText(
				R.string.oma_status_invalid_version), OmaDownloadManager
				.statusMessage(mContext, STATUS_INVALID_DDVERSION));

	}

	/**
	 * there tests method statusMessage and statusMessage is
	 * STATUS_DEVICE_ABORTED.
	 * 
	 * @throws Exception
	 */
	public void teststatusMessageSTATUS_DEVICE_ABORTED() throws Exception {
		assertEquals(mInst.getTargetContext().getText(
				R.string.oma_status_device_aborted), OmaDownloadManager
				.statusMessage(mContext, STATUS_DEVICE_ABORTED));

	}

	/**
	 * there tests method statusMessage and statusMessage is
	 * STATUS_NONACCEPTABLE_CONTENT.
	 * 
	 * @throws Exception
	 */
	public void teststatusMessageSTATUS_NONACCEPTABLE_CONTENT()
			throws Exception {

		assertEquals(mInst.getTargetContext().getText(
				R.string.oma_status_non_acceptable_content), OmaDownloadManager
				.statusMessage(mContext, STATUS_NONACCEPTABLE_CONTENT));

	}

	/**
	 * there tests method statusMessage and statusMessage is
	 * STATUS_LOADER_ERROR.
	 * 
	 * @throws Exception
	 */
	public void teststatusMessageSTATUS_LOADER_ERROR() throws Exception {
		assertEquals(mInst.getTargetContext().getText(
				R.string.oma_status_loader_error), OmaDownloadManager
				.statusMessage(mContext, STATUS_LOADER_ERROR));

	}

	/**
	 * there tests method errorMessage and statusmessage is
	 * STATUS_INSUFFICIENT_MEMORY.
	 * 
	 * @throws Exception
	 */
	public void testerrorMessage() throws Exception {
		assertEquals(mInst.getTargetContext().getText(
				R.string.oma_error_insufficient_memory), OmaDownloadManager
				.errorMessage(mContext, STATUS_INSUFFICIENT_MEMORY));
	}

	/**
	 * there tests method errorMessage and statusmessage is
	 * STATUS_NONACCEPTABLE_CONTENT.
	 * 
	 * @throws Exception
	 */
	public void testerrorMessageSTATUS_NONACCEPTABLE_CONTENT() throws Exception {
		assertEquals(mInst.getTargetContext().getText(
				R.string.oma_error_non_acceptable_content), OmaDownloadManager
				.errorMessage(mContext, STATUS_NONACCEPTABLE_CONTENT));
	}

	/**
	 * there tests method onDownloadManagerError.
	 * 
	 * @throws Exception
	 */
	public void testonDownloadManagerError() throws Exception {
		OmaDownloadManager.OmaDownloadManagerBroadcastReceiver oma = new OmaDownloadManagerBroadcastReceiver();
		ReflectHelper.runPrivateMethod(oma, "onDownloadManagerError",
				new Class[] { Context.class, int.class, String.class },
				new Object[] { mContext, Downloads.STATUS_FILE_ERROR,
						"http://baidu.com" });
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		ReflectHelper.runPrivateMethod(oma, "onDownloadManagerError",
				new Class[] { Context.class, int.class, String.class },
				new Object[] { mContext, Downloads.STATUS_CANCELED,
						"http://baidu.com" });
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		ReflectHelper.runPrivateMethod(oma, "onDownloadManagerError",
				new Class[] { Context.class, int.class, String.class },
				new Object[] { mContext, Downloads.STATUS_NOT_ACCEPTABLE,
						"http://baidu.com" });
		Helper.HardKey.center(mInst);
	}

	// help method

	/**
	 * there launch OmaDownloadManager and URL is FileURL.
	 * 
	 * @return
	 */
	private OmaDownloadManager launchOmaDownloadManagerURLIsFileURL(
			String name, String filepath) {
		Helper.createFileToSdcard(mInst.getContext(), name, PATH);
		Uri uri = Uri.parse(filepath);
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		intent.putExtra("contenturi", Downloads.CONTENT_URI);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClass(mContext, OmaDownloadManager.class);
		mOmaDownloadManager = (OmaDownloadManager) mInst
				.startActivitySync(intent);
		return mOmaDownloadManager;
	}

	/**
	 * there launch OmaDownloadManager and URL is click exit.
	 * 
	 * @return
	 */
	private OmaDownloadManager launchOmaDownloadManager(Uri seturi,
			String name, String filepath) {
		Helper.createFileToSdcard(mInst.getContext(), name, PATH);
		Uri uri = Uri.parse(filepath);
		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
		intent.putExtra("contenturi", seturi);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClass(mContext, OmaDownloadManager.class);
		mOmaDownloadManager = (OmaDownloadManager) mInst
				.startActivitySync(intent);
		return mOmaDownloadManager;
	}

	/**
	 * there launch OmaDownloadManager and URL is not FileURL show Dialog Error.
	 * 
	 * @return
	 */
	private OmaDownloadManager launchOmaDownloadManagerURLIsNotFileURL() {
		Intent intent = new Intent(Intent.ACTION_VIEW, Downloads.CONTENT_URI);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClass(mContext, OmaDownloadManager.class);
		mOmaDownloadManager = (OmaDownloadManager) mInst
				.startActivitySync(intent);
		return mOmaDownloadManager;
	}

	/**
	 * insert into download.
	 */
	private Uri insertdownload(int status, String type) {
		ContentValues cv = new ContentValues();
		cv.put(Downloads.COLUMN_URI, "http://www.baidu.com");
		cv.put(Downloads._DATA, "file:///sdcard");
		cv.put(Downloads.COLUMN_TITLE, "luo");
		cv.put(Downloads.COLUMN_STATUS, status);
//		cv.put(Downloads.COLUMN_NOTIFICATION_EXTRAS, "file:///sdcard");
//		cv.put(Downloads.COLUMN_USER_AGENT, "file:///sdcard");
//		cv.put(Downloads.COLUMN_PROXY_HOST, "file:///sdcard");
//		cv.put(Downloads.COLUMN_PROXY_PORT, "80");
		cv.put(Downloads.COLUMN_MIME_TYPE, type);
		Uri uri = mContext.getContentResolver().insert(Downloads.CONTENT_URI,
				cv);
		return uri;

	}

	/**
	 * clear all downloads.
	 */
	private void clearAllDownloads() {
		Cursor DownloadCursor;
		DownloadCursor = mContext.getContentResolver().query(
				Downloads.CONTENT_URI, null, null, null, null);
		try {
			int mIdColumnId = DownloadCursor
					.getColumnIndexOrThrow(Downloads._ID);
			if (DownloadCursor.moveToFirst()) {
				StringBuilder where = new StringBuilder();
				boolean firstTime = true;
				while (!DownloadCursor.isAfterLast()) {
					if (firstTime) {
						firstTime = false;
					} else {
						where.append(" OR ");
					}
					where.append("( ");
					where.append(Downloads._ID);
					where.append(" = '");
					where.append(DownloadCursor.getLong(mIdColumnId));
					where.append("' )");
					DownloadCursor.moveToNext();
				}
				if (!firstTime) {
					mContext.getContentResolver().delete(Downloads.CONTENT_URI,
							where.toString(), null);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			DownloadCursor.close();
			DownloadCursor = null;
		}

	}
}
