package com.android.browser;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.MediumTest;

/**
 * test BrowserPreferencesPage.java.
 * 
 * @author Tang Ting
 * 
 */
public class BrowserPreferencesPageTest extends
		ActivityUnitTestCase<BrowserPreferencesPage> {
	private BrowserPreferencesPage mBrowserPreferencesPage;
	private static final int SHORT_TIME = 200;
	private Preference mPref;
	private Context mContext;

	public BrowserPreferencesPageTest() {
		super(BrowserPreferencesPage.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mContext = getInstrumentation().getTargetContext();
		mPref = new Preference(mContext);
	}

	@Override
	protected void tearDown() throws Exception {
		if (mBrowserPreferencesPage != null) {
			mBrowserPreferencesPage.finish();
			SystemClock.sleep(SHORT_TIME);
			mBrowserPreferencesPage = null;
		}
		mContext = null;
		mPref = null;
		super.tearDown();
	}

	// method
	private BrowserPreferencesPage launchActvitiy() {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		BrowserPreferencesPage activity = startActivity(intent, null, null);
		assertNotNull(activity);
		return activity;
	}

	/**
	 * test onPreferenceChange with reset default preferences
	 */
	@MediumTest
	public void testonPreferenceChange_ResetDefaultPref() {
		mBrowserPreferencesPage = launchActvitiy();
		assertNotNull(mBrowserPreferencesPage);
		mPref.setKey(BrowserSettings.PREF_EXTRAS_RESET_DEFAULTS);
		Boolean value = true;
		assertFalse(mBrowserPreferencesPage.onPreferenceChange(mPref, value));
	}

	/**
	 * test onPreferenceChange with change homepage then change homepage to
	 * default
	 */
	@LargeTest
	public void testonPreferenceChange_ChangeHomepage() {
		mBrowserPreferencesPage = launchActvitiy();
		assertNotNull(mBrowserPreferencesPage);
		String homePage = " forum.byr.edu.cn ";
		Preference editTextPref = new EditTextPreference(mContext);
		editTextPref.setKey(BrowserSettings.PREF_HOMEPAGE);
		assertFalse(mBrowserPreferencesPage.onPreferenceChange(editTextPref,
				homePage));

		String defaultHomePage = "file:///oms_asset/html/home.html";
		assertTrue(mBrowserPreferencesPage.onPreferenceChange(editTextPref,
				defaultHomePage));
	}

	/**
	 * test onPreferenceChange with set text size
	 */
	@MediumTest
	public void testonPreferenceChange_SetTextSize() {
		mBrowserPreferencesPage = launchActvitiy();
		assertNotNull(mBrowserPreferencesPage);
		String value = "Large";
		mPref.setKey(BrowserSettings.PREF_TEXT_SIZE);
		assertTrue(mBrowserPreferencesPage.onPreferenceChange(mPref, value));
	}

	/**
	 * test onPreferenceChange with set text encode
	 */
	@MediumTest
	public void testonPreferenceChange_SetTextEncode() {
		mBrowserPreferencesPage = launchActvitiy();
		assertNotNull(mBrowserPreferencesPage);
		String value = "Chinese Trad.(BIG5)";
		mPref.setKey(BrowserSettings.PREF_DEFAULT_TEXT_ENCODING);
		assertTrue(mBrowserPreferencesPage.onPreferenceChange(mPref, value));
	}

	/**
	 * test onPreferenceChange with set search portal
	 */
	@LargeTest
	public void testonPreferenceChange_SetSearchPortal() {
		mBrowserPreferencesPage = launchActvitiy();
		assertNotNull(mBrowserPreferencesPage);
		String value = "Baidu";
		mPref.setKey(BrowserSettings.PREF_SEARCH_PORTAL);
		assertTrue(mBrowserPreferencesPage.onPreferenceChange(mPref, value));
	}

	/**
	 * test onPreferenceChange with set data connection
	 */
	@MediumTest
	public void testonPreferenceChange_SetDataConnection() {
		mBrowserPreferencesPage = launchActvitiy();
		assertNotNull(mBrowserPreferencesPage);
		Object value = "cmmail";
//		mPref.setKey(BrowserSettings.PREF_DATA_CONNECTION);
		ListPreference lpf = new ListPreference(mContext);
		lpf.setKey(BrowserSettings.PREF_DATA_CONNECTION);
		assertTrue(mBrowserPreferencesPage.onPreferenceChange(lpf, value));
	}

	/**
	 * test onPreferenceClick with gears setting
	 */
	@LargeTest
	public void testonPreferenceClick_GearsSet() {
		mBrowserPreferencesPage = launchActvitiy();
		assertNotNull(mBrowserPreferencesPage);
		mPref.setKey(BrowserSettings.PREF_GEARS_SETTINGS);
		assertTrue(mBrowserPreferencesPage.onPreferenceClick(mPref));
	}

	/**
	 * test onPreferenceClick with set download directory
	 */
	@MediumTest
	public void testonPreferenceClick_SetDownloadDir() {
		mBrowserPreferencesPage = launchActvitiy();
		assertNotNull(mBrowserPreferencesPage);
		mPref.setKey(BrowserSettings.PREF_DOWNLOAD_DIR);
		assertTrue(mBrowserPreferencesPage.onPreferenceClick(mPref));
	}

	/**
	 * test onPause
	 */
	@LargeTest
	public void testonPause() {
		mBrowserPreferencesPage = launchActvitiy();
		assertNotNull(mBrowserPreferencesPage);
		mBrowserPreferencesPage.onPause();
	}

	/**
	 * test onNewIntent
	 */
	@MediumTest
	public void testonNewIntent() {
		mBrowserPreferencesPage = launchActvitiy();
		assertNotNull(mBrowserPreferencesPage);
		Intent intent = new Intent();
		intent.setAction("reset_homepage");
		mBrowserPreferencesPage.onNewIntent(intent);
	}

	/**
	 * test onActivityResult
	 */
	@LargeTest
	public void testonActivityResult() {
		String path = "///sdcard/";
		Uri uri = Uri.parse(path);
		Intent intent = new Intent();
		intent.setData(uri);
		int requestCode = BrowserPreferencesPage.GET_DOWNLOAD_DIR;
		int resultCode = BrowserPreferencesPage.RESULT_OK;

		mBrowserPreferencesPage = launchActvitiy();
		assertNotNull(mBrowserPreferencesPage);
		mBrowserPreferencesPage.onActivityResult(requestCode, resultCode,
				intent);

		mBrowserPreferencesPage.onActivityResult(requestCode, 0, intent);
	}

}
