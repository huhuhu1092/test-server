package com.android.browser.unittests.cmcc;

import java.util.Date;

import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Browser;
import android.provider.Browser.BookmarkColumns;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;

import com.android.browser.cmcc.CMCCAddBookmarkPage;
import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

/**
 * Test CMMCABookmarkPage.java.
 * @author b391(LuoXiaofei)
 *
 */
@Suppress
public class CMCCAddBookmarkPageTest extends
		ActivityUnitTestCase<CMCCAddBookmarkPage> {

	private Instrumentation mInst;
	private Context mContext;
	private CMCCAddBookmarkPage mCMCCAddBookmarkPage;
	private static final String TITLE = "baidu";
	private static final String URL = "http://baidu/";
	
	private static Uri sUri;
	private static int sCount;
	
	public CMCCAddBookmarkPageTest() {
		super(CMCCAddBookmarkPage.class);
		sCount ++;
	}
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mContext = mInst.getTargetContext();
		mInst.setInTouchMode(false);
		if(!ifHaveOneBookMark()){
			sUri = addOneBookmark(TITLE,URL);
		}
	}

	@Override
	protected void tearDown() throws Exception {
		if(-- sCount == 0 && sUri != null) {
			clearBookmarks(sUri);
		}
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		mContext = null;
		mInst = null;
		if (mCMCCAddBookmarkPage != null) {
			mCMCCAddBookmarkPage.finish();
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
			mCMCCAddBookmarkPage = null;
		}
		super.tearDown();
	}

	/**
	 * there tests launchCMCCAddBookmarkPage
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testlaunchCMCCAddBookmarkPage() throws Exception {
		assertNotNull(launchCMCCAddBookmarkPage(TITLE,URL));
	}
	/**
	 * there tests click Ok and then click Override and title!=null and
	 * url!=null
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testclickOkOverride() throws Exception {
		assertNotNull(launchCMCCAddBookmarkPage(TITLE, URL));
		// click ok
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		// click the OverrideDialog Override
		Helper.HardKey.center(mInst);

	}

	/**
	 * there tests click Ok and then click Override and title=null and url!=null
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testclickOkOverrideTitleNull() throws Exception {
		assertNotNull(launchCMCCAddBookmarkPage(null, URL));
		// click ok
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);

	}

	/**
	 * there tests click Ok and then click Override and title!=null and url=null
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testclickOkOverrideURlNull() throws Exception {
		assertNotNull(launchCMCCAddBookmarkPage(TITLE, null));
		// click ok
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);

	}

	/**
	 * there tests click Ok and then click Override and title=null and url=null
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testclickOkOverrideTitleURlNull() throws Exception {
		assertNotNull(launchCMCCAddBookmarkPage(null, null));
		// click ok
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);

	}

	/**
	 * there tests click Ok and then click cancle
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testclickOkcancle() throws Exception {
		assertNotNull(launchCMCCAddBookmarkPage(TITLE, URL));
		// click ok
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		// click the OverrideDialog cancle
		Helper.HardKey.right(mInst);
		Helper.HardKey.center(mInst);

	}

	/**
	 * there tests click cancle
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testclickcancle() throws Exception {
		assertNotNull(launchCMCCAddBookmarkPage(TITLE, URL));
		// click cancle
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.right(mInst);
		Helper.HardKey.center(mInst);
	}

	/**
	 * there tests click ok and mEditingExisting=true
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testclickOKcusrsorHaveNoData() throws Exception {
		clearBookmarks();
		assertNotNull(launchCMCCAddBookmarkPage(TITLE, URL));
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
	}

	/**
	 * there tests method click ok and mEditingExisting=false
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testcickOKcursorHaveNodataAndmEditingExistingFalse()
			throws Exception {
		clearBookmarks();
		assertNotNull(launchCMCCAddBookmarkPage(TITLE, URL));
		ReflectHelper.setPrivateField(mCMCCAddBookmarkPage, "mEditingExisting",
				false);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
	}

	// help method
	/**
	 * there is launch CMCCAddBookmarkPage
	 */
	private CMCCAddBookmarkPage launchCMCCAddBookmarkPage(String title,
			String url) {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClass(mContext, CMCCAddBookmarkPage.class);
		Bundle bundle = new Bundle();
		Bundle getbundle = new Bundle();
		getbundle.putString("title", title);
		getbundle.putString("url", url);
		getbundle.putString("catid", "1");
		bundle.putBundle("bookmark", getbundle);
		intent.putExtras(bundle);
		mCMCCAddBookmarkPage = (CMCCAddBookmarkPage) mInst
				.startActivitySync(intent);
//		mInst.waitForIdleSync();
		SystemClock.sleep(20000);
		return mCMCCAddBookmarkPage;
	}

	// Insert Bookmarks to DB.
	private Uri addOneBookmark(String title, String url) {
		final Uri BOOKMARKS_URI = Uri.parse("content://browser/bookmarks");
		ContentResolver contentResolver = mInst.getTargetContext()
				.getContentResolver();
		long creationTime = new Date().getTime();
		ContentValues map = new ContentValues();
		map.put(BookmarkColumns.TITLE, title);
		map.put(BookmarkColumns.URL, url);
		map.put(BookmarkColumns.CREATED, creationTime);
		map.put(BookmarkColumns.BOOKMARK, 1);
		map.put(BookmarkColumns.DATE, 0);
		map.put(BookmarkColumns.VISITS, 0);
		Uri uri = contentResolver.insert(BOOKMARKS_URI, map);
		assertNotNull("Insert history to DB failed! ", uri);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		return uri;
	}

	// clear Bookmarks in DB
	private void clearBookmarks() {
		final Uri BOOKMARKS_URI = Uri.parse("content://browser/bookmarks");
		ContentResolver contentResolver = getInstrumentation().getTargetContext().getContentResolver();
		contentResolver.delete(BOOKMARKS_URI, null, null);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Cursor c = contentResolver
				.query(BOOKMARKS_URI, null, null, null, null);
		assertEquals(0, c.getCount());

		c.close();
		c = null;
	}
	
	private void clearBookmarks(Uri uri) {
		ContentResolver contentResolver = getInstrumentation().getTargetContext().getContentResolver();
		contentResolver.delete(uri, null, null);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Cursor c = contentResolver
				.query(uri, null, null, null, null);
		assertEquals(0, c.getCount());

		c.close();
		c = null;
	}
	
	private boolean ifHaveOneBookMark() {
		Cursor c = mInst.getTargetContext().getContentResolver().query(Browser.BOOKMARKS_URI, null, null, null, null);
		if(c.getCount() == 1) {
			return true;
		}
		if(c.getCount() > 1) {
			clearBookmarks();
		}
		return false;
	}
}
