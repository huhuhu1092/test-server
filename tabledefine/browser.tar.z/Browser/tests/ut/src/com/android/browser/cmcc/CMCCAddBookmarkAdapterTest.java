package com.android.browser.cmcc;

import java.util.ArrayList;

import android.test.AndroidTestCase;
import android.test.suitebuilder.annotation.MediumTest;
import android.test.suitebuilder.annotation.SmallTest;

/**
 * test CMCCAddBookmarkAdapter.java.
 * 
 * @author Tang Ting
 * 
 */
public class CMCCAddBookmarkAdapterTest extends AndroidTestCase {
	private static final String CATID = "1";
	private static final int RES = 10;

	private ArrayList<String> catList;
	private CMCCAddBookmarkAdapter mCMCCAddBookmarkAdapter;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	@Override
	protected void tearDown() throws Exception {
		mCMCCAddBookmarkAdapter = null;
		catList = null;
		super.tearDown();
	}

	// method
	private CMCCAddBookmarkAdapter createCMCCAddBookmarkAdapter(String catid,
			int res) {
		catList = new ArrayList<String>();
		catList.add("borqs");
		catList.add("cmcc");
		return (new CMCCAddBookmarkAdapter(getContext(), catid, null, res,
				catList));
	}

	/**
	 * test getSelectedIndex
	 */
	@SmallTest
	public void testgetSelectedIndex() {
		mCMCCAddBookmarkAdapter = createCMCCAddBookmarkAdapter(CATID, RES);
		assertEquals(0, mCMCCAddBookmarkAdapter.getSelectedIndex());
	}

	/**
	 * test getSelectedIndex with catid of CMCCAddBookmarkAdapter is null
	 */
	@MediumTest
	public void testtestgetSelectedIndexCatidNull() {
		mCMCCAddBookmarkAdapter = createCMCCAddBookmarkAdapter(null, RES);
		assertEquals(-1, mCMCCAddBookmarkAdapter.getSelectedIndex());
	}

	/**
	 * test getFilter
	 */
	@SmallTest
	public void testgetFilter() {
		mCMCCAddBookmarkAdapter = createCMCCAddBookmarkAdapter(CATID, RES);
		assertEquals(null, mCMCCAddBookmarkAdapter.getFilter());
	}

	/**
	 * test getItem
	 */
	@SmallTest
	public void testgetItem() {
		mCMCCAddBookmarkAdapter = createCMCCAddBookmarkAdapter(CATID, RES);
		mCMCCAddBookmarkAdapter.getItem(0);
	}

}
