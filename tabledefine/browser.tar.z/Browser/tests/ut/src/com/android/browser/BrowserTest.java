package com.android.browser;

import android.test.AndroidTestCase;
import android.test.suitebuilder.annotation.MediumTest;

/**
 * Test Browser.java.
 * @author b391(LuoXiaofei)
 *
 */

public class BrowserTest extends AndroidTestCase {

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	@Override
	protected void tearDown() throws Exception {
		super.tearDown();

	}

	/**
	 * there tests new BrowserEditTextPreference
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testnewBrowser() throws Exception {

		Browser browser = new Browser();
		browser.onCreate();
		assertNotNull(Browser.createBrowserViewIntent());
	}

}
