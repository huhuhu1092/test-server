package com.android.browser;

import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.MediumTest;
import android.test.suitebuilder.annotation.Suppress;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.android.browser.unittests.testutil.Helper;

/**
 * Test class of BrowserSetting
 * @author I087(Cao Lina)
 *
 */
@Suppress
public class BrowserSettingTest extends ActivityUnitTestCase<BrowserActivity> {
    private BrowserSettings mBrowserSettings;
    private Instrumentation mInst;
    private Context mContext;
    public static String DEFAULT_HOMEPAGE = "file:///oms_asset/html/home.html";
    private static BrowserActivity sBrowserActivity;
    private static boolean sFlag = true;
    private static int sCount = 0;
    
	public BrowserSettingTest() {
		super(BrowserActivity.class);
		sCount ++;
	}

	protected void setUp() throws Exception {
		super.setUp();
		if(sFlag) {
			sBrowserActivity = lanuchBrowserActivity();
			sFlag = false;
		}
		mInst=this.getInstrumentation();
		mContext=mInst.getTargetContext();
		mBrowserSettings = BrowserSettings.getInstance();
		mBrowserSettings.setBrowserActivity(sBrowserActivity);
	}

	protected void tearDown() throws Exception {
		if(--sCount == 0 && sBrowserActivity != null) {
			sBrowserActivity.goQuit();
			SystemClock.sleep(2000);
			sBrowserActivity = null;
		}
		mBrowserSettings=null;
		mContext=null;
		mInst=null;
		super.tearDown();
	}
//    /**
//     * test method of setBrowserActivity()
//     * @throws Exception
//     */
//	@LargeTest
//    public void testsetBrowserActivity() throws Exception{
////    	BrowserActivity ba=launchActivity();
//    	assertNotNull(sBrowserActivity);
////        mBrowserSettings.setBrowserActivity(ba);
//      //b392 5.20
//    	SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//    	FrameLayout contentView =  (FrameLayout) ReflectHelper.getPrivateField(sBrowserActivity, "mContentView");
//		if(contentView != null){
//			contentView.removeAllViews();
//		}
//		ba.finish();
//    	ba = null;
//    	//end
//    }
    /**
     * test method of getHomePage()
     * @throws Exception
     */
	@MediumTest
    public void testgetHomePage() throws Exception{
    	assertEquals(DEFAULT_HOMEPAGE, mBrowserSettings.getHomePage());
    }
    /**
     * test method of chooseDefaultHomePage()
     * @throws Exception
     */
    @LargeTest
    public void testchooseDefaultHomePage() throws Exception{
    	assertEquals(DEFAULT_HOMEPAGE, mBrowserSettings.chooseDefaultHomePage());
    }
    /**
     * test method of setHomePage()
     * @throws Exception
     */
    @LargeTest
    public void testsetHomePage() throws Exception{
    	mBrowserSettings.setHomePage(mContext, "www.baidu.com");
    	assertEquals("www.baidu.com", mBrowserSettings.getHomePage());
    }
    /**
     * test method of setLoginInitialized()
     * @throws Exception
     */
    @LargeTest
    public void testsetLoginInitialized()throws Exception{
    	mBrowserSettings.setLoginInitialized(mContext);
    	assertEquals(true,mBrowserSettings.isLoginInitialized());
    }
    /**
     * test method of getOrientation()
     * @throws Exception
     */
    @LargeTest
    public void testgetOrientation() throws Exception{
    	assertEquals(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED,mBrowserSettings.getOrientation());
    }
    /**
     * test method of setOrientation()
     * @throws Exception
     */
    @MediumTest
    public void testsetOrientation() throws Exception{
    	mBrowserSettings.setOrientation(mContext, 1);
    	assertEquals(1, mBrowserSettings.getOrientation());
    }
    /**
     * test method of getTextSize()
     * @throws Exception
     */
    @MediumTest
    public void testgetTextSize() throws Exception{
    	assertEquals(WebSettings.TextSize.NORMAL,mBrowserSettings.getTextSize());
    }
    /**
     * test method of openInBackground()
     * @throws Exception
     */
    @MediumTest
    public void testopenInBackground() throws Exception{
    	assertEquals(false,mBrowserSettings.openInBackground());
    }
    /**
     * test method of showSecurityWarnings()
     * @throws Exception
     */
    @MediumTest
    public void testshowSecurityWarnings() throws Exception{
    	assertEquals(true,mBrowserSettings.showSecurityWarnings());
    }
    /**
     * test method of isTracing()
     * @throws Exception
     */
    @MediumTest
    public void testisTracing() throws Exception{
    	assertEquals(false,mBrowserSettings.isTracing());
    }
    /**
     * test method of isLightTouch()
     * @throws Exception
     */
    @MediumTest
    public void testisLightTouch() throws Exception{
    	assertEquals(false,mBrowserSettings.isLightTouch());
    }
    /**
     * test method of isNavDump()
     * @throws Exception
     */
    @MediumTest
    public void testisNavDump() throws Exception{
    	assertEquals(false,mBrowserSettings.isNavDump());
    }
    /**
     * test method of doFlick() 
     * @throws Exception
     */
    @LargeTest
    public void testdoFlick() throws Exception{
    	assertEquals(false,mBrowserSettings.doFlick());
    }
    /**
     * test method of showDebugSettings()
     * @throws Exception
     */
    @MediumTest
    public void testshowDebugSettings() throws Exception{
    	assertEquals(false,mBrowserSettings.showDebugSettings());
    }
    /**
     * test method of toggleDebugSettings()
     * @throws Exception
     */
    @MediumTest
    public void testtoggleDebugSettings() throws Exception{
    	mBrowserSettings.toggleDebugSettings();
    	assertEquals(true,mBrowserSettings.showDebugSettings());
    }
    /**
     * test method of getSearchPortal()
     * @throws Exception
     */
    @MediumTest
    public void testgetSearchPortal() throws Exception{
    	assertEquals(1,mBrowserSettings.getSearchPortal());
    }
    /**
     * test method of setSearchPortal()
     * @throws Exception
     */
    @LargeTest
    public void testsetSearchPortal() throws Exception{
    	mBrowserSettings.setSearchPortal(mContext, 2);
    	assertEquals(2, mBrowserSettings.getSearchPortal());
    }
    /**
     * test method of getHistorySort()
     * @throws Exception
    */
    @MediumTest
    public void testgetHistorySort() throws Exception{
    	assertEquals(0, mBrowserSettings.getHistorySort());
    }
    /**
     * test method of setHistorySort()
     * @throws Exception
     */
    @LargeTest
    public void testsetHistorySort() throws Exception{
    	mBrowserSettings.setHistorySort(mContext, 3);
    	assertEquals(3, mBrowserSettings.getHistorySort());
    }
    /**
     * test method of deleteObserver()
     * @throws Exception
     */
    @LargeTest
    public void testdeleteObserver() throws Exception{
    	WebView view=new WebView(mContext);
     	mBrowserSettings.deleteObserver(view.getSettings());	
    }
    /**
     * test method of sclearCache() 
     */
    @LargeTest
    public void testsclearCache() throws Exception{
//    	BrowserActivity ba=launchActivity();
    	TabControl tabControl=new TabControl(sBrowserActivity);
    	mBrowserSettings.setTabControl(tabControl);
    	mBrowserSettings.clearCache(mContext);
//    	//b392 5.20
//    	SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//    	FrameLayout contentView =  (FrameLayout) ReflectHelper.getPrivateField(ba, "mContentView");
//		if(contentView != null){
//			contentView.removeAllViews();
//		}
//		ba.finish();
//    	ba = null;
    	//end
    }
    /**
     * test method of clearCookies()
     * @throws Exception
     */
    @MediumTest
    public void testclearCookies() throws Exception{
    	
    	mBrowserSettings.clearCookies(mContext);
    }
    /**
     * test method of clearHistory()
     * @throws Exception
     */
    @MediumTest
    public void testclearHistory() throws Exception{
    	mBrowserSettings.clearHistory(mContext);
    }
    /**
     * test method of clearFormData()
     * @throws Exception
     */
    @MediumTest
    public void testclearFormData() throws Exception{
    	mBrowserSettings.clearFormData(mContext);
    }
    /**
     * test method of clearPasswords()
     * @throws Exception
     */
    @MediumTest
    public void testclearPasswords() throws Exception{
    	mBrowserSettings.clearPasswords(mContext);
    }
    /**
     * test method of resetDefaultPreferences() 
     * @throws Exception
     */
    @LargeTest
    public void testzresetDefaultPreferences() throws Exception{
    	mBrowserSettings.resetDefaultPreferences(mContext);
    	assertEquals(DEFAULT_HOMEPAGE, mBrowserSettings.getHomePage());
    }
    /**
     * test method of clearBrowserData()
     * @throws Exception
     */
    @LargeTest
    public void testclearBrowserData() throws Exception{
    	mBrowserSettings.clearBrowserData(mContext);
    }
    /**
     * test method of updateDMProperties() 
     * @throws Exception
     */
    @LargeTest
    public void testupdateDMProperties() throws Exception{
    	ContentResolver cr= mInst.getTargetContext().getContentResolver();
    	String key="test";
    	String value="test";
    	mBrowserSettings.updateDMProperties(cr, key, value);
    }
    /**
     * test method of getStorePath() 
     * @throws Exception
     */
    @MediumTest
    public void testgetStorePath() throws Exception{
//       assertEquals("/sdcard/download",mBrowserSettings.getStorePath());
    	assertNotNull(mBrowserSettings.getStorePath());
    }
    /**
     * test method of isBrowserDownloadAudiovideo
     * @throws Exception
     */
    @MediumTest
    public void testisBrowserDownloadAudiovideo() throws Exception{
    	mBrowserSettings.isBrowserDownloadAudiovideo();
    	assertEquals(true,mBrowserSettings.isBrowserDownloadAudiovideo());
    }
    /**
     * test method of syncSharedPreferences()
     * @throws Exception
     */
    @LargeTest
    public void testzsyncSharedPreferences() throws Exception{
    	SharedPreferences p=PreferenceManager.getDefaultSharedPreferences(mContext);
    	mBrowserSettings.syncSharedPreferences(p);
    }

    //help method 
//    private BrowserActivity launchActivity(){
//        Intent intent = new Intent(Intent.ACTION_VIEW);
//        intent.setData(Uri.parse("file://sdcard/download/gif.bb"));
//        Bundle bundle = new Bundle();
//        bundle.putBoolean("testing", false);
//        intent.putExtras(bundle);
//        return startActivity(intent, null, null);
//    }
    
    private BrowserActivity lanuchBrowserActivity() throws Exception {
//		Helper.createFileToSdcard(getInstrumentation().getContext(), "test.txt", "/sdcard");
    	Helper.createFileToSdcard(getInstrumentation().getContext(), "test.html", "/sdcard");
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse("file:///sdcard/test.html"));
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName("com.android.browser", BrowserActivity.class.getName());

		BrowserActivity activity = (BrowserActivity) this.getInstrumentation().startActivitySync(intent);
		SystemClock.sleep(40000);
		assertNotNull(activity);
		return activity;
	}
}
