package com.android.browser;

import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.Downloads;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;

import com.android.browser.unittests.testutil.Helper;

/**
 * test FetchUrlMimeType
 * 
 * @author wsj
 * 
 */
public class FetchUrlMimeTypeTest extends InstrumentationTestCase {
	private Instrumentation mInst;
	private static BrowserActivity mActivity = null;
	private static int mCount = 0;
	private FetchUrlMimeType mFetchUrlMimeType;
	private BrowserDownloadPage mBrowserDownloadPage;
	private Instrumentation.ActivityMonitor BrowserDownloadPageMonitor = new Instrumentation.ActivityMonitor(
			BrowserDownloadPage.class.getName(), null, false);

	public FetchUrlMimeTypeTest() {
		super();
		mCount++;
	}

	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mInst.addMonitor(BrowserDownloadPageMonitor);
		if (mActivity == null) {
			mActivity = getBrowserActivity();
		}
	}

	protected void tearDown() throws Exception {
//		Log.e("*******************", " " + mCount);
		mFetchUrlMimeType = null;
		deleteDownloads();
		mBrowserDownloadPage = (BrowserDownloadPage) Helper
				.waitForActivity(BrowserDownloadPageMonitor);
		if (mBrowserDownloadPage != null) {
			mBrowserDownloadPage.finish();
			mBrowserDownloadPage = null;
		}

		if (--mCount == 0 && mActivity != null) {
			Helper.deleteFileAndFolder("///sdcard");
			mActivity.goQuit();
			SystemClock.sleep(15000);
			mActivity = null;
		}
		if (mInst != null) {
			mInst.removeMonitor(BrowserDownloadPageMonitor);
			mInst = null;
		}
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);

		super.tearDown();
	}

	// test Method
	/**
	 * test doInBackground and onPostExecute while values aren't null
	 */
	@LargeTest
	public void testdoInBackground_ValuesNotNull_OnPostExecute()
			throws Exception {
		ContentValues values = new ContentValues();
		values.put(Downloads.COLUMN_URI, "http://www.baidu.com/");
		values.put(Downloads.COLUMN_COOKIE_DATA, "http://www.baidu.com");

		values.put(Downloads.COLUMN_REFERER, "Content-Type");
		values.put(Downloads.COLUMN_NOTIFICATION_CLASS, 0);
		values.put(Downloads.COLUMN_VISIBILITY,
				Downloads.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
		values.put(Downloads.COLUMN_MIME_TYPE, "application/octet-stream");
		values.put(Downloads.COLUMN_DESCRIPTION, 0);
		mFetchUrlMimeType = getFetchUrlMimeType();
		assertNotNull(mFetchUrlMimeType);
		mFetchUrlMimeType.doInBackground(values);
		mFetchUrlMimeType.onPostExecute("application/octet-stream");

	}

	/**
	 * test doInBackground's Exception
	 */
	@LargeTest
	public void testdoInBackground_Exception() throws Exception {
		ContentValues values = new ContentValues();
//		values.put(Downloads.COLUMN_URI, "file:///sdcard/test.txt");
		values.put(Downloads.COLUMN_URI, "file:///sdcard/test.html");
		values.put(Downloads.COLUMN_MIME_TYPE, "application/octet-stream");
		mFetchUrlMimeType = getFetchUrlMimeType();
		assertNotNull(mFetchUrlMimeType);
		mFetchUrlMimeType.doInBackground(values);
		mFetchUrlMimeType.onPostExecute("application/octet-stream");

	}

	/**
	 * test doInBackground while values are null
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testdoInBackground_ValuesNull() throws Exception {
		ContentValues values = new ContentValues();
		values.put(Downloads.COLUMN_URI, "");
		try {
			mFetchUrlMimeType = getFetchUrlMimeType();
			assertNotNull(mFetchUrlMimeType);
			mFetchUrlMimeType.doInBackground(values);
		} catch (IllegalArgumentException e) {
			e.fillInStackTrace();
		}
	}
	

	// help Method
	/**
	 * launch BrowserActivity
	 */
	private BrowserActivity getBrowserActivity() throws Exception {
//		Helper.createFileToSdcard(mInst.getContext(), "test.txt", "/sdcard");
		Helper.createFileToSdcard(mInst.getContext(), "test.html", "/sdcard");
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setClassName("com.android.browser", BrowserActivity.class
				.getName());
//		intent.setData(Uri.parse("file:///sdcard/test.txt"));
		intent.setData(Uri.parse("file:///sdcard/test.html"));
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		BrowserActivity browserActivity = (BrowserActivity) mInst.startActivitySync(intent);
		SystemClock.sleep(60000);
		return browserActivity;
	}

	/**
	 * get a FetchUrlMimeType Object
	 * 
	 * @return
	 * @throws Exception
	 */
	private FetchUrlMimeType getFetchUrlMimeType() throws Exception {
		FetchUrlMimeType fetchUrlMimeType = new FetchUrlMimeType(mActivity);
		return fetchUrlMimeType;
	}

	/**
	 * 
	 * there is delete alldownloads
	 */
	/*
	 * 
	 * private void clearAllDownloads() {
	 * 
	 * 
	 * 
	 * }
	 */

	/**
	 * delete values in Downloads
	 */
	private void deleteDownloads() throws Exception {
		ContentResolver resolver = mInst.getContext().getContentResolver();
		Cursor mDownloadCursor;

		mDownloadCursor = resolver.query(Downloads.CONTENT_URI, null,

		null, null, null);

		int mIdColumnId = mDownloadCursor.getColumnIndexOrThrow(Downloads._ID);

		if (mDownloadCursor.moveToFirst()) {

			StringBuilder where = new StringBuilder();

			boolean firstTime = true;

			while (!mDownloadCursor.isAfterLast()) {

				if (firstTime) {

					firstTime = false;

				} else {

					where.append(" OR ");

				}

				where.append("( ");

				where.append(Downloads._ID);

				where.append(" = '");

				where.append(mDownloadCursor.getLong(mIdColumnId));

				where.append("' )");

				mDownloadCursor.moveToNext();

			}

			if (!firstTime) {
				try {
					resolver.delete(Downloads.CONTENT_URI,

					where.toString(), null);
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {

						mDownloadCursor.close();
						mDownloadCursor = null;
					} catch (Exception e) {
						e.printStackTrace();
					}

				}

			}

		}

	}
	
//	private void clearTabsFromContentView() {
//		mInst.runOnMainSync(new Runnable() {
//			public void run() {
//				try {
//					FrameLayout contentView = (FrameLayout) ReflectHelper
//							.getPrivateField(mActivity, "mContentView");
//					if (contentView != null) {
//						contentView.removeAllViews();
//					}
//					mActivity = null;
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
}
