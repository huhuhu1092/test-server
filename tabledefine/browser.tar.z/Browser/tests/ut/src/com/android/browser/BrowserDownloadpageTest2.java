package com.android.browser;

import java.util.concurrent.TimeUnit;

import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.Downloads;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.ContextMenu.ContextMenuInfo;

import com.android.browser.BrowserDownloadPage.DownloadReceiver;
import com.android.browser.unittests.testutil.Helper;

/**
 * Test BRowserDownloadpage.java.
 * 
 * @author b391(LuoXiaofei)
 * 
 */
@Suppress
public class BrowserDownloadpageTest2 extends
		ActivityUnitTestCase<BrowserDownloadPage> {

	public BrowserDownloadpageTest2() {
		super(BrowserDownloadPage.class);
	}

	private Instrumentation mInst;
	private Context mContext;
	private BrowserDownloadPage mBrowserDownloadPage;
	private ContentResolver mContentResolver;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mInst.setInTouchMode(false);
		mContext = mInst.getTargetContext();
		mContentResolver = mContext.getContentResolver();
	}

	@Override
	protected void tearDown() throws Exception {
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		mInst = null;
		mContext = null;
		if (mBrowserDownloadPage != null) {
			mBrowserDownloadPage.finish();
			mBrowserDownloadPage = null;
		}
		mContentResolver = null;
		super.tearDown();
	}

	// test method
//	/**
//	 * there tests launchBrowserDownloadPage.
//	 */
//	@LargeTest
//	public void testlaunchBrowserDownloadPage() throws Exception {
//		assertNotNull(launchBrowserDownloadPage());
//		TimeUnit.SECONDS.sleep(2);
//		this.sendKeys(KeyEvent.KEYCODE_DPAD_DOWN);
//		this.sendKeys(KeyEvent.KEYCODE_DPAD_RIGHT);
//		this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);
//		TimeUnit.SECONDS.sleep(2);
//	}

	/**
	 * there tests launchBrowserDownloadPage and click ok.
	 * 
	 * @throws Exception
	 *//*
	@LargeTest
	public void testZ000launchBrowserDownloadPageClickOK() throws Exception {
		assertNotNull(launchBrowserDownloadPage());
		SystemClock.sleep(SHORT_TIME);
		Helper.HardKey.center(mInst);
		TimeUnit.SECONDS.sleep(2);
	}

	*//**
	 * there tests launchBrowserDownloadPage and click cancel.
	 * 
	 * @throws Exception
	 *//*
	@LargeTest
	public void testZ000launchBrowserDownloadPageClickCanner() throws Exception {
		assertNotNull(launchBrowserDownloadPage());
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.right(mInst);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	*//**
	 * there tests method OptionsItemSelected and listview.getcount<0.
	 * 
	 * @throws Exception
	 *//*
	@LargeTest
	public void testonOptionsItemSelectedViewgetcount() throws Exception {
		mBrowserDownloadPage = launchBrowserDownloadPage();
		assertNotNull(mBrowserDownloadPage);
		mInst.invokeMenuActionSync(mBrowserDownloadPage,
				R.id.download_menu_cancel_all, 0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.right(mInst);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	*//**
	 * there tests method OptionsItemSelected and listview.getcount>0 and status
	 * is 205 and type is text/vnd.sun.j2me.app-descriptor.
	 * 
	 * @throws Exception
	 *//*
	@LargeTest
	public void testonOptionsItemSelecteddownload_menu_cancel_all()
			throws Exception {
		int status = 205;
		String type = "text/vnd.sun.j2me.app-descriptor";
		insertdownload(status, type);
		mBrowserDownloadPage = launchBrowserDownloadPage();
		assertNotNull(mBrowserDownloadPage);
		try {
			mInst.invokeMenuActionSync(mBrowserDownloadPage,
					R.id.download_menu_cancel_all, 0);
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
			Helper.HardKey.center(mInst);
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		} catch (Exception e) {
		} finally {
			clearAllDownloads();
		}
	}

	*//**
	 * there tests method OptionsItemSelected and listview.getcount>0 and status
	 * is 205 and type is 123type.
	 * 
	 * @throws Exception
	 *//*
	@LargeTest
	public void testonOptionsItemSelecteddownload_menu_cancel_alltype()
			throws Exception {
		int status = 205;
		String type = "123type";
		insertdownload(status, type);
		mBrowserDownloadPage = launchBrowserDownloadPage();
		assertNotNull(mBrowserDownloadPage);
		try {
			mInst.invokeMenuActionSync(mBrowserDownloadPage,
					R.id.download_menu_cancel_all, 0);
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
			Helper.HardKey.center(mInst);
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		} catch (Exception e) {
		} finally {
			clearAllDownloads();
		}
	}

	*//**
	 * there tests method onOptionsItemSelected and
	 * itemid=R.id.download_menu_clear_all.
	 * 
	 * @throws Exception
	 *//*
	@LargeTest
	public void testZ001onOptionsItemSelecteddownload_menu_clear_all()
			throws Exception {
		clearAllDownloads();
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		int status = 205;
		insertdownloadwithoutdata(status);
		mBrowserDownloadPage = launchBrowserDownloadPageWithnotExtra();
		assertNotNull(mBrowserDownloadPage);
		try {
			mInst.invokeMenuActionSync(mBrowserDownloadPage,
					R.id.download_menu_clear_all, 0);

			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
			Helper.HardKey.down(mInst);
			Helper.HardKey.center(mInst);
			TimeUnit.SECONDS.sleep(2);
		} catch (Exception e) {
		} finally {
			clearAllDownloads();
		}
	}

	*//**
	 * there tests launchBrowserDownloadPage and the method checkStatus.
	 *//*
	@LargeTest
	public void testlaunchBrowserDownloadPagecheckStatus() throws Exception {
		int status = 205;
		String type = "123type";
		insertdownload(status, type);
		mBrowserDownloadPage = launchBrowserDownloadPageWithnotExtra();
		assertNotNull(mBrowserDownloadPage);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		Helper.HardKey.center(mInst);
		// clearAllDownloads();

	}

	*//**
	 * there tests method onContextItemSelected and id=R.id.download_menu_retry.
	 *//*
	@LargeTest
	public void testonContextItemSelecteddownload_menu_retry() throws Exception {
		int status = 191;
		String type = "123type";
		insertdownload(status, type);
		mBrowserDownloadPage = launchBrowserDownloadPageWithnotExtra();
		assertNotNull(mBrowserDownloadPage);
		try {
			mInst.invokeContextMenuAction(mBrowserDownloadPage,
					R.id.download_menu_retry, 0);
			Helper.HardKey.center(mInst);
			TimeUnit.SECONDS.sleep(2);
		} catch (Exception e) {
		} finally {
			clearAllDownloads();
		}

	}

	*//**
	 * there tests method onContextItemSelected and id=R.id.download_menu_retry
	 * and insert down load without data.
	 *//*
	@LargeTest
	public void testZ002onContextItemSelecteddownload_menu_retrynoData()
			throws Exception {
		int status = 191;
		insertdownloadwithoutdata(status);
		mBrowserDownloadPage = launchBrowserDownloadPageWithnotExtra();
		assertNotNull(mBrowserDownloadPage);
		try {
			mInst.invokeContextMenuAction(mBrowserDownloadPage,
					R.id.download_menu_retry, 0);
			Helper.HardKey.center(mInst);
			TimeUnit.SECONDS.sleep(2);
		} catch (Exception e) {
		} finally {
			clearAllDownloads();
		}

	}
*/
	/**
	 * there tests method resumeAllDownloads.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testresumeAllDownloads() throws Exception {
		int status = Downloads.STATUS_PAUSED_BY_USER;
		String type = "123type";
		insertdownload(status, type);
		mBrowserDownloadPage = launchBrowserDownloadPageWithnotExtra();
		assertNotNull(mBrowserDownloadPage);
		try {
			mInst.runOnMainSync(new Runnable() {
				public void run() {
					mBrowserDownloadPage.resumeAllDownloads();
				}
			});
		} catch (Exception e) {
		} finally {
			clearAllDownloads();
		}
	}

	/**
	 * there tests method pauseAllDownloads.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testpauseAllDownloads() throws Exception {
		int status = Downloads.STATUS_RUNNING;
		String type = "123type";
		insertdownload(status, type);
		mBrowserDownloadPage = launchBrowserDownloadPageWithnotExtra();
		assertNotNull(mBrowserDownloadPage);
		try {
			mInst.runOnMainSync(new Runnable() {
				public void run() {
					mBrowserDownloadPage.pauseAllDownloads();
				}
			});
		} catch (Exception e) {
		} finally {
			clearAllDownloads();
		}
	}

	/**
	 * there tests method onContextItemSelected and id=R.id.download_menu_retry.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonContextItemSelecteddownload_menu_cancel()
			throws Exception {
		int status = 405;
		String type = "123type";
		insertdownload(status, type);
		mBrowserDownloadPage = launchBrowserDownloadPageWithnotExtra();
		assertNotNull(mBrowserDownloadPage);
		try {
			mInst.invokeContextMenuAction(mBrowserDownloadPage,
					R.id.download_menu_cancel, 0);
			Helper.HardKey.down(mInst);
			Helper.HardKey.center(mInst);
		} catch (Exception e) {
		} finally {
			clearAllDownloads();
		}
	}

	/**
	 * there tests method onReceive in class DownloadReceiver and
	 * intent.action!=Downloads.ACTION_DOWNLOAD_COMPLETED.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonReceive() throws Exception {
		BrowserDownloadPage.DownloadReceiver downloadreceiver = new DownloadReceiver();
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_MAIN);
		intent.setData(Downloads.CONTENT_URI);
		downloadreceiver.onReceive(mContext, intent);
	}

	/**
	 * there tests method onReceive in class DownloadReceiver and
	 * intent.action=Downloads.ACTION_DOWNLOAD_COMPLETED.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonReceiveACTION_DOWNLOAD_COMPLETED() throws Exception {
		int status = Downloads.STATUS_RUNNING;
		String type = "application/java-archive";
		insertdownload(status, type);
		BrowserDownloadPage.DownloadReceiver downloadreceiver = new DownloadReceiver();
		Intent intent = new Intent(Downloads.ACTION_DOWNLOAD_COMPLETED);
		intent.setData(Downloads.CONTENT_URI);
		downloadreceiver.onReceive(mContext, intent);
		clearAllDownloads();
	}

	/**
	 * there tests method onReceive and type is "application/vnd.oma.dd+xml".
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonReceivetypeIsOMA_DD_TYPE() throws Exception {
		int status = Downloads.STATUS_RUNNING;
		String type = "application/vnd.oma.dd+xml";
		insertdownload(status, type);
		BrowserDownloadPage.DownloadReceiver downloadreceiver = new DownloadReceiver();
		Intent intent = new Intent(Downloads.ACTION_DOWNLOAD_COMPLETED);
		intent.setData(Downloads.CONTENT_URI);
		downloadreceiver.onReceive(mContext, intent);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.center(mInst);
		clearAllDownloads();
	}

	/**
	 * there tests method onReceive and type is
	 * "application/vnd.android.package-archive".
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonReceivetypeIsANDROID_APK_TYPE() throws Exception {
		int status = Downloads.STATUS_SUCCESS;
		String type = "application/vnd.android.package-archive";
		insertdownload(status, type);
		BrowserDownloadPage.DownloadReceiver downloadreceiver = new DownloadReceiver();
		Intent intent = new Intent(Downloads.ACTION_DOWNLOAD_COMPLETED);
		intent.setData(Downloads.CONTENT_URI);
		downloadreceiver.onReceive(mContext, intent);
		clearAllDownloads();
	}

	/**
	 * there tests method onContextItemSelected and id= R.id.download_menu_pause.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonContextItemSelecteddownload_menu_pause() throws Exception {
		int status = 405;
		String type = "123type";
		insertdownload(status, type);
		mBrowserDownloadPage = launchBrowserDownloadPageWithnotExtra();
		assertNotNull(mBrowserDownloadPage);
		try {
			mBrowserDownloadPage.onContextItemSelected(new MockMenuItem(
					R.id.download_menu_pause));
		}finally {
			clearAllDownloads();
		}
	}

	/**
	 * there tests method onContextItemSelected and id= R.id.download_menu_pause.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonContextItemSelecteddownload_menu_resume()
			throws Exception {
		String type = "123type";
		int status = 205;
		insertdownload(status, type);
		mBrowserDownloadPage = launchBrowserDownloadPageWithnotExtra();
		assertNotNull(mBrowserDownloadPage);
		try {
			mBrowserDownloadPage.onContextItemSelected(new MockMenuItem(
					R.id.download_menu_resume));
		}finally {
			clearAllDownloads();
		}
	}

	/**
	 * there tests method unfinishedMidlet.
	 */
	@LargeTest
	public void testunfinishedMidlet() throws Exception {
		assertFalse(BrowserDownloadPage.unfinishedMidlet(mContext));
	}

	/**
	 * there tests method unfinishedDownload.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testunfinishedDownload() throws Exception {
		assertFalse(BrowserDownloadPage.unfinishedDownload(mContext));
	}

	// help method

	/**
	 *there is launch the activity BrowserDownloadPage.
	 * 
	 * @return mBrowserDownloadPage
	 */
	private BrowserDownloadPage launchBrowserDownloadPage() {
		BrowserDownloadPage browserDownloadPage;
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClass(mContext, BrowserDownloadPage.class);
		Uri uri = Uri.parse(Downloads.CONTENT_URI.toString() + "/1");
		intent.setData(uri);
		intent.putExtra("drm_cid", "drm_cid");
		String[] value = new String[] { "1", "2" };
		String key = "drm_cid";
		OmaDownloadManager.mDrmCidMap.put(key, value);
		browserDownloadPage = (BrowserDownloadPage) mInst
				.startActivitySync(intent);
		return browserDownloadPage;
	}

	/**
	 * there is launch the activity BrowserDownloadPage and don't have Extra.
	 * 
	 * @return
	 */
	private BrowserDownloadPage launchBrowserDownloadPageWithnotExtra() {
		BrowserDownloadPage browserDownloadPage;
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClass(mContext, BrowserDownloadPage.class);
		Uri uri = Uri.parse(Downloads.CONTENT_URI.toString() + "/1");
		intent.setData(uri);
		browserDownloadPage = (BrowserDownloadPage) mInst
				.startActivitySync(intent);
		return browserDownloadPage;
	}

	/**
	 * insert into down load.
	 */
	private void insertdownload(int status, String type) {
		ContentValues cv = new ContentValues();
		cv.put(Downloads.COLUMN_URI, "http://www.baidu.com");
		cv.put(Downloads._DATA, "/sdcard");
		cv.put(Downloads.COLUMN_TITLE, "luo");
		cv.put(Downloads.COLUMN_STATUS, status);
		cv.put(Downloads.COLUMN_MIME_TYPE, type);
		mContentResolver.insert(Downloads.CONTENT_URI, cv);

	}

/*	private void insertdownloadwithoutdata(int status) {
		ContentValues cv = new ContentValues();
		cv.put(Downloads.COLUMN_TITLE, "luo");
		cv.put(Downloads.COLUMN_STATUS, status);
		cv.put(Downloads.COLUMN_MIME_TYPE, "text/vnd.sun.j2me.app-descriptor");
		mContentResolver.insert(Downloads.CONTENT_URI, cv);
	}*/

	/**
	 * there is delete all down loads.
	 */
	private void clearAllDownloads() {
		Cursor DownloadCursor;
		DownloadCursor = mContentResolver.query(Downloads.CONTENT_URI, null,
				null, null, null);
		try {
			int mIdColumnId = DownloadCursor
					.getColumnIndexOrThrow(Downloads._ID);
			if (DownloadCursor.moveToFirst()) {
				StringBuilder where = new StringBuilder();
				boolean firstTime = true;
				while (!DownloadCursor.isAfterLast()) {
					if (firstTime) {
						firstTime = false;
					} else {
						where.append(" OR ");
					}
					where.append("( ");
					where.append(Downloads._ID);
					where.append(" = '");
					where.append(DownloadCursor.getLong(mIdColumnId));
					where.append("' )");
					DownloadCursor.moveToNext();
				}
				if (!firstTime) {
					mContentResolver.delete(Downloads.CONTENT_URI, where
							.toString(), null);
				}
			}
		} catch (Exception e) {
		} finally {
			DownloadCursor.close();
			DownloadCursor = null;
		}

	}

	// help class
	static class MockMenuItem implements MenuItem {

		int id = 0;

		public MockMenuItem(int itemid) {
			id = itemid;
		}

		public char getAlphabeticShortcut() {
			return 0;
		}

		public int getGroupId() {
			return 0;
		}

		public Drawable getIcon() {
			return null;
		}

		public Intent getIntent() {
			return null;
		}

		public int getItemId() {
			return id;
		}

		public ContextMenuInfo getMenuInfo() {
			return null;
		}

		public char getNumericShortcut() {
			return 0;
		}

		public int getOrder() {
			return 0;
		}

		public SubMenu getSubMenu() {
			return null;
		}

		public CharSequence getTitle() {
			return null;
		}

		public CharSequence getTitleCondensed() {
			return null;
		}

		public boolean hasSubMenu() {
			return false;
		}

		public boolean isCheckable() {
			return false;
		}

		public boolean isChecked() {
			return false;
		}

		public boolean isEnabled() {
			return false;
		}

		public boolean isVisible() {
			return false;
		}

		public MenuItem setAlphabeticShortcut(char arg0) {
			return null;
		}

		public MenuItem setCheckable(boolean arg0) {
			return null;
		}

		public MenuItem setChecked(boolean arg0) {
			return null;
		}

		public MenuItem setEnabled(boolean arg0) {
			return null;
		}

		public MenuItem setIcon(Drawable arg0) {
			return null;
		}

		public MenuItem setIcon(int arg0) {
			return null;
		}

		public MenuItem setIntent(Intent arg0) {
			return null;
		}

		public MenuItem setNumericShortcut(char arg0) {
			return null;
		}

		public MenuItem setOnMenuItemClickListener(OnMenuItemClickListener arg0) {
			return null;
		}

		public MenuItem setShortcut(char arg0, char arg1) {
			return null;
		}

		public MenuItem setTitle(CharSequence arg0) {
			return null;
		}

		public MenuItem setTitle(int arg0) {
			return null;
		}

		public MenuItem setTitleCondensed(CharSequence arg0) {
			return null;
		}

		public MenuItem setVisible(boolean arg0) {
			return null;
		}

	}

}
