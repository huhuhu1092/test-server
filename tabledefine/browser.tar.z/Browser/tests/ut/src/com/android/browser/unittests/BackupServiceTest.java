package com.android.browser.unittests;

import com.android.browser.BackupService;
import com.android.browser.unittests.testutil.Helper;
import oms.android.backup.BaseBackupService;
import oms.android.backup.IBackupService;
import oms.android.backup.IBackupService.Stub;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Browser;
import android.test.ServiceTestCase;
import android.test.suitebuilder.annotation.LargeTest;

/**
 * this class is to test BackupService.
 * 
 * @author wsj
 * 
 */
public class BackupServiceTest extends ServiceTestCase<BackupService> {
	private BaseBackupService mBackupService;
	private ContentResolver mResolver;
	private IBackupService.Stub mBinder;
	private final String PATH = "///sdcard/UTFile";
	private final String PATH_ = "///sdcard/UTFile/";
	private final String FILE_BOOKMARK_CSV = "bookmark.csv";
	private final String FILE_CATEGORY_CSV = "category.csv";
	private final String FILE_SETTING_CSV = "setting.csv";

	public BackupServiceTest() {
		super(BackupService.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	@Override
	protected void tearDown() throws Exception {
		mBackupService = null;
		mResolver = null;
		super.tearDown();
	}

	// ***************************************************************Help
	// Method
	/**
	 * insert BookMarks
	 */
	private void insertBookMarks() throws Exception {
		ContentValues values = new ContentValues();
		values.put(Browser.BookmarkColumns.TITLE, "Google");
		values.put(Browser.BookmarkColumns.URL, "http://www.google.com/");
		values.put(Browser.BookmarkColumns.VISITS, 0);
		values.put(Browser.BookmarkColumns.DATE, 0);
		values.put(Browser.BookmarkColumns.CREATED, 0);
		values.put(Browser.BookmarkColumns.BOOKMARK, 1);
		values.put(Browser.BookmarkColumns.CATID, 1);
		getTestContext().getContentResolver().insert(Browser.BOOKMARKS_URI,
				values);
	}

	/**
	 * delete BookMarks
	 * 
	 * @throws Exception
	 */
	private void deleteBookMarks() throws Exception {
		try {
				mResolver.delete(Browser.BOOKMARKS_URI, null, null);
			} catch (Exception e) {
			e.printStackTrace();
		} 
	}

	/**
	 * get BackupService
	 * 
	 * @throws Exception
	 */
	private void getBackupService() throws Exception {
		startService(new Intent());
		mResolver = this.getTestContext().getContentResolver();
		insertBookMarks();
		mBackupService = getService();
		mBinder = (Stub) mBackupService.onBind(new Intent());
		assertNotNull(mBackupService);
	}
  /**
   * create Folder to SdCard
   * @throws Exception
   */
	private void createFolderToSdcard() throws Exception {
		Helper.createFolder(PATH);
	}
   /**
    * test File to SdCard
    * @throws Exception
    */
	private void createFileToSdcard() throws Exception {

		Helper.createFileToSdcard(this.getTestContext(), FILE_BOOKMARK_CSV,
				PATH);

		Helper.createFileToSdcard(this.getTestContext(), FILE_CATEGORY_CSV,
				PATH);

		Helper.createFileToSdcard(this.getTestContext(), FILE_SETTING_CSV,
				PATH);

	}

	// ****************************************************test Case
	/**
	 *  test backup while having File
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testbackup_HaveFile() throws Exception {
		createFolderToSdcard();
		getBackupService();
		Bundle extra = new Bundle();
		mBinder.backup(PATH_, extra);
		Thread.sleep(Helper.WAIT_FOR_LONGTIME);
		deleteBookMarks();
		Helper.deleteFileAndFolder(PATH_);
	}

	/**
	 * test backup for catching Exception
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testbackup_Exception() throws Exception {
		getBackupService();
		Bundle extra = new Bundle();
		mBinder.backup(PATH_, extra);
		Thread.sleep(Helper.WAIT_FOR_LONGTIME);
		deleteBookMarks();
	}

	/**
	 * test restore while having File
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testRestore_HaveFile() throws Exception {
		createFileToSdcard();
		getBackupService();
		Bundle extra = new Bundle();
		mBinder.restore(PATH_, extra);
		Thread.sleep(Helper.WAIT_FOR_LONGTIME);
		deleteBookMarks();
		Helper.deleteFileAndFolder(PATH_);
	}
	/**
	 * test restore
	 */
	@LargeTest
	public void testRestore_Exception() throws Exception {
		getBackupService();
		Bundle extra = new Bundle();
		mBinder.restore(PATH_, extra);
		deleteBookMarks();
	}

}
