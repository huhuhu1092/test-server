package com.android.browser.unittests;

import junit.framework.TestSuite;
import oms.test.SuppressInstRunner;

import com.android.browser.BrowserActivityUIITest;
import com.android.browser.BrowserActivityUITest;
import com.android.browser.BrowserDownloadAdapterTest;
import com.android.browser.BrowserSettingTest;
import com.android.browser.BrowserYesNoPreferenceTest;
import com.android.browser.FakeWebViewTest;
import com.android.browser.FindDialogTest;
import com.android.browser.OMaDownloadManagerTest;
import com.android.browser.cmcc.CMCCBookmarkExpandableListAdapterTest;
import com.android.browser.unittests.cmcc.CMCCAddBookmarkPageTest;


public class SuppressedClassInstrumentationTestRunner extends
		SuppressInstRunner {

	public SuppressedClassInstrumentationTestRunner() {
		super(true);
	}

	/**
	 * Override this to define all of the tests to run in your package.
	 */
	public TestSuite getAllTests() {
		TestSuite suite = new TestSuite();
		suite.addTestSuite(BrowserYesNoPreferenceTest.class);
		suite.addTestSuite(BrowserSettingTest.class);   
		suite.addTestSuite(BrowserActivityUIITest.class);
		suite.addTestSuite(BrowserActivityUITest.class);
		suite.addTestSuite(com.android.browser.BrowserActivityUTTest.class);
		suite.addTestSuite(OMaDownloadManagerTest.class);
		suite.addTestSuite(FindDialogTest.class);
		suite.addTestSuite(CMCCAddBookmarkPageTest.class);
		suite.addTestSuite(FakeWebViewTest.class);
		suite.addTestSuite(CMCCBookmarkExpandableListAdapterTest.class);
		suite.addTestSuite(BrowserDownloadAdapterTest.class);
		suite.addTestSuite(BrowserReceiverTest.class);
		
		return suite;
	}
}
