package com.android.browser.cmcc;


import com.android.browser.unittests.testutil.Helper;

import android.app.ExpandableListActivity;
import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Browser;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

/**
 * Test class of CMCCBookmarkExpandableListAdapter
 * @author I087(Cao Lina)
 *
 */
@Suppress
public class CMCCBookmarkExpandableListAdapterTest extends ActivityUnitTestCase<ExpandableListActivity> {
    
	//private Context mContext;
    private Instrumentation mInst;
//    private  Cursor c;
    private ContentResolver mContentResolver;
    private static CMCCBrowserBookmarksPage mCMCCBrowserBookmarksPage;
    private static CMCCBookmarkExpandableListAdapter mCMCCBookmarkExpandableListAdapter;
    
    //b392 5.20
    private static int count = 0;
	private static boolean flag = true;
	private static boolean isDestroyed = false;
    
	public CMCCBookmarkExpandableListAdapterTest() {
		super(ExpandableListActivity.class);
		count ++;
	}

	protected void setUp() throws Exception {
		super.setUp();
		mInst=this.getInstrumentation();
		//mContext=mInst.getTargetContext();
		mContentResolver=mInst.getTargetContext().getContentResolver();
		//b392 5.20
//		if(mCMCCBrowserBookmarksPage == null ) {
//			mCMCCBrowserBookmarksPage =launchActvitiy();
//			SystemClock.sleep(1000);
//		}
		if(flag){
			mCMCCBrowserBookmarksPage =launchActvitiy();
			flag = false;
		}
		//end
		insertDatas();
		mCMCCBookmarkExpandableListAdapter = new CMCCBookmarkExpandableListAdapter(mCMCCBrowserBookmarksPage,"1",false,mCMCCBrowserBookmarksPage);
		SystemClock.sleep(1000);
	}

	protected void tearDown() throws Exception {
		//b392 5.20
//		if (mCMCCBrowserBookmarksPage!=null){
//			mCMCCBrowserBookmarksPage.finish();
//			mCMCCBrowserBookmarksPage = null;
//		}
//		deleteDataInBookMarks();
//		deleteDataInCategory();
//		mCMCCBookmarkExpandableListAdapter=null;
		deleteDataInBookMarks();
		deleteDataInCategory();
		if(--count == 0){
			if (mCMCCBrowserBookmarksPage!=null){
				mCMCCBrowserBookmarksPage.finish();
				SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
				mCMCCBrowserBookmarksPage = null;
			}
			InsertDataInCategory("My favorites");
		}
		//end
		if(!isDestroyed){
			mCMCCBookmarkExpandableListAdapter.onDestroy();
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		}else{
			isDestroyed = false;
		}
		mCMCCBookmarkExpandableListAdapter=null;
		//mContext=null;
		mInst=null;
		super.tearDown();
	}
   /**
    * test CMCCBookmarkExpandableListAdapter's Constructor
    * @throws Exception
    */
	@LargeTest
	public void testConstructor() throws Exception{
		assertNotNull(mCMCCBookmarkExpandableListAdapter);
		SystemClock.sleep(1000);
	}
	/**
	 * test method of onDestroy()
	 * @throws Exception
	 */
	@LargeTest
	public void testonDestroy() throws Exception{
		mCMCCBookmarkExpandableListAdapter.onDestroy();
		SystemClock.sleep(1000);
		isDestroyed = true;
	}
	/**
	 * test method of getChildView()
	 * @throws Exception
	 */
	@LargeTest
	public void testgetChildView() throws Exception{
		int groupPosition=0;
		int childPosition=1;
		boolean isLastChild=true; 
		View convertView=new View(mInst.getTargetContext());
		ViewGroup parent=new WebView(mInst.getTargetContext());
		assertNotNull(mCMCCBookmarkExpandableListAdapter.getChildView(groupPosition, childPosition, isLastChild, convertView, parent));
		SystemClock.sleep(1000);
	}
	/**
	 * test method of getChildId()
	 * @throws Exception
	 */
	@LargeTest
	public void testgetChildId() throws Exception{
	 assertEquals(2, mCMCCBookmarkExpandableListAdapter.getChildId(1, 2));
	 SystemClock.sleep(1000);
	}
	/**
	 * test method of hasStableIds()
	 * @throws Exception
	 */
	@LargeTest
	public void testhasStableIds() throws Exception{
		assertTrue(mCMCCBookmarkExpandableListAdapter.hasStableIds());
		SystemClock.sleep(1000);
	}
	/**
	 * test method of isChildSelectable()
	 * @throws Exception
	 */
	@LargeTest
	public void testisChildSelectable() throws Exception{
		boolean t=mCMCCBookmarkExpandableListAdapter.isChildSelectable(1, 2);
		assertTrue(t);
		SystemClock.sleep(1000);
	}

	/**
	 * test method of getChildrenCount()
	 */
	@LargeTest
	public void testgetChildrenCount() throws Exception{
		assertNotNull(mCMCCBookmarkExpandableListAdapter.getChildrenCount(0));
		SystemClock.sleep(1000);
	}
	/**
	 * test method of getCategoryCount()
	 */
	@LargeTest
	public void testgetCategoryCount() throws Exception{
	    int b= mCMCCBookmarkExpandableListAdapter.getCategoryCount();
	    assertNotNull(b);
	}
	/**
	 * test method of onGroupExpanded()
	 * @throws Exception
	 */
//	@LargeTest
//	public void testAonGroupExpanded() throws Exception{
//		mCMCCBookmarkExpandableListAdapter.onGroupExpanded(1);
//		int i=mCMCCBookmarkExpandableListAdapter.getExpandedGroupPosition();
//		assertEquals(1,i);
//		SystemClock.sleep(1000);
//	}
	/**
	 * test method of onGroupCollapsed()
	 * @throws Exception
	 */
	@LargeTest
	public void testonGroupCollapsed() throws Exception{
      mCMCCBookmarkExpandableListAdapter.onGroupCollapsed(-1);
      assertEquals(-1, mCMCCBookmarkExpandableListAdapter.getExpandedGroupPosition());
      SystemClock.sleep(1000);
	}
	/**
	 * test method of getRow()
	 * @throws Exception
	 */
	@LargeTest
	public void testgetRow() throws Exception{
	 assertNotNull(mCMCCBookmarkExpandableListAdapter.getRow(0, 1));
	 SystemClock.sleep(1000);
	}
	/**
	 * test method of getCategoryRow()
	 * @throws Exception
	 */
	@LargeTest
	public void testgetCategoryRow() throws Exception{
	   assertNotNull(mCMCCBookmarkExpandableListAdapter.getCategoryRow(0, 1));
	   SystemClock.sleep(1000);
	}
	/**
	 * test method of getCategoryCursor()
	 * @throws Exception
	 */
	@LargeTest
	public void testgetCategoryCursor() throws Exception{
	   assertNotNull(mCMCCBookmarkExpandableListAdapter.getCategoryCursor());
	   SystemClock.sleep(1000);
	}
	/**
	 * test method of getRow()
	 */
	
	@LargeTest
	public void testupdateRow() throws Exception{
	   Bundle map=mCMCCBookmarkExpandableListAdapter.getRow(0, 1);
		mCMCCBookmarkExpandableListAdapter.updateRow(map);
		SystemClock.sleep(1000);
	}
	/**
	 * test method of deleteRow()
	 * @throws Exception
	 */
	@LargeTest
	public void testdeleteRow() throws Exception{
		mCMCCBookmarkExpandableListAdapter.deleteRow(0, 1);
		SystemClock.sleep(1000);
	}
	/**
	 * test method of deleteAll()
	 * @throws Exception
	 */
	@LargeTest
	public void testdeleteAll() throws Exception{
		mCMCCBookmarkExpandableListAdapter.deleteAll();
		SystemClock.sleep(1000);
	}
	/**
	 * test method of deleteBookmarks()
	 * @throws Exception
	 */
	@LargeTest
	public void testdeleteBookmarks() throws Exception{
		mCMCCBookmarkExpandableListAdapter.deleteBookmarks();
		SystemClock.sleep(1000);
	}
	/**
	 * test method of getCheckedItemCount()
	 * @throws Exception
	 */
	@LargeTest
	public void testgetCheckedItemCount() throws Exception{
		assertNotNull(mCMCCBookmarkExpandableListAdapter.getCheckedItemCount());
		SystemClock.sleep(1000);
	}
	/**
	 * test method of sortAlphabetical()
	 * @throws Exception
	 */
	@LargeTest
	public void testsortAlphabetical() throws Exception{
		mCMCCBookmarkExpandableListAdapter.sortAlphabetical();
		SystemClock.sleep(1000);
	}
	/**
	 * test method of clearCheckedList()
	 * @throws Exception
	 */
	@LargeTest
	public void testclearCheckedList() throws Exception{
		mCMCCBookmarkExpandableListAdapter.clearCheckedList();
		SystemClock.sleep(1000);
	}
	/**
	 * test method of selectAll()
	 * @throws Exception
	 */
	@LargeTest
	public void testselectAll() throws Exception{
		//b392 5.20
		mInst.runOnMainSync(new Runnable(){
			public void run(){
				mCMCCBookmarkExpandableListAdapter.onGroupExpanded(5);
			}
		});
//		mCMCCBookmarkExpandableListAdapter.onGroupExpanded(5);
		//end
		mCMCCBookmarkExpandableListAdapter.selectAll();
		SystemClock.sleep(1000);
	}
	/**
	 * test method of cancelSelectAll
	 * @throws Exception
	 */
	@LargeTest
	public void testcancelSelectAll() throws Exception{
		//b392 5.20
		mInst.runOnMainSync(new Runnable(){
			public void run(){
				mCMCCBookmarkExpandableListAdapter.onGroupExpanded(10);
			}
		});
//		mCMCCBookmarkExpandableListAdapter.onGroupExpanded(10);
		//end
		mCMCCBookmarkExpandableListAdapter.cancelSelectAll();
		SystemClock.sleep(1000);
	}
	/**
	 * test method of toggleBookmark()with two parameter
	 * @throws Exception
	 */
	@LargeTest
	public void testtoggleBookmarkWithTwoParameter() throws Exception{
		mCMCCBookmarkExpandableListAdapter.toggleBookmark("3", true);
		SystemClock.sleep(1000);
	}
	/**
	 * test method of toggleBookmark with three parameter
	 * @throws Exception
	 */
	@LargeTest
	public void testtoggleBookmarkWithThreeParameter() throws Exception{
		mCMCCBookmarkExpandableListAdapter.toggleBookmark(-1,1, true);
		SystemClock.sleep(1000);
	}
	/**
	 * test method of search()
	 * @throws Exception
	 */
	@LargeTest
	public void testsearch() throws Exception{
		mCMCCBookmarkExpandableListAdapter.search("test likes null");
		SystemClock.sleep(1000);
	}
	/**
	 * test method of updateBookmarkFavicon()
	 * @throws Exception
	 */
	@LargeTest
	public void testupdateBookmarkFavicon() throws Exception{
		Bitmap favicon=Bitmap.screenshot();
		CMCCBookmarkExpandableListAdapter.updateBookmarkFavicon(mContentResolver,"http://local.8080", favicon);
		SystemClock.sleep(1000);
	}
	/**
	 * test method of getUrl()
	 * @throws Exception
	 */
	@LargeTest
	public void testgetUrl() throws Exception{
		assertNotNull(mCMCCBookmarkExpandableListAdapter.getUrl(0, 1));
		SystemClock.sleep(1000);
	}
	/**
	 * test method of getTitle()
	 * @throws Exception
	 */
	@LargeTest
	public void testgetTitle() throws Exception{
		assertNotNull(mCMCCBookmarkExpandableListAdapter.getTitle(0, 1));
		SystemClock.sleep(1000);
	}

	//help method
	private Uri InsertDataInCategory(String name){
		ContentValues values = new ContentValues();
		values.put(Browser.CategoryColumns.NAME, name);
		Uri uri = mContentResolver.insert(Browser.CATEGORY_URI, values);
		return uri;
	}
    //help method 
	private Uri InsertDataInBookMarks(String title,String url,String bookmark,String visits,String favicon,String catid){
		ContentValues values = new ContentValues();
		values.put(Browser.BookmarkColumns.TITLE, title);
		values.put(Browser.BookmarkColumns.URL,url);
		values.put(Browser.BookmarkColumns.BOOKMARK, bookmark);
		values.put(Browser.BookmarkColumns.VISITS,visits);
		values.put(Browser.BookmarkColumns.FAVICON,favicon);
		values.put(Browser.BookmarkColumns.CATID,catid);
		Uri uri1 = mContentResolver.insert(Browser.BOOKMARKS_URI, values);
		return uri1;
	}
	//delete Data InBookMarks
	private void deleteDataInBookMarks() {
		int i = 0;
	    Cursor c = mContentResolver.query(Browser.CATEGORY_URI, null, null, null,null);
		try {
			if (c.getCount() > 0) {
				for (i = 0; i < c.getCount(); i++) {
					c.moveToNext();
					mContentResolver.delete(ContentUris.withAppendedId(
													Browser.CATEGORY_URI, c.getInt(c.getColumnIndexOrThrow(Browser.CategoryColumns._ID))),
									null, null);
				}
			}
		} finally {
			c.close();
		}
	}
	//delete Data In Category
	private void deleteDataInCategory() {
		int i = 0;
		Cursor c = mContentResolver.query(Browser.BOOKMARKS_URI, null, null,
				null, null);
		try {
			if (c.getCount() > 0) {
				for (i = 0; i < c.getCount(); i++) {
					c.moveToNext();
					mContentResolver.delete(ContentUris.withAppendedId(
													Browser.BOOKMARKS_URI, c.getInt(c.getColumnIndexOrThrow(Browser.BookmarkColumns._ID))),
									null, null);
				}
			}
		} finally {
			c.close();
		}
	}
	
	private void insertDatas() {
		Uri category = InsertDataInCategory("one");
		Cursor c = mContentResolver.query(category, null, null, null, null);
		c.moveToNext();
		
		InsertDataInBookMarks("test","http://local.8080","1","1","test",c.getString(0));
		InsertDataInBookMarks("test","http://local.8080","1","1","test",c.getString(0));
		InsertDataInBookMarks("test","http://local.8080","1","1","test",c.getString(0));
	}
	
//	private void closeCursor() {
//		if (c != null) {
//			c.close();
//			c = null;
//		}
//	}

    //launch CMCCBrowserBookmarksPage Activity
    private CMCCBrowserBookmarksPage launchActvitiy(){
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setClassName(mInst.getTargetContext(), CMCCBrowserBookmarksPage.class.getName());
        CMCCBrowserBookmarksPage cmccBrowserBookmarksPage = (CMCCBrowserBookmarksPage) mInst.startActivitySync(intent);
        SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
        return cmccBrowserBookmarksPage;
    }
}
