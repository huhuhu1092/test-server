package com.android.browser.midlet;
import android.app.Instrumentation;
import android.content.Context;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.KeyEvent;
import android.view.View;
import com.android.browser.midlet.MidletDownloadManager;
import com.android.browser.midlet.MidletInstall;
import com.android.browser.unittests.testutil.Helper;
/**the class is used to test MidletInstall.
 * @author b364-Pang Hongwei*/
public class MidletInstallTest extends ActivityUnitTestCase<MidletDownloadManager> {

	public MidletInstallTest() {
		super(MidletDownloadManager.class);
	}
	private Instrumentation mInst;
	private Context mContext;
	private static String NO_FILE_EXIT="/sdcard/Browser/test.jpg";
	private static String A_FOLDER_IN_SDCARD="/sdcard/BrowserUT";
	private static String A_FILE_IN_SDCARD=A_FOLDER_IN_SDCARD+"/"+"test.txt";
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst =getInstrumentation();
		mContext = mInst.getTargetContext();
	}
	@Override
	protected void tearDown() throws Exception {
		Helper.deleteFileAndFolder(A_FOLDER_IN_SDCARD);
		if(	mContext!=null){
			mContext=null;
		}
		if(mInst!=null){
			mInst=null;
		}
		super.tearDown();
	}
	/**test setDisplayinfo().
	 * @throws Exception
	 * */
	@LargeTest
	public void testT001SetDisplayinfo()throws Exception{
		MidletInstall install =new MidletInstall(mContext,new Action(),new Cancle(),NO_FILE_EXIT);
		assertNull(install.mMidletStruct);
		assertNull(install.setDisplayinfo(install.mMidletStruct, true));
		assertNull(install.getNotifyUri());
	}
	/**test what about JadFile
	 * @throws Excetion
	 * */
	@LargeTest
	public void testT002JadFile()throws Exception{
		Helper.createFileToSdcard(mInst.getContext(), "test.txt", A_FOLDER_IN_SDCARD);
		Helper.createFileToSdcard(mInst.getContext(), "test.properties", A_FOLDER_IN_SDCARD);
		MidletInstall install =new MidletInstall(mContext,new Action(),new Cancle(),A_FILE_IN_SDCARD);
		//test setting and getting jad file.
		assertEquals("/sdcard/BrowserUT/test.txt",install.getJadFile());
		install.setJadFile("/sdcard/BrowserUT/test.properties");
		assertEquals("/sdcard/BrowserUT/test.properties",install.getJadFile());
		//in file test.properties ,value of notify uri is "notify".
		assertEquals("notify",install.getNotifyUri());
	}
	/**test dispatchKeyEvent().
	 * @throws Exception.
	 * */
	@LargeTest
	public void testdispatchKeyEvent01()throws Exception{
		Helper.createFileToSdcard(mInst.getContext(), "test.txt", A_FOLDER_IN_SDCARD);
		MidletInstall install =new MidletInstall(mContext,new Action(),new Cancle(),A_FILE_IN_SDCARD);
		//KEYCODE_BACK Down.
		KeyEvent KeyBackDown =new KeyEvent(10,10,KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_BACK,0);
		install.dispatchKeyEvent(KeyBackDown);
		//other Key down
		KeyEvent notKeyBackDown =new KeyEvent(10,10,KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_DPAD_CENTER,0);
		install.dispatchKeyEvent(notKeyBackDown);
		//other Key event .
		KeyEvent KeyBackNotDown =new KeyEvent(10,10,KeyEvent.ACTION_UP,KeyEvent.KEYCODE_DPAD_CENTER,0);
		install.dispatchKeyEvent(KeyBackNotDown);
	}
	/**mock a onClickListener for mActionButton in MidletInstall.
	 * */
    private class Action implements View.OnClickListener{

		public void onClick(View arg0) {
		}
    	
    }
    /**mock a onClickListener for mCancleButton in MidletInstall.
	 * */
    private class Cancle implements View.OnClickListener{

		public void onClick(View arg0) {
		}
    	
    }
    
}
