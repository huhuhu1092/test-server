package com.android.browser.unittests;

import java.util.Date;

import junit.framework.Assert;
import android.app.SearchManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ProviderInfo;
import android.database.AbstractCursor;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Browser;
import android.test.ProviderTestCase2;
import android.test.suitebuilder.annotation.MediumTest;
import android.util.Log;
import com.android.browser.R;

import com.android.browser.BrowserProvider;

/**
 * the class is used to test BrowserProvider.
 * 
 * @author b364-Pang Hongwei
 * */
public class BrowserProviderTest extends ProviderTestCase2<BrowserProvider> {
	private static final int SUGGEST_COLUMN_INTENT_ACTION_ID = 1;
	private static final int SUGGEST_COLUMN_INTENT_DATA_ID = 2;
	private static final int SUGGEST_COLUMN_TEXT_1_ID = 3;
	private static final int SUGGEST_COLUMN_TEXT_2_ID = 4;
	private static final int SUGGEST_COLUMN_ICON_1_ID = 5;
	private static final int SUGGEST_COLUMN_ICON_2_ID = 6;
	private static final int SUGGEST_COLUMN_QUERY_ID = 7;

	private static final int FIRST_INDEX = 0;
	private static final String log="BrowserProviderTest";
	private static final Uri SUGGEST_URI = Uri.parse("content://browser/"
			+ SearchManager.SUGGEST_URI_PATH_QUERY);
	private static final Uri UNKOWN_URI = Browser.INLINE_URI;

	public BrowserProviderTest() {
		super(BrowserProvider.class, "browser");
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * test the contstuctor of BrowserProvider.
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT001Constructor() throws Exception {
		assertNotNull(new BrowserProvider());
	}

	/**
	 * test resetBrowserTables().
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT002ResetBrowserTables() throws Exception {
		BrowserProvider.resetBrowserTables(getMockContext());
	}

	/**
	 * test Querying with an useless uri.
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT003Query() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),new ProviderInfo());
		Uri useLessUri = Uri.parse("");
		Cursor cursor = null;
		try {
			cursor = provider.query(useLessUri, null, null, null, null);
		} catch (IllegalArgumentException exception) {
			assertEquals(exception.getMessage(), new IllegalArgumentException(
					"Unknown URL").getMessage());
			Log.i(log,"testT002Query:catch the expected  exception successfully!");
			assertTrue(closeCursor(cursor));
			return;
		}
		assertTrue(closeCursor(cursor));
		Assert.fail("catch the expected exception unsuccessfully!");
	}

	/**
	 * test quering with BookMarks_URI.
	 * 
	 * @throws Exception.
	 * */
	@MediumTest
	public void testT004Query() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),new ProviderInfo());
		Cursor cursor = null;
		try {
			cursor = provider.query(Browser.BOOKMARKS_URI, new String[] {
					Browser.BookmarkColumns.TITLE,
					Browser.BookmarkColumns.BOOKMARK }, null, null, null);
			assertTrue(closeCursor(cursor));
		} catch (Exception exception) {
			Assert.fail("BrowserProviderTest--testT003Query:query bookmarks.db  unsuccessfully!");
		}
	}

	/**
	 * test inserting to BookMarks.
	 * 
	 * @throws Exception.
	 * */
	@MediumTest
	public void testT005InsertBookMarks() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),new ProviderInfo());
		ContentValues value = new ContentValues();
		value.put(Browser.BookmarkColumns.CREATED, new Date().getTime());
		value.put(Browser.BookmarkColumns.TITLE, "New Page");
		value.put(Browser.BookmarkColumns.BOOKMARK, 1);
		value.put(Browser.BookmarkColumns.URL, "http://www.youku.com/");
		value.put(Browser.BookmarkColumns.DATE, 0);
		value.put(Browser.BookmarkColumns.VISITS, 0);
		assertNotNull(provider.insert(Browser.BOOKMARKS_URI, value));
	}

	/**
	 * test inserting to BookMarks.
	 * 
	 * @throws Exception.
	 * */
	@MediumTest
	public void testT006InsertCategory() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),new ProviderInfo());
		ContentValues value = new ContentValues();
		value.put(Browser.CategoryColumns.NAME, "name");
		assertNotNull(provider.insert(Browser.CATEGORY_URI, value));
	}

	/**
	 * test inserting to Search.
	 * 
	 * @throws Exception.
	 * */
	@MediumTest
	public void testT007InsertSearches() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),new ProviderInfo());
		ContentValues value = new ContentValues();
		value.put(Browser.SearchColumns.SEARCH, "search");
		value.put(Browser.SearchColumns.DATE, "2010-05-07");
		assertNotNull(provider.insert(Browser.SEARCHES_URI, value));
	}

	/**
	 * test inserting to Property.
	 * 
	 * @throws Exception.
	 * */
	@MediumTest
	public void testT008InsertProperty() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),new ProviderInfo());
		ContentValues value = new ContentValues();
		value.put(Browser.PropertyColumns.NAME, "property-name");
		value.put(Browser.PropertyColumns.VALUE, "value");
		assertNotNull(provider.insert(Browser.PROPERTY_URI, value));
	}

	/**
	 * test inserting with an unkown uri.
	 * 
	 * @throws Exception.
	 * */
	@MediumTest
	public void testT009InsertWithUnKownUrl01() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),new ProviderInfo());
		ContentValues value = new ContentValues();
		try {
			// give an incorrect uri,insert() will throw an IllegalArgumentException.
			provider.insert(UNKOWN_URI, value);
		} catch (IllegalArgumentException e) {
			Log.i(log,"testT006InsertWithUnKownUrl:catch expected exception successfully!");
			return;
		}
		Assert.fail("testT009InsertWithUnKownUrl01:catch expected exception unsuccessfully!");
	}

	/**
	 * test inserting with an unkown uri.
	 * */
	@MediumTest
	public void testT010InsertWithUnKownUrl02() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		// put a wrong value.insert() will throw an IllegalArgumentException.
		ContentValues value = new ContentValues();
		value.put("_id", 1);
		try {
			provider.insert(Browser.BOOKMARKS_URI, value);
		} catch (IllegalArgumentException e) {
			Log.i(log,"testT006InsertWithUnKownUrl:catch expected exception successfully!");
			return;
		}
		Assert.fail("testT010InsertWithUnKownUrl02:catch expected exception unsuccessfully!");
	}

	/**
	 * test querying with SUGGEST_URI.
	 * 
	 * @throws Exception.
	 * */
	@MediumTest
	public void testT011Query() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		Cursor cursor = null;
		// selectionArgs[0] is ""
		cursor = provider.query(SUGGEST_URI, null, null, new String[] { "" },
				null);
		assertTrue(closeCursor(cursor));
		// selectionArgs[0] starts with "http".
		cursor = provider.query(SUGGEST_URI, null, "url LIKE ?",
				new String[] { "http://" }, null);
		assertTrue(closeCursor(cursor));
		// selectionArgs[0] not null and not start with "http".
		cursor = provider.query(SUGGEST_URI, null, null,
				new String[] { "www." }, null);
		assertTrue(closeCursor(cursor));
		// match == URI_MATCH_BOOKMARKS_ID
		Uri uri = Uri.withAppendedPath(Browser.BOOKMARKS_URI, "1");
		cursor = provider.query(uri, null, "title !='Google'", null, null);
		assertTrue(closeCursor(cursor));
	}

	/**
	 * test getType().
	 * 
	 * @throws Exception.
	 * */
	@MediumTest
	public void testT012GetType() throws Exception {
		BrowserProvider provider = new BrowserProvider();
		// match ==URI_MATCH_BOOKMARKS.
		assertEquals("vnd.android.cursor.dir/bookmark", provider
				.getType(Browser.BOOKMARKS_URI));
		// match==URI_MATCH_BOOKMARKS_ID.
		Uri bookMarkWithID = Uri.withAppendedPath(Browser.BOOKMARKS_URI, "1");
		assertEquals("vnd.android.cursor.item/bookmark", provider
				.getType(bookMarkWithID));
		// match=URI_MATCH_SEARCHES.
		assertEquals("vnd.android.cursor.dir/searches", provider
				.getType(Browser.SEARCHES_URI));
		// match=URI_MATCH_SEARCHES_ID.
		Uri searchesWithID = Uri.withAppendedPath(Browser.SEARCHES_URI, "1");
		assertEquals("vnd.android.cursor.item/searches", provider
				.getType(searchesWithID));
		// match=URI_MATCH_SUGGEST
		Uri suggest = Uri.parse("content://browser/"
				+ SearchManager.SUGGEST_URI_PATH_QUERY);
		assertEquals(SearchManager.SUGGEST_MIME_TYPE, provider.getType(suggest));
		// throw IllegalArgumentException.
		try {
			provider.getType(UNKOWN_URI);
		} catch (IllegalArgumentException e) {
			Log.i(log,"testT012GetType:catch expected exception successfully!");
			return;
		}
		Assert.fail("testT012GetType:catch expected exception unsuccessfully!");
	}

	/**
	 * test delete().
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT013Delete() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		Uri bookMarksWithID = Uri.withAppendedPath(Browser.BOOKMARKS_URI, "1");
		int count = provider.delete(bookMarksWithID, "title = ?",
				new String[] { "Google" });
		assertEquals(1, count);
		try {
			provider.delete(UNKOWN_URI, null, null);
		} catch (IllegalArgumentException e) {
			Log.i(log,"testT013Delete:catch expected exception successfully!");
			return;
		}
		Assert.fail("testT013Delete:catch expected exception unsuccessfully!");
	}

	/**
	 * test update().
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT014Update() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		Uri bookMarksWithID = Uri.withAppendedPath(Browser.BOOKMARKS_URI, "1");
		ContentValues value = new ContentValues();
		value.put(Browser.BookmarkColumns.TITLE, "goole");
		int count = provider.update(bookMarksWithID, value, "title = ?",
				new String[] { "Google" });
		assertEquals(1, count);
		try {
			provider.update(Browser.INLINE_URI, null, null, null);
		} catch (IllegalArgumentException e) {
			Log.i(log,"testT014Update:catch expected exception successfully!");
			return;
		}
		Assert.fail("testT014Update:catch expected exception unsuccessfully!");
	}

	/**
	 * test getString()
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT015QueryCursor_getString() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		AbstractCursor cursor = getAbstractCursorFromBrowserProvider(provider,
				SUGGEST_URI);
		cursor.moveToFirst();
		assertEquals(7, cursor.getCount());
		assertEquals(8, cursor.getColumnNames().length);
		// test getString().mHistoryCount>mPost at first time
		assertEquals(Intent.ACTION_VIEW, cursor
				.getString(SUGGEST_COLUMN_INTENT_ACTION_ID));
		assertEquals("http://www.google.com", cursor
				.getString(SUGGEST_COLUMN_INTENT_DATA_ID));
		assertEquals("http://www.google.com", cursor
				.getString(SUGGEST_COLUMN_TEXT_1_ID));
		assertEquals("Google", cursor.getString(SUGGEST_COLUMN_TEXT_2_ID));
		assertEquals(new Integer(R.drawable.ic_search_category_bookmark)
				.toString(), cursor.getString(SUGGEST_COLUMN_ICON_1_ID));
		assertEquals(new String("0"), cursor
				.getString(SUGGEST_COLUMN_ICON_2_ID));
		assertNull(cursor.getString(SUGGEST_COLUMN_QUERY_ID));
		// It causes that mHistoryCount is less than mPost.
		cursor.moveToLast();
		assertEquals(Intent.ACTION_SEARCH, cursor
				.getString(SUGGEST_COLUMN_INTENT_ACTION_ID));
		assertNull(cursor.getString(SUGGEST_COLUMN_INTENT_DATA_ID));
		assertEquals("http://", cursor.getString(SUGGEST_COLUMN_TEXT_1_ID));
		assertEquals(getContext().getString(R.string.search_google), cursor
				.getString(SUGGEST_COLUMN_TEXT_2_ID));
		assertEquals(new Integer(R.drawable.ic_search_category_suggest)
				.toString(), cursor.getString(SUGGEST_COLUMN_ICON_1_ID));
		assertEquals(new String("0"), cursor
				.getString(SUGGEST_COLUMN_ICON_2_ID));
		assertEquals("http://", cursor.getString(SUGGEST_COLUMN_QUERY_ID));
		cursor.moveToPosition(-1);
		assertNull(cursor.getString(0));
		assertTrue(closeCursor(cursor));
	}

	/**
	 * test getDouble()
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT016Query_getDouble() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		AbstractCursor cursor = getAbstractCursorFromBrowserProvider(provider,
				SUGGEST_URI);
		try {
			cursor.getDouble(FIRST_INDEX);
		} catch (UnsupportedOperationException e) {
			Log.i(log,"testT016Query_getDouble:catch expected exception successfully!");
			assertTrue(closeCursor(cursor));
			return;
		}
		assertTrue(closeCursor(cursor));
		Assert
				.fail("testT016Query_getDouble:catch expected exception unsuccessfully!");
	}

	/**
	 * test getFloat()
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT017Query_getFloat() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		AbstractCursor cursor = getAbstractCursorFromBrowserProvider(provider,
				SUGGEST_URI);
		try {
			cursor.getFloat(FIRST_INDEX);
		} catch (UnsupportedOperationException e) {
			Log.i(log,"testT016Query_getDouble:catch expected exception successfully!");
			assertTrue(closeCursor(cursor));
			return;
		}
		assertTrue(closeCursor(cursor));
		Assert
				.fail("testT016Query_getDouble:catch expected exception unsuccessfully!");
	}

	/**
	 * test getInt()
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT018Query_getInt() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		AbstractCursor cursor = getAbstractCursorFromBrowserProvider(provider,
				SUGGEST_URI);
		try {
			cursor.getInt(FIRST_INDEX);
		} catch (UnsupportedOperationException e) {
			Log.i(log,"testT016Query_getDouble:catch expected exception successfully!");
			assertTrue(closeCursor(cursor));
			return;
		}
		assertTrue(closeCursor(cursor));
		Assert.fail("testT016Query_getDouble:catch expected exception unsuccessfully!");
	}

	/**
	 * test getShort()
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT019Query_getShort() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		AbstractCursor cursor = getAbstractCursorFromBrowserProvider(provider,
				SUGGEST_URI);
		try {
			cursor.getShort(FIRST_INDEX);
		} catch (UnsupportedOperationException e) {
			Log.i(log,"testT016Query_getDouble:catch expected exception successfully!");
			assertTrue(closeCursor(cursor));
			return;
		}
		assertTrue(closeCursor(cursor));
		Assert.fail("testT016Query_getDouble:catch expected exception unsuccessfully!");
	}

	/**
	 * test isNull()
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT019Query_isNull() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		AbstractCursor cursor = getAbstractCursorFromBrowserProvider(provider,
				SUGGEST_URI);
		try {
			cursor.isNull(FIRST_INDEX);
		} catch (UnsupportedOperationException e) {
			Log.i(log,"testT016Query_getDouble:catch expected exception successfully!");
			assertTrue(closeCursor(cursor));
			return;
		}
		assertTrue(closeCursor(cursor));
		Assert.fail("testT016Query_getDouble:catch expected exception unsuccessfully!");
	}

	/**
	 * test getLong()
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT020Query_getLong() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		AbstractCursor cursor = getAbstractCursorFromBrowserProvider(provider,
				SUGGEST_URI);
		// mPos!=-1 and colum=0.
		cursor.moveToFirst();
		assertEquals(0, cursor.getLong(FIRST_INDEX));
		// mPos==-1
		cursor.moveToPosition(-1);
		try {
			cursor.getLong(FIRST_INDEX);
		} catch (UnsupportedOperationException e) {
			Log.i(log,"testT016Query_getDouble:catch expected exception successfully!");
			assertTrue(closeCursor(cursor));
			return;
		}
		assertTrue(closeCursor(cursor));
		Assert.fail("testT016Query_getDouble:catch expected exception unsuccessfully!");
	}

	/**
	 * test requery()
	 * 
	 * @throws Exception
	 * */
	@MediumTest
	public void testT020Requery() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		AbstractCursor cursor = getAbstractCursorFromBrowserProvider(provider,
				SUGGEST_URI);
		assertTrue(cursor.requery());
		assertTrue(closeCursor(cursor));
	}

	/**
	 * test deactive().
	 * 
	 * @throws Exception.
	 * */
	@MediumTest
	public void testT021Deactive() throws Exception {
		BrowserProvider provider = getBrowserProvider(getMockContext(),
				new ProviderInfo());
		AbstractCursor cursor = getAbstractCursorFromBrowserProvider(provider,
				SUGGEST_URI);
		cursor.deactivate();
		closeCursor(cursor);
	}

	/**
	 * get a BrowserProvider object.
	 * 
	 * @param context
	 *            in which the BrowserProvider object is.
	 * @param info
	 *            a ProviderInfo.
	 * */
	private BrowserProvider getBrowserProvider(Context context,
			ProviderInfo info) {
		BrowserProvider provider = new BrowserProvider();
		provider.attachInfo(context, info);
		assertNotNull(provider.getContext());
		return provider;
	}

	/**
	 * return a abstractCursor object form a {@link provider}.
	 * 
	 * @param provider
	 *            a BrowserProvider object.
	 * @param uri
	 *            used to query.
	 * */
	private AbstractCursor getAbstractCursorFromBrowserProvider(
			BrowserProvider provider, Uri uri) {
		if (provider == null || uri == null) {
			return null;
		}
		AbstractCursor cursor = (AbstractCursor) provider.query(uri, null,
				"url LIKE ?", new String[] { "http://" }, null);
		assertNotNull(cursor);
		return cursor;
	}

	/**
	 * close cursor
	 * 
	 * @param cursor
	 *            a cursor which will be closed.
	 * */
	private boolean closeCursor(Cursor cursor) {
		if (cursor == null) {
			return true;
		}
		try {
			cursor.close();
			cursor = null;
		} catch (Exception e) {
			Log.d(log, "closing cursor unsuccessfully!");
			return false;
		}
		return true;
	}
}
