package com.android.browser.cmcc;

import com.android.browser.R;
import com.android.browser.unittests.testutil.Helper;
import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Browser;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.widget.TextView;

/**
 * test CMCCAddCategoryPage.java.
 * 
 * @author Tang Ting
 * 
 */
public class CMCCAddCategoryPageTest extends InstrumentationTestCase {
	private static final int SHORT_TIME = 500;
	private CMCCAddCategoryPage mCMCCAddCategoryPage;
	private Instrumentation mInst;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
	}

	@Override
	protected void tearDown() throws Exception {
		clearCategories();
		if (mCMCCAddCategoryPage != null) {
			mCMCCAddCategoryPage.finish();
			SystemClock.sleep(SHORT_TIME);
			mCMCCAddCategoryPage = null;
		}
		mInst = null;
		super.tearDown();
	}

	// launch CMCCAddCategoryPage Activity
	private CMCCAddCategoryPage launchActvitiy(String data) {
		Bundle bundle = new Bundle();
		Bundle putBundle = new Bundle();
		putBundle.putString(Browser.CategoryColumns._ID, "3");
		putBundle.putString(Browser.CategoryColumns.NAME, data);
		bundle.putBundle("bookmark", putBundle);

		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName(mInst.getTargetContext(), CMCCAddCategoryPage.class
				.getName());
		intent.putExtras(bundle);
		return (CMCCAddCategoryPage) mInst.startActivitySync(intent);
	}

	/**
	 * test save() with not input the name of category
	 */
	@LargeTest
	public void testNotInputNameSave() {
		mCMCCAddCategoryPage = launchActvitiy(null);
		assertNotNull(mCMCCAddCategoryPage);
		TextView buttonOk = (TextView) mCMCCAddCategoryPage
				.findViewById(R.id.OK);
		Helper.clickOn(mInst, buttonOk);
	}

	/**
	 * test save() with input the name of category which is already existed
	 */
	@LargeTest
	public void testInputExistedNameSave() {
		String categoryNameWithSpace = " borqs1 ";
		mCMCCAddCategoryPage = launchActvitiy(categoryNameWithSpace);
		TextView buttonOk = (TextView) mCMCCAddCategoryPage
				.findViewById(R.id.OK);
		Helper.clickOn(mInst, buttonOk);
		mCMCCAddCategoryPage.finish();

		mCMCCAddCategoryPage = launchActvitiy(categoryNameWithSpace);
		Helper.clickOn(mInst, buttonOk);
	}

	/**
	 * test save() with input the name of category which isnot include space at
	 * its start and end
	 */
	@LargeTest
	public void testInputNotIncludeSpaceNameSave() {
		String categoryNameWithNoSpace = "borqs2";
		mCMCCAddCategoryPage = launchActvitiy(categoryNameWithNoSpace);
		TextView buttonOk = (TextView) mCMCCAddCategoryPage
				.findViewById(R.id.OK);
		Helper.clickOn(mInst, buttonOk);
	}

	/**
	 * test cancel()
	 */
	@LargeTest
	public void testCancel() {
		mCMCCAddCategoryPage = launchActvitiy(null);
		TextView buttonCancel = (TextView) mCMCCAddCategoryPage
				.findViewById(R.id.cancel);
		Helper.clickOn(mInst, buttonCancel);
	}
	
	private void clearCategories() {
		final Uri CATEGORIES_URI = Uri.parse("content://browser/categories");
		ContentResolver resolver = mInst.getTargetContext()
				.getContentResolver();
		resolver.delete(CATEGORIES_URI, "_id <> 1", null);
		SystemClock.sleep(SHORT_TIME);
		Cursor c = resolver.query(CATEGORIES_URI, null, null, null, null);
		assertEquals(1, c.getCount());
		c.close();
		c = null;
	}
}
