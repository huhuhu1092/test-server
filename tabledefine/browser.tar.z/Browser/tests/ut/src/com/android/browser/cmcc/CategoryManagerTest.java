package com.android.browser.cmcc;

import com.android.browser.cmcc.CategoryManager;
import com.android.browser.unittests.testutil.Helper;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.Browser;
import android.test.AndroidTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.MediumTest;
import android.test.suitebuilder.annotation.SmallTest;

/**
 * Test Categorymanager.java.
 * 
 * @author b391(LuoXiaofei)
 * 
 */
public class CategoryManagerTest extends AndroidTestCase {

	private Context mContext;
	private CategoryManager mCategoryManager;
	private static final String NAME = "baidu";
	private ContentValues mContentValues;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mContext = getContext();
	}

	@Override
	protected void tearDown() throws Exception {
		mContext = null;
		super.tearDown();
	}

	/**
	 * there tests instance
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testnewCategoryManager() throws Exception {
		mCategoryManager = CategoryManager.instance(mContext);
		assertNotNull(mCategoryManager);
	}

	/**
	 * there tests method insert
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testinsert() throws Exception {
		Uri uri = insertCATEGORY_URI();
		clearCATEGORY_URI(uri);
	}

	/**
	 * there tests method query
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testquery() throws Exception {
		mCategoryManager = CategoryManager.instance(mContext);
		assertNotNull(mCategoryManager);
		mCategoryManager.query(Browser.CATEGORY_URI, null, null, null, null);
	}

	/**
	 * there tests method update
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testupdate() throws Exception {
		Uri uri = insertCATEGORY_URI();
		mCategoryManager.update(uri, mContentValues,
				Browser.CategoryColumns.NAME, null);
		clearCATEGORY_URI(uri);
	}

	/**
	 * there tests method delete
	 * 
	 * @throws Exception
	 */
	@MediumTest
	public void testdelete() throws Exception {
		insertCATEGORY_URI();
		mCategoryManager.delete(Browser.CATEGORY_URI, "_id<>1", null);
	}

	/**
	 * there tests method getCount
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testgetCount() throws Exception {
		Uri uri = insertCATEGORY_URI();
		mCategoryManager.getCount();
		clearCATEGORY_URI(uri);
	}

	/**
	 * there tests method getIdList
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testgetIdList() throws Exception {
		Uri uri = insertCATEGORY_URI();
		mCategoryManager.getIdList();
		clearCATEGORY_URI(uri);
	}

	/**
	 * there test method getNameList
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testgetNameList() throws Exception {
		Uri uri = insertCATEGORY_URI();
		mCategoryManager.getNameList();
		clearCATEGORY_URI(uri);
	}

	/**
	 * there tests method loadPreloadedCategories
	 * 
	 * @throws Exception
	 */
	@SmallTest
	public void testloadPreloadedCategories() throws Exception {
		CategoryManager.loadPreloadedCategories(mContext);
	}

	// help method
	/**
	 * insert into Browser.CATEGORY_URI
	 */
	public Uri insertCATEGORY_URI() {
		mCategoryManager = CategoryManager.instance(mContext);
		assertNotNull(mCategoryManager);
		mContentValues = new ContentValues();
		mContentValues.put(Browser.CategoryColumns.NAME, NAME);
		return mCategoryManager.insert(Browser.CATEGORY_URI, mContentValues);
	}

	/**
	 * clear Browser.CATEGORY_URI
	 */
	private void clearCATEGORY_URI(Uri uri) {
		ContentResolver mContentResolver = mContext.getContentResolver();
		mContentResolver.delete(Browser.CATEGORY_URI, "_id <> 1", null);
//		mContentResolver.delete(uri, null, null);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Cursor c = mContentResolver.query(Browser.CATEGORY_URI, null, null,
				null, null);
		assertEquals(1, c.getCount());

		c.close();
		c = null;
	}

}
