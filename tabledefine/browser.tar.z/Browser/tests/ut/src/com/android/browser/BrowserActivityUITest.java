package com.android.browser;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.android.browser.cmcc.CMCCBrowserBookmarksPage;
import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

/**
 * This class tests BrowserActivity start activity by the way of UI
 * 
 * @author maying
 * 
 */
@Suppress
public class BrowserActivityUITest extends InstrumentationTestCase {

	// copy from source code
	final static int BOOKMARKS_PAGE = 1;
	final static int CLASSIC_HISTORY_PAGE = 2;
	final static int DOWNLOAD_PAGE = 3;
	final static int PREFERENCES_PAGE = 4;
	final static int SEARCH_PAGE = 5;
	final static int FILE_PICK_UI = 21;
	final static int EXTRA_MENU = 10;
//	private static final int FOCUS_NODE_HREF = 102;

	//

	private static BrowserActivity mBrowserActivity;
	private Instrumentation mInst;
	private Context mCtx;
	private Intent mIntent;
//	private static final String FILENAME = "test.txt";
//	private static final String FILEPATH = "file:///sdcard/test.txt";
	private static final String FILENAME = "test.html";
	private static final String FILEPATH = "file:///sdcard/test.html";
	//b392 5.19
	private static int count = 0;

	public BrowserActivityUITest() {
		count ++;
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = this.getInstrumentation();
		mCtx = mInst.getTargetContext();
		mIntent = new Intent(Intent.ACTION_VIEW);
		mInst.setInTouchMode(false);
		if(mBrowserActivity == null){
			Helper.createFileToSdcard(mInst.getContext(), FILENAME,
					Helper.SDCARDPATH);
			mBrowserActivity = launchActivity(FILEPATH);
		}
	}

	@Override
	protected void tearDown() throws Exception {
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
		if(--count == 0 && mBrowserActivity != null){
			finishActivity();
			Helper.deleteAllFileAndFolderExceptSelf(Helper.SDCARDPATH);
		}
		mIntent = null;
		mCtx = null;
		mInst = null;
		super.tearDown();
	}

	//test method
//	/**
//	 * This method tests onActivityResult and requestcode is
//	 * CLASSIC_HISTORY_PAGE and result is RESULT_OK.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void test0OnActivityResultFILE_PICK_UIRESULT_OK() throws Exception {
//		assertNotNull(mBrowserActivity);
//
//		Intent data = new Intent();
//		//7.7
//		data.setData(Uri.parse(FILEPATH));
//
////		mBrowserActivity.onActivityResult(FILE_PICK_UI, 0, data);
//		mBrowserActivity.onActivityResult(FILE_PICK_UI, -1, data);
//		//end
//	}
//
//	/**
//	 * This method tests onActivityResult and requestcode is
//	 * CLASSIC_HISTORY_PAGE and new_window is true.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testOnActivityResultCLASSIC_HISTORY_PAGE() throws Exception {
//		assertNotNull(mBrowserActivity);
//		TabControl tabControl = (TabControl) ReflectHelper.getPrivateField(
//				mBrowserActivity, "mTabControl");
//		Intent i = new Intent(mBrowserActivity, BrowserHistoryPage.class);
//
//		i.putExtra("maxTabsOpen",
//				tabControl.getTabCount() >= TabControl.MAX_TABS);
//
//		Intent data = new Intent(FILEPATH);
//		Bundle bundle = new Bundle();
//		bundle.putBoolean("new_window", true);
//		data.putExtras(bundle);
//		ActivityResult result = new ActivityResult(Activity.RESULT_OK, data);
//
//		Instrumentation.ActivityMonitor monitor = mInst.addMonitor(BrowserHistoryPage.class.getName(), result, true);
//		try {
//			mBrowserActivity.startActivityForResult(i, CLASSIC_HISTORY_PAGE);
//		} finally {
//			mInst.removeMonitor(monitor);
//		}
//	}
//
//	/**
//	 * This method tests onDownloadStartNoStream.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testOnDownloadStartNoStream() throws Exception {
//		assertNotNull(mBrowserActivity);
//		//These params only be used in this case.312l is length of download file.
//		mBrowserActivity.onDownloadStartNoStream(FILEPATH, "userAgent",
//				"http://www.w3.org/Protocols/rfc2616/rfc2616-sec19.html",
//				"text/plain", 312l); 
//		
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}
//
//	/**
//	 * This method tests onDownloadStartNoStream.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testShowTabPicker() throws Exception {
//		assertNotNull(mBrowserActivity);
//		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
//		mInst.runOnMainSync(new Runnable() {
//			public void run() {
//				mBrowserActivity.showTabPicker();
//			}
//		});
//		
//		Helper.HardKey.back(mInst);
//		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
////		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
////		Helper.HardKey.right(mInst);
////		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
////		Helper.HardKey.center(mInst);
////		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}
//
////	/**
////	 * This method tests OnReceivedSslError.
////	 * 
////	 * @throws Exception
////	 
////	@LargeTest
////	public void testOnReceivedSslError() throws Exception {
//////		finishActivity();
////		
////		BrowserSettings mBrowserSettings = BrowserSettings.getInstance();
////		assertNotNull(mBrowserSettings);
////		ReflectHelper.setPrivateField(mBrowserSettings, "tracing", true);
////
//////		mBrowserActivity = launchActivity("https://localhost:8080");
////		mBrowserActivity.loadUrlInternal(mBrowserActivity.getCurrentWebView(), "https://localhost:8080", true);
////		SystemClock.sleep(40000);
//////		assertNotNull(mBrowserActivity);
////		
////		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
////		Helper.HardKey.down(mInst);
////		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
////		Helper.HardKey.center(mInst);
////		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
////		Helper.HardKey.down(mInst);
////		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
////		Helper.HardKey.center(mInst);
////		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
//////		finishActivity();
////		mBrowserActivity.onBackKey();
////	}
//
//	/**
//	 * This method tests showTab().
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testShowTab() throws Exception {
//		assertNotNull(mBrowserActivity);
//		TabControl tabControl = (TabControl) ReflectHelper.getPrivateField(
//				mBrowserActivity, "mTabControl");
//		assertNotNull(tabControl);
//		final TabControl.Tab t = tabControl.getCurrentTab();
//		assertNotNull(t);
//		mInst.runOnMainSync(new Runnable() {
//			public void run() {
//				mBrowserActivity.showTab(t);
//			}
//		});
//
//	}
//
//	/**
//	 * This method tests showTab().
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testShowDrmDlg() throws Exception {
//		assertNotNull(mBrowserActivity);
//
//		String cid = "1";
//		mBrowserActivity.showDrmDlg(cid);// this param is the id of the
//		// table "Download".
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}
//
//	// /**
//	// * This method tests showTitleBarContextMenu.
//	// *
//	// * @throws Exception
//	// */
//	// @LargeTest
//	// public void testshowTitleBarContextMenu() throws Exception{
//	// mBrowserActivity = launchActivity(FILEPATH);
//	// assertNotNull(mBrowserActivity);
//	// mBrowserActivity.showTitleBarContextMenu();
//	// }
////7.7 redirect to baidu
////	/**
////	 * This method tests loadURL.
////	 * 
////	 * @throws Exception
////	 */
////	@LargeTest
////	public void testLoadURL() throws Exception {
////		assertNotNull(mBrowserActivity);
////		TabControl tabControl = (TabControl) ReflectHelper.getPrivateField(
////				mBrowserActivity, "mTabControl");
////		assertNotNull(tabControl);
////		WebView view = tabControl.getCurrentTopWebView();
////		String url = "wtai://wp/sd;10086";// need a String start with
////		// "wtai://wp/sd;"+
////		ReflectHelper.runPrivateMethod(mBrowserActivity, "loadURL",
////				new Class[] { WebView.class, String.class }, new Object[] {
////						view, url });
////		mBrowserActivity.stopLoading();
////		SystemClock.sleep(1000);
////		mBrowserActivity.onNewIntent(mIntent);
////		// mBrowserActivity.onBackKey();
////	}
//
//	// /**
//	// * This method tests loadURL.
//	// *
//	// * @throws Exception
//	// */
//	// @LargeTest
//	// //TODO StreamingPlaybackActivity can't close.
//	// public void testlaunchRtspIfNeeded() throws Exception{
//	// mBrowserActivity = launchActivity(FILEPATH);
//	// assertNotNull(mBrowserActivity);
//	// Intent intent = new Intent(Intent.ACTION_VIEW);
//	// intent.setData(Uri.parse("rtsp://browser/bookmarks"));
//	//		
//	// String action = Intent.ACTION_VIEW;
//	// IntentFilter filter = new IntentFilter(action);
//	// filter.addCategory(Intent.CATEGORY_BROWSABLE);
//	// filter.addDataScheme("rtsp");
//	// monitor = new Instrumentation.ActivityMonitor(filter, null, true);
//	// mInst.addMonitor(monitor);
//	// mBrowserActivity.onNewIntent(intent);
//	// SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	// }
//	/**
//	 * This method tests onActivityResult and requestcode is
//	 * CLASSIC_HISTORY_PAGE and new_window is false.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testOnActivityResultCLASSIC_HISTORY_PAGENewWindowFalse() throws Exception {
//		assertNotNull(mBrowserActivity);
//		Intent data = new Intent(FILEPATH);
//		mBrowserActivity.onActivityResult(CLASSIC_HISTORY_PAGE, Activity.RESULT_OK, data);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}
//	
//	
//	
////	From UIITest
//	/**
//	 * This method tests OnContextItemSelected and the menu is
//	 * open_newtab_context_menu_id.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testOnContextItemSelectedopen_newtab_context_menu_id()
//			throws Exception {
////		mBrowserActivity = launchActivity(FILEPATH);
//		assertNotNull(mBrowserActivity);
//		Helper.HardKey.down(mInst);
//		mInst.invokeContextMenuAction(mBrowserActivity,
//				R.id.open_newtab_context_menu_id, 0);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}
	
//	7.12 add
	/**
	 * This method test onOptionsItemSelected and menu id is R.id.goto_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedgoto_menu_id() throws Exception {
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.goto_menu_id, 0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}
	
	/**mAlertDialog
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.stop_reload_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedstop_reload_menu_id() throws Exception {
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.stop_reload_menu_id,
				0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	/**
	 * This method test onOptionsItemSelected and menu id is R.id.back_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedback_menu_id() throws Exception {
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.back_menu_id, 0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.forward_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedforward_menu_id() throws Exception {
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.forward_menu_id, 0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}
	
	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.advanced_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedadvanced_menu_id() throws Exception {
		Instrumentation.ActivityMonitor monitor = new Instrumentation.ActivityMonitor(BrowserExtraMenuPage.class.getName(), null, true);
		mInst.addMonitor(monitor);
		try {
			assertNotNull(mBrowserActivity);
			mInst.invokeMenuActionSync(mBrowserActivity, R.id.advanced_menu_id, 0);
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		} finally {
			mInst.removeMonitor(monitor);
		}
		
	}
	
	/**
	 * This method test onOptionsItemSelected and mCanChord is false.
	 */
	@LargeTest
	public void testShouldOverrideUrlLoadingmNetworkConnectingFalse() throws Exception {
		assertNotNull(mBrowserActivity);
		final Boolean networkConnecting = (Boolean) ReflectHelper.getPrivateField(mBrowserActivity, "mNetworkConnecting");
		final Boolean menuIsDown = (Boolean) ReflectHelper.getPrivateField(mBrowserActivity, "mMenuIsDown");
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				try {
					WebViewClient webViewClient = (WebViewClient) ReflectHelper
							.getPrivateField(mBrowserActivity, "mWebViewClient");
					assertNotNull(webViewClient);
					ReflectHelper.setPrivateField(mBrowserActivity,
							"mNetworkConnecting", false);
					ReflectHelper.setPrivateField(mBrowserActivity,
							"mMenuIsDown", true);
					webViewClient.shouldOverrideUrlLoading(null, Helper.URL);
					SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
					Helper.HardKey.down(mInst);
					SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
					Helper.HardKey.center(mInst);
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					try {
						ReflectHelper.setPrivateField(mBrowserActivity,
								"mNetworkConnecting", networkConnecting);
						ReflectHelper.setPrivateField(mBrowserActivity,
								"mMenuIsDown", menuIsDown);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		});
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}
	
	/**
	 * this case tests onOptionsItemSelected() for bookmarks_tab_menu
	 */
	@LargeTest
	public void testOnOptionsItemSelected_bookmarks_tab_menu() throws Exception {
		Instrumentation.ActivityMonitor monitor = new Instrumentation.ActivityMonitor(CMCCBrowserBookmarksPage.class.getName(), null, true);
	    mInst.addMonitor(monitor);
		try {
		assertTrue(mBrowserActivity instanceof BrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mMenuState", R.id.TAB_MENU);
		assertTrue(mInst.invokeMenuActionSync(mBrowserActivity,
				R.id.bookmarks_tab_menu_id, 0));
		}finally {
			mInst.removeMonitor(monitor);
		}
	}
	
	/**
	 * this case tests onOptionsItemSelected() for book marks
	 */
	@LargeTest
	public void testOnoptionsItemSelected_bookmarks_menu_id() {
		Instrumentation.ActivityMonitor monitor = new Instrumentation.ActivityMonitor(CMCCBrowserBookmarksPage.class.getName(), null, true);
	    mInst.addMonitor(monitor);
		try {
			assertTrue(mBrowserActivity instanceof BrowserActivity);
			mInst.invokeMenuActionSync(mBrowserActivity, R.id.bookmarks_menu_id, 0);
		} finally {
			mInst.removeMonitor(monitor);
		}
	}

	/**
	 * this case tests onOptionsItemSelected() for copy and paste
	 */
	@LargeTest
	public void testOnOptionsItemSelected_copy_and_paste() {
		assertTrue(mBrowserActivity instanceof BrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.copy_and_paste_id, 0);
	}
	//end
	
	//from browser UITest
	/**
	 * This method tests loadURL.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testLoadURL() throws Exception {
		assertNotNull(mBrowserActivity);

		WebView view = new WebView(mCtx);
		String url = "wtai://wp/sd;10086";// need a String start with
		// "wtai://wp/sd;"+
		ReflectHelper.runPrivateMethod(mBrowserActivity, "loadURL",
				new Class[] { WebView.class, String.class }, new Object[] {
						view, url });
	}
	
	
	// help method
	private BrowserActivity launchActivity(String url) {
		mIntent.setClass(mCtx, BrowserActivity.class);
		mIntent.setData(Uri.parse(url));
		mIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		mBrowserActivity = (BrowserActivity) mInst.startActivitySync(mIntent);
		SystemClock.sleep(60000);
		return mBrowserActivity;
	}

	private void finishActivity() throws Exception {
		if (mBrowserActivity != null) {
			mBrowserActivity.goQuit();
			SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
		}
	}
	
//	private void clearTabsFromContentView() {
//		mInst.runOnMainSync(new Runnable(){
//			public void run(){
//				FrameLayout contentView;
//				try {
//					contentView = (FrameLayout) ReflectHelper.getPrivateField(mBrowserActivity, "mContentView");
//					if(contentView != null){
//						contentView.removeAllViews();
//					}
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

}
