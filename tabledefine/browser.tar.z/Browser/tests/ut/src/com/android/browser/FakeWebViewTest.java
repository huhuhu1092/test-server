package com.android.browser;


import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.os.SystemClock;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;
import android.widget.FrameLayout;

/**
 * Test class of FakeWebView()
 * @author I087(Cao Lina)
 *
 */
@Suppress
//public class FakeWebViewTest extends InstrumentationTestCase {
public class FakeWebViewTest extends ActivityUnitTestCase<BrowserActivity> {
	private Context mContext;
	private FakeWebView mFakeWebView;
	
	public FakeWebViewTest() {
		super(BrowserActivity.class);
	}

	protected void setUp() throws Exception {
		super.setUp();
		mContext=this.getInstrumentation().getTargetContext();
	}

	protected void tearDown() throws Exception {
		mContext=null;
		super.tearDown();
	}
	/**
	 * test FakeWebView's Constructor with one Parameter
	 * @throws Exception
	 */
	@LargeTest
	public void testConstructor() throws Exception{
		mFakeWebView=new FakeWebView(mContext);
	    assertNotNull(mFakeWebView);
	}
	/**
	 * test FakeWebView's Constructor with two Parameter
	 * @throws Exception
	 */
	@LargeTest
	public void testConstructorWithTwoParameter() throws Exception{
		mFakeWebView=new FakeWebView(mContext,null);
	    assertNotNull(mFakeWebView);
	}
	/**
	 * test FakeWebView's Constructor with three Parameter
	 * @throws Exception
	 */
	@LargeTest
	public void testConstructorWithThreeParameter() throws Exception{
		mFakeWebView=new FakeWebView(mContext,null,1);
	    assertNotNull(mFakeWebView);
	}
/*	//TODO	
	*//**
	 * test method of onDraw() With UsesResource Is False
	 * @throws Exception
	 *//*
	@LargeTest
	public void testonDrawWithUsesResourceIsFalse() throws Exception{
	    mFakeWebView=new FakeWebView(mContext,null);
	    assertNotNull(mFakeWebView);
	    ReflectHelper.setPrivateField(mFakeWebView, "mUsesResource", false);
	    Canvas canvas=new Canvas();
	    mFakeWebView.onDraw(canvas);
//	    mFakeWebView.onDraw(null);
	    SystemClock.sleep(2000);
	}*/
//	public void testonDrawWithUsesResourceIsFalse() throws Exception {
//		Helper.createFileToSdcard(getInstrumentation().getContext(),
//				"test.txt", "/sdcard");
//		Intent intent = new Intent(Intent.ACTION_VIEW);
//		intent.setData(Uri.parse("file:///sdcard/test.txt"));
//		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//		intent.setClassName("com.android.browser",
//				BrowserActivity.class.getName());
//		final BrowserActivity activity = (BrowserActivity) getInstrumentation()
//				.startActivitySync(intent);
//		SystemClock.sleep(20000);
//		assertNotNull(activity);
//
//		getInstrumentation().runOnMainSync(new Runnable() {
//			public void run() {
//				try {
//					mFakeWebView = new FakeWebView(activity);
//					assertNotNull(mFakeWebView);
//					ReflectHelper.setPrivateField(mFakeWebView,
//							"mUsesResource", false);
//					Canvas canvas = new Canvas();
//					mFakeWebView.onDraw(canvas);
//					SystemClock.sleep(2000);
//				} catch (Exception e) {
//					e.printStackTrace();
//				} finally {
//					activity.goQuit();
////					SystemClock.sleep(1000);
////					FrameLayout contentView = (FrameLayout) ReflectHelper.getPrivateField(
////							activity, "mContentView");
////					if (contentView != null) {
////						contentView.removeAllViews();
////					}
//					SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
//					Helper.deleteFileAndFolder("/sdcard");
//				}
//			}
//		});
//	}
	/**
	 * test method of onDraw()  With UsesResource Is True
	 * @throws Exception
	 */
	@LargeTest
	public void testonDrawWithUsesResourceIsTrue() throws Exception{
		mFakeWebView=new FakeWebView(mContext);
	    assertNotNull(mFakeWebView);
		mFakeWebView.setImageResource(1);
		Canvas canvas=new Canvas();
		mFakeWebView.onDraw(canvas);
	}
	/**
	 * test method of SetTab()
	 * @throws Exception
	 */
	@LargeTest
	public void testSetTab() throws Exception{
		mFakeWebView=new FakeWebView(mContext);
	    assertNotNull(mFakeWebView);
	    final BrowserActivity browserActivity=lanuchActivity();
	    assertNotNull(browserActivity);
	    TabControl tab=new TabControl(browserActivity);
		TabControl.Tab t=tab.createNewTab(true, "1", "file:///sdcard/download");
	    mFakeWebView.setTab(t);
	    SystemClock.sleep(1000);  
	    browserActivity.finish();
	    getInstrumentation().runOnMainSync(new Runnable(){
	    	public void run(){
	    		FrameLayout contentView;
				try {
					contentView = (FrameLayout) ReflectHelper.getPrivateField(browserActivity, "mContentView");
					if(contentView != null){
		    			contentView.removeAllViews();
		    		}
		    	    SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
				} catch (Exception e) {
					e.printStackTrace();
				}
	    	}
	    });
	    Helper.deleteFileAndFolder("/sdcard");
	}
	//launch Activity 
	private BrowserActivity lanuchActivity()throws Exception{
//		    Helper.createFileToSdcard(getInstrumentation().getContext(), "test.txt", "/sdcard");
//            Intent intent = new Intent(Intent.ACTION_VIEW);
//            intent.setData(Uri.parse("file:///sdcard/test.txt"));
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            intent.setClassName("com.android.browser", BrowserActivity.class.getName());
//            BrowserActivity  activity =(BrowserActivity)this.getInstrumentation().startActivitySync(intent);
//            SystemClock.sleep(20000);
//            assertNotNull(activity);
		    Intent intent = new Intent(Intent.ACTION_MAIN);
		    intent.setClassName("com.android.browser", BrowserActivity.class.getName());
		    BrowserActivity  activity = startActivity(intent, null, null);
            return activity;
        }
}
