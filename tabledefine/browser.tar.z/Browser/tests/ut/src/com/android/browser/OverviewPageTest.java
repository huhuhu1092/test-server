package com.android.browser;

import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.webkit.WebView;

import com.android.browser.OverviewPage.OverviewListener;
import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

/**
 * Test class of OverviewPage
 * @author I087(Cao Lina)
 *
 */
@Suppress
public class OverviewPageTest extends ActivityUnitTestCase<BrowserActivity> {

	private OverviewPage mOverviewPage;
	private WebView mWebView;
	private static BrowserActivity mBrowserActivity;
	
	//b392 5.20 only launch once
	private static int count = 0;
	private static boolean flag = true;
	
	public OverviewPageTest() {
		super(BrowserActivity.class);
		count ++;
	}

	protected void setUp() throws Exception {
		super.setUp();
		if(flag){
//			Helper.createFileToSdcard(getInstrumentation().getContext(), "test.txt",
//					Helper.SDCARDPATH);
			Helper.createFileToSdcard(getInstrumentation().getContext(), "test.html",
					Helper.SDCARDPATH);
			mBrowserActivity = launchActivity("file:///sdcard/test.html");
			flag = false;
		}
		mWebView = mBrowserActivity.getCurrentWebView();
		mOverviewPage = new OverviewPage(mBrowserActivity, mWebView);
	
	}

	protected void tearDown() throws Exception {
		if(--count == 0 ){
			finishActivity();
		}
		mWebView=null;
		mOverviewPage=null;
		super.tearDown();
	}
	
	/**
	 * test overviewpage's constructor
	 * @throws Exception
	 */
	@LargeTest
    public void testConstructor() throws Exception{
    	assertNotNull(mOverviewPage);
    }
    /**
     * test method of onKeyUp()
     * @throws Exception
     */
	@LargeTest
    public void testOnKeyUp() throws Exception{
       assertFalse(mOverviewPage.onKeyUp(1, new KeyEvent(1,3)));
    }
    /**
     * test method of onKeyDown()
     * @throws Exception
     */
	@LargeTest
    public void testOnKeyDownWithKEYCODE_DPAD_UP() throws Exception{
    	KeyEvent event=new KeyEvent(1,2);
    	assertTrue(mOverviewPage.onKeyDown(KeyEvent.KEYCODE_DPAD_UP,event));
    }
    /**
     * test method of report()
     * @throws Exception
     */
	@LargeTest
    public void testReport() throws Exception{
    	mOverviewPage.report();
    }
    /**
     * test method of onKeyDown() with action=KEYCODE_DPAD_DOWN
     * @throws Exception
     */
	@LargeTest
    public void testOnKeyDownWithKEYCODE_DPAD_DOWN() throws Exception{
    	KeyEvent event=new KeyEvent(1,2);
    	assertTrue(mOverviewPage.onKeyDown(KeyEvent.KEYCODE_DPAD_DOWN,event));
    }
    /**
     * test method of onKeyDown() with action=KEYCODE_DPAD_LEFT
     * @throws Exception
     */
	@LargeTest
    public void testOnKeyDownWithKEYCODE_DPAD_LEFT() throws Exception{
    	KeyEvent event=new KeyEvent(1,2);
    	assertTrue(mOverviewPage.onKeyDown(KeyEvent.KEYCODE_DPAD_LEFT,event));
    }
    /**
     * test method of onKeyDown() with action=KEYCODE_DPAD_RIGHT
     * @throws Exception
     */
	@LargeTest
    public void testOnKeyDownWithKEYCODE_DPAD_RIGHT() throws Exception{
    	KeyEvent event=new KeyEvent(1,2);
    	assertTrue(mOverviewPage.onKeyDown(KeyEvent.KEYCODE_DPAD_RIGHT,event));
    }
    /**
     * test method of onKeyDown() with action=KEYCODE_APOSTROPHE
     * @throws Exception
     */
	@LargeTest
    public void testOnKeyDownWithDefault() throws Exception{
    	KeyEvent event=new KeyEvent(1,2);
    	assertFalse(mOverviewPage.onKeyDown(KeyEvent.KEYCODE_APOSTROPHE,event));
    }
    /**
     * test method of onKeyDown() with action=KEYCODE_ENTER
     * @throws Exception
     */
	@LargeTest
    public void testOnKeyDownWithKEYCODE_ENTER() throws Exception{
    	KeyEvent event=new KeyEvent(1,2);
    	OverviewListener l=new Overview();
    	mOverviewPage.setListener(l);
    	assertTrue(mOverviewPage.onKeyDown(KeyEvent.KEYCODE_ENTER,event));
    }
    /**
     * test method of onTouchEvent() with action=ACTION_DOWN
     * @throws Exception
     */
	@LargeTest
    public void testOnTouchEventWithACTION_DOWN() throws Exception{
    	MotionEvent ev=MotionEvent.obtain(2L, 3L, MotionEvent.ACTION_DOWN, 0, 0, 1);
    	assertTrue(mOverviewPage.onTouchEvent(ev));
    }
    /**
     * test method of onTouchEvent() with action=ACTION_MOVE
     * @throws Exception
     */
	@LargeTest
    public void testOnTouchEventWithACTION_MOVE() throws Exception{
    	MotionEvent ev=MotionEvent.obtain(2L, 3L, MotionEvent.ACTION_MOVE, -100000000, 100000000, 1);
    	assertTrue(mOverviewPage.onTouchEvent(ev));
    }
    /**
     * test method of onTouchEvent() with action=ACTION_UP
     * @throws Exception
     */
	@LargeTest
    public void testOnTouchEventWithACTION_UP() throws Exception{
    	MotionEvent ev=MotionEvent.obtain(2L, 3L, MotionEvent.ACTION_UP, 10000, 10000, 1);
    	OverviewListener l=new Overview();
    	mOverviewPage.setListener(l);
    	assertTrue(mOverviewPage.onTouchEvent(ev));
    }
   /**
    * test method of setListener()
    * @throws Exception
    */
	@LargeTest
    public void testSetListener() throws Exception{
    	OverviewListener l=new Overview();
    	mOverviewPage.setListener(l);
    }
    /**
     * test method of Update()
     * @throws Exception
     */
	@LargeTest
    public void testUpdate() throws Exception{
    	ReflectHelper.runPrivateMethod(mOverviewPage, "update", null, null);
    }
    
    //launch Activity
    private BrowserActivity launchActivity(String url) {
    	Intent intent = new Intent(Intent.ACTION_VIEW);
    	intent.setClass(getInstrumentation().getTargetContext(), BrowserActivity.class);
    	intent.setData(Uri.parse(url));
    	intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mBrowserActivity = (BrowserActivity) getInstrumentation().startActivitySync(intent);
        SystemClock.sleep(60000);
        return mBrowserActivity;
    }
    
    //b392 5.20
    private void finishActivity() {
		if (mBrowserActivity != null) {
			mBrowserActivity.goQuit();
			final int WAIT_FOR_FINISH = 15000;
			SystemClock.sleep(WAIT_FOR_FINISH);
			mBrowserActivity = null;
		}
	}
	//end
    
   // Implement Overview class
     private static class Overview implements OverviewListener{
		public void onClick(int x, int y) {
		}
    	 
     }
}
