package com.android.browser.cmcc;

import com.android.browser.unittests.testutil.Helper;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;

/**
 * test CMCCBookmarkItem.java
 * 
 * @author Tang Ting
 * 
 */
public class CMCCBookmarkItemTest extends
		ActivityUnitTestCase<CMCCBrowserBookmarksPage> {
	private CMCCBookmarkItem mCMCCBookmarkItem;
	private CMCCBrowserBookmarksPage mCMCCBrowserBookmarksPage;
	private Instrumentation mInst;
	private Context mContext;

	public CMCCBookmarkItemTest() {
		super(CMCCBrowserBookmarksPage.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mContext = mInst.getTargetContext();
		mCMCCBookmarkItem = createCMCCBookmarkItem(true);
	}

	@Override
	protected void tearDown() throws Exception {
		// TODO Auto-generated method stub
		if (mCMCCBrowserBookmarksPage != null) {
			mCMCCBrowserBookmarksPage.finish();
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
			mCMCCBrowserBookmarksPage = null;
		}
		mCMCCBookmarkItem = null;
		mInst = null;
		mContext = null;
		super.tearDown();
	}

	// method
	// create CMCCBookmarkItem
	private CMCCBookmarkItem createCMCCBookmarkItem(boolean inDeleteView) {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName(mInst.getTargetContext(),
				CMCCBrowserBookmarksPage.class.getName());
		mCMCCBrowserBookmarksPage = (CMCCBrowserBookmarksPage) mInst
				.startActivitySync(intent);

		CMCCBookmarkExpandableListAdapter adapter = new CMCCBookmarkExpandableListAdapter(
				mCMCCBrowserBookmarksPage, null, false, mContext);
		return (new CMCCBookmarkItem(adapter, mContext, inDeleteView));
	}

	/**
	 * test copyTo()
	 */
	@LargeTest
	public void testcopyTo() {
		mCMCCBookmarkItem.copyTo(mCMCCBookmarkItem);
	}

	/**
	 * test setName() and getName()
	 */
	@LargeTest
	public void testSetAndGetName() {
		String titleName = "borqs";
		mCMCCBookmarkItem.setName(titleName);
		assertEquals(titleName, mCMCCBookmarkItem.getName());
	}

	/**
	 * test setBookmarkId and getBookmarkId
	 */
	@LargeTest
	public void testSetAndGetBookmarkId() {
		String bookmarkId = "borqsId";
		mCMCCBookmarkItem.setBookmarkId(bookmarkId);
		assertEquals(bookmarkId, mCMCCBookmarkItem.getBookmarkId());
	}

	/**
	 * test getNameTextView
	 */
	@LargeTest
	public void testgetNameTextView() {
		assertNotNull(mCMCCBookmarkItem.getNameTextView());
	}

	/**
	 * test setFavicon and setUrl
	 */
	@LargeTest
	public void testset() {
		String url = "www.borqs.com";
		mCMCCBookmarkItem.setFavicon(null);
		mCMCCBookmarkItem.setUrl(url);
	}

	/**
	 * test setChecked and isChecked
	 */
	@LargeTest
	public void testsetChecked() {
		mCMCCBookmarkItem.setChecked(true);
		assertTrue(mCMCCBookmarkItem.isChecked());
	}

	/**
	 * test toggle
	 */
	@LargeTest
	public void testtoggle() {
		mCMCCBookmarkItem.toggle();
	}

}
