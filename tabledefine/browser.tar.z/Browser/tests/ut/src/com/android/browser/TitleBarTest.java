package com.android.browser;

import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.MotionEvent;
import android.widget.FrameLayout;

/**
 * Test TitleBar.java.
 * 
 * @author b391(LuoXiaofei)
 * 
 */
public class TitleBarTest extends ActivityUnitTestCase<BrowserActivity> {

	public TitleBarTest() {
		super(BrowserActivity.class);
	}

	private Instrumentation mInst;
	private Context mContext;
	private BrowserActivity mBrowserActivity;
	private TitleBar mTitleBar;
//	private final static String NAME="test.txt";
//	private final static String PATH="/sdcard";
//	private final static String FILEPATH="file:///sdcard/test.txt";
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mContext = mInst.getTargetContext();
	}

	@Override
	protected void tearDown() throws Exception {
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		finishActivity();
		mInst = null;
		mContext = null;
		mTitleBar = null;
		
		super.tearDown();
	}

//	/**
//	 * there tests new TitleBar
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void test001NewTitleBar() throws Exception {
//		mBrowserActivity = launchBrowserActivity();
//		assertNotNull(mBrowserActivity);
//		mTitleBar = new TitleBar(mBrowserActivity);
//		Helper.deleteFileAndFolder(PATH);
//	}

	/**
	 * there test method onTouchEvent and event.action=MotionEvent.ACTION_CANCEL
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonTouchEventACTION_CANCEL() throws Exception {
		long downTime = 0;
		long eventTime = 0;
		int action = MotionEvent.ACTION_CANCEL;
		float x = 0;
		float y = 0;
		int metaState = 0;
		MotionEvent event = MotionEvent.obtain(downTime, eventTime, action, x,
				y, metaState);
		mBrowserActivity = launchUTBrowserActivity();
		assertNotNull(mBrowserActivity);
		mTitleBar = new TitleBar(mBrowserActivity);
		assertTrue(mTitleBar.onTouchEvent(event));
	}

	/**
	 * there tests method onTouchEvent and event.avtion=MotionEvent.ACTION_DOWN
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonTouchEventACTION_DOWN() throws Exception {
		long downTime = 0;
		long eventTime = 0;
		int action = MotionEvent.ACTION_DOWN;
		float x = 0;
		float y = 0;
		int metaState = 0;
		MotionEvent event = MotionEvent.obtain(downTime, eventTime, action, x,
				y, metaState);
		mBrowserActivity = launchUTBrowserActivity();
		assertNotNull(mBrowserActivity);
		mTitleBar = new TitleBar(mBrowserActivity);
		assertTrue(mTitleBar.onTouchEvent(event));
	}

	/**
	 * there tests method onTouchEvent and event.avtion=MotionEvent.ACTION_MOVE
	 * and
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonTouchEventACTION_MOVE() throws Exception {
		long downTime = 0;
		long eventTime = 0;
		int action = MotionEvent.ACTION_MOVE;
		float x = 0;
		float y = 100;
		int metaState = 0;
		MotionEvent event = MotionEvent.obtain(downTime, eventTime, action, x,
				y, metaState);
		mBrowserActivity = launchUTBrowserActivity();
		assertNotNull(mBrowserActivity);
		mTitleBar = new TitleBar(mBrowserActivity);
		assertTrue(mTitleBar.onTouchEvent(event));
	}

//	/**
//	 * there tests method onTouchEvent and event.avtion=MotionEvent.ACTION_UP
//	 * and mRtButton.clickOn
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testonTouchEventACTION_UPmRtButton() throws Exception {
//		long downTime = 0;
//		long eventTime = 0;
//		int action = MotionEvent.ACTION_UP;
//		float x = 0;
//		float y = 100;
//		int metaState = 0;
//		MotionEvent event = MotionEvent.obtain(downTime, eventTime, action, x,
//				y, metaState);
//		mBrowserActivity = launchBrowserActivity();
//		assertNotNull(mBrowserActivity);
//		mTitleBar = new TitleBar(mBrowserActivity);
//		ImageView mRtButton = (ImageView) mBrowserActivity
//				.findViewById(R.id.rt_btn);
//		Helper.clickOn(mInst, mRtButton);
//		assertTrue(mTitleBar.onTouchEvent(event));
//		Helper.deleteFileAndFolder(PATH);
//	}

//	/**
//	 * there tests method onTouchEvent and event.action=MotionEvent.ACTION_MOVE
//	 * and mTitleBg.clickOk
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testonTouchEventACTION_MOVEmRtButton() throws Exception {
//		long downTime = 0;
//		long eventTime = 0;
//		int action = MotionEvent.ACTION_MOVE;
//		float x = 100;
//		float y = 0;
//		int metaState = 0;
//		MotionEvent event = MotionEvent.obtain(downTime, eventTime, action, x,
//				y, metaState);
//		mBrowserActivity = launchBrowserActivity();
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		assertNotNull(mBrowserActivity);
//		mTitleBar = new TitleBar(mBrowserActivity);
//		ImageView mRtButton = (ImageView) mBrowserActivity
//				.findViewById(R.id.rt_btn);
//		Helper.clickOn(mInst, mRtButton);
//		assertTrue(mTitleBar.onTouchEvent(event));
//		Helper.deleteFileAndFolder(PATH);
//
//	}

	/**
	 * there tests method setToTabPicker
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testsetToTabPicker() throws Exception {
		mBrowserActivity = launchUTBrowserActivity();
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		assertNotNull(mBrowserActivity);
		mTitleBar = new TitleBar(mBrowserActivity);
		mTitleBar.setToTabPicker();
	}
//
//	/**
//	 * there tests handler message
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testhandlermessage() throws Exception {
//		mBrowserActivity = launchBrowserActivity();
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		assertNotNull(mBrowserActivity);
//		mTitleBar = new TitleBar(mBrowserActivity);
//		Handler handler = (Handler) ReflectHelper.getPrivateField(mTitleBar,
//				"mHandler");
//		Message msg = new Message();
//		int LONG_PRESS = 1;
//		msg.what = LONG_PRESS;
//		handler.handleMessage(msg);
//		Helper.deleteFileAndFolder(PATH);
//	}

	// help method
//	/**
//	 * there launchUIBrowserActivity
//	 */
//	private BrowserActivity launchBrowserActivity() {
//		Helper.createFileToSdcard(mInst.getContext(), NAME, PATH);
//		Intent intent = new Intent(Intent.ACTION_VIEW);
//		intent.setData(Uri.parse(FILEPATH));
//		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//		intent.setClass(mContext, BrowserActivity.class);
//		mBrowserActivity = (BrowserActivity) mInst.startActivitySync(intent);
//		mInst.waitForIdleSync();
//		SystemClock.sleep(30000);
//		return mBrowserActivity;
//	}

	/**
	 * there launchUTBrowserActivity
	 * 
	 * @return
	 */
	private BrowserActivity launchUTBrowserActivity() {
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClass(mContext, BrowserActivity.class);
		mBrowserActivity = this.startActivity(intent, null, null);
		return mBrowserActivity;
	}
	
	 //b392 5.20
    private void finishActivity() {
		if (mBrowserActivity != null) {
			mBrowserActivity.finish();
			getInstrumentation().runOnMainSync(new Runnable() {
				public void run() {
					try {
						FrameLayout contentView =  (FrameLayout) ReflectHelper.getPrivateField(mBrowserActivity, "mContentView");
						if(contentView != null){
							contentView.removeAllViews();
						}
					}catch(Exception e){
						e.printStackTrace();
					}
				}
			});
			mBrowserActivity = null;
		}
	}
	//end
}
