package com.android.browser;

import android.app.Instrumentation;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.provider.Browser;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.MediumTest;
import android.widget.FrameLayout;

import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

/**
 * Test class of NetworkManager
 * @author I087(Cao Lina)
 *
 */
public class NetworkManagerTest extends ActivityUnitTestCase<BrowserActivity> {

    private NetworkManager mNetworkManager;
    private static BrowserActivity mBrowserActivity ;
    private static int caseCount;
    private static final int EVENT_DATA_STATE_CHANGED = 2;
    private Instrumentation mInst;
    
    
	public NetworkManagerTest() {
		super(BrowserActivity.class);
		caseCount ++;
	}

	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		if(mBrowserActivity == null ) {
			mBrowserActivity = launchActivity();
		}
		mNetworkManager=new NetworkManager(mBrowserActivity);
	}

	protected void tearDown() throws Exception {
		caseCount --;
		if(caseCount == 0) {
			finishActivity();
		}
		mNetworkManager=null;
		mInst = null;
		super.tearDown();
	}
   /**
    * test method of createInstance()
    * @throws Exception
    */
	@LargeTest
	public void testCreateInstance() throws Exception{
	  assertNotNull(NetworkManager.createInstance(mBrowserActivity));
	}
	/**
	 * test method of setNetworkProfile()
	 * @throws Exception
	 */
	@LargeTest
	public void testSetNetworkProfile() throws Exception{
		assertNotNull(mNetworkManager);
		mNetworkManager.setNetworkProfile("test");
	}
	/**
	 * test method of peekInstance()
	 * @throws Exception
	 */
	@MediumTest
	public void testPeekInstance() throws Exception{
	   assertNotNull(NetworkManager.peekInstance());	
	}
	/**
	 * test method of switchNetworkProfile()
	 * @throws Exception
	 */
	@LargeTest
	public void testSwitchNetworkProfile() throws Exception{
		mNetworkManager.switchNetworkProfile("internet");
		assertEquals("internet", mNetworkManager.getNetworkProfile());
	}
	/**
	 * test method of connected()
	 * @throws Exception
	 */
	@LargeTest
	public void testConnected() throws Exception{
	    assertEquals(false,mNetworkManager.connected());
	}
	/**
	 * test method of getNetworkInterface()
	 * @throws Exception
	 */
	@LargeTest
	public void testGetNetworkInterface() throws Exception{
		assertNull(mNetworkManager.getNetworkInterface());
	}
	/**
	 * test method of finish()
	 * @throws Exception
	 */
	@MediumTest
	public void testFinish() throws Exception{
		mNetworkManager.finish();
		assertNull(mNetworkManager.getNetworkInterface());
	}
	/**
	 * test method of OpenDataConnectionIfNeeded
	 * @throws Exception
	 */
	@LargeTest
	public void testOpenDataConnectionIfNeeded() throws Exception{
		assertTrue(mNetworkManager.openDataConnectionIfNeeded());
	}
	/**
	 * test method of GetNetworkParam
	 * @throws Exception
	 */
	@LargeTest
	public void testGetNetworkParam() throws Exception{
		assertNotNull(mNetworkManager.getNetworkParam());
	}
    /**
     * test method of connect when mIsEmulator=false
     * @throws Exception
     */
	@LargeTest
	public void testConnectIsEmulatorfalse()throws Exception{
//		ReflectHelper.setStaticPrivateField(NetworkManager.class, "mIsEmulator", false);
		boolean result = mNetworkManager.connect();
		assertTrue(result);
	}
	/**
	 * test method of handleMessage() when msg.what=EVENT_DATA_STATE_CHANGED
	 * @throws Exception
	 */
	@MediumTest
	public void testHandleMessage()throws Exception{
		assertNotNull(mNetworkManager);
		Handler handler=(Handler)ReflectHelper.getPrivateInnerClass(mNetworkManager, "com.android.browser.NetworkManager$ServiceHandler", 
				                      new Class[]{mNetworkManager.getClass()}, new Object[]{mNetworkManager});
		assertNotNull(handler);
		Message msg=new Message();
		msg.what=EVENT_DATA_STATE_CHANGED;
		handler.handleMessage(msg);
	}
	/**
	 * test method of handleMessage() when msg.what is default
	 * @throws Exception
	 */
	@MediumTest
	public void testHandleMessagewithDefault()throws Exception{
		assertNotNull(mNetworkManager);
		Handler ha=(Handler)ReflectHelper.getPrivateInnerClass(mNetworkManager, "com.android.browser.NetworkManager$ServiceHandler", 
				                      new Class[]{mNetworkManager.getClass()}, new Object[]{mNetworkManager});
		assertNotNull(ha);
		Message msg=new Message();
		ha.handleMessage(msg);
	}
	public void testsetupWlanProxyIfNeeded() throws Exception{
		ReflectHelper.runPrivateMethod(mNetworkManager,"setupWlanProxyIfNeeded",null,null);
	}
	
    //help method 
    private BrowserActivity launchActivity(){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("file://sdcard/download/gif.bb"));
        Bundle bundle = new Bundle();
        bundle.putBoolean("testing", false);
        intent.putExtras(bundle);
        bundle.putInt(Browser.INITIAL_ZOOM_LEVEL, 1);
        return startActivity(intent, null, null);
    }
    
    private void finishActivity() {
    	mBrowserActivity.finish();
    	SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
    	mInst.runOnMainSync(new Runnable(){
    		public void run(){
    			FrameLayout contentView;
				try {
					contentView = (FrameLayout) ReflectHelper.getPrivateField(mBrowserActivity, "mContentView");
					if(contentView != null){
						contentView.removeAllViews();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
    		}
    	});
		mBrowserActivity = null;
    }
}
