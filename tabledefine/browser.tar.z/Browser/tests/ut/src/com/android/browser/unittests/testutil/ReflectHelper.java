package com.android.browser.unittests.testutil;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

@SuppressWarnings("unchecked")
public class ReflectHelper {
        private ReflectHelper(){}
	/** get value of static private field
         *  @param clazz: Object.class (e.g.:ReflectHelper.class)
         *  @param name: the name of private static field
         *  @return the object of static private field
         */
	public static Object getStaticPrivateField(Class clazz,String name) throws Exception {
		Field field = clazz.getDeclaredField(name);
		field.setAccessible(true);
		return field.get(null);
	}
	/** get value of private field
         *  @param object: the object has private field (e.g.:new ReflectHelper())
         *  @param name: the name of private field
         *  @return the object of private field
         */
	public static Object getPrivateField(Object object,String name) throws Exception {
		Field field = object.getClass().getDeclaredField(name);
		field.setAccessible(true);
		return field.get(object);
	}
	/** set static private field = value
         *  @param clazz: Object.class (e.g.:ReflectHelper.class)
         *  @param name: the name of static private field
         *  @param value: set the value of static private field
         *  @return null
         */
	public static void setStaticPrivateField(Class clazz,String name,Object value) throws Exception {
		Field field = clazz.getDeclaredField(name);
		field.setAccessible(true);
		field.set(null, value);
	}
	/** set private field = value
         *  @param object: the object has private field (e.g.:new ReflectHelper())
         *  @param name: the name of private field
         *  @param value: set the value of private field
         *  @return null
         */
	public static void setPrivateField(Object object,String name,Object value) throws Exception {
		Field field = object.getClass().getDeclaredField(name);
		field.setAccessible(true);
		field.set(object, value);
	}
	/** run static private method
         *  @param clazz: Object.class (e.g.:ReflectHelper.class)
         *  @param name: the name of static private method
         *  @param parameter: the param list of static private method
         *  @param parameterValue: the value list mirror param list 
         *  @return null
         */
	public static Object runStaticPrivateMethod(Class clazz,String name,Class[] parameter,Object[] parameterValue) throws Exception {
		Method method = clazz.getDeclaredMethod(name, parameter);
		method.setAccessible(true);
		return method.invoke(null, parameterValue);
	}
	/** run private method
         *  @param object: the object has private method (e.g.:new ReflectHelper())
         *  @param name: the name of private method
         *  @param parameter: the param list of static private method
         *  @param parameterValue: the value list mirror param list
         *  @return null
         */
	public static Object runPrivateMethod(Object object,String name,Class[] parameter,Object[] parameterValue) throws Exception {
		Method method = object.getClass().getDeclaredMethod(name, parameter);
		method.setAccessible(true);
		return method.invoke(object, parameterValue);
	}
//	//get static private class
//	public static Object getStaticPrivateInnerClass(Class outClass,String innerClassName,Class[] innerParameter,Object[] innerParameterValue) throws Exception {
//		Class[] innerClassS = outClass.getDeclaredClasses();
//		for(Class clazz:innerClassS){
//			if(clazz.getName().equals(innerClassName)){
//				return clazz.getDeclaredConstructor(innerParameter).newInstance(innerParameterValue); 
//			}
//		}
//		return null;
//	}
	/** get private class
         *  @param outObject: Outer class (e.g.:new OuterClass())
         *  @param innerClassName: the name of Inner class (e.g.:package.OuterClass$InnerClass)
         *  @param innerParameter: the param list of Inner class (e.g.:new Class[]{OuterClass.class,int.class})
         *  @param innerParameterValue: the value list mirror innerParameter (e.g.:new Object[]{outObject,0})
         *  @return the object of Inner class
         */
	public static Object getPrivateInnerClass(Object outObject,String innerClassName,Class[] innerParameter,Object[] innerParameterValue) throws Exception {
		Class[] innerClassS = outObject.getClass().getDeclaredClasses();
		for(Class clazz:innerClassS){
			if(clazz.getName().equals(innerClassName)){
				Constructor constructor = clazz.getDeclaredConstructor(innerParameter);
				constructor.setAccessible(true);
				return constructor.newInstance(innerParameterValue); 
			}
		}
		return null;
	}
}
