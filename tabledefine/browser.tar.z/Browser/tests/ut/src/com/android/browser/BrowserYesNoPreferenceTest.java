package com.android.browser;

import android.app.Instrumentation;
import android.content.Intent;
import android.os.SystemClock;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ListView;

import com.android.browser.unittests.testutil.Helper;
/**
 * test BrowserYesNoPreference.
 * @author wsj
 *
 */
@Suppress
public class BrowserYesNoPreferenceTest extends ActivityUnitTestCase<BrowserPreferencesPage> {
	private static BrowserPreferencesPage mActivity;
	private Instrumentation mInst;
	private static ListView mlistView;
	private static int mCount = 0;
    private static final boolean ONCLICKDILOG_OK= true;
	public BrowserYesNoPreferenceTest() {
		super(BrowserPreferencesPage.class);
		mCount++;
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		if (mActivity == null) {
			mActivity = getPerferenceActivity();
			assertNotNull(mActivity);
			mlistView = mActivity.getListView();
		}

	}

	@Override
	protected void tearDown() throws Exception {
        mCount--;
		if (mCount == 0) {
			if (mActivity != null) {
				mActivity.finish();
				mActivity = null;
				mlistView = null;
			}
		}
		mInst = null;
		super.tearDown();
	}
	//**********************************************Test Method
	/**
	 * test CLEAR_CACHE of BrowserYesNoPreference
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testBrowserYesNoPreference_CLEAR_CACHE() throws Exception {
		clickSettingItem(mInst, mlistView, BrowserSetting.CLEAR_CACHE);
		confirmDialogClick(ONCLICKDILOG_OK);
	}

	/**
	 * test RESET_HOME_PAGE of BrowserYesNoPreference
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testBrowserYesNoPreference_RESET_HOME_PAGE() throws Exception {
		clickSettingItem(mInst, mlistView, BrowserSetting.RESET_HOME_PAGE);
		confirmDialogClick(ONCLICKDILOG_OK);
	}

	/**
	 * test CLEAR_HISTORY of BrowserYesNoPreference
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testBrowserYesNoPreference_CLEAR_HISTORY() throws Exception {
		clickSettingItem(mInst, mlistView, BrowserSetting.CLEAR_HISTORY);
		confirmDialogClick(ONCLICKDILOG_OK);
	}

	/**
	 * test CLEAR_ALL_COOKIE_DATA of BrowserYesNoPreference
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testBrowserYesNoPreference_CLEAR_ALL_COOKIE_DATA()
			throws Exception {
		clickSettingItem(mInst, mlistView, BrowserSetting.CLEAR_ALL_COOKIES_DATA);
		confirmDialogClick(ONCLICKDILOG_OK);
	}

	/**
	 * test CLEAR_FORM_DATA of BrowserYesNoPreference
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testBrowserYesNoPreference_CLEAR_FORM_DATA() throws Exception {
//		mActivity.finish();
//		SystemClock.sleep(2000);
//		Intent intent = new Intent(Intent.ACTION_VIEW);
//		intent.setClass(mInst.getTargetContext(), BrowserActivity.class);
//		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//		BrowserActivity activity = (BrowserActivity) mInst
//				.startActivitySync(intent);
//		SystemClock.sleep(20000);
//		activity.goQuit();
//		activity.finish();
//		SystemClock.sleep(2000);
//		mActivity = getPerferenceActivity();
//		BrowserSettings.getInstance().setTabControl(new TabControl(activity));
		clickSettingItem(mInst, mlistView, BrowserSetting.CLEAR_FORM_DATA);
		confirmDialogClick(ONCLICKDILOG_OK);
	}

	/**
	 * test CLEAR_PASSWORDS of BrowserYesNoPreference
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testBrowserYesNoPreference_CLEAR_PASSWORDS() throws Exception {
		clickSettingItem(mInst, mlistView, BrowserSetting.CLEAR_PASSWORDS);
		confirmDialogClick(ONCLICKDILOG_OK);
	}

	/**
	 * test RESET_TO_DEFAULT of BrowserYesNoPreference
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testBrowserYesNoPreference_RESET_TO_DEFAULT() throws Exception {
//		mActivity.finish();
//		SystemClock.sleep(2000);
//		Intent intent = new Intent(Intent.ACTION_VIEW);
//		intent.setClass(mInst.getTargetContext(), BrowserActivity.class);
//		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//		BrowserActivity activity = (BrowserActivity) mInst
//				.startActivitySync(intent);
//		SystemClock.sleep(20000);
//		activity.goQuit();
//		activity.finish();
//		SystemClock.sleep(2000);
//		mActivity = getPerferenceActivity();
		clickSettingItem(mInst, mlistView, BrowserSetting.RESET_TO_DEFAULT);
		confirmDialogClick(ONCLICKDILOG_OK);
	}
	
	//************************************Help Method
	private BrowserPreferencesPage getPerferenceActivity() throws Exception {
		BrowserPreferencesPage browserPreferencesPage;
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setClassName("com.android.browser", BrowserPreferencesPage.class
				.getName());
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		browserPreferencesPage = (BrowserPreferencesPage) mInst
				.startActivitySync(intent);
		return browserPreferencesPage;
	}

	private static void clickSettingItem(Instrumentation inst, ListView lv,
			BrowserSetting settingItem) {
		int position = 0;
		for (BrowserSetting item : BrowserSetting.values()) {
			if (settingItem.equals(item))
				break;
			position++;
		}
		inst.runOnMainSync(new SelectListItem(lv, position));
		inst.waitForIdleSync();
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
		View listItem = lv.getChildAt(position - lv.getFirstVisiblePosition());
		int[] location = { 0, 0 };
		listItem.getLocationOnScreen(location);

		location[0] += (listItem.getWidth() / 2);
		location[1] += (listItem.getHeight() / 2);

		long downTime = SystemClock.uptimeMillis();
		MotionEvent mv = MotionEvent.obtain(downTime, SystemClock
				.uptimeMillis(), KeyEvent.ACTION_DOWN, location[0],
				location[1], 0);
		inst.sendPointerSync(mv);
		inst.waitForIdleSync();
		SystemClock.sleep(ViewConfiguration.getPressedStateDuration());
		mv = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(),
				KeyEvent.ACTION_UP, location[0], location[1], 0);
		inst.sendPointerSync(mv);
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
	}

	private static class SelectListItem implements Runnable {
		ListView mListView;
		int mPosition;

		public SelectListItem(ListView lv, int pos) {
			mListView = lv;
			mPosition = pos;
		}

		public void run() {
			mListView.setSelection(mPosition);
		}
	}

	private enum BrowserSetting {
		// Order must be consistent with the Setting List order
		PAGE_CONTENT_SETTINGS("Page content settings"), SET_DEFAULT_ZOOM(
				"Set default zoom"), SET_TEXT_ENCODING("Set text encoding"), BLOCK_POPUP_WINDOWS(
				"Block pop-up windows"), LOAD_IMAGES("Load images"),
		// FIT_SCREEN_WIDTH("fit_screen_width"),//no
		ENABLE_JAVASCRIPT("Enable JavaScript"),
		PREVIEW_MODE("Preview mode"), // yes
		OPEN_IN_BACKGROUND("open_in_background"),
		SET_HOME_PAGE("Set home page"), RESET_HOME_PAGE("Reset home page"),
		// SELECT_PRELOAD_HOME_PAGE("homepage"),
		SEARCH_PORTAL("Search portal"), NETWORK("Network"), DATA_CONNECTION(
				"Data connection"), PRIVACY_SETTINGS("Privacy settings"), CLEAR_CACHE(
				"Clear cache"), CLEAR_HISTORY("Clear history"), ACCEPT_COOKIES(
				"Accept cookies"), CLEAR_ALL_COOKIES_DATA(
				"Clear all cookie data"), REMEMBER_FORM_DATA(
				"Remember form data"), CLEAR_FORM_DATA("Clear form data"), SECURITY_SETTINGS(
				"Security settings"), REMEMBER_PASSWORDS("Remember passwords"), CLEAR_PASSWORDS(
				"Clear passwords"), SHOW_SECURITY_WARNINGS(
				"Show security warnings"), ADVANCED_SETTINGS(
				"Advanced settings"),
		// EXTRAS("Extras"),
		// ENABLE_GEARS("enable_gears"),
		// GEARS_SETTINGS("gear settings"),
		RESET_TO_DEFAULT("Reset to default"), SET_DOWNLOAD_DIRCETORY(
				"set download directory"), DOWNLOAD_MEDIA_FILES(
				"Download media files");
		// Constructor
		BrowserSetting(String prefKey) {
			mKey = prefKey;
		}

		final String mKey;
		//b392 5.21
//		public final String prefKey() {
//			return mKey;
//		}
//
//		public static int settingItemCount() {
//			return BrowserSetting.values().length;
//		}
//end
	}

	private void confirmDialogClick(boolean  yesOrNo) {
		int id = -1;
		Instrumentation inst = getInstrumentation();
		if(yesOrNo){
			id = 1;
		}
		else if(!yesOrNo){
			id = 0;
		}
		switch (id) {
		case 1: {
			inst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_DOWN);
			inst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_LEFT);
			inst.waitForIdleSync();
			inst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_CENTER);
			inst.waitForIdleSync();
			SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
			break;
		}
		case 0: {
			inst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_DOWN);
			inst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_RIGHT);
			inst.waitForIdleSync();
			inst.sendCharacterSync(KeyEvent.KEYCODE_DPAD_CENTER);
			inst.waitForIdleSync();
			SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
			break;
		}
		default:
			break;
		}
	}
}
