package com.android.browser;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.Suppress;
import android.webkit.WebViewClient;

import com.android.browser.unittests.testutil.Helper;
import com.android.browser.unittests.testutil.ReflectHelper;

/**
 * This class tests BrowserActivity start activity by the way of UI
 * 
 * @author maying
 * 
 */
@Suppress
public class BrowserActivityUIITest extends InstrumentationTestCase {

	// copy from source code
	final static int BOOKMARKS_PAGE = 1;
	final static int CLASSIC_HISTORY_PAGE = 2;
	final static int DOWNLOAD_PAGE = 3;
	final static int PREFERENCES_PAGE = 4;
	final static int SEARCH_PAGE = 5;
	final static int FILE_PICK_UI = 21;
	final static int EXTRA_MENU = 10;

	/* package */final static String SCHEME_WTAI = "wtai://wp/";
	/* package */final static String SCHEME_WTAI_MC = "wtai://wp/mc;";
	/* package */final static String SCHEME_WTAI_SD = "wtai://wp/sd;";
	/* package */final static String SCHEME_WTAI_AP = "wtai://wp/ap;";
	//

	private static BrowserActivity mBrowserActivity;
	private Instrumentation mInst;
	private Context mCtx;
	private static Intent mIntent;
//	private static final String FILENAME = "test.txt";
	private static final String FILENAME = "test.html";
//	private static final String MOCK_PACKAGE = "mock.pkg";
//	private static final String MOCK_CLASS = "mock.pkg.TestClass";
//	private static final String FILEPATH = "file:///sdcard/test.txt";
	private static final String FILEPATH = "file:///sdcard/test.html";
	
	private static int count = 0;

	private Instrumentation.ActivityMonitor mMonitor;

	public BrowserActivityUIITest() {
		count ++;
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = this.getInstrumentation();
		mCtx = mInst.getTargetContext();
		mIntent = new Intent(Intent.ACTION_VIEW);
		mInst.setInTouchMode(false);
		if(mBrowserActivity == null){
			Helper.createFileToSdcard(mInst.getContext(), FILENAME,
					Helper.SDCARDPATH);
			mBrowserActivity = launchActivity(FILEPATH);
		}
		
	}

	@Override
	protected void tearDown() throws Exception {
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
		if(--count == 0 && mBrowserActivity != null){
			finishActivity();
			Helper.deleteAllFileAndFolderExceptSelf(Helper.SDCARDPATH);
			mIntent = null;
		}
		if(mMonitor != null){
			mInst.removeMonitor(mMonitor);
		}
		mMonitor = null;
		mCtx = null;
		mInst = null;
		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
		super.tearDown();
	}

	//test method
//	/**
//	 * This method tests launch activity use mock server.
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testLaunchActivityStartServer() throws Exception {
//		//b392 5.20
//		assertNotNull(mBrowserActivity);
//		mBrowserActivity.goQuit();
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		mIntent.setData(Uri.parse(Helper.URL));
//		mBrowserActivity.onNewIntent(mIntent);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		assertTrue(MockServer.start(Helper.SERVERPORT, Helper.SDCARDPATH));
//		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
//		
//		MockServer.stop();
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		finishActivity();
//		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
//	}
	
	
	//remove reason: can't press OK button, the process will be killed.
//	/**
//	 * This method tests OnOptionsItemSelected and the menu is exit_menu_id and
//	 * click OK.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void test01OnOptionsItemSelectedexit_menu_idOK() throws Exception {
////		mBrowserActivity = launchActivity(FILEPATH);
//		assertNotNull(mBrowserActivity);
//		mInst.invokeMenuActionSync(mBrowserActivity, R.id.exit_menu_id, 0);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//		clickOK();
//		SystemClock.sleep(15000);
//		mBrowserActivity = null;
//	}

	/**
	 * This method tests OnOptionsItemSelected and the menu is exit_menu_id and
	 * click cancel.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnOptionsItemSelectedexit_menu_idCancel() throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.exit_menu_id, 0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		clickCancel();
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

	/**
	 * This method tests OnOptionsItemSelected and the menu is find_menu_id.
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testOnOptionsItemSelectedfind_menu_idCancel() throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.find_menu_id, 0);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		//click menu "x".
		Helper.HardKey.back(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.right(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}

//	/**
//	 * This method tests OnContextItemSelected and the menu is
//	 * open_newtab_context_menu_id.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testOnContextItemSelectedopen_newtab_context_menu_id()
//			throws Exception {
////		mBrowserActivity = launchActivity(FILEPATH);
//		assertNotNull(mBrowserActivity);
//		Helper.HardKey.down(mInst);
//		mInst.invokeContextMenuAction(mBrowserActivity,
//				R.id.open_newtab_context_menu_id, 0);
//		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
//	}

	/**
	 * This method tests OnKeyDown and request code is KEYCODE_SPACE.
	 * 
	 * @throws Exception
	 */
	/*	@LargeTest
	public void testOnKeyDownKEYCODE_SPACE() throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		assertNotNull(mBrowserActivity);
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				assertTrue(mBrowserActivity.onKeyDown(KeyEvent.KEYCODE_SPACE,
						new KeyEvent(KeyEvent.ACTION_DOWN,
								KeyEvent.KEYCODE_SPACE)));
			}
		});

	}*/

	/**
	 * This method tests OnKeyDown and request code is KEYCODE_MENU.
	 * 
	 * @throws Exception
	 */
/*	@LargeTest
	public void testOnKeyDownKEYCODE_MENU() throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		assertNotNull(mBrowserActivity);
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				mBrowserActivity.onKeyDown(KeyEvent.KEYCODE_MENU, new KeyEvent(
						KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MENU));
			}
		});

	}*/

	// /**
	// * this case tests do flick on the blank place
	// */
	// public void testDoFlick() {
	// mBrowserActivity = launchActivity(FILEPATH);
	// MotionEvent event = MotionEvent.obtain(0, 500, MotionEvent.ACTION_DOWN,
	// 50, 50, 0);
	// mInst.sendPointerSync(event);
	// event = MotionEvent.obtain(0, 500, MotionEvent.ACTION_MOVE, 0, 50, 0);
	// mInst.sendPointerSync(event);
	// event = MotionEvent.obtain(0, 500, MotionEvent.ACTION_UP, 0, 50, 0);
	// mInst.sendPointerSync(event);
	// }
	/**
	 * This method tests onActivityResult and requestcode is PREFERENCES_PAGE.
	 * 
	 * @throws Exception
	 */
/*	@LargeTest
	public void testOnActivityResultPREFERENCES_PAGE() throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		mMonitor = new Instrumentation.ActivityMonitor(BrowserPreferencesPage.class.getName(), null, true);
		mInst.addMonitor(mMonitor);
		assertNotNull(mBrowserActivity);
		Intent intent = new Intent(mBrowserActivity,
				BrowserPreferencesPage.class);
		Intent data = new Intent(Helper.URL);
		Bundle bundle = new Bundle();
		bundle.putBoolean("new_window", false);
		ActivityResult result = new ActivityResult(Activity.RESULT_OK, data);

		mInst.addMonitor(BrowserPreferencesPage.class.getName(), result, true);
		mBrowserActivity.startActivityForResult(intent, PREFERENCES_PAGE);
	}*/

	
	/**
	 * This method tests reload().
	 * 
	 * @throws Exception
	 */
/*	@LargeTest
	public void testReload() throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		assertNotNull(mBrowserActivity);
		mBrowserActivity.reload();
	}*/

//	/**
//	 * This method tests titleSelected.
//	 * 
//	 * @throws Exception
//	 */
//	@LargeTest
//	public void testTitleSelected() throws Exception {
////		mBrowserActivity = launchActivity(FILEPATH);
//		assertNotNull(mBrowserActivity);
//		mBrowserActivity.titleSelected();
//		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
//		Helper.HardKey.back(mInst);
//		SystemClock.sleep(Helper.WAIT_FOR_LONGTIME);
//	}
	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.advanced_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedadvanced_menu_idSET_AS_HOMEPAGE()
			throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		mMonitor = new Instrumentation.ActivityMonitor(BrowserExtraMenuPage.class.getName(), null, false);
		mInst.addMonitor(mMonitor);
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.advanced_menu_id, 0);
		SystemClock.sleep(10000);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		BrowserExtraMenuPage browserExtraMenuPage = (BrowserExtraMenuPage) Helper.waitForActivity(mMonitor);
		if(browserExtraMenuPage != null){
			browserExtraMenuPage.finish();
		}
	}

	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.advanced_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedadvanced_menu_idPAGE_INFO()
			throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		mMonitor = new Instrumentation.ActivityMonitor(BrowserExtraMenuPage.class.getName(), null, false);
		mInst.addMonitor(mMonitor);
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.advanced_menu_id, 0);
		SystemClock.sleep(10000);
		//select PAGE_INFO menu and click
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
		//
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		//click ok
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
		//
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		BrowserExtraMenuPage browserExtraMenuPage = (BrowserExtraMenuPage) Helper.waitForActivity(mMonitor);
		if(browserExtraMenuPage != null){
			browserExtraMenuPage.finish();
		}
	}
	
	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.advanced_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedadvanced_menu_idPAGE_INFOCancel()
			throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		mMonitor = new Instrumentation.ActivityMonitor(BrowserExtraMenuPage.class.getName(), null, false);
		mInst.addMonitor(mMonitor);
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.advanced_menu_id, 0);
		SystemClock.sleep(10000);
		//select PAGE_INFO menu and click
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
		//
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.back(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		BrowserExtraMenuPage browserExtraMenuPage = (BrowserExtraMenuPage) Helper.waitForActivity(mMonitor);
		if(browserExtraMenuPage != null){
			browserExtraMenuPage.finish();
		}
	}

	
	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.advanced_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedadvanced_menu_idSHARE_PAGE()
			throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		mMonitor = new Instrumentation.ActivityMonitor(BrowserExtraMenuPage.class.getName(), null, false);
		mInst.addMonitor(mMonitor);
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.advanced_menu_id, 0);
		SystemClock.sleep(10000);
		//select SHARE_PAGE menu and click
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
		//
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.back(mInst);
		BrowserExtraMenuPage browserExtraMenuPage = (BrowserExtraMenuPage) Helper.waitForActivity(mMonitor);
		if(browserExtraMenuPage != null){
			browserExtraMenuPage.finish();
		}
	}

	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.advanced_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedadvanced_menu_idFULL_SCREEN()
			throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		mMonitor = new Instrumentation.ActivityMonitor(BrowserExtraMenuPage.class.getName(), null, false);
		mInst.addMonitor(mMonitor);
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.advanced_menu_id, 0);
		SystemClock.sleep(10000);
		//select FULL_SCREEN menu and click
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
		//
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		BrowserExtraMenuPage browserExtraMenuPage = (BrowserExtraMenuPage) Helper.waitForActivity(mMonitor);
		if(browserExtraMenuPage != null){
			browserExtraMenuPage.finish();
		}
	}

	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.advanced_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedadvanced_menu_idLOCK_ORIENTATION()
			throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		mMonitor = new Instrumentation.ActivityMonitor(BrowserExtraMenuPage.class.getName(), null, false);
		mInst.addMonitor(mMonitor);
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.advanced_menu_id, 0);
		SystemClock.sleep(10000);
		//select LOCK_ORIENTATION menu and click
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
		//
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		BrowserExtraMenuPage browserExtraMenuPage = (BrowserExtraMenuPage) Helper.waitForActivity(mMonitor);
		if(browserExtraMenuPage != null){
			browserExtraMenuPage.finish();
		}
	}

	/**
	 * This method test onOptionsItemSelected and menu id is
	 * R.id.advanced_menu_id.
	 */
	@LargeTest
	public void testOnOptionsItemSelectedadvanced_menu_idFIND_ON_PAGE()
			throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		mMonitor = new Instrumentation.ActivityMonitor(BrowserExtraMenuPage.class.getName(), null, false);
		mInst.addMonitor(mMonitor);
		assertNotNull(mBrowserActivity);
		mInst.invokeMenuActionSync(mBrowserActivity, R.id.advanced_menu_id, 0);
		SystemClock.sleep(10000);
		//select find_on_page menu and click
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.down(mInst);
		Helper.HardKey.center(mInst);
		//
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.back(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.right(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		Helper.HardKey.center(mInst);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		BrowserExtraMenuPage browserExtraMenuPage = (BrowserExtraMenuPage) Helper.waitForActivity(mMonitor);
		if(browserExtraMenuPage != null){
			browserExtraMenuPage.finish();
		}
	}

	/**
	 * This method tests onMenuOpened().
	 * 
	 * @throws Exception
	 */
/*	@LargeTest
	public void testOnMenuOpened() throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);

		assertNotNull(mBrowserActivity);
		assertTrue(mBrowserActivity.onMenuOpened(Window.FEATURE_OPTIONS_PANEL, null));
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}*/

	/**
	 * This method tests onMenuOpened().
	 * 
	 * @throws Exception
	 */
/*	@LargeTest
	public void testOnMenuOpenedmOptionsMenuOpenmConfigChangedIsTrue()
			throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);

		assertNotNull(mBrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mOptionsMenuOpen",
				true);
		ReflectHelper.setPrivateField(mBrowserActivity, "mConfigChanged", true);
		assertTrue(mBrowserActivity.onMenuOpened(Window.FEATURE_OPTIONS_PANEL, null));
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}*/
	/**
	 * This method tests onMenuOpened().
	 * 
	 * @throws Exception
	 */
/*	@LargeTest
	public void testOnMenuOpenedmOptionsMenuOpenTruemConfigChangedFalse()
			throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);

		assertNotNull(mBrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mOptionsMenuOpen",
				true);
		assertTrue(mBrowserActivity.onMenuOpened(Window.FEATURE_OPTIONS_PANEL, null));
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}*/
	/**
	 * This method tests onMenuOpened().
	 * 
	 * @throws Exception
	 */
/*	@LargeTest
	public void testOnMenuOpenedmOptionsMenuOpenTruemConfigChangedFalsemIconViewTrue()
			throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);

		assertNotNull(mBrowserActivity);
		ReflectHelper.setPrivateField(mBrowserActivity, "mOptionsMenuOpen",
				true);
		ReflectHelper.setPrivateField(mBrowserActivity, "mIconView", true);
		assertTrue(mBrowserActivity.onMenuOpened(Window.FEATURE_OPTIONS_PANEL, null));
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}*/

	/**
	 * This method tests shouldOverrideUrlLoading().
	 * 
	 * @throws Exception
	 */
/*	@LargeTest
	public void testShouldOverrideUrlLoadingSCHEME_WTAI_MC() throws Exception {
		String url = SCHEME_WTAI_MC + "10086";
		String webViewClientS = "mWebViewClient";
//		mBrowserActivity = launchActivity(FILEPATH);

		assertNotNull(mBrowserActivity);
		WebViewClient webViewClient = (WebViewClient) ReflectHelper
				.getPrivateField(mBrowserActivity, webViewClientS);
		assertNotNull(webViewClient);
		Intent intent = new Intent(Intent.ACTION_VIEW, Uri
				.parse(WebView.SCHEME_TEL
						+ url.substring(SCHEME_WTAI_MC.length())));
		String action = intent.getAction();
		IntentFilter filter = new IntentFilter(action);
		filter.addDataScheme("tel");
		filter.addCategory("android.intent.category.BROWSABLE");
		mMonitor = new Instrumentation.ActivityMonitor(filter, null, true);
		mInst.addMonitor(mMonitor);

		assertTrue(webViewClient.shouldOverrideUrlLoading(null, url));
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}*/

	/**
	 * This method tests shouldOverrideUrlLoading().
	 * 
	 * @throws Exception
	 */
/*	@LargeTest
	public void testShouldOverrideUrlLoadingSCHEME_WTAI_SD() throws Exception {
		//b392 5.20
		IntentFilter intentFl = new IntentFilter(Intent.ACTION_VIEW);
		intentFl.addDataScheme("tel");
		mMonitor = new Instrumentation.ActivityMonitor(intentFl, null, true);
		mInst.addMonitor(mMonitor);
		//end
		String url = SCHEME_WTAI_SD + "10086";
		String webViewClientS = "mWebViewClient";
//		mBrowserActivity = launchActivity(FILEPATH);

		assertNotNull(mBrowserActivity);
		WebViewClient webViewClient = (WebViewClient) ReflectHelper
				.getPrivateField(mBrowserActivity, webViewClientS);

		assertNotNull(webViewClient);
		assertTrue(webViewClient.shouldOverrideUrlLoading(null, url));
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}*/

	/**
	 * This method tests shouldOverrideUrlLoading().
	 * 
	 * @throws Exception
	 */
/*	@LargeTest
	public void testShouldOverrideUrlLoadingSCHEME_WTAI_AP() throws Exception {
		String url = SCHEME_WTAI_AP + "10086;abc";
		String webViewClientS = "mWebViewClient";
//		mBrowserActivity = launchActivity(FILEPATH);
		assertNotNull(mBrowserActivity);
		WebViewClient webViewClient = (WebViewClient) ReflectHelper
				.getPrivateField(mBrowserActivity, webViewClientS);
		assertNotNull(webViewClient);
		String action = Intent.ACTION_INSERT;
		IntentFilter filter = new IntentFilter(action);
		filter.addDataType("vnd.android.cursor.dir/person");
		mMonitor = new Instrumentation.ActivityMonitor(filter, null, true);
		mInst.addMonitor(mMonitor);
		
		assertTrue(webViewClient.shouldOverrideUrlLoading(null, url));
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}*/

	/**
	 * This method tests shouldOverrideUrlLoading().
	 * 
	 * @throws Exception
	 */
/*	@LargeTest
	public void testShouldOverrideUrlLoading() throws Exception {
		String url = "mms:10086?subject=MMS+Testing&body=MMS";
		String webViewClientS = "mWebViewClient";
//		mBrowserActivity = launchActivity(FILEPATH);
		assertNotNull(mBrowserActivity);
		WebViewClient webViewClient = (WebViewClient) ReflectHelper
				.getPrivateField(mBrowserActivity, webViewClientS);
		assertNotNull(webViewClient);
		String action = Intent.ACTION_SENDTO;
		IntentFilter filter = new IntentFilter(action);
		filter.addDataScheme("mmsto");
		filter.addCategory("android.intent.category.BROWSABLE");
		mMonitor = new Instrumentation.ActivityMonitor(filter, null, true);
		mInst.addMonitor(mMonitor);
		
		assertTrue(webViewClient.shouldOverrideUrlLoading(null, url));
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}*/
	
	/**
	 * This method tests shouldOverrideUrlLoading().
	 * 
	 * @throws Exception
	 */
	@LargeTest
	//TODO
	public void testShouldOverrideUrlLoadingfile() throws Exception {
//		mBrowserActivity = launchActivity(FILEPATH);
		String webViewClientS = "mWebViewClient";
		assertNotNull(mBrowserActivity);
		WebViewClient webViewClient = (WebViewClient) ReflectHelper
				.getPrivateField(mBrowserActivity, webViewClientS);
		assertNotNull(webViewClient);
		webViewClient.shouldOverrideUrlLoading(null, "content://contacts/people/1");
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
	}
	
	/**
	 * This method tests OnNetworkToggle.
	 * @throws Exception
	 */
	@LargeTest
	//TODO
	public void testOnNetworkToggle() throws Exception{
		assertNotNull(mBrowserActivity);
		mBrowserActivity.onNetworkToggle(true);
		ReflectHelper.setPrivateField(mBrowserActivity, "mInLoad", true);
		mBrowserActivity.onNetworkToggle(false);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		mBrowserActivity.onNetworkToggle(true);
	}
	
	
	// help method
	private BrowserActivity launchActivity(String url) {
		mIntent.setClass(mCtx, BrowserActivity.class);
		mIntent.setData(Uri.parse(url));
		mIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		mBrowserActivity = (BrowserActivity) mInst.startActivitySync(mIntent);
		SystemClock.sleep(60000);
		return mBrowserActivity;
	}

//	private void clickOK() {
//		Helper.HardKey.down(mInst);
//		Helper.HardKey.left(mInst);
//		Helper.HardKey.center(mInst);
//	}

	private void clickCancel() {
		Helper.HardKey.down(mInst);
		Helper.HardKey.right(mInst);
		Helper.HardKey.center(mInst);
	}

	private void finishActivity() throws Exception {
		if (mBrowserActivity != null) {
			mBrowserActivity.runOnUiThread(new Runnable() {
				public void run() {
					mBrowserActivity.goQuit();
				}
			});
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		}
	}
	
}
