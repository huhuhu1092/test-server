package com.android.browser;

import android.test.AndroidTestCase;
import android.test.suitebuilder.annotation.MediumTest;
import android.test.suitebuilder.annotation.SmallTest;

/**
 * test SearchPortal.java.
 * 
 * @author Tang Ting
 * 
 */
public class SearchPortalTest extends AndroidTestCase {
	private SearchPortal mSearchPortal;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mSearchPortal = new SearchPortal();
	}

	@Override
	protected void tearDown() throws Exception {
		mSearchPortal = null;
		super.tearDown();
	}

	/**
	 * test getInstance
	 */
	@MediumTest
	public void testgetInstance() {
		assertNotNull(SearchPortal.getInstance());
	}

	/**
	 * test getSearchString
	 */
	@SmallTest
	public void testgetSearchString() {
		mSearchPortal = new SearchPortal();
		mSearchPortal.initSearchString(getContext());
		mSearchPortal.initSearchString(getContext());
		assertNotNull(mSearchPortal.getSearchString());
	}

}
