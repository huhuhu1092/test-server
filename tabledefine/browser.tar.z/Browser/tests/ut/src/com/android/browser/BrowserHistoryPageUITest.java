package com.android.browser;

import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.Browser.BookmarkColumns;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.KeyEvent;

import com.android.browser.unittests.testutil.Helper;

/**
 * tests BrowserHistoryPage.java.
 * 
 * @author Tang Ting
 * 
 */
public class BrowserHistoryPageUITest extends InstrumentationTestCase {
	private static final int SHORT_TIME = 2500;
	private static final String HISTORY_TITLE = "borqs";
	private static final String HISTORY_URL = "www.borqs.com";
	private static final int HISTORY_VISITED_TIME = 10;

	private Instrumentation mInst;

	BrowserHistoryPage mBrowserHistoryPage;

	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mInst.setInTouchMode(false);
		addOneHistory(HISTORY_TITLE, HISTORY_URL, HISTORY_VISITED_TIME);
	}

	@Override
	protected void tearDown() throws Exception {
		if (mBrowserHistoryPage != null) {
			mBrowserHistoryPage.finish();
			SystemClock.sleep(SHORT_TIME);
			mBrowserHistoryPage = null;
		}
		mInst = null;
		clearHistory();
		super.tearDown();
	}

	/**
	 * tests titleSelected
	 */
	@LargeTest
	public void testtitleSelected() {
		mBrowserHistoryPage = launchActvitiy();
		assertNotNull(mBrowserHistoryPage);
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				mBrowserHistoryPage.titleSelected();
			}
		});
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				mBrowserHistoryPage.titleSelected();
			}
		});
	}

	/**
	 * tests onKeyDown
	 */
	@LargeTest
	public void testonKeyDown() {
		mBrowserHistoryPage = launchActvitiy();
		assertNotNull(mBrowserHistoryPage);
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				mBrowserHistoryPage.titleSelected();
			}
		});
		mInst.runOnMainSync(new Runnable() {
			public void run() {
				int keyCode = KeyEvent.KEYCODE_BACK;
				KeyEvent keyEvent = new KeyEvent(KeyEvent.ACTION_DOWN,
						KeyEvent.KEYCODE_BACK);
				assertTrue(mBrowserHistoryPage.onKeyDown(keyCode, keyEvent));
			}
		});
	}

	/**
	 * tests onOptionsItemSelected with chose the menuItem of clear history
	 */
	@LargeTest
	public void testonOptionsItemClearHistorySelected() {
		mBrowserHistoryPage = launchActvitiy();
		assertNotNull(mBrowserHistoryPage);
		mInst.invokeMenuActionSync(mBrowserHistoryPage, R.id.clear_history_menu_id, 0);
		SystemClock.sleep(SHORT_TIME);

		mInst.invokeMenuActionSync(mBrowserHistoryPage, R.id.select_all_history_menu_id, 0);
		SystemClock.sleep(SHORT_TIME);

		mInst.invokeMenuActionSync(mBrowserHistoryPage, R.id.unselect_all_history_menu_id, 0);
		SystemClock.sleep(SHORT_TIME);

		// choose the first history page
		Helper.HardKey.down(mInst);
		Helper.HardKey.enter(mInst);
		SystemClock.sleep(SHORT_TIME);

		mInst.invokeMenuActionSync(mBrowserHistoryPage, R.id.remove_multiple_history_menu_id, 0);
	}

	/**
	 * tests onOptionsItemSelected with chose the menuItem of clear today
	 * history
	 */
	@LargeTest
	public void testonOptionsItemClearTodayHistorySelected() {
		mBrowserHistoryPage = launchActvitiy();
		assertNotNull(mBrowserHistoryPage);
		mInst.invokeMenuActionSync(mBrowserHistoryPage, R.id.clear_today_history_menu_id, 0);
		SystemClock.sleep(SHORT_TIME);

		pressOK();
	}

	/**
	 * tests onOptionsItemSelected with chose the menuItem of sort history
	 */
	@LargeTest
	public void testonOptionsItemSortSelected() {
		mBrowserHistoryPage = launchActvitiy();
		assertNotNull(mBrowserHistoryPage);
		mInst.invokeMenuActionSync(mBrowserHistoryPage, R.id.sort_history_menu_id, 0);

		// press three times up to ensure that it choose the Time Sort
		Helper.HardKey.up(mInst);
		Helper.HardKey.up(mInst);
		Helper.HardKey.up(mInst);
		Helper.HardKey.enter(mInst);
		SystemClock.sleep(SHORT_TIME);

		// choose Visits Sort
		mInst.invokeMenuActionSync(mBrowserHistoryPage, R.id.sort_history_menu_id, 0);
		Helper.HardKey.down(mInst);
		SystemClock.sleep(SHORT_TIME);
		Helper.HardKey.enter(mInst);
		SystemClock.sleep(SHORT_TIME);

		// choose URL address Sort
		mInst.invokeMenuActionSync(mBrowserHistoryPage, R.id.sort_history_menu_id, 0);
	}

	/**
	 * tests onContextItemSelected with chose the menuItem of open in new
	 * windows
	 */
	@LargeTest
	public void testonContextItemOpenInNewWindowsSelected() {
		mBrowserHistoryPage = launchActvitiy();
		assertNotNull(mBrowserHistoryPage);
		SystemClock.sleep(SHORT_TIME);
		Helper.HardKey.down(mInst);
		mInst.invokeContextMenuAction(mBrowserHistoryPage, R.id.new_window_context_menu_id, 0);
	}

	/**
	 * tests onContextItemSelected with chose the menuItem of book mark link
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonContextItemBookmarkLinkSelected() throws Exception {
		IntentFilter intentFilter = new IntentFilter(Intent.ACTION_INSERT);
		intentFilter.addCategory("android.intent.category.DEFAULT");
		intentFilter.addDataType("vnd.android.cursor.dir/bookmark");
		Instrumentation.ActivityMonitor bookmarkLinkMonitor = new Instrumentation.ActivityMonitor(
				intentFilter, null, true);
		mBrowserHistoryPage = launchActvitiy();
		assertNotNull(mBrowserHistoryPage);
		mInst.addMonitor(bookmarkLinkMonitor);
		SystemClock.sleep(SHORT_TIME);
		try {
			Helper.HardKey.down(mInst);
			SystemClock.sleep(SHORT_TIME);
			mInst.invokeContextMenuAction(mBrowserHistoryPage,
					R.id.save_to_bookmarks_menu_id, 0);
		} finally {
			mInst.removeMonitor(bookmarkLinkMonitor);
		}
	}

	/**
	 * tests onContextItemSelected with chose the menuItem of share link
	 * 
	 * @throws Exception
	 */
	@LargeTest
	public void testonContextItemShareLinkSelected() throws Exception {
		String setType = "text/plain";
		mBrowserHistoryPage = launchActvitiy();
		assertNotNull(mBrowserHistoryPage);
		SystemClock.sleep(SHORT_TIME);
		Helper.HardKey.down(mInst);
		SystemClock.sleep(SHORT_TIME);

		Intent intent = new Intent(Intent.ACTION_SEND);
		intent.setType(setType);
		Intent chooserIntent = Intent.createChooser(intent, null);
		IntentFilter filter = new IntentFilter(chooserIntent.getAction());
		Instrumentation.ActivityMonitor monitor = mInst.addMonitor(filter, null, true);
		try {
			mInst.invokeContextMenuAction(mBrowserHistoryPage,
					R.id.share_link_context_menu_id, 0);
			SystemClock.sleep(SHORT_TIME);
		} finally {
			mInst.removeMonitor(monitor);
		}
	}

	/**
	 * tests onContextItemSelected with chose the menuItem of copy link
	 */
	@LargeTest
	public void testonContextItemCopyLinkSelected() {
		mBrowserHistoryPage = launchActvitiy();
		Helper.HardKey.down(mInst);
		SystemClock.sleep(SHORT_TIME);
		mInst.invokeContextMenuAction(mBrowserHistoryPage, R.id.copy_context_menu_id, 0);
	}

	/**
	 * tests onContextItemSelected with chose the menuItem of remove from
	 * history
	 */
	@LargeTest
	public void testonContextItemRemoveSelected() {
		mBrowserHistoryPage = launchActvitiy();
		Helper.HardKey.down(mInst);
		SystemClock.sleep(SHORT_TIME);
		mInst.invokeContextMenuAction(mBrowserHistoryPage, R.id.delete_context_menu_id, 0);
		SystemClock.sleep(SHORT_TIME);

		pressOK();
	}

	// *******************************************************************************************
	// helper method

	// Insert History to DB.
	private void addOneHistory(String title, String url, int time) {
		final Uri BOOKMARKS_URI = Uri.parse("content://browser/bookmarks");
		ContentResolver resolver = mInst.getContext().getContentResolver();
		ContentValues value = new ContentValues();
		value.put(BookmarkColumns.TITLE, title);
		value.put(BookmarkColumns.URL, url);
		value.put(BookmarkColumns.VISITS, time);
		value.put(BookmarkColumns.BOOKMARK, "0");
		Uri uri = resolver.insert(BOOKMARKS_URI, value);
		assertNotNull("Insert history to DB failed! ", uri);
		SystemClock.sleep(SHORT_TIME);
	}

	// clear History in DB
	private void clearHistory() {
		final Uri BOOKMARKS_URI = Uri.parse("content://browser/bookmarks");
		ContentResolver resolver = getInstrumentation().getContext()
				.getContentResolver();
		resolver.delete(BOOKMARKS_URI, null, null);
		SystemClock.sleep(SHORT_TIME);
		Cursor c = resolver.query(BOOKMARKS_URI, null, null, null, null);
		assertEquals(0, c.getCount());

		c.close();
		c = null;
	}

	// launch BrowserHistoryPage Activity
	private BrowserHistoryPage launchActvitiy() {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName(mInst.getTargetContext(), BrowserHistoryPage.class
				.getName());
		BrowserHistoryPage browserHistoryPage = (BrowserHistoryPage) mInst.startActivitySync(intent);
		SystemClock.sleep(10000);
		return browserHistoryPage;
	}

	// press OK
	private void pressOK() {
		Helper.HardKey.enter(mInst);
		SystemClock.sleep(SHORT_TIME);
	}
}
