package com.android.browser;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.test.InstrumentationTestCase;
import android.test.suitebuilder.annotation.LargeTest;
import android.test.suitebuilder.annotation.MediumTest;
import android.test.suitebuilder.annotation.Suppress;

import com.android.browser.TabControl.Tab;
/**test the class TabControl
 * @author b364-Pang Hongwei*/

@Suppress
public class TabControlTest extends InstrumentationTestCase {
	public TabControlTest(){
		super();
		caseCount++;
	}
	private Instrumentation mInst;
	private Context mTargetContext;
	private static BrowserActivity mActivity;
	private static boolean activityIfLive=false;
	private static int caseCount=0;
	private static final int MAX_TABS = 8;
	
	private static final String NUMTABS = "numTabs";
	private static final String WEBVIEW = "webview";
    private static final String CURRTAB = "currentTab";
    private static final String CLOSEONEXIT = "closeonexit";
    private static final String PARENTTAB = "parentTab";
    private static final String APPID = "appid";
    private static final String ORIGINALURL = "originalUrl";
    
    @Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst=getInstrumentation();
		mTargetContext=mInst.getTargetContext();
	}
    
	@Override
	protected void tearDown() throws Exception {
		if(--caseCount==0){
			mActivity.goQuit();
			SystemClock.sleep(15000);
			mActivity=null;
			activityIfLive=false;
		}
			mInst=null;
		if(mTargetContext!=null){
			mTargetContext=null;
		}
		super.tearDown();
	}

	/**launching BrowserActivity and return its object.
	 * @throws Exception
	 * */
	private BrowserActivity launchActivity()throws Exception{
		BrowserActivity activity=null;
		if(!activityIfLive){
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.setClassName("com.android.browser", BrowserActivity.class.getName());
			activity =(BrowserActivity)mInst.startActivitySync(intent);
			SystemClock.sleep(60000);
			assertNotNull(activity);
			activityIfLive=true;
		}
		return activity!=null?activity:mActivity;
	}
	/**test tab controled.
	 * @throws Exception
	 * */
	@LargeTest
	public void testT001TabControled()throws Exception{
		mActivity= launchActivity();
		TabControl tabControl = new TabControl(mActivity);
		Tab  tab0=tabControl.createNewTab(false, "ID-0", null);
		assertNull(tab0.getUrl());
		assertNull(tab0.getTitle());
		assertNull(tab0.getFavicon());
		assertFalse(tab0.closeOnExit());
		//test getTabFromId();
		assertEquals(1,tabControl.getTabCount());
		assertEquals(tab0,tabControl.getTabFromId("ID-0"));
		assertNull(tabControl.getTabFromId(null));
		assertNull(tabControl.getTabFromId("uselessID"));
		//test getTab(int index);
		assertEquals(tab0,tabControl.getTab(0));
		assertNull(tabControl.getTab(-1));
		//test getTabIndex(Tab t).
		assertEquals(0,tabControl.getTabIndex(tab0));
		assertEquals(-1,tabControl.getTabIndex(null));
		//test SetCurrentTab(Tab t).
		assertTrue(tabControl.setCurrentTab(tab0));
		assertFalse(tabControl.setCurrentTab(null));
		tabControl.createSubWindow();
		//test getTabfromView()
		assertEquals(tab0,tabControl.getTabFromView(tab0.getSubWebView()));
		assertEquals(null,tabControl.getTabFromView(null));
		tabControl.pauseCurrentTab();
		tabControl.resumeCurrentTab();
	}
	/**test Cleaning up the data for all tabs.
	 * @throws Exception
	 * */
	@MediumTest
	public void testT002populatePickerData()throws Exception{
		mActivity= launchActivity();
		TabControl tabControl = new TabControl(mActivity);
		Tab  tab0=tabControl.createNewTab(false, "ID-0", "http://www.baidu.com/");
		tabControl.populatePickerData(tab0);
		tabControl.populatePickerData(null);
		assertEquals(1,tabControl.getTabCount());
		Tab tab1=tabControl.createNewTab(false, "ID-1", "http://www.google.com/");
		tabControl.setCurrentTab(tab1);
		tabControl.wipeAllPickerData();
		//check the data of all tabs.
		assertNull(tab0.getUrl());
		assertNull(tab0.getTitle());
		assertNull(tab1.getUrl());
		assertNull(tab1.getTitle());
	}
	/**test Max count of tabs controled.
	 * @throws Exception
	 * */
	@MediumTest
	public void testT003MaxCountOfTabControled()throws Exception{
		mActivity= launchActivity();
		TabControl tabControl = new TabControl(mActivity);
		assertNotNull(tabControl.getThumbnailDir());
		assertNotNull(tabControl.getBrowserActivity());
		Tab tab=null;
		for(int i=1;i<=MAX_TABS;i++){
			tab = tabControl.createNewTab(false, "Tab"+i, null);
			assertNotNull(tab);
			assertTrue(tabControl.setCurrentTab(tab));	
		}
		//the count of tabs controled already is Max,so failed
		tab=tabControl.createNewTab(false, "Tab"+(MAX_TABS+1), null);
		assertNull(tab);
		assertFalse(tabControl.setCurrentTab(tab));
		
		//test the index of the current tab 
		assertEquals(MAX_TABS-1,tabControl.getCurrentIndex());
	}
	/**test setting current tab and creating sub window and dismissing.
	 * @throws Exception
	 * */
	@MediumTest
	public void testT004SetCurrentTabAndSubWindow()throws Exception{
		mActivity = launchActivity();
		TabControl tabControl = new TabControl(mActivity);
		
		//no tab controled.
		assertNull(tabControl.getCurrentSubWindow());
		assertNull(tabControl.getCurrentWebView());
		assertNull(tabControl.getCurrentTopWebView());		
		assertEquals(-1,tabControl.getCurrentIndex());
		
		//create a new tab and add it to TabControl.
		Tab  tab0=tabControl.createNewTab(false, "ID-0", null);
		tabControl.setCurrentTab(tab0);//set tab0 as the current tab.
		
		assertNotNull(tabControl.getCurrentWebView());
		assertNotNull(tabControl.getCurrentTopWebView());
		assertEquals(0,tabControl.getCurrentIndex());
		assertEquals(0,tabControl.getTabIndex(tab0));
		
		//add a new tab "ID-1" and set the tab as the sub window.
		Tab tab1=tabControl.createNewTab(false, "ID-1", null);
		assertEquals(0,tabControl.getCurrentIndex());
		tabControl.setCurrentTab(tab1);//set tab1 as the current tab.
		assertEquals(1,tabControl.getCurrentIndex());
		assertEquals(1,tabControl.getTabIndex(tab1));
		
		//set the current tab as the sub Window. 
		assertNull(tabControl.getCurrentSubWindow());
		tabControl.createSubWindow();
		assertNotNull(tabControl.getCurrentSubWindow());
		//dismiss sub window.
		tabControl.dismissSubWindow(tab1);
		assertNull(tabControl.getCurrentSubWindow());
	}
	/**test setting freed tab as the current tab.
	 * @throws Exception
	*/
	@LargeTest
	public void testT005SetFreedTabASTheCurrentTab()throws Exception{
		mActivity = launchActivity();
		TabControl tabControl = new TabControl(mActivity);
		//controled two tab and set the second tab as the current tab.
		Tab  tab0=tabControl.createNewTab(false, "ID-0", null);
		tabControl.setCurrentTab(tab0);
		Tab tab1 =tabControl.createNewTab(false,"ID-1",null);
		tabControl.setCurrentTab(tab1);
		
		tabControl.freeMemory();//free tab0 so that tab0.mainView is null.
		assertNull(tab0.getWebView());
		tabControl.setCurrentTab(tab0);//After tab0 be setted the current tab,its mainView not null.
		assertNotNull(tab0.getWebView());
	}
	/**test settiing the sub window as the current tab.
	*@throws Exception 
	*/
	@MediumTest
	public void testT006SetSubWindowAsCurrentTab()throws Exception{
		mActivity = launchActivity();
		TabControl tabControl = new TabControl(mActivity);
		Tab tab0 =tabControl.createNewTab(false,"ID-0",null);
		tabControl.setCurrentTab(tab0);
		
		//test setting the current tab  as current tab again.
		assertTrue(tabControl.setCurrentTab(tab0));
	
		//set tab0 the sub window.
		tabControl.createSubWindow();
		assertEquals(tab0,tabControl.getCurrentTab());
		assertNotNull(tabControl.getCurrentTab().getSubWebView());
		
		Tab tab1 =tabControl.createNewTab(false,"ID-1",null);
		tabControl.setCurrentTab(tab1);
		assertEquals(tab1,tabControl.getCurrentTab());
		assertNull(tabControl.getCurrentTab().getSubWebView());//tab1.subWebView is null.
		
		//set the sub window as the current tab.
		assertTrue(tabControl.setCurrentTab(tab0));
		assertEquals(tab0,tabControl.getCurrentTab());
		assertNotNull(tab0.getSubWebView());//because tab0 was setted the sub window, tab0.subWebView not null.
		assertNotNull(tab0.getSubWebViewContainer());//tab0.mSubViewContainer not null
		assertEquals(tab0.getSubWebView(),tab0.getTopWindow());	//the top window of tab0  equals to tab0.mSubView
		assertTrue(tab0.getWebView()!=tab0.getTopWindow());//the top window of tab0 does not equals to tab0.mianView.
	}
	/**test adding child tab ,setting parent tab and remove a tab that has a child tab.
	 * @throws Exception
	 * */
	@LargeTest
	public void testT007AddChildTabAndSetParentTabAndRemoveTab()throws Exception{
		mActivity = launchActivity();
		TabControl tabControl = new TabControl(mActivity);
		Tab tab0 =tabControl.createNewTab(false,"ID-0",null);
		tabControl.setCurrentTab(tab0);
		Tab tab1 =tabControl.createNewTab(false,"ID-1",null);
		tabControl.setCurrentTab(tab1);
		Tab tab2 =tabControl.createNewTab(false,"ID-2",null);
		//tab0.addChildTab(null);
		tab0.addChildTab(tab1);
		tab1.addChildTab(tab2);
		assertEquals(tab1,tabControl.getTabFromId("ID-2").getParentTab());
		assertEquals(3,tabControl.getTabCount());
		assertFalse(tabControl.removeTab(null));
		assertTrue(tabControl.removeTab(tab1));
		assertEquals(2,tabControl.getTabCount());
	}
	/**test clearHistory() and destroy().
	 * @throws Exception
	 * */
	@MediumTest
	public void testT008ClearHistoryAndDestroy()throws Exception{
		mActivity = launchActivity();
		TabControl tabControl = new TabControl(mActivity);
		Tab tab0 =tabControl.createNewTab(false,"ID-0",null);
		tabControl.setCurrentTab(tab0);
		tabControl.createSubWindow();
		tabControl.clearHistory();
		assertEquals(1,tabControl.getTabCount());
		tabControl.destroy();
		assertEquals(0,tabControl.getTabCount());
	}
	/**test freeMomery().
	 * @throws Exception
	 * */
	@MediumTest
	public void testT009FreeMomery()throws Exception{
		mActivity = launchActivity();
		TabControl tabControl = new TabControl(mActivity);
		//count ==1,getLeastUsedTab() return null.
		Tab tab0 =tabControl.createNewTab(false,"ID-0",null);
		tabControl.freeMemory();
		//mTabQueue.size()==0,getLeastUsedTab() will return null.
		Tab tab1 =tabControl.createNewTab(false,"ID-1",null);
		tabControl.freeMemory();
		//the last remaining tab is the current one,getLeastUsedTab() will return null.
		tabControl.setCurrentTab(tab0);//mTabQueue.size()!=0
		tabControl.freeMemory();
		
		//the last remaining tab is not the current one
		assertNotNull(tab0.getWebView());
		tabControl.setCurrentTab(tab1);
		tabControl.freeMemory();//clear tab0.mMainView  and set it null.
		assertNull(tab0.getWebView());
	}
	/**test recreating web view.
	 * @throws Exception
	 * */
	@LargeTest
	public void testT010RecreateWebView()throws Exception{
		mActivity= launchActivity();
		String url="http://www.baidu.com/";
		String newUrl="http://www.google.com/";
		TabControl tabControl = new TabControl(mActivity);
		Tab  tab0=tabControl.createNewTab(false, "ID-0",url );
		//It will failed  to recreate web view with the same url.
		assertFalse(tabControl.recreateWebView(tab0, url));
		//recreate  with an unsame url.
		assertTrue(tabControl.recreateWebView(tab0,newUrl));
		//recreate web view of the current tab. 
		tabControl.setCurrentTab(tab0);
		assertTrue(tabControl.recreateWebView(tab0, url));
		
	}
	/**test saving state and restoring state.
	 * @throws Exception.
	 * */
	@LargeTest
	public void testT011SaveStateAndRestoreState()throws Exception{
		mActivity= launchActivity();
		TabControl tabControl = new TabControl(mActivity);
		Tab  tab0=tabControl.createNewTab(false, "ID-0", "http://news.baidu.com/");
		tabControl.setCurrentTab(tab0);
		Tab  tab1=tabControl.createNewTab(false, "ID-1", "http://www.google.com/");
		tab0.addChildTab(tab1);
		tabControl.setCurrentTab(tab1);
		tabControl.freeMemory();
		//tab0.mainView==null,it means we ran low on memory and we
		//already stored the saved state in mSavedState,so saving state successfully.
		assertNull(tab0.getWebView());
		Bundle b = new Bundle();
		tabControl.saveState(b);
		assertNull(tab0.getWebView());
	}
	/**test restoring state.
	 * @throws Exception
	 * */
	@LargeTest
	public void testT012RestoreState()throws Exception{
		mActivity= launchActivity();
		TabControl tabControl = new TabControl(mActivity);
		Tab  tab0=tabControl.createNewTab(false, "ID-0", "http://news.baidu.com/");
		//the bundle does not contain the bundle(WEB+i).
		Bundle bundleContainOnlyCURRTAB = new Bundle();	
		bundleContainOnlyCURRTAB.putInt(NUMTABS,tabControl.getTabCount());
		bundleContainOnlyCURRTAB.putInt(CURRTAB, 0);
		tabControl.restoreState(bundleContainOnlyCURRTAB);	
		//the bundle contains more information but CURRTAB.
		Bundle bundle = new Bundle();
		bundle.putInt(NUMTABS, tabControl.getTabCount());
		//construct the state.
		Bundle state = new Bundle();
		state.putBoolean(CLOSEONEXIT, false);
		state.putString(APPID, "ID-0");
		state.putString(ORIGINALURL, "http://news.baidu.com/");
		Tab  tab1=tabControl.createNewTab(false, "ID-1", "http://www.google.com/");
		tab1.addChildTab(tab0);
		state.putInt(PARENTTAB, tabControl.getTabIndex(tab1));
		
		bundle.putBundle(WEBVIEW+0, state);
		assertTrue(tabControl.restoreState(bundle));	
		//contain CURRTAB.
		bundle.putInt(CURRTAB, 0);
		assertTrue(tabControl.restoreState(bundle));	
	}
}

