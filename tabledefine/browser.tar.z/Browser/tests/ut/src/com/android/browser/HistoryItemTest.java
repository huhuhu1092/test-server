package com.android.browser;

import com.android.browser.unittests.testutil.Helper;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.test.ActivityUnitTestCase;
import android.test.suitebuilder.annotation.LargeTest;

/**
 * test HistoryItem.java.
 * 
 * @author Tang Ting
 * 
 */
public class HistoryItemTest extends ActivityUnitTestCase<BrowserHistoryPage> {
	private HistoryItem mHistoryItem;
	private BrowserHistoryPage mBrowserHistoryPage;
	private Instrumentation mInst;
	private Context mContext;

	public HistoryItemTest() {
		super(BrowserHistoryPage.class);
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		mInst = getInstrumentation();
		mContext = mInst.getTargetContext();
		mHistoryItem = createHistoryItem(true);
	}

	@Override
	protected void tearDown() throws Exception {
		if (mBrowserHistoryPage != null) {
			mBrowserHistoryPage.finish();
			SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
			mBrowserHistoryPage = null;
		}
		mHistoryItem = null;
		mInst = null;
		mContext = null;
		super.tearDown();
	}

	// method
	// create HistoryItem
	private HistoryItem createHistoryItem(boolean inDeleteView) {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setClassName(mInst.getTargetContext(), BrowserHistoryPage.class
				.getName());
		mBrowserHistoryPage = (BrowserHistoryPage) mInst
				.startActivitySync(intent);
		SystemClock.sleep(Helper.WAIT_FOR_SHORTTIME);
		BrowserHistoryPage.HistoryAdapter adapter = mBrowserHistoryPage.new HistoryAdapter();
		return (new HistoryItem(mContext, adapter, inDeleteView));
	}

	/**
	 * test copyTo()
	 */
	@LargeTest
	public void testcopyTo() {
		mHistoryItem.copyTo(mHistoryItem);
	}

	/**
	 * test setName() with input the name is too long
	 */
	@LargeTest
	public void testSetAndGetName() {
		String titleNameLengthEqulsEighty = "01234567890123456789"
				+ "01234567890123456789" + "01234567890123456789"
				+ "01234567890123456789";
		String titleNameTooLong = titleNameLengthEqulsEighty + "01234";
		mHistoryItem.setName(titleNameTooLong);
		assertEquals(titleNameLengthEqulsEighty, mHistoryItem.getName());
	}

	/**
	 * test setUrl and setUrl
	 */
	@LargeTest
	public void testSetAndGetUrl() {
		String url = "borqs";
		mHistoryItem.setUrl(url);
		assertEquals(url, mHistoryItem.getUrl());
	}

	/**
	 * test setFavicon
	 */
	@LargeTest
	public void testsetFavicon() {
		mHistoryItem.setFavicon(null);
	}

	/**
	 * test setID
	 */
	@LargeTest
	public void testsetID() {
		mHistoryItem.setID(null);
	}

	/**
	 * test setChecked and isChecked
	 */
	@LargeTest
	public void testsetChecked() {
		mHistoryItem.setChecked(true);
		assertTrue(mHistoryItem.isChecked());
	}

	/**
	 * test toggle
	 */
	@LargeTest
	public void testtoggle() {
		mHistoryItem.toggle();
	}

	/**
	 * test setSelectMode
	 */
	@LargeTest
	public void testsetSelectMode() {
		mHistoryItem.setSelectMode(false);
		assertFalse(mHistoryItem.isChecked());
	}
}
